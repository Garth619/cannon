# WordPress MySQL database migration
#
# Generated: Tuesday 11. September 2018 22:23 UTC
# Hostname: localhost
# Database: `cannon`
# URL: //cannon-demo.com
# Path: /Applications/MAMP/htdocs/cannon
# Tables: wp_commentmeta, wp_comments, wp_gf_draft_submissions, wp_gf_entry, wp_gf_entry_meta, wp_gf_entry_notes, wp_gf_form, wp_gf_form_meta, wp_gf_form_view, wp_links, wp_options, wp_postmeta, wp_posts, wp_rg_form, wp_rg_form_meta, wp_rg_form_view, wp_rg_incomplete_submissions, wp_rg_lead, wp_rg_lead_detail, wp_rg_lead_detail_long, wp_rg_lead_meta, wp_rg_lead_notes, wp_term_relationships, wp_term_taxonomy, wp_termmeta, wp_terms, wp_usermeta, wp_users
# Table Prefix: wp_
# Post Types: revision, acf-field, acf-field-group, attachment, nav_menu_item, page, post
# Protocol: http
# Multisite: false
# Subsite Export: false
# --------------------------------------------------------

/*!40101 SET NAMES utf8mb4 */;

SET sql_mode='NO_AUTO_VALUE_ON_ZERO';



#
# Delete any existing table `wp_commentmeta`
#

DROP TABLE IF EXISTS `wp_commentmeta`;


#
# Table structure of table `wp_commentmeta`
#

CREATE TABLE `wp_commentmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`meta_id`),
  KEY `comment_id` (`comment_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_commentmeta`
#

#
# End of data contents of table `wp_commentmeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_comments`
#

DROP TABLE IF EXISTS `wp_comments`;


#
# Table structure of table `wp_comments`
#

CREATE TABLE `wp_comments` (
  `comment_ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_post_ID` bigint(20) unsigned NOT NULL DEFAULT '0',
  `comment_author` tinytext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `comment_author_email` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `comment_karma` int(11) NOT NULL DEFAULT '0',
  `comment_approved` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_type` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`comment_ID`),
  KEY `comment_post_ID` (`comment_post_ID`),
  KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  KEY `comment_date_gmt` (`comment_date_gmt`),
  KEY `comment_parent` (`comment_parent`),
  KEY `comment_author_email` (`comment_author_email`(10))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_comments`
#

#
# End of data contents of table `wp_comments`
# --------------------------------------------------------



#
# Delete any existing table `wp_gf_draft_submissions`
#

DROP TABLE IF EXISTS `wp_gf_draft_submissions`;


#
# Table structure of table `wp_gf_draft_submissions`
#

CREATE TABLE `wp_gf_draft_submissions` (
  `uuid` char(32) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `form_id` mediumint(8) unsigned NOT NULL,
  `date_created` datetime NOT NULL,
  `ip` varchar(39) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `source_url` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `submission` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  PRIMARY KEY (`uuid`),
  KEY `form_id` (`form_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_gf_draft_submissions`
#

#
# End of data contents of table `wp_gf_draft_submissions`
# --------------------------------------------------------



#
# Delete any existing table `wp_gf_entry`
#

DROP TABLE IF EXISTS `wp_gf_entry`;


#
# Table structure of table `wp_gf_entry`
#

CREATE TABLE `wp_gf_entry` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `form_id` mediumint(8) unsigned NOT NULL,
  `post_id` bigint(20) unsigned DEFAULT NULL,
  `date_created` datetime NOT NULL,
  `date_updated` datetime DEFAULT NULL,
  `is_starred` tinyint(1) NOT NULL DEFAULT '0',
  `is_read` tinyint(1) NOT NULL DEFAULT '0',
  `ip` varchar(39) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `source_url` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_agent` varchar(250) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `currency` varchar(5) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `payment_status` varchar(15) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `payment_date` datetime DEFAULT NULL,
  `payment_amount` decimal(19,2) DEFAULT NULL,
  `payment_method` varchar(30) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `transaction_id` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `is_fulfilled` tinyint(1) DEFAULT NULL,
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `transaction_type` tinyint(1) DEFAULT NULL,
  `status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'active',
  PRIMARY KEY (`id`),
  KEY `form_id` (`form_id`),
  KEY `form_id_status` (`form_id`,`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_gf_entry`
#

#
# End of data contents of table `wp_gf_entry`
# --------------------------------------------------------



#
# Delete any existing table `wp_gf_entry_meta`
#

DROP TABLE IF EXISTS `wp_gf_entry_meta`;


#
# Table structure of table `wp_gf_entry_meta`
#

CREATE TABLE `wp_gf_entry_meta` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `form_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `entry_id` bigint(20) unsigned NOT NULL,
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`id`),
  KEY `meta_key` (`meta_key`(191)),
  KEY `entry_id` (`entry_id`),
  KEY `meta_value` (`meta_value`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_gf_entry_meta`
#

#
# End of data contents of table `wp_gf_entry_meta`
# --------------------------------------------------------



#
# Delete any existing table `wp_gf_entry_notes`
#

DROP TABLE IF EXISTS `wp_gf_entry_notes`;


#
# Table structure of table `wp_gf_entry_notes`
#

CREATE TABLE `wp_gf_entry_notes` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `entry_id` int(10) unsigned NOT NULL,
  `user_name` varchar(250) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `user_id` bigint(20) DEFAULT NULL,
  `date_created` datetime NOT NULL,
  `value` longtext COLLATE utf8mb4_unicode_520_ci,
  `note_type` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `sub_type` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `entry_id` (`entry_id`),
  KEY `entry_user_key` (`entry_id`,`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_gf_entry_notes`
#

#
# End of data contents of table `wp_gf_entry_notes`
# --------------------------------------------------------



#
# Delete any existing table `wp_gf_form`
#

DROP TABLE IF EXISTS `wp_gf_form`;


#
# Table structure of table `wp_gf_form`
#

CREATE TABLE `wp_gf_form` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(150) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `date_created` datetime NOT NULL,
  `date_updated` datetime DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `is_trash` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_gf_form`
#
INSERT INTO `wp_gf_form` ( `id`, `title`, `date_created`, `date_updated`, `is_active`, `is_trash`) VALUES
(1, 'Contact', '2018-01-23 02:49:42', NULL, 1, 0),
(2, 'Contact Sidebar', '2018-09-06 20:53:15', NULL, 1, 0) ;

#
# End of data contents of table `wp_gf_form`
# --------------------------------------------------------



#
# Delete any existing table `wp_gf_form_meta`
#

DROP TABLE IF EXISTS `wp_gf_form_meta`;


#
# Table structure of table `wp_gf_form_meta`
#

CREATE TABLE `wp_gf_form_meta` (
  `form_id` mediumint(8) unsigned NOT NULL,
  `display_meta` longtext COLLATE utf8mb4_unicode_520_ci,
  `entries_grid_meta` longtext COLLATE utf8mb4_unicode_520_ci,
  `confirmations` longtext COLLATE utf8mb4_unicode_520_ci,
  `notifications` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`form_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_gf_form_meta`
#
INSERT INTO `wp_gf_form_meta` ( `form_id`, `display_meta`, `entries_grid_meta`, `confirmations`, `notifications`) VALUES
(1, '{"title":"Contact","description":"","labelPlacement":"top_label","descriptionPlacement":"below","button":{"type":"text","text":"Submit","imageUrl":""},"fields":[{"type":"text","id":1,"label":"First Name","adminLabel":"","isRequired":true,"size":"medium","errorMessage":"","visibility":"visible","inputs":null,"formId":1,"description":"","allowsPrepopulate":false,"inputMask":false,"inputMaskValue":"","inputType":"","labelPlacement":"","descriptionPlacement":"","subLabelPlacement":"","placeholder":"First Name","cssClass":"","inputName":"","noDuplicates":false,"defaultValue":"","choices":"","conditionalLogic":"","productField":"","enablePasswordInput":"","maxLength":"","multipleFiles":false,"maxFiles":"","calculationFormula":"","calculationRounding":"","enableCalculation":"","disableQuantity":false,"displayAllCategories":false,"useRichTextEditor":false,"pageNumber":1},{"type":"text","id":2,"label":"Last Name","adminLabel":"","isRequired":true,"size":"medium","errorMessage":"","visibility":"visible","inputs":null,"formId":1,"description":"","allowsPrepopulate":false,"inputMask":false,"inputMaskValue":"","inputType":"","labelPlacement":"","descriptionPlacement":"","subLabelPlacement":"","placeholder":"Last Name","cssClass":"","inputName":"","noDuplicates":false,"defaultValue":"","choices":"","conditionalLogic":"","productField":"","enablePasswordInput":"","maxLength":"","multipleFiles":false,"maxFiles":"","calculationFormula":"","calculationRounding":"","enableCalculation":"","disableQuantity":false,"displayAllCategories":false,"useRichTextEditor":false,"pageNumber":1},{"type":"phone","id":3,"label":"Phone Number","adminLabel":"","isRequired":true,"size":"medium","errorMessage":"","visibility":"visible","inputs":null,"phoneFormat":"standard","formId":1,"description":"","allowsPrepopulate":false,"inputMask":false,"inputMaskValue":"","inputType":"","labelPlacement":"","descriptionPlacement":"","subLabelPlacement":"","placeholder":"Phone Number","cssClass":"","inputName":"","noDuplicates":false,"defaultValue":"","choices":"","conditionalLogic":"","form_id":"","productField":"","multipleFiles":false,"maxFiles":"","calculationFormula":"","calculationRounding":"","enableCalculation":"","disableQuantity":false,"displayAllCategories":false,"useRichTextEditor":false,"pageNumber":1},{"type":"email","id":4,"label":"Email","adminLabel":"","isRequired":true,"size":"medium","errorMessage":"","visibility":"visible","inputs":null,"formId":1,"description":"","allowsPrepopulate":false,"inputMask":false,"inputMaskValue":"","inputType":"","labelPlacement":"","descriptionPlacement":"","subLabelPlacement":"","placeholder":"Email","cssClass":"","inputName":"","noDuplicates":false,"defaultValue":"","choices":"","conditionalLogic":"","productField":"","emailConfirmEnabled":"","multipleFiles":false,"maxFiles":"","calculationFormula":"","calculationRounding":"","enableCalculation":"","disableQuantity":false,"displayAllCategories":false,"useRichTextEditor":false,"pageNumber":1},{"type":"select","id":5,"label":"Type of Case","adminLabel":"","isRequired":true,"size":"medium","errorMessage":"","visibility":"visible","inputs":null,"choices":[{"text":"First Choice","value":"First Choice","isSelected":false,"price":""},{"text":"Second Choice","value":"Second Choice","isSelected":false,"price":""},{"text":"Third Choice","value":"Third Choice","isSelected":false,"price":""}],"formId":1,"description":"","allowsPrepopulate":false,"inputMask":false,"inputMaskValue":"","inputType":"","labelPlacement":"","descriptionPlacement":"","subLabelPlacement":"","placeholder":"Type of Case","cssClass":"","inputName":"","noDuplicates":false,"defaultValue":"","conditionalLogic":"","productField":"","enablePrice":"","multipleFiles":false,"maxFiles":"","calculationFormula":"","calculationRounding":"","enableCalculation":"","disableQuantity":false,"displayAllCategories":false,"useRichTextEditor":false,"pageNumber":1},{"type":"textarea","id":6,"label":"Describe Your Case","adminLabel":"","isRequired":true,"size":"medium","errorMessage":"","visibility":"visible","inputs":null,"formId":1,"description":"","allowsPrepopulate":false,"inputMask":false,"inputMaskValue":"","inputType":"","labelPlacement":"","descriptionPlacement":"","subLabelPlacement":"","placeholder":"Describe Your Case","cssClass":"","inputName":"","noDuplicates":false,"defaultValue":"","choices":"","conditionalLogic":"","productField":"","form_id":"","useRichTextEditor":false,"multipleFiles":false,"maxFiles":"","calculationFormula":"","calculationRounding":"","enableCalculation":"","disableQuantity":false,"displayAllCategories":false,"pageNumber":1}],"version":"2.3.2","id":1,"subLabelPlacement":"below","cssClass":"","enableHoneypot":true,"enableAnimation":false,"save":{"enabled":false,"button":{"type":"link","text":"Save and Continue Later"}},"limitEntries":false,"limitEntriesCount":"","limitEntriesPeriod":"","limitEntriesMessage":"","scheduleForm":false,"scheduleStart":"","scheduleStartHour":"","scheduleStartMinute":"","scheduleStartAmpm":"","scheduleEnd":"","scheduleEndHour":"","scheduleEndMinute":"","scheduleEndAmpm":"","schedulePendingMessage":"","scheduleMessage":"","requireLogin":false,"requireLoginMessage":"","useCurrentUserAsAuthor":true,"postContentTemplateEnabled":false,"postTitleTemplateEnabled":false,"postTitleTemplate":"","postContentTemplate":"","lastPageButton":null,"pagination":null,"firstPageCssClass":null}', NULL, '{"5a66a2c69162e":{"id":"5a66a2c69162e","name":"Default Confirmation","isDefault":true,"type":"page","message":"","url":"","pageId":37,"queryString":"","disableAutoformat":false,"conditionalLogic":[]}}', '{"5a66a2c69111e":{"isActive":true,"id":"5a66a2c69111e","name":"Admin Notification","service":"wordpress","event":"form_submission","to":"joe@1point21interactive.com","toType":"email","bcc":"","subject":"{Name:1} - Case Evaluation inquiry from clientname.com","message":"<div align=\\"center\\"><img src=\\"http:\\/\\/www.ilawyermarketing.com\\/images\\/ilawyerlogo.jpg\\" alt=\\"Website lead from iLawyerMarketing\\" \\/><\\/div>\\r\\n{all_fields}","from":"noreply@ilawyermarketing.org","fromName":"Clientwebsite.com","replyTo":"{Email: 3}","routing":null,"conditionalLogic":null,"disableAutoformat":false}}'),
(2, '{"title":"Contact Sidebar","description":"","labelPlacement":"top_label","descriptionPlacement":"below","button":{"type":"text","text":"Submit","imageUrl":""},"fields":[{"type":"text","id":1,"label":"First Name","adminLabel":"","isRequired":true,"size":"medium","errorMessage":"","visibility":"visible","inputs":null,"formId":2,"description":"","allowsPrepopulate":false,"inputMask":false,"inputMaskValue":"","inputType":"","labelPlacement":"","descriptionPlacement":"","subLabelPlacement":"","placeholder":"First Name","cssClass":"","inputName":"","noDuplicates":false,"defaultValue":"","choices":"","conditionalLogic":"","productField":"","enablePasswordInput":"","maxLength":"","multipleFiles":false,"maxFiles":"","calculationFormula":"","calculationRounding":"","enableCalculation":"","disableQuantity":false,"displayAllCategories":false,"useRichTextEditor":false,"pageNumber":1,"displayOnly":""},{"type":"text","id":2,"label":"Last Name","adminLabel":"","isRequired":true,"size":"medium","errorMessage":"","visibility":"visible","inputs":null,"formId":2,"description":"","allowsPrepopulate":false,"inputMask":false,"inputMaskValue":"","inputType":"","labelPlacement":"","descriptionPlacement":"","subLabelPlacement":"","placeholder":"Last Name","cssClass":"","inputName":"","noDuplicates":false,"defaultValue":"","choices":"","conditionalLogic":"","productField":"","enablePasswordInput":"","maxLength":"","multipleFiles":false,"maxFiles":"","calculationFormula":"","calculationRounding":"","enableCalculation":"","disableQuantity":false,"displayAllCategories":false,"useRichTextEditor":false,"pageNumber":1,"displayOnly":""},{"type":"phone","id":3,"label":"Phone Number","adminLabel":"","isRequired":true,"size":"medium","errorMessage":"","visibility":"visible","inputs":null,"phoneFormat":"standard","formId":2,"description":"","allowsPrepopulate":false,"inputMask":false,"inputMaskValue":"","inputType":"","labelPlacement":"","descriptionPlacement":"","subLabelPlacement":"","placeholder":"Phone Number","cssClass":"","inputName":"","noDuplicates":false,"defaultValue":"","choices":"","conditionalLogic":"","form_id":"","productField":"","multipleFiles":false,"maxFiles":"","calculationFormula":"","calculationRounding":"","enableCalculation":"","disableQuantity":false,"displayAllCategories":false,"useRichTextEditor":false,"pageNumber":1,"displayOnly":""},{"type":"email","id":4,"label":"Email","adminLabel":"","isRequired":true,"size":"medium","errorMessage":"","visibility":"visible","inputs":null,"formId":2,"description":"","allowsPrepopulate":false,"inputMask":false,"inputMaskValue":"","inputType":"","labelPlacement":"","descriptionPlacement":"","subLabelPlacement":"","placeholder":"Email","cssClass":"","inputName":"","noDuplicates":false,"defaultValue":"","choices":"","conditionalLogic":"","productField":"","emailConfirmEnabled":"","multipleFiles":false,"maxFiles":"","calculationFormula":"","calculationRounding":"","enableCalculation":"","disableQuantity":false,"displayAllCategories":false,"useRichTextEditor":false,"pageNumber":1,"displayOnly":""},{"type":"select","id":5,"label":"Type of Case","adminLabel":"","isRequired":true,"size":"medium","errorMessage":"","visibility":"visible","inputs":null,"choices":[{"text":"First Choice","value":"First Choice","isSelected":false,"price":""},{"text":"Second Choice","value":"Second Choice","isSelected":false,"price":""},{"text":"Third Choice","value":"Third Choice","isSelected":false,"price":""}],"formId":2,"description":"","allowsPrepopulate":false,"inputMask":false,"inputMaskValue":"","inputType":"","labelPlacement":"","descriptionPlacement":"","subLabelPlacement":"","placeholder":"Type of Case","cssClass":"","inputName":"","noDuplicates":false,"defaultValue":"","conditionalLogic":"","productField":"","enablePrice":"","multipleFiles":false,"maxFiles":"","calculationFormula":"","calculationRounding":"","enableCalculation":"","disableQuantity":false,"displayAllCategories":false,"useRichTextEditor":false,"pageNumber":1,"displayOnly":""},{"type":"textarea","id":6,"label":"Describe Your Case","adminLabel":"","isRequired":true,"size":"medium","errorMessage":"","visibility":"visible","inputs":null,"formId":2,"description":"","allowsPrepopulate":false,"inputMask":false,"inputMaskValue":"","inputType":"","labelPlacement":"","descriptionPlacement":"","subLabelPlacement":"","placeholder":"Describe Your Case","cssClass":"","inputName":"","noDuplicates":false,"defaultValue":"","choices":"","conditionalLogic":"","productField":"","form_id":"","useRichTextEditor":false,"multipleFiles":false,"maxFiles":"","calculationFormula":"","calculationRounding":"","enableCalculation":"","disableQuantity":false,"displayAllCategories":false,"pageNumber":1,"displayOnly":""}],"version":"2.3.2","id":2,"subLabelPlacement":"below","cssClass":"","enableHoneypot":true,"enableAnimation":false,"save":{"enabled":false,"button":{"type":"link","text":"Save and Continue Later"}},"limitEntries":false,"limitEntriesCount":"","limitEntriesPeriod":"","limitEntriesMessage":"","scheduleForm":false,"scheduleStart":"","scheduleStartHour":"","scheduleStartMinute":"","scheduleStartAmpm":"","scheduleEnd":"","scheduleEndHour":"","scheduleEndMinute":"","scheduleEndAmpm":"","schedulePendingMessage":"","scheduleMessage":"","requireLogin":false,"requireLoginMessage":"","useCurrentUserAsAuthor":true,"postContentTemplateEnabled":false,"postTitleTemplateEnabled":false,"postTitleTemplate":"","postContentTemplate":"","lastPageButton":null,"pagination":null,"firstPageCssClass":null,"notifications":{"5a66a2c69111e":{"isActive":true,"id":"5a66a2c69111e","name":"Admin Notification","service":"wordpress","event":"form_submission","to":"joe@1point21interactive.com","toType":"email","bcc":"","subject":"{Name:1} - Case Evaluation inquiry from clientname.com","message":"<div align=\\"center\\"><img src=\\"http:\\/\\/www.ilawyermarketing.com\\/images\\/ilawyerlogo.jpg\\" alt=\\"Website lead from iLawyerMarketing\\" \\/><\\/div>\\r\\n{all_fields}","from":"noreply@ilawyermarketing.org","fromName":"Clientwebsite.com","replyTo":"{Email: 3}","routing":null,"conditionalLogic":null,"disableAutoformat":false}},"confirmations":{"5a66a2c69162e":{"id":"5a66a2c69162e","name":"Default Confirmation","isDefault":true,"type":"page","message":"","url":"","pageId":37,"queryString":"","disableAutoformat":false,"conditionalLogic":[]}}}', NULL, '{"5a66a2c69162e":{"id":"5a66a2c69162e","name":"Default Confirmation","isDefault":true,"type":"page","message":"","url":"","pageId":37,"queryString":"","disableAutoformat":false,"conditionalLogic":[]}}', '{"5a66a2c69111e":{"isActive":true,"id":"5a66a2c69111e","name":"Admin Notification","service":"wordpress","event":"form_submission","to":"joe@1point21interactive.com","toType":"email","bcc":"","subject":"{Name:1} - Case Evaluation inquiry from clientname.com","message":"<div align=\\"center\\"><img src=\\"http:\\/\\/www.ilawyermarketing.com\\/images\\/ilawyerlogo.jpg\\" alt=\\"Website lead from iLawyerMarketing\\" \\/><\\/div>\\r\\n{all_fields}","from":"noreply@ilawyermarketing.org","fromName":"Clientwebsite.com","replyTo":"{Email: 3}","routing":null,"conditionalLogic":null,"disableAutoformat":false}}') ;

#
# End of data contents of table `wp_gf_form_meta`
# --------------------------------------------------------



#
# Delete any existing table `wp_gf_form_view`
#

DROP TABLE IF EXISTS `wp_gf_form_view`;


#
# Table structure of table `wp_gf_form_view`
#

CREATE TABLE `wp_gf_form_view` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `form_id` mediumint(8) unsigned NOT NULL,
  `date_created` datetime NOT NULL,
  `ip` char(15) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `count` mediumint(8) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `date_created` (`date_created`),
  KEY `form_id` (`form_id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_gf_form_view`
#
INSERT INTO `wp_gf_form_view` ( `id`, `form_id`, `date_created`, `ip`, `count`) VALUES
(1, 1, '2018-09-05 16:11:36', '', 73),
(2, 1, '2018-09-06 17:05:02', '', 104),
(3, 2, '2018-09-06 20:59:26', '', 67),
(4, 1, '2018-09-07 17:08:08', '', 44),
(5, 1, '2018-09-10 14:47:01', '', 203),
(6, 2, '2018-09-10 15:50:54', '', 13),
(7, 1, '2018-09-11 14:56:43', '', 171),
(8, 2, '2018-09-11 16:58:43', '', 7) ;

#
# End of data contents of table `wp_gf_form_view`
# --------------------------------------------------------



#
# Delete any existing table `wp_links`
#

DROP TABLE IF EXISTS `wp_links`;


#
# Table structure of table `wp_links`
#

CREATE TABLE `wp_links` (
  `link_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `link_url` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_name` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_image` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_target` varchar(25) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_description` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_visible` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'Y',
  `link_owner` bigint(20) unsigned NOT NULL DEFAULT '1',
  `link_rating` int(11) NOT NULL DEFAULT '0',
  `link_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `link_rel` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_notes` mediumtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `link_rss` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`link_id`),
  KEY `link_visible` (`link_visible`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_links`
#

#
# End of data contents of table `wp_links`
# --------------------------------------------------------



#
# Delete any existing table `wp_options`
#

DROP TABLE IF EXISTS `wp_options`;


#
# Table structure of table `wp_options`
#

CREATE TABLE `wp_options` (
  `option_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `option_name` varchar(191) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `option_value` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `autoload` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'yes',
  PRIMARY KEY (`option_id`),
  UNIQUE KEY `option_name` (`option_name`)
) ENGINE=InnoDB AUTO_INCREMENT=899 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_options`
#
INSERT INTO `wp_options` ( `option_id`, `option_name`, `option_value`, `autoload`) VALUES
(1, 'siteurl', 'http://cannon-demo.com', 'yes'),
(2, 'home', 'http://cannon-demo.com', 'yes'),
(3, 'blogname', 'Cannon &amp; Dunphy S.C.', 'yes'),
(4, 'blogdescription', '', 'yes'),
(5, 'users_can_register', '0', 'yes'),
(6, 'admin_email', 'joe.t.oconnor@gmail.com', 'yes'),
(7, 'start_of_week', '1', 'yes'),
(8, 'use_balanceTags', '0', 'yes'),
(9, 'use_smilies', '1', 'yes'),
(10, 'require_name_email', '1', 'yes'),
(11, 'comments_notify', '1', 'yes'),
(12, 'posts_per_rss', '10', 'yes'),
(13, 'rss_use_excerpt', '0', 'yes'),
(14, 'mailserver_url', 'mail.example.com', 'yes'),
(15, 'mailserver_login', 'login@example.com', 'yes'),
(16, 'mailserver_pass', 'password', 'yes'),
(17, 'mailserver_port', '110', 'yes'),
(18, 'default_category', '1', 'yes'),
(19, 'default_comment_status', 'open', 'yes'),
(20, 'default_ping_status', 'open', 'yes'),
(21, 'default_pingback_flag', '1', 'yes'),
(22, 'posts_per_page', '10', 'yes'),
(23, 'date_format', 'F j, Y', 'yes'),
(24, 'time_format', 'g:i a', 'yes'),
(25, 'links_updated_date_format', 'F j, Y g:i a', 'yes'),
(26, 'comment_moderation', '0', 'yes'),
(27, 'moderation_notify', '1', 'yes'),
(28, 'permalink_structure', '/%postname%/', 'yes'),
(29, 'rewrite_rules', 'a:88:{s:11:"^wp-json/?$";s:22:"index.php?rest_route=/";s:14:"^wp-json/(.*)?";s:33:"index.php?rest_route=/$matches[1]";s:21:"^index.php/wp-json/?$";s:22:"index.php?rest_route=/";s:24:"^index.php/wp-json/(.*)?";s:33:"index.php?rest_route=/$matches[1]";s:47:"category/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:42:"category/(.+?)/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:23:"category/(.+?)/embed/?$";s:46:"index.php?category_name=$matches[1]&embed=true";s:35:"category/(.+?)/page/?([0-9]{1,})/?$";s:53:"index.php?category_name=$matches[1]&paged=$matches[2]";s:17:"category/(.+?)/?$";s:35:"index.php?category_name=$matches[1]";s:44:"tag/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:39:"tag/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:20:"tag/([^/]+)/embed/?$";s:36:"index.php?tag=$matches[1]&embed=true";s:32:"tag/([^/]+)/page/?([0-9]{1,})/?$";s:43:"index.php?tag=$matches[1]&paged=$matches[2]";s:14:"tag/([^/]+)/?$";s:25:"index.php?tag=$matches[1]";s:45:"type/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:40:"type/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:21:"type/([^/]+)/embed/?$";s:44:"index.php?post_format=$matches[1]&embed=true";s:33:"type/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?post_format=$matches[1]&paged=$matches[2]";s:15:"type/([^/]+)/?$";s:33:"index.php?post_format=$matches[1]";s:12:"robots\\.txt$";s:18:"index.php?robots=1";s:48:".*wp-(atom|rdf|rss|rss2|feed|commentsrss2)\\.php$";s:18:"index.php?feed=old";s:20:".*wp-app\\.php(/.*)?$";s:19:"index.php?error=403";s:18:".*wp-register.php$";s:23:"index.php?register=true";s:32:"feed/(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:27:"(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:8:"embed/?$";s:21:"index.php?&embed=true";s:20:"page/?([0-9]{1,})/?$";s:28:"index.php?&paged=$matches[1]";s:27:"comment-page-([0-9]{1,})/?$";s:39:"index.php?&page_id=10&cpage=$matches[1]";s:41:"comments/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:36:"comments/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:17:"comments/embed/?$";s:21:"index.php?&embed=true";s:44:"search/(.+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:39:"search/(.+)/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:20:"search/(.+)/embed/?$";s:34:"index.php?s=$matches[1]&embed=true";s:32:"search/(.+)/page/?([0-9]{1,})/?$";s:41:"index.php?s=$matches[1]&paged=$matches[2]";s:14:"search/(.+)/?$";s:23:"index.php?s=$matches[1]";s:47:"author/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:42:"author/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:23:"author/([^/]+)/embed/?$";s:44:"index.php?author_name=$matches[1]&embed=true";s:35:"author/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?author_name=$matches[1]&paged=$matches[2]";s:17:"author/([^/]+)/?$";s:33:"index.php?author_name=$matches[1]";s:69:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:64:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:45:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/embed/?$";s:74:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&embed=true";s:57:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:81:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&paged=$matches[4]";s:39:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/?$";s:63:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]";s:56:"([0-9]{4})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:51:"([0-9]{4})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:32:"([0-9]{4})/([0-9]{1,2})/embed/?$";s:58:"index.php?year=$matches[1]&monthnum=$matches[2]&embed=true";s:44:"([0-9]{4})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:65:"index.php?year=$matches[1]&monthnum=$matches[2]&paged=$matches[3]";s:26:"([0-9]{4})/([0-9]{1,2})/?$";s:47:"index.php?year=$matches[1]&monthnum=$matches[2]";s:43:"([0-9]{4})/feed/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:38:"([0-9]{4})/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:19:"([0-9]{4})/embed/?$";s:37:"index.php?year=$matches[1]&embed=true";s:31:"([0-9]{4})/page/?([0-9]{1,})/?$";s:44:"index.php?year=$matches[1]&paged=$matches[2]";s:13:"([0-9]{4})/?$";s:26:"index.php?year=$matches[1]";s:27:".?.+?/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:37:".?.+?/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:57:".?.+?/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:".?.+?/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:".?.+?/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:33:".?.+?/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:16:"(.?.+?)/embed/?$";s:41:"index.php?pagename=$matches[1]&embed=true";s:20:"(.?.+?)/trackback/?$";s:35:"index.php?pagename=$matches[1]&tb=1";s:40:"(.?.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:35:"(.?.+?)/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:28:"(.?.+?)/page/?([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&paged=$matches[2]";s:35:"(.?.+?)/comment-page-([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&cpage=$matches[2]";s:24:"(.?.+?)(?:/([0-9]+))?/?$";s:47:"index.php?pagename=$matches[1]&page=$matches[2]";s:27:"[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:37:"[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:57:"[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:"[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:"[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:33:"[^/]+/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:16:"([^/]+)/embed/?$";s:37:"index.php?name=$matches[1]&embed=true";s:20:"([^/]+)/trackback/?$";s:31:"index.php?name=$matches[1]&tb=1";s:40:"([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?name=$matches[1]&feed=$matches[2]";s:35:"([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?name=$matches[1]&feed=$matches[2]";s:28:"([^/]+)/page/?([0-9]{1,})/?$";s:44:"index.php?name=$matches[1]&paged=$matches[2]";s:35:"([^/]+)/comment-page-([0-9]{1,})/?$";s:44:"index.php?name=$matches[1]&cpage=$matches[2]";s:24:"([^/]+)(?:/([0-9]+))?/?$";s:43:"index.php?name=$matches[1]&page=$matches[2]";s:16:"[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:26:"[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:46:"[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:41:"[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:41:"[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:22:"[^/]+/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";}', 'yes'),
(30, 'hack_file', '0', 'yes'),
(31, 'blog_charset', 'UTF-8', 'yes'),
(32, 'moderation_keys', '', 'no'),
(33, 'active_plugins', 'a:8:{i:0;s:29:"gravityforms/gravityforms.php";i:1;s:41:"acf-theme-code-pro/acf_theme_code_pro.php";i:2;s:57:"advanced-custom-fields-nav-menu-field/fz-acf-nav-menu.php";i:3;s:34:"advanced-custom-fields-pro/acf.php";i:4;s:19:"akismet/akismet.php";i:5;s:19:"mailgun/mailgun.php";i:6;s:38:"post-duplicator/m4c-postduplicator.php";i:7;s:39:"wp-migrate-db-pro/wp-migrate-db-pro.php";}', 'yes'),
(34, 'category_base', '', 'yes'),
(35, 'ping_sites', '', 'yes'),
(36, 'comment_max_links', '2', 'yes'),
(37, 'gmt_offset', '-8', 'yes'),
(38, 'default_email_category', '1', 'yes'),
(39, 'recently_edited', '', 'no'),
(40, 'template', 'cannon-dunphy', 'yes'),
(41, 'stylesheet', 'cannon-dunphy', 'yes'),
(42, 'comment_whitelist', '1', 'yes'),
(43, 'blacklist_keys', '', 'no'),
(44, 'comment_registration', '0', 'yes'),
(45, 'html_type', 'text/html', 'yes'),
(46, 'use_trackback', '0', 'yes'),
(47, 'default_role', 'subscriber', 'yes'),
(48, 'db_version', '38590', 'yes'),
(49, 'uploads_use_yearmonth_folders', '1', 'yes'),
(50, 'upload_path', '', 'yes'),
(51, 'blog_public', '0', 'yes'),
(52, 'default_link_category', '0', 'yes'),
(53, 'show_on_front', 'page', 'yes'),
(54, 'tag_base', '', 'yes'),
(55, 'show_avatars', '1', 'yes'),
(56, 'avatar_rating', 'G', 'yes'),
(57, 'upload_url_path', '', 'yes'),
(58, 'thumbnail_size_w', '150', 'yes'),
(59, 'thumbnail_size_h', '150', 'yes'),
(60, 'thumbnail_crop', '1', 'yes'),
(61, 'medium_size_w', '300', 'yes'),
(62, 'medium_size_h', '300', 'yes'),
(63, 'avatar_default', 'mystery', 'yes'),
(64, 'large_size_w', '1024', 'yes'),
(65, 'large_size_h', '1024', 'yes'),
(66, 'image_default_link_type', 'none', 'yes'),
(67, 'image_default_size', '', 'yes'),
(68, 'image_default_align', '', 'yes'),
(69, 'close_comments_for_old_posts', '0', 'yes'),
(70, 'close_comments_days_old', '14', 'yes'),
(71, 'thread_comments', '1', 'yes'),
(72, 'thread_comments_depth', '5', 'yes'),
(73, 'page_comments', '0', 'yes'),
(74, 'comments_per_page', '50', 'yes'),
(75, 'default_comments_page', 'newest', 'yes'),
(76, 'comment_order', 'asc', 'yes'),
(77, 'sticky_posts', 'a:0:{}', 'yes'),
(78, 'widget_categories', 'a:2:{i:2;a:4:{s:5:"title";s:0:"";s:5:"count";i:0;s:12:"hierarchical";i:0;s:8:"dropdown";i:0;}s:12:"_multiwidget";i:1;}', 'yes'),
(79, 'widget_text', 'a:0:{}', 'yes'),
(80, 'widget_rss', 'a:0:{}', 'yes'),
(81, 'uninstall_plugins', 'a:0:{}', 'no'),
(82, 'timezone_string', '', 'yes'),
(83, 'page_for_posts', '12', 'yes'),
(84, 'page_on_front', '10', 'yes'),
(85, 'default_post_format', '0', 'yes'),
(86, 'link_manager_enabled', '0', 'yes'),
(87, 'finished_splitting_shared_terms', '1', 'yes'),
(88, 'site_icon', '0', 'yes'),
(89, 'medium_large_size_w', '768', 'yes'),
(90, 'medium_large_size_h', '0', 'yes'),
(91, 'initial_db_version', '38590', 'yes'),
(92, 'wp_user_roles', 'a:5:{s:13:"administrator";a:2:{s:4:"name";s:13:"Administrator";s:12:"capabilities";a:61:{s:13:"switch_themes";b:1;s:11:"edit_themes";b:1;s:16:"activate_plugins";b:1;s:12:"edit_plugins";b:1;s:10:"edit_users";b:1;s:10:"edit_files";b:1;s:14:"manage_options";b:1;s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:6:"import";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:8:"level_10";b:1;s:7:"level_9";b:1;s:7:"level_8";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;s:12:"delete_users";b:1;s:12:"create_users";b:1;s:17:"unfiltered_upload";b:1;s:14:"edit_dashboard";b:1;s:14:"update_plugins";b:1;s:14:"delete_plugins";b:1;s:15:"install_plugins";b:1;s:13:"update_themes";b:1;s:14:"install_themes";b:1;s:11:"update_core";b:1;s:10:"list_users";b:1;s:12:"remove_users";b:1;s:13:"promote_users";b:1;s:18:"edit_theme_options";b:1;s:13:"delete_themes";b:1;s:6:"export";b:1;}}s:6:"editor";a:2:{s:4:"name";s:6:"Editor";s:12:"capabilities";a:34:{s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;}}s:6:"author";a:2:{s:4:"name";s:6:"Author";s:12:"capabilities";a:10:{s:12:"upload_files";b:1;s:10:"edit_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:4:"read";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;s:22:"delete_published_posts";b:1;}}s:11:"contributor";a:2:{s:4:"name";s:11:"Contributor";s:12:"capabilities";a:5:{s:10:"edit_posts";b:1;s:4:"read";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;}}s:10:"subscriber";a:2:{s:4:"name";s:10:"Subscriber";s:12:"capabilities";a:2:{s:4:"read";b:1;s:7:"level_0";b:1;}}}', 'yes'),
(93, 'fresh_site', '0', 'yes'),
(94, 'widget_search', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(95, 'widget_recent-posts', 'a:2:{i:2;a:2:{s:5:"title";s:0:"";s:6:"number";i:5;}s:12:"_multiwidget";i:1;}', 'yes'),
(96, 'widget_recent-comments', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(97, 'widget_archives', 'a:2:{i:2;a:3:{s:5:"title";s:0:"";s:5:"count";i:0;s:8:"dropdown";i:0;}s:12:"_multiwidget";i:1;}', 'yes'),
(98, 'widget_meta', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(99, 'sidebars_widgets', 'a:5:{s:19:"wp_inactive_widgets";a:0:{}s:7:"sidebar";a:3:{i:0;s:14:"recent-posts-2";i:1;s:12:"categories-2";i:2;s:10:"archives-2";}s:16:"category_sidebar";a:0:{}s:15:"archive_sidebar";a:0:{}s:13:"array_version";i:3;}', 'yes'),
(100, 'widget_pages', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes') ;
INSERT INTO `wp_options` ( `option_id`, `option_name`, `option_value`, `autoload`) VALUES
(101, 'widget_calendar', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(102, 'widget_media_audio', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(103, 'widget_media_image', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(104, 'widget_media_video', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(105, 'widget_tag_cloud', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(106, 'widget_nav_menu', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(107, 'cron', 'a:7:{i:1536707849;a:1:{s:34:"wp_privacy_delete_old_export_files";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:6:"hourly";s:4:"args";a:0:{}s:8:"interval";i:3600;}}}i:1536710111;a:3:{s:16:"wp_version_check";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:17:"wp_update_plugins";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:16:"wp_update_themes";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1536710124;a:1:{s:19:"wp_scheduled_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1536710136;a:1:{s:25:"delete_expired_transients";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1536710221;a:1:{s:17:"gravityforms_cron";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1536710504;a:1:{s:30:"wp_scheduled_auto_draft_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}s:7:"version";i:2;}', 'yes'),
(115, 'auth_key', 'K=3.iXnFZ [w&.2`S$kAD A@T^>g-U5E8om8tSv65JCiR};p13v!tT{Kb!L0&8eN', 'no'),
(116, 'auth_salt', 't-+MqB8q;PKo6_r6p<_(qQ1zzGNk:X(>U:#rY~JQ,kXdDY!Rj7I>rWbcf$9vR~cs', 'no'),
(117, 'logged_in_key', 'OsQxav}hN|Mn1`^c_|#S44R:Mb#Ya(Ofv%pV%jlt:9^*Jam|@;(,bsQkn)3#^?)R', 'no'),
(118, 'logged_in_salt', '{1W,O]W2qY3@~isBHBq[mW&-Tb>a{IunM~`SaMKB!6;kShfM1zxd8g@X[/L@|z`L', 'no'),
(120, 'nonce_key', '#PDsB]U|n}Vjk:?4TM-,k?V].s[vwflLa25vI-& }Li&]m#>mYczNkb]%ml_HwTU', 'no'),
(121, 'nonce_salt', 'tK^$AahAb0V}x<U?G{4yKZLIq:D3c&T8lHN@5J|IR/T;77M5lC<91}a|TjcpXuuF', 'no'),
(124, 'can_compress_scripts', '0', 'no'),
(139, 'widget_media_gallery', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(140, 'widget_custom_html', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(146, 'recently_activated', 'a:0:{}', 'yes'),
(148, 'mailgun', 'a:12:{s:6:"useAPI";s:1:"1";s:6:"domain";s:20:"ilawyermarketing.org";s:6:"apiKey";s:36:"key-3b836150d2968b324f4b8471feeeb3c1";s:8:"username";s:0:"";s:8:"password";s:0:"";s:6:"secure";s:1:"1";s:12:"track-clicks";s:8:"htmlonly";s:11:"track-opens";s:1:"1";s:12:"from-address";s:28:"noreply@ilawyermarketing.org";s:9:"from-name";s:28:""Client/Site Name" + Website";s:13:"override-from";N;s:11:"campaign-id";s:0:"";}', 'yes'),
(149, 'widget_akismet_widget', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(150, 'widget_gform_widget', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(151, 'widget_list_widget', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(152, 'rg_form_version', '2.3.2', 'yes'),
(155, 'acf_version', '5.6.10', 'yes'),
(156, 'rg_gforms_key', '621e21584ab7936611e0d28422299c97', 'yes'),
(157, 'rg_gforms_disable_css', '1', 'yes'),
(158, 'rg_gforms_enable_html5', '', 'yes'),
(159, 'gform_enable_noconflict', '', 'yes'),
(160, 'rg_gforms_enable_akismet', '1', 'yes'),
(161, 'rg_gforms_captcha_public_key', '', 'yes'),
(162, 'rg_gforms_captcha_private_key', '', 'yes'),
(163, 'rg_gforms_currency', 'USD', 'yes'),
(164, 'rg_gforms_message', '<!--GFM-->', 'yes'),
(166, 'gravityformsaddon_gravityformswebapi_version', '1.0', 'yes'),
(167, 'gf_is_upgrading', '0', 'yes'),
(168, 'gf_previous_db_version', '2.2.5', 'yes'),
(175, 'acf_pro_license', 'YToyOntzOjM6ImtleSI7czo3MjoiYjNKa1pYSmZhV1E5TXpZd01EaDhkSGx3WlQxa1pYWmxiRzl3WlhKOFpHRjBaVDB5TURFMExUQTNMVEk0SURJd09qVXlPak0zIjtzOjM6InVybCI7czoyMToiaHR0cDovL2xvY2FsaG9zdDo4ODg4Ijt9', 'yes'),
(182, 'akismet_strictness', '0', 'yes'),
(183, 'akismet_show_user_comments_approved', '0', 'yes'),
(184, 'wordpress_api_key', '46c90999075a', 'yes'),
(185, 'akismet_spam_count', '2', 'yes'),
(201, 'theme_mods_twentyseventeen', 'a:1:{s:16:"sidebars_widgets";a:2:{s:4:"time";i:1514333141;s:4:"data";a:4:{s:19:"wp_inactive_widgets";a:0:{}s:9:"sidebar-1";a:6:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";}s:9:"sidebar-2";a:0:{}s:9:"sidebar-3";a:0:{}}}}', 'yes'),
(202, 'current_theme', '', 'yes'),
(203, 'theme_mods_joe-blank-theme', 'a:4:{i:0;b:0;s:18:"nav_menu_locations";a:0:{}s:18:"custom_css_post_id";i:-1;s:16:"sidebars_widgets";a:2:{s:4:"time";i:1534890347;s:4:"data";a:2:{s:19:"wp_inactive_widgets";a:0:{}s:12:"blog_sidebar";a:3:{i:0;s:14:"recent-posts-2";i:1;s:12:"categories-2";i:2;s:10:"archives-2";}}}}', 'yes'),
(204, 'theme_switched', '', 'yes'),
(283, 'category_children', 'a:0:{}', 'yes'),
(372, 'WPLANG', '', 'yes'),
(373, 'new_admin_email', 'joe.t.oconnor@gmail.com', 'yes'),
(402, 'gf_upgrade_lock', '', 'yes'),
(403, 'gform_sticky_admin_messages', 'a:0:{}', 'yes'),
(407, 'gf_submissions_block', '', 'yes'),
(408, 'gf_db_version', '2.3.2', 'yes'),
(409, 'gform_version_info', 'a:10:{s:12:"is_valid_key";b:1;s:6:"reason";s:0:"";s:7:"version";s:5:"2.3.3";s:3:"url";s:166:"http://s3.amazonaws.com/gravityforms/releases/gravityforms_2.3.3.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1536850215&Signature=KMvC6Ulbq%2BTcb3UTGLJYe1hi6po%3D";s:15:"expiration_time";i:1538456400;s:9:"offerings";a:46:{s:12:"gravityforms";a:5:{s:12:"is_available";b:1;s:7:"version";s:5:"2.3.3";s:14:"version_latest";s:8:"2.3.3.10";s:3:"url";s:166:"http://s3.amazonaws.com/gravityforms/releases/gravityforms_2.3.3.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1536850215&Signature=KMvC6Ulbq%2BTcb3UTGLJYe1hi6po%3D";s:10:"url_latest";s:167:"http://s3.amazonaws.com/gravityforms/releases/gravityforms_2.3.3.10.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1536850215&Signature=9SkHZWUjp7hn5jA52Dts8X99Ya0%3D";}s:26:"gravityformsactivecampaign";a:5:{s:12:"is_available";b:1;s:7:"version";s:3:"1.4";s:14:"version_latest";s:5:"1.4.5";s:3:"url";s:191:"http://s3.amazonaws.com/gravityforms/addons/activecampaign/gravityformsactivecampaign_1.4.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1536850215&Signature=3VN4N%2BMIdNaB3neWOy6mhR1Ghos%3D";s:10:"url_latest";s:191:"http://s3.amazonaws.com/gravityforms/addons/activecampaign/gravityformsactivecampaign_1.4.5.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1536850215&Signature=X6FTOXyPyzaJ0HEXFTjmN17NJrA%3D";}s:20:"gravityformsagilecrm";a:5:{s:12:"is_available";b:1;s:7:"version";s:3:"1.2";s:14:"version_latest";s:3:"1.2";s:3:"url";s:177:"http://s3.amazonaws.com/gravityforms/addons/agilecrm/gravityformsagilecrm_1.2.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1536850215&Signature=yUMsXHioemrX5lBmn6JSFBm71p8%3D";s:10:"url_latest";s:177:"http://s3.amazonaws.com/gravityforms/addons/agilecrm/gravityformsagilecrm_1.2.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1536850215&Signature=yUMsXHioemrX5lBmn6JSFBm71p8%3D";}s:24:"gravityformsauthorizenet";a:5:{s:12:"is_available";b:1;s:7:"version";s:3:"2.6";s:14:"version_latest";s:3:"2.6";s:3:"url";s:185:"http://s3.amazonaws.com/gravityforms/addons/authorizenet/gravityformsauthorizenet_2.6.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1536850215&Signature=ouailavflSgQjnHY7VAh87Q20oo%3D";s:10:"url_latest";s:185:"http://s3.amazonaws.com/gravityforms/addons/authorizenet/gravityformsauthorizenet_2.6.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1536850215&Signature=ouailavflSgQjnHY7VAh87Q20oo%3D";}s:18:"gravityformsaweber";a:5:{s:12:"is_available";b:1;s:7:"version";s:3:"2.7";s:14:"version_latest";s:5:"2.7.1";s:3:"url";s:175:"http://s3.amazonaws.com/gravityforms/addons/aweber/gravityformsaweber_2.7.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1536850215&Signature=Nm2MNT9bhMI89BhLYT4xB%2BdmFTA%3D";s:10:"url_latest";s:175:"http://s3.amazonaws.com/gravityforms/addons/aweber/gravityformsaweber_2.7.1.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1536850215&Signature=XNPtVtCQBCNjyWfqSV2bzAHmGyU%3D";}s:21:"gravityformsbatchbook";a:5:{s:12:"is_available";b:1;s:7:"version";s:3:"1.3";s:14:"version_latest";s:3:"1.3";s:3:"url";s:183:"http://s3.amazonaws.com/gravityforms/addons/batchbook/gravityformsbatchbook_1.3.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1536850215&Signature=Q%2FtfzNWuAc0zuSdx7uT%2FLIOzP6I%3D";s:10:"url_latest";s:183:"http://s3.amazonaws.com/gravityforms/addons/batchbook/gravityformsbatchbook_1.3.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1536850215&Signature=Q%2FtfzNWuAc0zuSdx7uT%2FLIOzP6I%3D";}s:18:"gravityformsbreeze";a:5:{s:12:"is_available";b:1;s:7:"version";s:3:"1.3";s:14:"version_latest";s:3:"1.3";s:3:"url";s:173:"http://s3.amazonaws.com/gravityforms/addons/breeze/gravityformsbreeze_1.3.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1536850215&Signature=4NzpEzkGpb3HsaYIrezz4Ywq7qo%3D";s:10:"url_latest";s:173:"http://s3.amazonaws.com/gravityforms/addons/breeze/gravityformsbreeze_1.3.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1536850215&Signature=4NzpEzkGpb3HsaYIrezz4Ywq7qo%3D";}s:27:"gravityformscampaignmonitor";a:5:{s:12:"is_available";b:1;s:7:"version";s:3:"3.7";s:14:"version_latest";s:3:"3.7";s:3:"url";s:191:"http://s3.amazonaws.com/gravityforms/addons/campaignmonitor/gravityformscampaignmonitor_3.7.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1536850215&Signature=PwIMjymG8a1zXkUciu0e1vtEork%3D";s:10:"url_latest";s:191:"http://s3.amazonaws.com/gravityforms/addons/campaignmonitor/gravityformscampaignmonitor_3.7.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1536850215&Signature=PwIMjymG8a1zXkUciu0e1vtEork%3D";}s:20:"gravityformscampfire";a:5:{s:12:"is_available";b:1;s:7:"version";s:3:"1.1";s:14:"version_latest";s:5:"1.2.1";s:3:"url";s:177:"http://s3.amazonaws.com/gravityforms/addons/campfire/gravityformscampfire_1.1.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1536850215&Signature=JoeNI8xKkvhTsBLCSVRKWPaDzwo%3D";s:10:"url_latest";s:181:"http://s3.amazonaws.com/gravityforms/addons/campfire/gravityformscampfire_1.2.1.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1536850215&Signature=NL2TIYUJYpjbumAfGhRy%2BTnzVAw%3D";}s:22:"gravityformscapsulecrm";a:5:{s:12:"is_available";b:1;s:7:"version";s:3:"1.3";s:14:"version_latest";s:3:"1.3";s:3:"url";s:183:"http://s3.amazonaws.com/gravityforms/addons/capsulecrm/gravityformscapsulecrm_1.3.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1536850215&Signature=3Sew1bqqtm8m0quuojroObMzV%2Bg%3D";s:10:"url_latest";s:183:"http://s3.amazonaws.com/gravityforms/addons/capsulecrm/gravityformscapsulecrm_1.3.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1536850215&Signature=3Sew1bqqtm8m0quuojroObMzV%2Bg%3D";}s:26:"gravityformschainedselects";a:5:{s:12:"is_available";b:1;s:7:"version";s:3:"1.1";s:14:"version_latest";s:5:"1.1.2";s:3:"url";s:189:"http://s3.amazonaws.com/gravityforms/addons/chainedselects/gravityformschainedselects_1.1.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1536850215&Signature=gNPqFinL2MlxdjK5KixSDrV8OFI%3D";s:10:"url_latest";s:191:"http://s3.amazonaws.com/gravityforms/addons/chainedselects/gravityformschainedselects_1.1.2.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1536850215&Signature=OATILJjGchjHTNENqFAYIQ2cJqo%3D";}s:23:"gravityformscleverreach";a:5:{s:12:"is_available";b:1;s:7:"version";s:3:"1.4";s:14:"version_latest";s:3:"1.4";s:3:"url";s:183:"http://s3.amazonaws.com/gravityforms/addons/cleverreach/gravityformscleverreach_1.4.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1536850215&Signature=GEm9UWqd8ywvjN8f4HQj7GmoUrY%3D";s:10:"url_latest";s:183:"http://s3.amazonaws.com/gravityforms/addons/cleverreach/gravityformscleverreach_1.4.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1536850215&Signature=GEm9UWqd8ywvjN8f4HQj7GmoUrY%3D";}s:19:"gravityformscoupons";a:5:{s:12:"is_available";b:1;s:7:"version";s:3:"2.6";s:14:"version_latest";s:5:"2.6.2";s:3:"url";s:179:"http://s3.amazonaws.com/gravityforms/addons/coupons/gravityformscoupons_2.6.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1536850215&Signature=aK3KDk%2BcoL8UYtPDG8QCZz7%2BzU0%3D";s:10:"url_latest";s:177:"http://s3.amazonaws.com/gravityforms/addons/coupons/gravityformscoupons_2.6.2.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1536850215&Signature=OrXzPWjOI0nqAc3WrCz8FzSEU28%3D";}s:17:"gravityformsdebug";a:5:{s:12:"is_available";b:1;s:7:"version";s:0:"";s:14:"version_latest";s:10:"1.0.beta10";s:3:"url";s:0:"";s:10:"url_latest";s:184:"http://s3.amazonaws.com/gravityforms/addons/debug/gravityformsdebug_1.0.beta10.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1536850215&Signature=BZ%2FpgoNr2obCC4%2FNHI42M01rH%2BU%3D";}s:19:"gravityformsdropbox";a:5:{s:12:"is_available";b:1;s:7:"version";s:3:"2.1";s:14:"version_latest";s:5:"2.1.1";s:3:"url";s:177:"http://s3.amazonaws.com/gravityforms/addons/dropbox/gravityformsdropbox_2.1.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1536850215&Signature=Ld%2B99CVCGGms9b0FHUcfj8jiEGE%3D";s:10:"url_latest";s:181:"http://s3.amazonaws.com/gravityforms/addons/dropbox/gravityformsdropbox_2.1.1.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1536850215&Signature=mw2761UYtK5ekwqGu%2BDuB%2FEbAAM%3D";}s:16:"gravityformsemma";a:5:{s:12:"is_available";b:1;s:7:"version";s:3:"1.2";s:14:"version_latest";s:5:"1.2.5";s:3:"url";s:169:"http://s3.amazonaws.com/gravityforms/addons/emma/gravityformsemma_1.2.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1536850215&Signature=hSkdO4T7Fi1pDtj4gzaxPM6jt1w%3D";s:10:"url_latest";s:173:"http://s3.amazonaws.com/gravityforms/addons/emma/gravityformsemma_1.2.5.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1536850215&Signature=PwGrvNyr9yXYkiRFCHhd%2B2YPYhw%3D";}s:22:"gravityformsfreshbooks";a:5:{s:12:"is_available";b:1;s:7:"version";s:3:"2.5";s:14:"version_latest";s:5:"2.5.2";s:3:"url";s:181:"http://s3.amazonaws.com/gravityforms/addons/freshbooks/gravityformsfreshbooks_2.5.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1536850215&Signature=9nshL0v57dm5gJTKodQkKd80VAM%3D";s:10:"url_latest";s:185:"http://s3.amazonaws.com/gravityforms/addons/freshbooks/gravityformsfreshbooks_2.5.2.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1536850215&Signature=cVO6%2BrrNkhZIkCpx23LK0t1adDk%3D";}s:23:"gravityformsgetresponse";a:5:{s:12:"is_available";b:1;s:7:"version";s:3:"1.2";s:14:"version_latest";s:3:"1.2";s:3:"url";s:183:"http://s3.amazonaws.com/gravityforms/addons/getresponse/gravityformsgetresponse_1.2.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1536850215&Signature=sPvcfHHxMkKjjiYdhOm7EHaojF8%3D";s:10:"url_latest";s:183:"http://s3.amazonaws.com/gravityforms/addons/getresponse/gravityformsgetresponse_1.2.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1536850215&Signature=sPvcfHHxMkKjjiYdhOm7EHaojF8%3D";}s:21:"gravityformsgutenberg";a:5:{s:12:"is_available";b:1;s:7:"version";s:10:"1.0-beta-5";s:14:"version_latest";s:10:"1.0-beta-5";s:3:"url";s:186:"http://s3.amazonaws.com/gravityforms/addons/gutenberg/gravityformsgutenberg_1.0-beta-5.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1536850215&Signature=jbzSGozVAMBzGgYnx7Oeic02xdg%3D";s:10:"url_latest";s:186:"http://s3.amazonaws.com/gravityforms/addons/gutenberg/gravityformsgutenberg_1.0-beta-5.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1536850215&Signature=jbzSGozVAMBzGgYnx7Oeic02xdg%3D";}s:21:"gravityformshelpscout";a:5:{s:12:"is_available";b:1;s:7:"version";s:3:"1.5";s:14:"version_latest";s:3:"1.5";s:3:"url";s:179:"http://s3.amazonaws.com/gravityforms/addons/helpscout/gravityformshelpscout_1.5.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1536850215&Signature=thYrxm9Jc8xDVeFJc9mCkJrFYCA%3D";s:10:"url_latest";s:179:"http://s3.amazonaws.com/gravityforms/addons/helpscout/gravityformshelpscout_1.5.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1536850215&Signature=thYrxm9Jc8xDVeFJc9mCkJrFYCA%3D";}s:20:"gravityformshighrise";a:5:{s:12:"is_available";b:1;s:7:"version";s:3:"1.2";s:14:"version_latest";s:5:"1.2.3";s:3:"url";s:179:"http://s3.amazonaws.com/gravityforms/addons/highrise/gravityformshighrise_1.2.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1536850215&Signature=g%2Bu7EhiCqtYy8QqdpXd9aph06CA%3D";s:10:"url_latest";s:181:"http://s3.amazonaws.com/gravityforms/addons/highrise/gravityformshighrise_1.2.3.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1536850215&Signature=DKM5hqFtd3wa4ttpwm8oP3fqP%2Fc%3D";}s:19:"gravityformshipchat";a:5:{s:12:"is_available";b:1;s:7:"version";s:3:"1.2";s:14:"version_latest";s:3:"1.2";s:3:"url";s:175:"http://s3.amazonaws.com/gravityforms/addons/hipchat/gravityformshipchat_1.2.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1536850215&Signature=yWrDO2xqea7gNYN7VY7yZ0uN9ps%3D";s:10:"url_latest";s:175:"http://s3.amazonaws.com/gravityforms/addons/hipchat/gravityformshipchat_1.2.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1536850215&Signature=yWrDO2xqea7gNYN7VY7yZ0uN9ps%3D";}s:20:"gravityformsicontact";a:5:{s:12:"is_available";b:1;s:7:"version";s:3:"1.3";s:14:"version_latest";s:3:"1.3";s:3:"url";s:177:"http://s3.amazonaws.com/gravityforms/addons/icontact/gravityformsicontact_1.3.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1536850215&Signature=bsMG6BwMpo9mUOG9pCnxVfUQA9U%3D";s:10:"url_latest";s:177:"http://s3.amazonaws.com/gravityforms/addons/icontact/gravityformsicontact_1.3.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1536850215&Signature=bsMG6BwMpo9mUOG9pCnxVfUQA9U%3D";}s:19:"gravityformslogging";a:5:{s:12:"is_available";b:1;s:7:"version";s:3:"1.3";s:14:"version_latest";s:5:"1.3.1";s:3:"url";s:177:"http://s3.amazonaws.com/gravityforms/addons/logging/gravityformslogging_1.3.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1536850215&Signature=xYO3v0YEs0UG9%2BsQBMY95a43rtE%3D";s:10:"url_latest";s:177:"http://s3.amazonaws.com/gravityforms/addons/logging/gravityformslogging_1.3.1.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1536850215&Signature=P2LF79rJ1J2ykwx0cG0oeBLolF4%3D";}s:19:"gravityformsmadmimi";a:5:{s:12:"is_available";b:1;s:7:"version";s:3:"1.2";s:14:"version_latest";s:3:"1.2";s:3:"url";s:181:"http://s3.amazonaws.com/gravityforms/addons/madmimi/gravityformsmadmimi_1.2.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1536850215&Signature=vLNWhHfRE3K14v%2BYJbc%2Br%2FqebRw%3D";s:10:"url_latest";s:181:"http://s3.amazonaws.com/gravityforms/addons/madmimi/gravityformsmadmimi_1.2.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1536850215&Signature=vLNWhHfRE3K14v%2BYJbc%2Br%2FqebRw%3D";}s:21:"gravityformsmailchimp";a:5:{s:12:"is_available";b:1;s:7:"version";s:3:"4.3";s:14:"version_latest";s:3:"4.3";s:3:"url";s:181:"http://s3.amazonaws.com/gravityforms/addons/mailchimp/gravityformsmailchimp_4.3.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1536850215&Signature=35vRG4S%2FLPdzrD1ItTcph9OpEpQ%3D";s:10:"url_latest";s:181:"http://s3.amazonaws.com/gravityforms/addons/mailchimp/gravityformsmailchimp_4.3.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1536850215&Signature=35vRG4S%2FLPdzrD1ItTcph9OpEpQ%3D";}s:26:"gravityformspartialentries";a:5:{s:12:"is_available";b:1;s:7:"version";s:3:"1.2";s:14:"version_latest";s:5:"1.2.1";s:3:"url";s:191:"http://s3.amazonaws.com/gravityforms/addons/partialentries/gravityformspartialentries_1.2.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1536850215&Signature=DHx3QIBjATGKo5FWHiXeBFtLD%2Fg%3D";s:10:"url_latest";s:195:"http://s3.amazonaws.com/gravityforms/addons/partialentries/gravityformspartialentries_1.2.1.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1536850215&Signature=lCdCu%2BkHttdCpKQAC8NaZOm%2FrCw%3D";}s:18:"gravityformspaypal";a:5:{s:12:"is_available";b:1;s:7:"version";s:3:"3.1";s:14:"version_latest";s:5:"3.1.1";s:3:"url";s:175:"http://s3.amazonaws.com/gravityforms/addons/paypal/gravityformspaypal_3.1.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1536850215&Signature=tfQhfbfG%2F17vlzSgPyWyLQ2A27U%3D";s:10:"url_latest";s:177:"http://s3.amazonaws.com/gravityforms/addons/paypal/gravityformspaypal_3.1.1.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1536850215&Signature=4h8TQXBrgy0pX%2BDBpAcgTm0SAp4%3D";}s:33:"gravityformspaypalexpresscheckout";a:3:{s:12:"is_available";b:0;s:7:"version";s:0:"";s:14:"version_latest";N;}s:29:"gravityformspaypalpaymentspro";a:5:{s:12:"is_available";b:1;s:7:"version";s:3:"2.3";s:14:"version_latest";s:5:"2.3.2";s:3:"url";s:197:"http://s3.amazonaws.com/gravityforms/addons/paypalpaymentspro/gravityformspaypalpaymentspro_2.3.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1536850215&Signature=hHDytddv31Tt0knMQuNj1%2BtWcfM%3D";s:10:"url_latest";s:197:"http://s3.amazonaws.com/gravityforms/addons/paypalpaymentspro/gravityformspaypalpaymentspro_2.3.2.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1536850215&Signature=GCLDFhV8imtm5PkboH9AooAQM8E%3D";}s:21:"gravityformspaypalpro";a:5:{s:12:"is_available";b:1;s:7:"version";s:5:"1.8.1";s:14:"version_latest";s:5:"1.8.1";s:3:"url";s:183:"http://s3.amazonaws.com/gravityforms/addons/paypalpro/gravityformspaypalpro_1.8.1.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1536850215&Signature=SbT8INP9FdyorxjE08z%2BOjtOGuA%3D";s:10:"url_latest";s:183:"http://s3.amazonaws.com/gravityforms/addons/paypalpro/gravityformspaypalpro_1.8.1.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1536850215&Signature=SbT8INP9FdyorxjE08z%2BOjtOGuA%3D";}s:20:"gravityformspicatcha";a:3:{s:12:"is_available";b:0;s:7:"version";s:3:"2.0";s:14:"version_latest";s:3:"2.0";}s:16:"gravityformspipe";a:5:{s:12:"is_available";b:1;s:7:"version";s:3:"1.1";s:14:"version_latest";s:3:"1.1";s:3:"url";s:171:"http://s3.amazonaws.com/gravityforms/addons/pipe/gravityformspipe_1.1.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1536850215&Signature=4UZnfkR2UFb5yqHC94D%2BrjNZFJ0%3D";s:10:"url_latest";s:171:"http://s3.amazonaws.com/gravityforms/addons/pipe/gravityformspipe_1.1.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1536850215&Signature=4UZnfkR2UFb5yqHC94D%2BrjNZFJ0%3D";}s:17:"gravityformspolls";a:5:{s:12:"is_available";b:1;s:7:"version";s:3:"3.1";s:14:"version_latest";s:5:"3.1.4";s:3:"url";s:173:"http://s3.amazonaws.com/gravityforms/addons/polls/gravityformspolls_3.1.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1536850215&Signature=s0qf2jB5Z%2F70m6bacElum7Q6NmM%3D";s:10:"url_latest";s:175:"http://s3.amazonaws.com/gravityforms/addons/polls/gravityformspolls_3.1.4.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1536850215&Signature=Xt0bjRHeE7AOc0qXyO%2BMQdU9CkQ%3D";}s:16:"gravityformsquiz";a:5:{s:12:"is_available";b:1;s:7:"version";s:3:"3.1";s:14:"version_latest";s:5:"3.1.8";s:3:"url";s:171:"http://s3.amazonaws.com/gravityforms/addons/quiz/gravityformsquiz_3.1.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1536850215&Signature=yxriPczSB8L%2FThlMPQ0zDgFAEbs%3D";s:10:"url_latest";s:171:"http://s3.amazonaws.com/gravityforms/addons/quiz/gravityformsquiz_3.1.8.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1536850215&Signature=iuoXyGGZ1zjJk95l3ouGTJAuhPs%3D";}s:19:"gravityformsrestapi";a:5:{s:12:"is_available";b:1;s:7:"version";s:10:"2.0-beta-2";s:14:"version_latest";s:10:"2.0-beta-2";s:3:"url";s:184:"http://s3.amazonaws.com/gravityforms/addons/restapi/gravityformsrestapi_2.0-beta-2.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1536850215&Signature=ZueSwEj9XHkofXX%2BzgY7EgCkfiU%3D";s:10:"url_latest";s:184:"http://s3.amazonaws.com/gravityforms/addons/restapi/gravityformsrestapi_2.0-beta-2.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1536850215&Signature=ZueSwEj9XHkofXX%2BzgY7EgCkfiU%3D";}s:21:"gravityformssignature";a:5:{s:12:"is_available";b:1;s:7:"version";s:5:"3.5.1";s:14:"version_latest";s:5:"3.5.2";s:3:"url";s:185:"http://s3.amazonaws.com/gravityforms/addons/signature/gravityformssignature_3.5.1.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1536850215&Signature=%2B%2FWyW4KZCo2m3xHzYqFDjOpc0dE%3D";s:10:"url_latest";s:183:"http://s3.amazonaws.com/gravityforms/addons/signature/gravityformssignature_3.5.2.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1536850215&Signature=jvaFyS6PJOpQR%2FyQbCLmkdcD998%3D";}s:17:"gravityformsslack";a:5:{s:12:"is_available";b:1;s:7:"version";s:3:"1.8";s:14:"version_latest";s:3:"1.8";s:3:"url";s:175:"http://s3.amazonaws.com/gravityforms/addons/slack/gravityformsslack_1.8.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1536850215&Signature=P%2B1dh8DapQ3R0fv8JbS%2BPFtnpEo%3D";s:10:"url_latest";s:175:"http://s3.amazonaws.com/gravityforms/addons/slack/gravityformsslack_1.8.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1536850215&Signature=P%2B1dh8DapQ3R0fv8JbS%2BPFtnpEo%3D";}s:18:"gravityformsstripe";a:5:{s:12:"is_available";b:1;s:7:"version";s:3:"2.5";s:14:"version_latest";s:5:"2.5.4";s:3:"url";s:173:"http://s3.amazonaws.com/gravityforms/addons/stripe/gravityformsstripe_2.5.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1536850215&Signature=ffluZ7kjOPf4Iu0YuQE7FcUv3AQ%3D";s:10:"url_latest";s:177:"http://s3.amazonaws.com/gravityforms/addons/stripe/gravityformsstripe_2.5.4.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1536850215&Signature=qrFs9q%2Fg2XPsLKondLs2a3nMYTE%3D";}s:18:"gravityformssurvey";a:5:{s:12:"is_available";b:1;s:7:"version";s:3:"3.2";s:14:"version_latest";s:5:"3.2.2";s:3:"url";s:175:"http://s3.amazonaws.com/gravityforms/addons/survey/gravityformssurvey_3.2.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1536850215&Signature=abTTiLCj1HK340rK7ZeCxzn%2B30g%3D";s:10:"url_latest";s:175:"http://s3.amazonaws.com/gravityforms/addons/survey/gravityformssurvey_3.2.2.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1536850215&Signature=igiSicV1q4fazsBHXpkD5KeZtEc%3D";}s:18:"gravityformstrello";a:5:{s:12:"is_available";b:1;s:7:"version";s:3:"1.2";s:14:"version_latest";s:5:"1.2.2";s:3:"url";s:173:"http://s3.amazonaws.com/gravityforms/addons/trello/gravityformstrello_1.2.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1536850215&Signature=38KfxRQLcHlhWP0lDXuX5WL7qLI%3D";s:10:"url_latest";s:177:"http://s3.amazonaws.com/gravityforms/addons/trello/gravityformstrello_1.2.2.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1536850215&Signature=XjsUP%2FoAQgICIiQPRwmgocNoQbo%3D";}s:18:"gravityformstwilio";a:5:{s:12:"is_available";b:1;s:7:"version";s:3:"2.5";s:14:"version_latest";s:5:"2.5.1";s:3:"url";s:173:"http://s3.amazonaws.com/gravityforms/addons/twilio/gravityformstwilio_2.5.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1536850215&Signature=5JdCREAy8Fc7NIBMlIlPNHgWoV0%3D";s:10:"url_latest";s:179:"http://s3.amazonaws.com/gravityforms/addons/twilio/gravityformstwilio_2.5.1.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1536850215&Signature=7K7inobvFFccw%2FiGwM0jjO5a%2Bog%3D";}s:28:"gravityformsuserregistration";a:5:{s:12:"is_available";b:1;s:7:"version";s:3:"3.9";s:14:"version_latest";s:5:"3.9.5";s:3:"url";s:195:"http://s3.amazonaws.com/gravityforms/addons/userregistration/gravityformsuserregistration_3.9.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1536850215&Signature=9Fw%2FizF1jlU7VSabTxJfo8omMBQ%3D";s:10:"url_latest";s:197:"http://s3.amazonaws.com/gravityforms/addons/userregistration/gravityformsuserregistration_3.9.5.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1536850215&Signature=ScaGhhgQq0%2FGwVdrc3nJ7GYFYuU%3D";}s:20:"gravityformswebhooks";a:5:{s:12:"is_available";b:1;s:7:"version";s:3:"1.1";s:14:"version_latest";s:5:"1.1.5";s:3:"url";s:177:"http://s3.amazonaws.com/gravityforms/addons/webhooks/gravityformswebhooks_1.1.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1536850215&Signature=7iIaxrE6ZtKB0GJBnhsY8rvTLAc%3D";s:10:"url_latest";s:179:"http://s3.amazonaws.com/gravityforms/addons/webhooks/gravityformswebhooks_1.1.5.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1536850215&Signature=d3OA1ypBSI0gJoU0imKP4PDjDzQ%3D";}s:18:"gravityformszapier";a:5:{s:12:"is_available";b:1;s:7:"version";s:3:"3.0";s:14:"version_latest";s:5:"3.0.1";s:3:"url";s:175:"http://s3.amazonaws.com/gravityforms/addons/zapier/gravityformszapier_3.0.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1536850215&Signature=Qav569oz1Ycwjwef70gi1n%2BzvgM%3D";s:10:"url_latest";s:177:"http://s3.amazonaws.com/gravityforms/addons/zapier/gravityformszapier_3.0.1.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1536850215&Signature=xpYfzVmygVwlOXF2It%2FiKqCLH6c%3D";}s:19:"gravityformszohocrm";a:5:{s:12:"is_available";b:1;s:7:"version";s:3:"1.5";s:14:"version_latest";s:3:"1.5";s:3:"url";s:177:"http://s3.amazonaws.com/gravityforms/addons/zohocrm/gravityformszohocrm_1.5.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1536850215&Signature=JFQdT3LAJn%2FMtWtLWdqrdnhqc8g%3D";s:10:"url_latest";s:177:"http://s3.amazonaws.com/gravityforms/addons/zohocrm/gravityformszohocrm_1.5.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1536850215&Signature=JFQdT3LAJn%2FMtWtLWdqrdnhqc8g%3D";}}s:9:"is_active";s:1:"1";s:14:"version_latest";s:8:"2.3.3.10";s:10:"url_latest";s:167:"http://s3.amazonaws.com/gravityforms/releases/gravityforms_2.3.3.10.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1536850215&Signature=9SkHZWUjp7hn5jA52Dts8X99Ya0%3D";s:9:"timestamp";i:1536677415;}', 'yes'),
(412, 'akismet_comment_form_privacy_notice', 'hide', 'yes'),
(445, 'theme_mods_starter-theme-master', 'a:4:{i:0;b:0;s:18:"nav_menu_locations";a:0:{}s:18:"custom_css_post_id";i:-1;s:16:"sidebars_widgets";a:2:{s:4:"time";i:1534891316;s:4:"data";a:4:{s:19:"wp_inactive_widgets";a:0:{}s:7:"sidebar";a:3:{i:0;s:14:"recent-posts-2";i:1;s:12:"categories-2";i:2;s:10:"archives-2";}s:16:"category_sidebar";a:0:{}s:15:"archive_sidebar";a:0:{}}}}', 'yes'),
(449, 'theme_mods_cannon-dunphy', 'a:3:{i:0;b:0;s:18:"nav_menu_locations";a:2:{s:9:"main_menu";i:2;s:7:"pa_menu";i:3;}s:18:"custom_css_post_id";i:-1;}', 'yes'),
(460, 'nav_menu_options', 'a:2:{i:0;b:0;s:8:"auto_add";a:0:{}}', 'yes'),
(496, 'wpmdb_usage', 'a:2:{s:6:"action";s:8:"savefile";s:4:"time";i:1536704628;}', 'no'),
(684, 'hookturn_acftcp_license_key', 'e7571ba1ffc7949980302747424143a1', 'yes'),
(884, '63a7ef4ac01620f4c0bfd0435ea66b0e', 'a:2:{s:7:"timeout";i:1536685923;s:5:"value";s:7440:"{"new_version":"2.3.0","stable_version":"2.3.0","name":"ACF Theme Code Pro","slug":"acf_theme_code_pro","url":"https:\\/\\/hookturn.io\\/downloads\\/acf-theme-code-pro\\/?changelog=1","last_updated":"2018-02-12 17:47:26","homepage":"https:\\/\\/hookturn.io\\/downloads\\/acf-theme-code-pro\\/","package":"https:\\/\\/hookturn.io\\/edd-sl\\/package_download\\/MTUzNjgyNjMyMjplNzU3MWJhMWZmYzc5NDk5ODAzMDI3NDc0MjQxNDNhMToxNToxMGE2MmIyOTg4ODgyZGI0MjUwNDBiYjIzZDgyYmM1MDpodHRwQC8vY2Fubm9uLWRlbW8uY29tOjA=","download_link":"https:\\/\\/hookturn.io\\/edd-sl\\/package_download\\/MTUzNjgyNjMyMjplNzU3MWJhMWZmYzc5NDk5ODAzMDI3NDc0MjQxNDNhMToxNToxMGE2MmIyOTg4ODgyZGI0MjUwNDBiYjIzZDgyYmM1MDpodHRwQC8vY2Fubm9uLWRlbW8uY29tOjA=","sections":{"description":"<p>Save time &amp; automatically generate the code required to implement Advanced Custom Fields in your themes!<br \\/>\\nACF Theme Code Pro is a premium add-on\\u00a0for the awesome\\u00a0<a href=\\"https:\\/\\/www.advancedcustomfields.com\\/pro\\/\\" target=\\"_blank\\" rel=\\"nofollow noopener noreferrer\\">Advanced Custom Fields Pro<\\/a>\\u00a0WordPress plugin.<\\/p>\\n<p>[ecquote]<\\/p>\\n<p>Whenever you publish, edit or update an ACF Field Group, the code required to implement your unique custom fields is conveniently displayed in a <strong>Theme Code<\\/strong> section right below the Field Group settings.<\\/p>\\n<p>Features<\\/p>\\n<ul>\\n<li>Clipboard icons to easily copy code blocks into your theme<\\/li>\\n<li>Field names and variables are automatically updated<\\/li>\\n<li>Code generated is based on the official ACF documentation<\\/li>\\n<li>Great for offline ACF documentation<\\/li>\\n<\\/ul>\\n<p>ACF Theme Code Pro generates code for the premium ACF fields:<\\/p>\\n<ul class=\\"two-up\\">\\n<li>Flexible content field<\\/li>\\n<li>Repeater field<\\/li>\\n<li>Gallery field<\\/li>\\n<li>Clone field<\\/li>\\n<li>Group field<\\/li>\\n<li>Link field<\\/li>\\n<li>Range field<\\/li>\\n<li>Button field<\\/li>\\n<\\/ul>\\n<p>ACF Theme Code Pro generates code for these 3rd Party fields:<\\/p>\\n<ul class=\\"two-up\\">\\n<li>Font Awesome field<\\/li>\\n<li>Google font selector field<\\/li>\\n<li>Image crop field<\\/li>\\n<li>Markdown field<\\/li>\\n<li>Nav Menu field<\\/li>\\n<li>RGBA Colour field<\\/li>\\n<li>Sidebar Selector field<\\/li>\\n<li>Smart Button field<\\/li>\\n<li>Table field<\\/li>\\n<li>TablePress field<\\/li>\\n<li>Address Field<\\/li>\\n<li>Number Slider Field<\\/li>\\n<li>Post Type Select Field<\\/li>\\n<li>Code Field<\\/li>\\n<li>Link Field<\\/li>\\n<li>Link Picker Field<\\/li>\\n<li>YouTube Picker Field<\\/li>\\n<li>Range Field<\\/li>\\n<li>Focal Point Field<\\/li>\\n<\\/ul>\\n<p>ACF Theme Code Pro generates the code for all standard ACF fields:<\\/p>\\n<ul class=\\"two-up\\">\\n<li>Text<\\/li>\\n<li>Text Area<\\/li>\\n<li>Number<\\/li>\\n<li>Email<\\/li>\\n<li>Password<\\/li>\\n<li>WYSIWYG<\\/li>\\n<li>File<\\/li>\\n<li>Image<\\/li>\\n<li>Select<\\/li>\\n<li>Checkbox<\\/li>\\n<li>Radio<\\/li>\\n<li>True \\/ False<\\/li>\\n<li>User<\\/li>\\n<li>Google Map<\\/li>\\n<li>Date Picker<\\/li>\\n<li>Date Time Picker<\\/li>\\n<li>Time Picker<\\/li>\\n<li>Color Picker<\\/li>\\n<li>Page Link<\\/li>\\n<li>Post Object<\\/li>\\n<li>Relationship<\\/li>\\n<li>Taxonomy<\\/li>\\n<li>oEmbed<\\/li>\\n<\\/ul>\\n<p>New in Version 2 : Location Rule Support<\\/p>\\n<p>ACF Theme Code Pro can generate code for multiple location rules on each field group, you\\u2019re using ACF Pro this includes locations\\u00a0like <strong>Options<\\/strong>, <strong>Users<\\/strong>, <strong>Widgets<\\/strong>, <strong>Comments<\\/strong>, <strong>Terms<\\/strong> and <strong>Attachments.<\\/strong><br \\/>\\nWorks best with:<\\/p>\\n<ul>\\n<li>Advanced Custom Fields\\u00a0Pro v5.6.8 or higher<\\/li>\\n<li>Advanced Custom Fields (Free) v4.4 or v5.0<\\/li>\\n<li>WordPress 4.9.4 or higher<\\/li>\\n<\\/ul>\\n<p>Current Pro Version<\\/p>\\n<ul>\\n<li>Version 2.3.0\\u00a0released in February 2018<\\/li>\\n<\\/ul>\\n<p>If you\'d like to \'try before you buy\' you can\\u00a0<a href=\\"https:\\/\\/wordpress.org\\/plugins\\/acf-theme-code\\/\\" target=\\"_blank\\" rel=\\"noopener noreferrer\\">check out our free version<\\/a> on WordPress.org. Our free version has basic support for the free version of Advanced Custom Fields.<br \\/>\\nThe ACF Theme Code Plugin was created by:<br \\/>\\nAaron &amp; Ben, two WordPress developers based in Melbourne, Australia.<\\/p>\\n<p>[plugin_authors_block]<\\/p>\\n","changelog":"<p>2.3.0<\\/p>\\n<ul>\\n<li>New Field Supported: ACF Ninja Forms add on<\\/li>\\n<li>New Field Supported: ACF Gravity Forms add on<\\/li>\\n<li>New Field Supported: ACF RGBA Colour picker<\\/li>\\n<li>New Field(s) Supported: ACF qTranslate<\\/li>\\n<li>Core: Resolved EDD Conflicts<\\/li>\\n<li>Core: Improved Widget Location Variables<\\/li>\\n<li>Fix: EDD naming conflict<\\/li>\\n<li>Fix: Location error if visual editor is disabled<\\/li>\\n<li>Fix: Select Conflict with Seamless Field Group Option<\\/li>\\n<\\/ul>\\n<p>2.2.0<\\/p>\\n<ul>\\n<li>New Field Supported: Button Field found in ACF Pro v5.6.3<\\/li>\\n<li>New Field Supported: Range Field found in ACF Pro v5.6.2<\\/li>\\n<li>Core: Copy All Feature Added<\\/li>\\n<\\/ul>\\n<p>2.1.0<\\/p>\\n<ul>\\n<li>New Field Supported: Group Field found in ACF Pro v5.6<\\/li>\\n<li>New Field Supported: Link Field found in ACF Pro v5.6<\\/li>\\n<li>New Field Supported: Range Field (Third Party)<\\/li>\\n<li>New Field Supported: Focal Point Field (Third Party)<\\/li>\\n<li>Field: Code field improved to escape output by default<\\/li>\\n<li>Field: Google Map field improved to return lat, lng &amp;\\u00a0address<\\/li>\\n<li>Core: resolved an issue with legacy PHP versions<\\/li>\\n<li>Fix: Bug in File field PHP when returned as a URL<\\/li>\\n<\\/ul>\\n<p>2.0.0<\\/p>\\n<ul>\\n<li>Core : Theme Code Pro now generates code based on your location rules!<\\/li>\\n<li>Core : Theme Code Pro now supports all official ACF Add ons!<\\/li>\\n<li>Core : Theme Code Pro now works when ACF Pro is included in a theme!<\\/li>\\n<li>Location Supported : Options Page<\\/li>\\n<li>Location Supported : Widget<\\/li>\\n<li>Location Supported : Comment<\\/li>\\n<li>Location Supported : Taxonomy Term<\\/li>\\n<li>Location Supported : User<\\/li>\\n<li>Location Supported : Attachment<\\/li>\\n<li>Add-on supported : Options Page<\\/li>\\n<li>Add on supported : Repeater Field<\\/li>\\n<li>Add on supported : Gallery Field<\\/li>\\n<li>Add on supported : Flexible Content Field<\\/li>\\n<li>Fix : Minor bug in file field example link markup<\\/li>\\n<li>Fix : Support for Quicklinks feature within locations<\\/li>\\n<\\/ul>\\n<p>1.2.0<\\/p>\\n<ul>\\n<li>Field : Clone - major improvements to the clone field code output<\\/li>\\n<li>New Field Supported : Address Field<\\/li>\\n<li>New Field Supported : Number Slider Field<\\/li>\\n<li>New Field Supported : Post Type Select Field<\\/li>\\n<li>New Field Supported : Code Field<\\/li>\\n<li>New Field Supported : Link Field<\\/li>\\n<li>New Field Supported : Link Picker Field<\\/li>\\n<li>New Field Supported : YouTube Picker Field<\\/li>\\n<li>Core : Special characters now removed from variable names<\\/li>\\n<li>Fix : Compatibility with CPTUI Pro Plugin<\\/li>\\n<\\/ul>\\n<p>1.1.0<\\/p>\\n<ul>\\n<li>Core: Quicklinks feature with anchor links to the relevant theme code block<\\/li>\\n<li>Core: Notice updates &amp; various bug fixes<\\/li>\\n<li>Core: Plugin options screen moved under Settings<\\/li>\\n<\\/ul>\\n<p>1.0.3<\\/p>\\n<ul>\\n<li>Fix: Use the_sub_field method for nested File fields with return format URL<\\/li>\\n<\\/ul>\\n<p>1.0.2<\\/p>\\n<ul>\\n<li>Field: Fix for Post Object when using ACF 4<\\/li>\\n<li>Core: Various internal code improvements<\\/li>\\n<\\/ul>\\n"},"banners":{"high":"","low":""}}";}', 'yes'),
(891, 'mtphr_post_duplicator_settings', '', 'yes') ;

#
# End of data contents of table `wp_options`
# --------------------------------------------------------



#
# Delete any existing table `wp_postmeta`
#

DROP TABLE IF EXISTS `wp_postmeta`;


#
# Table structure of table `wp_postmeta`
#

CREATE TABLE `wp_postmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`meta_id`),
  KEY `post_id` (`post_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=1853 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_postmeta`
#
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(2, 4, '_edit_last', '1'),
(3, 4, '_edit_lock', '1536677819:1'),
(7, 10, '_edit_last', '1'),
(8, 10, '_edit_lock', '1536340822:1'),
(9, 12, '_edit_last', '1'),
(10, 12, '_edit_lock', '1514332978:1'),
(11, 10, '_wp_page_template', 'template-home.php'),
(16, 15, '_edit_last', '1'),
(19, 15, '_edit_lock', '1514333171:1'),
(20, 17, '_edit_last', '1'),
(23, 17, '_edit_lock', '1514333184:1'),
(24, 19, '_edit_last', '1'),
(25, 19, '_edit_lock', '1514333195:1'),
(28, 21, '_edit_last', '1'),
(29, 21, '_edit_lock', '1514333206:1'),
(32, 23, '_edit_last', '1'),
(33, 23, '_edit_lock', '1514333226:1'),
(36, 37, '_edit_last', '1'),
(37, 37, '_edit_lock', '1516675376:1'),
(38, 37, '_wp_page_template', 'default'),
(39, 39, '_edit_last', '1'),
(40, 39, '_wp_page_template', 'default'),
(41, 39, '_edit_lock', '1516676839:1'),
(42, 46, '_edit_last', '1'),
(43, 46, '_wp_page_template', 'default'),
(44, 46, '_edit_lock', '1516676818:1'),
(45, 48, '_edit_last', '1'),
(46, 48, '_wp_page_template', 'default'),
(47, 48, '_edit_lock', '1516676850:1'),
(48, 50, '_edit_last', '1'),
(49, 50, '_edit_lock', '1536340814:1'),
(50, 50, '_wp_page_template', 'default'),
(51, 52, '_edit_last', '1'),
(52, 52, '_wp_page_template', 'template-testimonials.php'),
(53, 52, '_edit_lock', '1536703018:1'),
(54, 54, '_edit_last', '1'),
(55, 54, '_wp_page_template', 'default'),
(56, 54, '_edit_lock', '1516676888:1'),
(57, 56, '_edit_last', '1'),
(58, 56, '_wp_page_template', 'default'),
(59, 56, '_edit_lock', '1516676922:1'),
(60, 58, '_edit_last', '1'),
(61, 58, '_edit_lock', '1516676969:1'),
(62, 58, '_wp_page_template', 'default'),
(63, 60, '_edit_last', '1'),
(64, 60, '_edit_lock', '1536684984:1'),
(65, 60, '_wp_page_template', 'template-bio.php'),
(66, 62, '_edit_last', '1'),
(67, 62, '_wp_page_template', 'default'),
(68, 62, '_edit_lock', '1516676996:1'),
(69, 68, '_edit_last', '1'),
(70, 68, '_edit_lock', '1534967167:1'),
(71, 68, '_wp_trash_meta_status', 'draft'),
(72, 68, '_wp_trash_meta_time', '1534967174'),
(73, 68, '_wp_desired_post_slug', ''),
(74, 70, '_menu_item_type', 'post_type'),
(75, 70, '_menu_item_menu_item_parent', '0'),
(76, 70, '_menu_item_object_id', '10'),
(77, 70, '_menu_item_object', 'page'),
(78, 70, '_menu_item_target', ''),
(79, 70, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(80, 70, '_menu_item_xfn', ''),
(81, 70, '_menu_item_url', ''),
(83, 71, '_menu_item_type', 'custom'),
(84, 71, '_menu_item_menu_item_parent', '0'),
(85, 71, '_menu_item_object_id', '71'),
(86, 71, '_menu_item_object', 'custom'),
(87, 71, '_menu_item_target', ''),
(88, 71, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(89, 71, '_menu_item_xfn', ''),
(90, 71, '_menu_item_url', ''),
(92, 72, '_menu_item_type', 'post_type'),
(93, 72, '_menu_item_menu_item_parent', '71'),
(94, 72, '_menu_item_object_id', '46'),
(95, 72, '_menu_item_object', 'page'),
(96, 72, '_menu_item_target', ''),
(97, 72, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(98, 72, '_menu_item_xfn', ''),
(99, 72, '_menu_item_url', ''),
(101, 73, '_menu_item_type', 'custom'),
(102, 73, '_menu_item_menu_item_parent', '0'),
(103, 73, '_menu_item_object_id', '73'),
(104, 73, '_menu_item_object', 'custom'),
(105, 73, '_menu_item_target', ''),
(106, 73, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(107, 73, '_menu_item_xfn', ''),
(108, 73, '_menu_item_url', ''),
(110, 74, '_menu_item_type', 'post_type'),
(111, 74, '_menu_item_menu_item_parent', '73'),
(112, 74, '_menu_item_object_id', '60'),
(113, 74, '_menu_item_object', 'page'),
(114, 74, '_menu_item_target', ''),
(115, 74, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(116, 74, '_menu_item_xfn', ''),
(117, 74, '_menu_item_url', ''),
(119, 75, '_menu_item_type', 'post_type'),
(120, 75, '_menu_item_menu_item_parent', '0'),
(121, 75, '_menu_item_object_id', '54'),
(122, 75, '_menu_item_object', 'page'),
(123, 75, '_menu_item_target', '') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(124, 75, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(125, 75, '_menu_item_xfn', ''),
(126, 75, '_menu_item_url', ''),
(128, 76, '_menu_item_type', 'post_type'),
(129, 76, '_menu_item_menu_item_parent', '0'),
(130, 76, '_menu_item_object_id', '52'),
(131, 76, '_menu_item_object', 'page'),
(132, 76, '_menu_item_target', ''),
(133, 76, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(134, 76, '_menu_item_xfn', ''),
(135, 76, '_menu_item_url', ''),
(137, 77, '_menu_item_type', 'post_type'),
(138, 77, '_menu_item_menu_item_parent', '0'),
(139, 77, '_menu_item_object_id', '62'),
(140, 77, '_menu_item_object', 'page'),
(141, 77, '_menu_item_target', ''),
(142, 77, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(143, 77, '_menu_item_xfn', ''),
(144, 77, '_menu_item_url', ''),
(146, 78, '_menu_item_type', 'post_type'),
(147, 78, '_menu_item_menu_item_parent', '0'),
(148, 78, '_menu_item_object_id', '56'),
(149, 78, '_menu_item_object', 'page'),
(150, 78, '_menu_item_target', ''),
(151, 78, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(152, 78, '_menu_item_xfn', ''),
(153, 78, '_menu_item_url', ''),
(155, 58, '_wp_trash_meta_status', 'publish'),
(156, 58, '_wp_trash_meta_time', '1534967326'),
(157, 58, '_wp_desired_post_slug', 'attorneys'),
(158, 48, '_wp_trash_meta_status', 'publish'),
(159, 48, '_wp_trash_meta_time', '1534967331'),
(160, 48, '_wp_desired_post_slug', 'practice-areas'),
(161, 79, '_edit_last', '1'),
(162, 79, '_edit_lock', '1536684487:1'),
(163, 79, '_wp_page_template', 'template-meetteam.php'),
(164, 81, '_menu_item_type', 'post_type'),
(165, 81, '_menu_item_menu_item_parent', '73'),
(166, 81, '_menu_item_object_id', '79'),
(167, 81, '_menu_item_object', 'page'),
(168, 81, '_menu_item_target', ''),
(169, 81, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(170, 81, '_menu_item_xfn', ''),
(171, 81, '_menu_item_url', ''),
(173, 82, '_menu_item_type', 'custom'),
(174, 82, '_menu_item_menu_item_parent', '0'),
(175, 82, '_menu_item_object_id', '82'),
(176, 82, '_menu_item_object', 'custom'),
(177, 82, '_menu_item_target', ''),
(178, 82, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(179, 82, '_menu_item_xfn', ''),
(180, 82, '_menu_item_url', ''),
(182, 83, '_menu_item_type', 'post_type'),
(183, 83, '_menu_item_menu_item_parent', '82'),
(184, 83, '_menu_item_object_id', '50'),
(185, 83, '_menu_item_object', 'page'),
(186, 83, '_menu_item_target', ''),
(187, 83, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(188, 83, '_menu_item_xfn', ''),
(189, 83, '_menu_item_url', ''),
(190, 85, '_menu_item_type', 'custom'),
(191, 85, '_menu_item_menu_item_parent', '0'),
(192, 85, '_menu_item_object_id', '85'),
(193, 85, '_menu_item_object', 'custom'),
(194, 85, '_menu_item_target', ''),
(195, 85, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(196, 85, '_menu_item_xfn', ''),
(197, 85, '_menu_item_url', ''),
(199, 86, '_menu_item_type', 'post_type'),
(200, 86, '_menu_item_menu_item_parent', '85'),
(201, 86, '_menu_item_object_id', '50'),
(202, 86, '_menu_item_object', 'page'),
(203, 86, '_menu_item_target', ''),
(204, 86, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(205, 86, '_menu_item_xfn', ''),
(206, 86, '_menu_item_url', ''),
(208, 87, '_edit_last', '1'),
(209, 87, '_wp_page_template', 'default'),
(210, 87, '_edit_lock', '1536268465:1'),
(211, 89, '_edit_last', '1'),
(212, 89, '_wp_page_template', 'default'),
(213, 89, '_edit_lock', '1536268478:1'),
(214, 91, '_edit_last', '1'),
(215, 91, '_wp_page_template', 'default'),
(216, 91, '_edit_lock', '1536268493:1'),
(217, 93, '_edit_last', '1'),
(218, 93, '_wp_page_template', 'default'),
(219, 93, '_edit_lock', '1536268515:1'),
(220, 95, '_menu_item_type', 'custom'),
(221, 95, '_menu_item_menu_item_parent', '0'),
(222, 95, '_menu_item_object_id', '95'),
(223, 95, '_menu_item_object', 'custom'),
(224, 95, '_menu_item_target', ''),
(225, 95, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(226, 95, '_menu_item_xfn', ''),
(227, 95, '_menu_item_url', ''),
(229, 96, '_menu_item_type', 'custom'),
(230, 96, '_menu_item_menu_item_parent', '0'),
(231, 96, '_menu_item_object_id', '96'),
(232, 96, '_menu_item_object', 'custom') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(233, 96, '_menu_item_target', ''),
(234, 96, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(235, 96, '_menu_item_xfn', ''),
(236, 96, '_menu_item_url', ''),
(238, 97, '_menu_item_type', 'post_type'),
(239, 97, '_menu_item_menu_item_parent', '96'),
(240, 97, '_menu_item_object_id', '93'),
(241, 97, '_menu_item_object', 'page'),
(242, 97, '_menu_item_target', ''),
(243, 97, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(244, 97, '_menu_item_xfn', ''),
(245, 97, '_menu_item_url', ''),
(247, 98, '_menu_item_type', 'post_type'),
(248, 98, '_menu_item_menu_item_parent', '95'),
(249, 98, '_menu_item_object_id', '91'),
(250, 98, '_menu_item_object', 'page'),
(251, 98, '_menu_item_target', ''),
(252, 98, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(253, 98, '_menu_item_xfn', ''),
(254, 98, '_menu_item_url', ''),
(256, 99, '_menu_item_type', 'post_type'),
(257, 99, '_menu_item_menu_item_parent', '95'),
(258, 99, '_menu_item_object_id', '89'),
(259, 99, '_menu_item_object', 'page'),
(260, 99, '_menu_item_target', ''),
(261, 99, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(262, 99, '_menu_item_xfn', ''),
(263, 99, '_menu_item_url', ''),
(265, 100, '_menu_item_type', 'post_type'),
(266, 100, '_menu_item_menu_item_parent', '85'),
(267, 100, '_menu_item_object_id', '87'),
(268, 100, '_menu_item_object', 'page'),
(269, 100, '_menu_item_target', ''),
(270, 100, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(271, 100, '_menu_item_xfn', ''),
(272, 100, '_menu_item_url', ''),
(282, 103, '_edit_last', '1'),
(283, 103, '_edit_lock', '1536594674:1'),
(284, 103, '_wp_page_template', 'template-padirectory.php'),
(285, 105, '_menu_item_type', 'post_type'),
(286, 105, '_menu_item_menu_item_parent', '0'),
(287, 105, '_menu_item_object_id', '103'),
(288, 105, '_menu_item_object', 'page'),
(289, 105, '_menu_item_target', ''),
(290, 105, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(291, 105, '_menu_item_xfn', ''),
(292, 105, '_menu_item_url', ''),
(293, 105, '_menu_item_orphaned', '1536341087'),
(294, 106, '_menu_item_type', 'post_type'),
(295, 106, '_menu_item_menu_item_parent', '82'),
(296, 106, '_menu_item_object_id', '103'),
(297, 106, '_menu_item_object', 'page'),
(298, 106, '_menu_item_target', ''),
(299, 106, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(300, 106, '_menu_item_xfn', ''),
(301, 106, '_menu_item_url', ''),
(302, 107, '_menu_item_type', 'post_type'),
(303, 107, '_menu_item_menu_item_parent', '85'),
(304, 107, '_menu_item_object_id', '93'),
(305, 107, '_menu_item_object', 'page'),
(306, 107, '_menu_item_target', ''),
(307, 107, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(308, 107, '_menu_item_xfn', ''),
(309, 107, '_menu_item_url', ''),
(311, 108, '_menu_item_type', 'post_type'),
(312, 108, '_menu_item_menu_item_parent', '85'),
(313, 108, '_menu_item_object_id', '91'),
(314, 108, '_menu_item_object', 'page'),
(315, 108, '_menu_item_target', ''),
(316, 108, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(317, 108, '_menu_item_xfn', ''),
(318, 108, '_menu_item_url', ''),
(320, 109, '_menu_item_type', 'post_type'),
(321, 109, '_menu_item_menu_item_parent', '85'),
(322, 109, '_menu_item_object_id', '89'),
(323, 109, '_menu_item_object', 'page'),
(324, 109, '_menu_item_target', ''),
(325, 109, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(326, 109, '_menu_item_xfn', ''),
(327, 109, '_menu_item_url', ''),
(328, 111, '_edit_last', '1'),
(329, 111, '_edit_lock', '1536683842:1'),
(330, 60, 'attorney_sub_header', 'Wisconsin Personal Injury Attorney'),
(331, 60, '_attorney_sub_header', 'field_5b96eb6fd59d2'),
(332, 60, 'attorney_image', '170'),
(333, 60, '_attorney_image', 'field_5b96eb78d59d3'),
(334, 60, 'accolades_0_accolades_title', 'professional memberships'),
(335, 60, '_accolades_0_accolades_title', 'field_5b96ebf2d59d5'),
(344, 60, 'accolades_0_accolades_bullets', '6'),
(345, 60, '_accolades_0_accolades_bullets', 'field_5b96ec0ad59d6'),
(346, 60, 'accolades', '4'),
(347, 60, '_accolades', 'field_5b96ebe8d59d4'),
(348, 120, 'attorney_sub_header', 'Wisconsin Personal Injury Attorney'),
(349, 120, '_attorney_sub_header', 'field_5b96eb6fd59d2'),
(350, 120, 'attorney_image', ''),
(351, 120, '_attorney_image', 'field_5b96eb78d59d3'),
(352, 120, 'accolades_0_accolades_title', ''),
(353, 120, '_accolades_0_accolades_title', 'field_5b96ebf2d59d5'),
(354, 120, 'accolades_0_accolades_bullets_0_accolades_bullet', ''),
(355, 120, '_accolades_0_accolades_bullets_0_accolades_bullet', 'field_5b96ec4cd59d7') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(356, 120, 'accolades_0_accolades_bullets_0_accolades_sub_bullets_0_accolades_sub_bullets', ''),
(357, 120, '_accolades_0_accolades_bullets_0_accolades_sub_bullets_0_accolades_sub_bullets', 'field_5b97d69f40931'),
(358, 120, 'accolades_0_accolades_bullets_0_accolades_sub_bullets_1_accolades_sub_bullets', ''),
(359, 120, '_accolades_0_accolades_bullets_0_accolades_sub_bullets_1_accolades_sub_bullets', 'field_5b97d69f40931'),
(360, 120, 'accolades_0_accolades_bullets_0_accolades_sub_bullets', '2'),
(361, 120, '_accolades_0_accolades_bullets_0_accolades_sub_bullets', 'field_5b96ec59d59d8'),
(362, 120, 'accolades_0_accolades_bullets', '1'),
(363, 120, '_accolades_0_accolades_bullets', 'field_5b96ec0ad59d6'),
(364, 120, 'accolades', '1'),
(365, 120, '_accolades', 'field_5b96ebe8d59d4'),
(366, 121, 'attorney_sub_header', 'Wisconsin Personal Injury Attorney'),
(367, 121, '_attorney_sub_header', 'field_5b96eb6fd59d2'),
(368, 121, 'attorney_image', ''),
(369, 121, '_attorney_image', 'field_5b96eb78d59d3'),
(370, 121, 'accolades_0_accolades_title', ''),
(371, 121, '_accolades_0_accolades_title', 'field_5b96ebf2d59d5'),
(372, 121, 'accolades_0_accolades_bullets_0_accolades_bullet', ''),
(373, 121, '_accolades_0_accolades_bullets_0_accolades_bullet', 'field_5b96ec4cd59d7'),
(374, 121, 'accolades_0_accolades_bullets_0_accolades_sub_bullets_0_accolades_sub_bullets', ''),
(375, 121, '_accolades_0_accolades_bullets_0_accolades_sub_bullets_0_accolades_sub_bullets', 'field_5b97d69f40931'),
(376, 121, 'accolades_0_accolades_bullets_0_accolades_sub_bullets_1_accolades_sub_bullets', ''),
(377, 121, '_accolades_0_accolades_bullets_0_accolades_sub_bullets_1_accolades_sub_bullets', 'field_5b97d69f40931'),
(378, 121, 'accolades_0_accolades_bullets_0_accolades_sub_bullets', '2'),
(379, 121, '_accolades_0_accolades_bullets_0_accolades_sub_bullets', 'field_5b96ec59d59d8'),
(380, 121, 'accolades_0_accolades_bullets', '1'),
(381, 121, '_accolades_0_accolades_bullets', 'field_5b96ec0ad59d6'),
(382, 121, 'accolades', '1'),
(383, 121, '_accolades', 'field_5b96ebe8d59d4'),
(384, 122, '_wp_attached_file', '2018/09/AP_img_PatrickDunphy.jpg'),
(385, 122, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:315;s:6:"height";i:425;s:4:"file";s:32:"2018/09/AP_img_PatrickDunphy.jpg";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:32:"AP_img_PatrickDunphy-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:32:"AP_img_PatrickDunphy-222x300.jpg";s:5:"width";i:222;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(386, 123, 'attorney_sub_header', 'Wisconsin Personal Injury Attorney'),
(387, 123, '_attorney_sub_header', 'field_5b96eb6fd59d2'),
(388, 123, 'attorney_image', '122'),
(389, 123, '_attorney_image', 'field_5b96eb78d59d3'),
(390, 123, 'accolades_0_accolades_title', ''),
(391, 123, '_accolades_0_accolades_title', 'field_5b96ebf2d59d5'),
(392, 123, 'accolades_0_accolades_bullets_0_accolades_bullet', ''),
(393, 123, '_accolades_0_accolades_bullets_0_accolades_bullet', 'field_5b96ec4cd59d7'),
(394, 123, 'accolades_0_accolades_bullets_0_accolades_sub_bullets_0_accolades_sub_bullets', ''),
(395, 123, '_accolades_0_accolades_bullets_0_accolades_sub_bullets_0_accolades_sub_bullets', 'field_5b97d69f40931'),
(396, 123, 'accolades_0_accolades_bullets_0_accolades_sub_bullets_1_accolades_sub_bullets', ''),
(397, 123, '_accolades_0_accolades_bullets_0_accolades_sub_bullets_1_accolades_sub_bullets', 'field_5b97d69f40931'),
(398, 123, 'accolades_0_accolades_bullets_0_accolades_sub_bullets', '2'),
(399, 123, '_accolades_0_accolades_bullets_0_accolades_sub_bullets', 'field_5b96ec59d59d8'),
(400, 123, 'accolades_0_accolades_bullets', '1'),
(401, 123, '_accolades_0_accolades_bullets', 'field_5b96ec0ad59d6'),
(402, 123, 'accolades', '1'),
(403, 123, '_accolades', 'field_5b96ebe8d59d4'),
(404, 124, 'attorney_sub_header', 'Wisconsin Personal Injury Attorney'),
(405, 124, '_attorney_sub_header', 'field_5b96eb6fd59d2'),
(406, 124, 'attorney_image', '122'),
(407, 124, '_attorney_image', 'field_5b96eb78d59d3'),
(408, 124, 'accolades_0_accolades_title', 'professional memberships'),
(409, 124, '_accolades_0_accolades_title', 'field_5b96ebf2d59d5'),
(410, 124, 'accolades_0_accolades_bullets', ''),
(411, 124, '_accolades_0_accolades_bullets', 'field_5b96ec0ad59d6'),
(412, 124, 'accolades', '1'),
(413, 124, '_accolades', 'field_5b96ebe8d59d4'),
(414, 60, 'accolades_0_accolades_bullets_0_accolades_bullet', 'Wisconsin Association for Justice'),
(415, 60, '_accolades_0_accolades_bullets_0_accolades_bullet', 'field_5b96ec4cd59d7'),
(416, 60, 'accolades_0_accolades_bullets_0_accolades_sub_bullets', ''),
(417, 60, '_accolades_0_accolades_bullets_0_accolades_sub_bullets', 'field_5b96ec59d59d8'),
(418, 60, 'accolades_0_accolades_bullets_1_accolades_bullet', 'American Association for Justice'),
(419, 60, '_accolades_0_accolades_bullets_1_accolades_bullet', 'field_5b96ec4cd59d7'),
(420, 60, 'accolades_0_accolades_bullets_1_accolades_sub_bullets', ''),
(421, 60, '_accolades_0_accolades_bullets_1_accolades_sub_bullets', 'field_5b96ec59d59d8'),
(422, 60, 'accolades_0_accolades_bullets_2_accolades_bullet', 'Chairman, DPT Litigation Committee, (ATLA) 1984-1986'),
(423, 60, '_accolades_0_accolades_bullets_2_accolades_bullet', 'field_5b96ec4cd59d7'),
(424, 60, 'accolades_0_accolades_bullets_2_accolades_sub_bullets', ''),
(425, 60, '_accolades_0_accolades_bullets_2_accolades_sub_bullets', 'field_5b96ec59d59d8'),
(426, 60, 'accolades_0_accolades_bullets_3_accolades_bullet', 'Member, Board of Directors, Aquatic Injury Safety Litigation Group, (ATLA) 1987-1990'),
(427, 60, '_accolades_0_accolades_bullets_3_accolades_bullet', 'field_5b96ec4cd59d7'),
(428, 60, 'accolades_0_accolades_bullets_3_accolades_sub_bullets', ''),
(429, 60, '_accolades_0_accolades_bullets_3_accolades_sub_bullets', 'field_5b96ec59d59d8'),
(430, 60, 'accolades_0_accolades_bullets_4_accolades_bullet', 'Diplomate, American Board of Professional Liability Attorneys. (Nationally Board Certified)'),
(431, 60, '_accolades_0_accolades_bullets_4_accolades_bullet', 'field_5b96ec4cd59d7'),
(432, 60, 'accolades_0_accolades_bullets_4_accolades_sub_bullets', ''),
(433, 60, '_accolades_0_accolades_bullets_4_accolades_sub_bullets', 'field_5b96ec59d59d8'),
(434, 60, 'accolades_0_accolades_bullets_5_accolades_bullet', 'Board Certified as Trial Attorney by the National Board of Trial Advocacy'),
(435, 60, '_accolades_0_accolades_bullets_5_accolades_bullet', 'field_5b96ec4cd59d7'),
(436, 60, 'accolades_0_accolades_bullets_5_accolades_sub_bullets', ''),
(437, 60, '_accolades_0_accolades_bullets_5_accolades_sub_bullets', 'field_5b96ec59d59d8'),
(438, 125, 'attorney_sub_header', 'Wisconsin Personal Injury Attorney'),
(439, 125, '_attorney_sub_header', 'field_5b96eb6fd59d2'),
(440, 125, 'attorney_image', '122'),
(441, 125, '_attorney_image', 'field_5b96eb78d59d3'),
(442, 125, 'accolades_0_accolades_title', 'professional memberships'),
(443, 125, '_accolades_0_accolades_title', 'field_5b96ebf2d59d5'),
(444, 125, 'accolades_0_accolades_bullets', '6'),
(445, 125, '_accolades_0_accolades_bullets', 'field_5b96ec0ad59d6'),
(446, 125, 'accolades', '1'),
(447, 125, '_accolades', 'field_5b96ebe8d59d4'),
(448, 125, 'accolades_0_accolades_bullets_0_accolades_bullet', 'Wisconsin Association for Justice'),
(449, 125, '_accolades_0_accolades_bullets_0_accolades_bullet', 'field_5b96ec4cd59d7'),
(450, 125, 'accolades_0_accolades_bullets_0_accolades_sub_bullets', ''),
(451, 125, '_accolades_0_accolades_bullets_0_accolades_sub_bullets', 'field_5b96ec59d59d8'),
(452, 125, 'accolades_0_accolades_bullets_1_accolades_bullet', 'American Association for Justice'),
(453, 125, '_accolades_0_accolades_bullets_1_accolades_bullet', 'field_5b96ec4cd59d7'),
(454, 125, 'accolades_0_accolades_bullets_1_accolades_sub_bullets', ''),
(455, 125, '_accolades_0_accolades_bullets_1_accolades_sub_bullets', 'field_5b96ec59d59d8') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(456, 125, 'accolades_0_accolades_bullets_2_accolades_bullet', 'Chairman, DPT Litigation Committee, (ATLA) 1984-1986'),
(457, 125, '_accolades_0_accolades_bullets_2_accolades_bullet', 'field_5b96ec4cd59d7'),
(458, 125, 'accolades_0_accolades_bullets_2_accolades_sub_bullets', ''),
(459, 125, '_accolades_0_accolades_bullets_2_accolades_sub_bullets', 'field_5b96ec59d59d8'),
(460, 125, 'accolades_0_accolades_bullets_3_accolades_bullet', 'Member, Board of Directors, Aquatic Injury Safety Litigation Group, (ATLA) 1987-1990'),
(461, 125, '_accolades_0_accolades_bullets_3_accolades_bullet', 'field_5b96ec4cd59d7'),
(462, 125, 'accolades_0_accolades_bullets_3_accolades_sub_bullets', ''),
(463, 125, '_accolades_0_accolades_bullets_3_accolades_sub_bullets', 'field_5b96ec59d59d8'),
(464, 125, 'accolades_0_accolades_bullets_4_accolades_bullet', 'Diplomate, American Board of Professional Liability Attorneys. (Nationally Board Certified)'),
(465, 125, '_accolades_0_accolades_bullets_4_accolades_bullet', 'field_5b96ec4cd59d7'),
(466, 125, 'accolades_0_accolades_bullets_4_accolades_sub_bullets', ''),
(467, 125, '_accolades_0_accolades_bullets_4_accolades_sub_bullets', 'field_5b96ec59d59d8'),
(468, 125, 'accolades_0_accolades_bullets_5_accolades_bullet', 'Board Certified as Trial Attorney by the National Board of Trial Advocacy'),
(469, 125, '_accolades_0_accolades_bullets_5_accolades_bullet', 'field_5b96ec4cd59d7'),
(470, 125, 'accolades_0_accolades_bullets_5_accolades_sub_bullets', ''),
(471, 125, '_accolades_0_accolades_bullets_5_accolades_sub_bullets', 'field_5b96ec59d59d8'),
(476, 126, 'attorney_sub_header', 'Wisconsin Personal Injury Attorney'),
(477, 126, '_attorney_sub_header', 'field_5b96eb6fd59d2'),
(478, 126, 'attorney_image', '122'),
(479, 126, '_attorney_image', 'field_5b96eb78d59d3'),
(480, 126, 'accolades_0_accolades_title', 'professional memberships'),
(481, 126, '_accolades_0_accolades_title', 'field_5b96ebf2d59d5'),
(482, 126, 'accolades_0_accolades_bullets', '6'),
(483, 126, '_accolades_0_accolades_bullets', 'field_5b96ec0ad59d6'),
(484, 126, 'accolades', '1'),
(485, 126, '_accolades', 'field_5b96ebe8d59d4'),
(486, 126, 'accolades_0_accolades_bullets_0_accolades_bullet', 'Wisconsin Association for Justice'),
(487, 126, '_accolades_0_accolades_bullets_0_accolades_bullet', 'field_5b96ec4cd59d7'),
(488, 126, 'accolades_0_accolades_bullets_0_accolades_sub_bullets', ''),
(489, 126, '_accolades_0_accolades_bullets_0_accolades_sub_bullets', 'field_5b96ec59d59d8'),
(490, 126, 'accolades_0_accolades_bullets_1_accolades_bullet', 'American Association for Justice'),
(491, 126, '_accolades_0_accolades_bullets_1_accolades_bullet', 'field_5b96ec4cd59d7'),
(492, 126, 'accolades_0_accolades_bullets_1_accolades_sub_bullets', '2'),
(493, 126, '_accolades_0_accolades_bullets_1_accolades_sub_bullets', 'field_5b96ec59d59d8'),
(494, 126, 'accolades_0_accolades_bullets_2_accolades_bullet', 'Chairman, DPT Litigation Committee, (ATLA) 1984-1986'),
(495, 126, '_accolades_0_accolades_bullets_2_accolades_bullet', 'field_5b96ec4cd59d7'),
(496, 126, 'accolades_0_accolades_bullets_2_accolades_sub_bullets', ''),
(497, 126, '_accolades_0_accolades_bullets_2_accolades_sub_bullets', 'field_5b96ec59d59d8'),
(498, 126, 'accolades_0_accolades_bullets_3_accolades_bullet', 'Member, Board of Directors, Aquatic Injury Safety Litigation Group, (ATLA) 1987-1990'),
(499, 126, '_accolades_0_accolades_bullets_3_accolades_bullet', 'field_5b96ec4cd59d7'),
(500, 126, 'accolades_0_accolades_bullets_3_accolades_sub_bullets', ''),
(501, 126, '_accolades_0_accolades_bullets_3_accolades_sub_bullets', 'field_5b96ec59d59d8'),
(502, 126, 'accolades_0_accolades_bullets_4_accolades_bullet', 'Diplomate, American Board of Professional Liability Attorneys. (Nationally Board Certified)'),
(503, 126, '_accolades_0_accolades_bullets_4_accolades_bullet', 'field_5b96ec4cd59d7'),
(504, 126, 'accolades_0_accolades_bullets_4_accolades_sub_bullets', ''),
(505, 126, '_accolades_0_accolades_bullets_4_accolades_sub_bullets', 'field_5b96ec59d59d8'),
(506, 126, 'accolades_0_accolades_bullets_5_accolades_bullet', 'Board Certified as Trial Attorney by the National Board of Trial Advocacy'),
(507, 126, '_accolades_0_accolades_bullets_5_accolades_bullet', 'field_5b96ec4cd59d7'),
(508, 126, 'accolades_0_accolades_bullets_5_accolades_sub_bullets', ''),
(509, 126, '_accolades_0_accolades_bullets_5_accolades_sub_bullets', 'field_5b96ec59d59d8'),
(510, 126, 'accolades_0_accolades_bullets_1_accolades_sub_bullets_0_accolades_sub_bullets', 'test'),
(511, 126, '_accolades_0_accolades_bullets_1_accolades_sub_bullets_0_accolades_sub_bullets', 'field_5b97d69f40931'),
(512, 126, 'accolades_0_accolades_bullets_1_accolades_sub_bullets_1_accolades_sub_bullets', 'test'),
(513, 126, '_accolades_0_accolades_bullets_1_accolades_sub_bullets_1_accolades_sub_bullets', 'field_5b97d69f40931'),
(514, 60, 'accolades_1_accolades_title', 'Admitted'),
(515, 60, '_accolades_1_accolades_title', 'field_5b96ebf2d59d5'),
(516, 60, 'accolades_1_accolades_bullets_0_accolades_bullet', '1972 Licensed to Practice Law in the State of Wisconsin'),
(517, 60, '_accolades_1_accolades_bullets_0_accolades_bullet', 'field_5b96ec4cd59d7'),
(518, 60, 'accolades_1_accolades_bullets_0_accolades_sub_bullets', ''),
(519, 60, '_accolades_1_accolades_bullets_0_accolades_sub_bullets', 'field_5b96ec59d59d8'),
(520, 60, 'accolades_1_accolades_bullets_1_accolades_bullet', '1972 Licensed to Practice Law in the following Federal Courts:'),
(521, 60, '_accolades_1_accolades_bullets_1_accolades_bullet', 'field_5b96ec4cd59d7'),
(522, 60, 'accolades_1_accolades_bullets_1_accolades_sub_bullets_0_accolades_sub_bullets', 'Eastern District Court for the State of Wisconsin'),
(523, 60, '_accolades_1_accolades_bullets_1_accolades_sub_bullets_0_accolades_sub_bullets', 'field_5b97d69f40931'),
(524, 60, 'accolades_1_accolades_bullets_1_accolades_sub_bullets_1_accolades_sub_bullets', 'Western District Court for the State of Wisconsin'),
(525, 60, '_accolades_1_accolades_bullets_1_accolades_sub_bullets_1_accolades_sub_bullets', 'field_5b97d69f40931'),
(526, 60, 'accolades_1_accolades_bullets_1_accolades_sub_bullets', '2'),
(527, 60, '_accolades_1_accolades_bullets_1_accolades_sub_bullets', 'field_5b96ec59d59d8'),
(528, 60, 'accolades_1_accolades_bullets_2_accolades_bullet', '1990 Licensed to Practice Law in the Supreme Court of the United States'),
(529, 60, '_accolades_1_accolades_bullets_2_accolades_bullet', 'field_5b96ec4cd59d7'),
(530, 60, 'accolades_1_accolades_bullets_2_accolades_sub_bullets', ''),
(531, 60, '_accolades_1_accolades_bullets_2_accolades_sub_bullets', 'field_5b96ec59d59d8'),
(532, 60, 'accolades_1_accolades_bullets_3_accolades_bullet', '1999 Licensed to Practice Law in the Seventh Circuit Court of Appeals'),
(533, 60, '_accolades_1_accolades_bullets_3_accolades_bullet', 'field_5b96ec4cd59d7'),
(534, 60, 'accolades_1_accolades_bullets_3_accolades_sub_bullets', ''),
(535, 60, '_accolades_1_accolades_bullets_3_accolades_sub_bullets', 'field_5b96ec59d59d8'),
(536, 60, 'accolades_1_accolades_bullets', '4'),
(537, 60, '_accolades_1_accolades_bullets', 'field_5b96ec0ad59d6'),
(538, 127, 'attorney_sub_header', 'Wisconsin Personal Injury Attorney'),
(539, 127, '_attorney_sub_header', 'field_5b96eb6fd59d2'),
(540, 127, 'attorney_image', '122'),
(541, 127, '_attorney_image', 'field_5b96eb78d59d3'),
(542, 127, 'accolades_0_accolades_title', 'professional memberships'),
(543, 127, '_accolades_0_accolades_title', 'field_5b96ebf2d59d5'),
(544, 127, 'accolades_0_accolades_bullets', '6'),
(545, 127, '_accolades_0_accolades_bullets', 'field_5b96ec0ad59d6'),
(546, 127, 'accolades', '2'),
(547, 127, '_accolades', 'field_5b96ebe8d59d4'),
(548, 127, 'accolades_0_accolades_bullets_0_accolades_bullet', 'Wisconsin Association for Justice'),
(549, 127, '_accolades_0_accolades_bullets_0_accolades_bullet', 'field_5b96ec4cd59d7'),
(550, 127, 'accolades_0_accolades_bullets_0_accolades_sub_bullets', ''),
(551, 127, '_accolades_0_accolades_bullets_0_accolades_sub_bullets', 'field_5b96ec59d59d8'),
(552, 127, 'accolades_0_accolades_bullets_1_accolades_bullet', 'American Association for Justice'),
(553, 127, '_accolades_0_accolades_bullets_1_accolades_bullet', 'field_5b96ec4cd59d7'),
(554, 127, 'accolades_0_accolades_bullets_1_accolades_sub_bullets', ''),
(555, 127, '_accolades_0_accolades_bullets_1_accolades_sub_bullets', 'field_5b96ec59d59d8'),
(556, 127, 'accolades_0_accolades_bullets_2_accolades_bullet', 'Chairman, DPT Litigation Committee, (ATLA) 1984-1986'),
(557, 127, '_accolades_0_accolades_bullets_2_accolades_bullet', 'field_5b96ec4cd59d7'),
(558, 127, 'accolades_0_accolades_bullets_2_accolades_sub_bullets', ''),
(559, 127, '_accolades_0_accolades_bullets_2_accolades_sub_bullets', 'field_5b96ec59d59d8') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(560, 127, 'accolades_0_accolades_bullets_3_accolades_bullet', 'Member, Board of Directors, Aquatic Injury Safety Litigation Group, (ATLA) 1987-1990'),
(561, 127, '_accolades_0_accolades_bullets_3_accolades_bullet', 'field_5b96ec4cd59d7'),
(562, 127, 'accolades_0_accolades_bullets_3_accolades_sub_bullets', ''),
(563, 127, '_accolades_0_accolades_bullets_3_accolades_sub_bullets', 'field_5b96ec59d59d8'),
(564, 127, 'accolades_0_accolades_bullets_4_accolades_bullet', 'Diplomate, American Board of Professional Liability Attorneys. (Nationally Board Certified)'),
(565, 127, '_accolades_0_accolades_bullets_4_accolades_bullet', 'field_5b96ec4cd59d7'),
(566, 127, 'accolades_0_accolades_bullets_4_accolades_sub_bullets', ''),
(567, 127, '_accolades_0_accolades_bullets_4_accolades_sub_bullets', 'field_5b96ec59d59d8'),
(568, 127, 'accolades_0_accolades_bullets_5_accolades_bullet', 'Board Certified as Trial Attorney by the National Board of Trial Advocacy'),
(569, 127, '_accolades_0_accolades_bullets_5_accolades_bullet', 'field_5b96ec4cd59d7'),
(570, 127, 'accolades_0_accolades_bullets_5_accolades_sub_bullets', ''),
(571, 127, '_accolades_0_accolades_bullets_5_accolades_sub_bullets', 'field_5b96ec59d59d8'),
(572, 127, 'accolades_1_accolades_title', 'Admitted'),
(573, 127, '_accolades_1_accolades_title', 'field_5b96ebf2d59d5'),
(574, 127, 'accolades_1_accolades_bullets_0_accolades_bullet', '1972 Licensed to Practice Law in the State of Wisconsin'),
(575, 127, '_accolades_1_accolades_bullets_0_accolades_bullet', 'field_5b96ec4cd59d7'),
(576, 127, 'accolades_1_accolades_bullets_0_accolades_sub_bullets', ''),
(577, 127, '_accolades_1_accolades_bullets_0_accolades_sub_bullets', 'field_5b96ec59d59d8'),
(578, 127, 'accolades_1_accolades_bullets_1_accolades_bullet', '1972 Licensed to Practice Law in the following Federal Courts:'),
(579, 127, '_accolades_1_accolades_bullets_1_accolades_bullet', 'field_5b96ec4cd59d7'),
(580, 127, 'accolades_1_accolades_bullets_1_accolades_sub_bullets_0_accolades_sub_bullets', 'Eastern District Court for the State of Wisconsin'),
(581, 127, '_accolades_1_accolades_bullets_1_accolades_sub_bullets_0_accolades_sub_bullets', 'field_5b97d69f40931'),
(582, 127, 'accolades_1_accolades_bullets_1_accolades_sub_bullets_1_accolades_sub_bullets', 'Western District Court for the State of Wisconsin'),
(583, 127, '_accolades_1_accolades_bullets_1_accolades_sub_bullets_1_accolades_sub_bullets', 'field_5b97d69f40931'),
(584, 127, 'accolades_1_accolades_bullets_1_accolades_sub_bullets', '2'),
(585, 127, '_accolades_1_accolades_bullets_1_accolades_sub_bullets', 'field_5b96ec59d59d8'),
(586, 127, 'accolades_1_accolades_bullets_2_accolades_bullet', '1990 Licensed to Practice Law in the Supreme Court of the United States'),
(587, 127, '_accolades_1_accolades_bullets_2_accolades_bullet', 'field_5b96ec4cd59d7'),
(588, 127, 'accolades_1_accolades_bullets_2_accolades_sub_bullets', ''),
(589, 127, '_accolades_1_accolades_bullets_2_accolades_sub_bullets', 'field_5b96ec59d59d8'),
(590, 127, 'accolades_1_accolades_bullets_3_accolades_bullet', '1999 Licensed to Practice Law in the Seventh Circuit Court of Appeals'),
(591, 127, '_accolades_1_accolades_bullets_3_accolades_bullet', 'field_5b96ec4cd59d7'),
(592, 127, 'accolades_1_accolades_bullets_3_accolades_sub_bullets', ''),
(593, 127, '_accolades_1_accolades_bullets_3_accolades_sub_bullets', 'field_5b96ec59d59d8'),
(594, 127, 'accolades_1_accolades_bullets', '4'),
(595, 127, '_accolades_1_accolades_bullets', 'field_5b96ec0ad59d6'),
(596, 60, 'accolades_2_accolades_title', 'Education'),
(597, 60, '_accolades_2_accolades_title', 'field_5b96ebf2d59d5'),
(598, 60, 'accolades_2_accolades_bullets_0_accolades_bullet', '1972 Licensed to Practice Law in the State of Wisconsin'),
(599, 60, '_accolades_2_accolades_bullets_0_accolades_bullet', 'field_5b96ec4cd59d7'),
(600, 60, 'accolades_2_accolades_bullets_0_accolades_sub_bullets', ''),
(601, 60, '_accolades_2_accolades_bullets_0_accolades_sub_bullets', 'field_5b96ec59d59d8'),
(602, 60, 'accolades_2_accolades_bullets_1_accolades_bullet', 'University of Paris, France'),
(603, 60, '_accolades_2_accolades_bullets_1_accolades_bullet', 'field_5b96ec4cd59d7'),
(604, 60, 'accolades_2_accolades_bullets_1_accolades_sub_bullets', ''),
(605, 60, '_accolades_2_accolades_bullets_1_accolades_sub_bullets', 'field_5b96ec59d59d8'),
(606, 60, 'accolades_2_accolades_bullets_2_accolades_bullet', 'National University of Ireland, Ireland'),
(607, 60, '_accolades_2_accolades_bullets_2_accolades_bullet', 'field_5b96ec4cd59d7'),
(608, 60, 'accolades_2_accolades_bullets_2_accolades_sub_bullets', ''),
(609, 60, '_accolades_2_accolades_bullets_2_accolades_sub_bullets', 'field_5b96ec59d59d8'),
(610, 60, 'accolades_2_accolades_bullets_3_accolades_bullet', 'Marquette University (A.B., 1969)'),
(611, 60, '_accolades_2_accolades_bullets_3_accolades_bullet', 'field_5b96ec4cd59d7'),
(612, 60, 'accolades_2_accolades_bullets_3_accolades_sub_bullets', ''),
(613, 60, '_accolades_2_accolades_bullets_3_accolades_sub_bullets', 'field_5b96ec59d59d8'),
(614, 60, 'accolades_2_accolades_bullets_4_accolades_bullet', 'University of Wisconsin-Madison Law School (J.D., 1972)'),
(615, 60, '_accolades_2_accolades_bullets_4_accolades_bullet', 'field_5b96ec4cd59d7'),
(616, 60, 'accolades_2_accolades_bullets_4_accolades_sub_bullets', ''),
(617, 60, '_accolades_2_accolades_bullets_4_accolades_sub_bullets', 'field_5b96ec59d59d8'),
(618, 60, 'accolades_2_accolades_bullets', '5'),
(619, 60, '_accolades_2_accolades_bullets', 'field_5b96ec0ad59d6'),
(620, 60, 'accolades_3_accolades_title', 'Accomplishments'),
(621, 60, '_accolades_3_accolades_title', 'field_5b96ebf2d59d5'),
(622, 60, 'accolades_3_accolades_bullets_0_accolades_bullet', 'Multiple million dollar personal injury awards.'),
(623, 60, '_accolades_3_accolades_bullets_0_accolades_bullet', 'field_5b96ec4cd59d7'),
(624, 60, 'accolades_3_accolades_bullets_0_accolades_sub_bullets', ''),
(625, 60, '_accolades_3_accolades_bullets_0_accolades_sub_bullets', 'field_5b96ec59d59d8'),
(626, 60, 'accolades_3_accolades_bullets_1_accolades_bullet', 'Listed in the June, 1990 issue of Milwaukee Magazine as the top personal injury trial attorney in Milwaukee.'),
(627, 60, '_accolades_3_accolades_bullets_1_accolades_bullet', 'field_5b96ec4cd59d7'),
(628, 60, 'accolades_3_accolades_bullets_1_accolades_sub_bullets', ''),
(629, 60, '_accolades_3_accolades_bullets_1_accolades_sub_bullets', 'field_5b96ec59d59d8'),
(630, 60, 'accolades_3_accolades_bullets_2_accolades_bullet', 'Continuously Listed in The Best Lawyers in America for Over 25 Consecutive Years'),
(631, 60, '_accolades_3_accolades_bullets_2_accolades_bullet', 'field_5b96ec4cd59d7'),
(632, 60, 'accolades_3_accolades_bullets_2_accolades_sub_bullets', ''),
(633, 60, '_accolades_3_accolades_bullets_2_accolades_sub_bullets', 'field_5b96ec59d59d8'),
(634, 60, 'accolades_3_accolades_bullets_3_accolades_bullet', 'Featured in Milwaukee Sentinel as one of four top attorneys in the "Million Dollar Club."'),
(635, 60, '_accolades_3_accolades_bullets_3_accolades_bullet', 'field_5b96ec4cd59d7'),
(636, 60, 'accolades_3_accolades_bullets_3_accolades_sub_bullets', ''),
(637, 60, '_accolades_3_accolades_bullets_3_accolades_sub_bullets', 'field_5b96ec59d59d8'),
(638, 60, 'accolades_3_accolades_bullets_4_accolades_bullet', 'Named in "Super Lawyers" Magazine as one of the Top 10 Super Lawyers in Wisconsin'),
(639, 60, '_accolades_3_accolades_bullets_4_accolades_bullet', 'field_5b96ec4cd59d7'),
(640, 60, 'accolades_3_accolades_bullets_4_accolades_sub_bullets', ''),
(641, 60, '_accolades_3_accolades_bullets_4_accolades_sub_bullets', 'field_5b96ec59d59d8'),
(642, 60, 'accolades_3_accolades_bullets', '5'),
(643, 60, '_accolades_3_accolades_bullets', 'field_5b96ec0ad59d6'),
(644, 128, 'attorney_sub_header', 'Wisconsin Personal Injury Attorney'),
(645, 128, '_attorney_sub_header', 'field_5b96eb6fd59d2'),
(646, 128, 'attorney_image', '122'),
(647, 128, '_attorney_image', 'field_5b96eb78d59d3'),
(648, 128, 'accolades_0_accolades_title', 'professional memberships'),
(649, 128, '_accolades_0_accolades_title', 'field_5b96ebf2d59d5'),
(650, 128, 'accolades_0_accolades_bullets', '6'),
(651, 128, '_accolades_0_accolades_bullets', 'field_5b96ec0ad59d6'),
(652, 128, 'accolades', '4'),
(653, 128, '_accolades', 'field_5b96ebe8d59d4'),
(654, 128, 'accolades_0_accolades_bullets_0_accolades_bullet', 'Wisconsin Association for Justice'),
(655, 128, '_accolades_0_accolades_bullets_0_accolades_bullet', 'field_5b96ec4cd59d7'),
(656, 128, 'accolades_0_accolades_bullets_0_accolades_sub_bullets', ''),
(657, 128, '_accolades_0_accolades_bullets_0_accolades_sub_bullets', 'field_5b96ec59d59d8'),
(658, 128, 'accolades_0_accolades_bullets_1_accolades_bullet', 'American Association for Justice'),
(659, 128, '_accolades_0_accolades_bullets_1_accolades_bullet', 'field_5b96ec4cd59d7') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(660, 128, 'accolades_0_accolades_bullets_1_accolades_sub_bullets', ''),
(661, 128, '_accolades_0_accolades_bullets_1_accolades_sub_bullets', 'field_5b96ec59d59d8'),
(662, 128, 'accolades_0_accolades_bullets_2_accolades_bullet', 'Chairman, DPT Litigation Committee, (ATLA) 1984-1986'),
(663, 128, '_accolades_0_accolades_bullets_2_accolades_bullet', 'field_5b96ec4cd59d7'),
(664, 128, 'accolades_0_accolades_bullets_2_accolades_sub_bullets', ''),
(665, 128, '_accolades_0_accolades_bullets_2_accolades_sub_bullets', 'field_5b96ec59d59d8'),
(666, 128, 'accolades_0_accolades_bullets_3_accolades_bullet', 'Member, Board of Directors, Aquatic Injury Safety Litigation Group, (ATLA) 1987-1990'),
(667, 128, '_accolades_0_accolades_bullets_3_accolades_bullet', 'field_5b96ec4cd59d7'),
(668, 128, 'accolades_0_accolades_bullets_3_accolades_sub_bullets', ''),
(669, 128, '_accolades_0_accolades_bullets_3_accolades_sub_bullets', 'field_5b96ec59d59d8'),
(670, 128, 'accolades_0_accolades_bullets_4_accolades_bullet', 'Diplomate, American Board of Professional Liability Attorneys. (Nationally Board Certified)'),
(671, 128, '_accolades_0_accolades_bullets_4_accolades_bullet', 'field_5b96ec4cd59d7'),
(672, 128, 'accolades_0_accolades_bullets_4_accolades_sub_bullets', ''),
(673, 128, '_accolades_0_accolades_bullets_4_accolades_sub_bullets', 'field_5b96ec59d59d8'),
(674, 128, 'accolades_0_accolades_bullets_5_accolades_bullet', 'Board Certified as Trial Attorney by the National Board of Trial Advocacy'),
(675, 128, '_accolades_0_accolades_bullets_5_accolades_bullet', 'field_5b96ec4cd59d7'),
(676, 128, 'accolades_0_accolades_bullets_5_accolades_sub_bullets', ''),
(677, 128, '_accolades_0_accolades_bullets_5_accolades_sub_bullets', 'field_5b96ec59d59d8'),
(678, 128, 'accolades_1_accolades_title', 'Admitted'),
(679, 128, '_accolades_1_accolades_title', 'field_5b96ebf2d59d5'),
(680, 128, 'accolades_1_accolades_bullets_0_accolades_bullet', '1972 Licensed to Practice Law in the State of Wisconsin'),
(681, 128, '_accolades_1_accolades_bullets_0_accolades_bullet', 'field_5b96ec4cd59d7'),
(682, 128, 'accolades_1_accolades_bullets_0_accolades_sub_bullets', ''),
(683, 128, '_accolades_1_accolades_bullets_0_accolades_sub_bullets', 'field_5b96ec59d59d8'),
(684, 128, 'accolades_1_accolades_bullets_1_accolades_bullet', '1972 Licensed to Practice Law in the following Federal Courts:'),
(685, 128, '_accolades_1_accolades_bullets_1_accolades_bullet', 'field_5b96ec4cd59d7'),
(686, 128, 'accolades_1_accolades_bullets_1_accolades_sub_bullets_0_accolades_sub_bullets', 'Eastern District Court for the State of Wisconsin'),
(687, 128, '_accolades_1_accolades_bullets_1_accolades_sub_bullets_0_accolades_sub_bullets', 'field_5b97d69f40931'),
(688, 128, 'accolades_1_accolades_bullets_1_accolades_sub_bullets_1_accolades_sub_bullets', 'Western District Court for the State of Wisconsin'),
(689, 128, '_accolades_1_accolades_bullets_1_accolades_sub_bullets_1_accolades_sub_bullets', 'field_5b97d69f40931'),
(690, 128, 'accolades_1_accolades_bullets_1_accolades_sub_bullets', '2'),
(691, 128, '_accolades_1_accolades_bullets_1_accolades_sub_bullets', 'field_5b96ec59d59d8'),
(692, 128, 'accolades_1_accolades_bullets_2_accolades_bullet', '1990 Licensed to Practice Law in the Supreme Court of the United States'),
(693, 128, '_accolades_1_accolades_bullets_2_accolades_bullet', 'field_5b96ec4cd59d7'),
(694, 128, 'accolades_1_accolades_bullets_2_accolades_sub_bullets', ''),
(695, 128, '_accolades_1_accolades_bullets_2_accolades_sub_bullets', 'field_5b96ec59d59d8'),
(696, 128, 'accolades_1_accolades_bullets_3_accolades_bullet', '1999 Licensed to Practice Law in the Seventh Circuit Court of Appeals'),
(697, 128, '_accolades_1_accolades_bullets_3_accolades_bullet', 'field_5b96ec4cd59d7'),
(698, 128, 'accolades_1_accolades_bullets_3_accolades_sub_bullets', ''),
(699, 128, '_accolades_1_accolades_bullets_3_accolades_sub_bullets', 'field_5b96ec59d59d8'),
(700, 128, 'accolades_1_accolades_bullets', '4'),
(701, 128, '_accolades_1_accolades_bullets', 'field_5b96ec0ad59d6'),
(702, 128, 'accolades_2_accolades_title', 'Education'),
(703, 128, '_accolades_2_accolades_title', 'field_5b96ebf2d59d5'),
(704, 128, 'accolades_2_accolades_bullets_0_accolades_bullet', '1972 Licensed to Practice Law in the State of Wisconsin'),
(705, 128, '_accolades_2_accolades_bullets_0_accolades_bullet', 'field_5b96ec4cd59d7'),
(706, 128, 'accolades_2_accolades_bullets_0_accolades_sub_bullets', ''),
(707, 128, '_accolades_2_accolades_bullets_0_accolades_sub_bullets', 'field_5b96ec59d59d8'),
(708, 128, 'accolades_2_accolades_bullets_1_accolades_bullet', 'University of Paris, France'),
(709, 128, '_accolades_2_accolades_bullets_1_accolades_bullet', 'field_5b96ec4cd59d7'),
(710, 128, 'accolades_2_accolades_bullets_1_accolades_sub_bullets', ''),
(711, 128, '_accolades_2_accolades_bullets_1_accolades_sub_bullets', 'field_5b96ec59d59d8'),
(712, 128, 'accolades_2_accolades_bullets_2_accolades_bullet', 'National University of Ireland, Ireland'),
(713, 128, '_accolades_2_accolades_bullets_2_accolades_bullet', 'field_5b96ec4cd59d7'),
(714, 128, 'accolades_2_accolades_bullets_2_accolades_sub_bullets', ''),
(715, 128, '_accolades_2_accolades_bullets_2_accolades_sub_bullets', 'field_5b96ec59d59d8'),
(716, 128, 'accolades_2_accolades_bullets_3_accolades_bullet', 'Marquette University (A.B., 1969)'),
(717, 128, '_accolades_2_accolades_bullets_3_accolades_bullet', 'field_5b96ec4cd59d7'),
(718, 128, 'accolades_2_accolades_bullets_3_accolades_sub_bullets', ''),
(719, 128, '_accolades_2_accolades_bullets_3_accolades_sub_bullets', 'field_5b96ec59d59d8'),
(720, 128, 'accolades_2_accolades_bullets_4_accolades_bullet', 'University of Wisconsin-Madison Law School (J.D., 1972)'),
(721, 128, '_accolades_2_accolades_bullets_4_accolades_bullet', 'field_5b96ec4cd59d7'),
(722, 128, 'accolades_2_accolades_bullets_4_accolades_sub_bullets', ''),
(723, 128, '_accolades_2_accolades_bullets_4_accolades_sub_bullets', 'field_5b96ec59d59d8'),
(724, 128, 'accolades_2_accolades_bullets', '5'),
(725, 128, '_accolades_2_accolades_bullets', 'field_5b96ec0ad59d6'),
(726, 128, 'accolades_3_accolades_title', 'Accomplishments'),
(727, 128, '_accolades_3_accolades_title', 'field_5b96ebf2d59d5'),
(728, 128, 'accolades_3_accolades_bullets_0_accolades_bullet', 'Multiple million dollar personal injury awards.'),
(729, 128, '_accolades_3_accolades_bullets_0_accolades_bullet', 'field_5b96ec4cd59d7'),
(730, 128, 'accolades_3_accolades_bullets_0_accolades_sub_bullets', ''),
(731, 128, '_accolades_3_accolades_bullets_0_accolades_sub_bullets', 'field_5b96ec59d59d8'),
(732, 128, 'accolades_3_accolades_bullets_1_accolades_bullet', 'Listed in the June, 1990 issue of Milwaukee Magazine as the top personal injury trial attorney in Milwaukee.'),
(733, 128, '_accolades_3_accolades_bullets_1_accolades_bullet', 'field_5b96ec4cd59d7'),
(734, 128, 'accolades_3_accolades_bullets_1_accolades_sub_bullets', ''),
(735, 128, '_accolades_3_accolades_bullets_1_accolades_sub_bullets', 'field_5b96ec59d59d8'),
(736, 128, 'accolades_3_accolades_bullets_2_accolades_bullet', 'Continuously Listed in The Best Lawyers in America for Over 25 Consecutive Years'),
(737, 128, '_accolades_3_accolades_bullets_2_accolades_bullet', 'field_5b96ec4cd59d7'),
(738, 128, 'accolades_3_accolades_bullets_2_accolades_sub_bullets', ''),
(739, 128, '_accolades_3_accolades_bullets_2_accolades_sub_bullets', 'field_5b96ec59d59d8'),
(740, 128, 'accolades_3_accolades_bullets_3_accolades_bullet', 'Featured in Milwaukee Sentinel as one of four top attorneys in the "Million Dollar Club."'),
(741, 128, '_accolades_3_accolades_bullets_3_accolades_bullet', 'field_5b96ec4cd59d7'),
(742, 128, 'accolades_3_accolades_bullets_3_accolades_sub_bullets', ''),
(743, 128, '_accolades_3_accolades_bullets_3_accolades_sub_bullets', 'field_5b96ec59d59d8'),
(744, 128, 'accolades_3_accolades_bullets_4_accolades_bullet', 'Named in "Super Lawyers" Magazine as one of the Top 10 Super Lawyers in Wisconsin'),
(745, 128, '_accolades_3_accolades_bullets_4_accolades_bullet', 'field_5b96ec4cd59d7'),
(746, 128, 'accolades_3_accolades_bullets_4_accolades_sub_bullets', ''),
(747, 128, '_accolades_3_accolades_bullets_4_accolades_sub_bullets', 'field_5b96ec59d59d8'),
(748, 128, 'accolades_3_accolades_bullets', '5'),
(749, 128, '_accolades_3_accolades_bullets', 'field_5b96ec0ad59d6'),
(750, 133, '_wp_attached_file', '2018/09/content1_logo_01.png'),
(751, 133, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:130;s:6:"height";i:130;s:4:"file";s:28:"2018/09/content1_logo_01.png";s:5:"sizes";a:0:{}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(752, 60, 'accolades_slider_title', 'Accolades'),
(753, 60, '_accolades_slider_title', 'field_5b97dd6a89d15'),
(754, 60, 'accolades_logos_0_accolade_logo', '133'),
(755, 60, '_accolades_logos_0_accolade_logo', 'field_5b97dd37a64e3'),
(756, 60, 'accolades_logos_1_accolade_logo', '133'),
(757, 60, '_accolades_logos_1_accolade_logo', 'field_5b97dd37a64e3'),
(758, 60, 'accolades_logos_2_accolade_logo', '133'),
(759, 60, '_accolades_logos_2_accolade_logo', 'field_5b97dd37a64e3') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(760, 60, 'accolades_logos_3_accolade_logo', '133'),
(761, 60, '_accolades_logos_3_accolade_logo', 'field_5b97dd37a64e3'),
(762, 60, 'accolades_logos_4_accolade_logo', '133'),
(763, 60, '_accolades_logos_4_accolade_logo', 'field_5b97dd37a64e3'),
(764, 60, 'accolades_logos_5_accolade_logo', '133'),
(765, 60, '_accolades_logos_5_accolade_logo', 'field_5b97dd37a64e3'),
(766, 60, 'accolades_logos', '6'),
(767, 60, '_accolades_logos', 'field_5b97dd2ea64e2'),
(768, 134, 'attorney_sub_header', 'Wisconsin Personal Injury Attorney'),
(769, 134, '_attorney_sub_header', 'field_5b96eb6fd59d2'),
(770, 134, 'attorney_image', '122'),
(771, 134, '_attorney_image', 'field_5b96eb78d59d3'),
(772, 134, 'accolades_0_accolades_title', 'professional memberships'),
(773, 134, '_accolades_0_accolades_title', 'field_5b96ebf2d59d5'),
(774, 134, 'accolades_0_accolades_bullets', '6'),
(775, 134, '_accolades_0_accolades_bullets', 'field_5b96ec0ad59d6'),
(776, 134, 'accolades', '4'),
(777, 134, '_accolades', 'field_5b96ebe8d59d4'),
(778, 134, 'accolades_0_accolades_bullets_0_accolades_bullet', 'Wisconsin Association for Justice'),
(779, 134, '_accolades_0_accolades_bullets_0_accolades_bullet', 'field_5b96ec4cd59d7'),
(780, 134, 'accolades_0_accolades_bullets_0_accolades_sub_bullets', ''),
(781, 134, '_accolades_0_accolades_bullets_0_accolades_sub_bullets', 'field_5b96ec59d59d8'),
(782, 134, 'accolades_0_accolades_bullets_1_accolades_bullet', 'American Association for Justice'),
(783, 134, '_accolades_0_accolades_bullets_1_accolades_bullet', 'field_5b96ec4cd59d7'),
(784, 134, 'accolades_0_accolades_bullets_1_accolades_sub_bullets', ''),
(785, 134, '_accolades_0_accolades_bullets_1_accolades_sub_bullets', 'field_5b96ec59d59d8'),
(786, 134, 'accolades_0_accolades_bullets_2_accolades_bullet', 'Chairman, DPT Litigation Committee, (ATLA) 1984-1986'),
(787, 134, '_accolades_0_accolades_bullets_2_accolades_bullet', 'field_5b96ec4cd59d7'),
(788, 134, 'accolades_0_accolades_bullets_2_accolades_sub_bullets', ''),
(789, 134, '_accolades_0_accolades_bullets_2_accolades_sub_bullets', 'field_5b96ec59d59d8'),
(790, 134, 'accolades_0_accolades_bullets_3_accolades_bullet', 'Member, Board of Directors, Aquatic Injury Safety Litigation Group, (ATLA) 1987-1990'),
(791, 134, '_accolades_0_accolades_bullets_3_accolades_bullet', 'field_5b96ec4cd59d7'),
(792, 134, 'accolades_0_accolades_bullets_3_accolades_sub_bullets', ''),
(793, 134, '_accolades_0_accolades_bullets_3_accolades_sub_bullets', 'field_5b96ec59d59d8'),
(794, 134, 'accolades_0_accolades_bullets_4_accolades_bullet', 'Diplomate, American Board of Professional Liability Attorneys. (Nationally Board Certified)'),
(795, 134, '_accolades_0_accolades_bullets_4_accolades_bullet', 'field_5b96ec4cd59d7'),
(796, 134, 'accolades_0_accolades_bullets_4_accolades_sub_bullets', ''),
(797, 134, '_accolades_0_accolades_bullets_4_accolades_sub_bullets', 'field_5b96ec59d59d8'),
(798, 134, 'accolades_0_accolades_bullets_5_accolades_bullet', 'Board Certified as Trial Attorney by the National Board of Trial Advocacy'),
(799, 134, '_accolades_0_accolades_bullets_5_accolades_bullet', 'field_5b96ec4cd59d7'),
(800, 134, 'accolades_0_accolades_bullets_5_accolades_sub_bullets', ''),
(801, 134, '_accolades_0_accolades_bullets_5_accolades_sub_bullets', 'field_5b96ec59d59d8'),
(802, 134, 'accolades_1_accolades_title', 'Admitted'),
(803, 134, '_accolades_1_accolades_title', 'field_5b96ebf2d59d5'),
(804, 134, 'accolades_1_accolades_bullets_0_accolades_bullet', '1972 Licensed to Practice Law in the State of Wisconsin'),
(805, 134, '_accolades_1_accolades_bullets_0_accolades_bullet', 'field_5b96ec4cd59d7'),
(806, 134, 'accolades_1_accolades_bullets_0_accolades_sub_bullets', ''),
(807, 134, '_accolades_1_accolades_bullets_0_accolades_sub_bullets', 'field_5b96ec59d59d8'),
(808, 134, 'accolades_1_accolades_bullets_1_accolades_bullet', '1972 Licensed to Practice Law in the following Federal Courts:'),
(809, 134, '_accolades_1_accolades_bullets_1_accolades_bullet', 'field_5b96ec4cd59d7'),
(810, 134, 'accolades_1_accolades_bullets_1_accolades_sub_bullets_0_accolades_sub_bullets', 'Eastern District Court for the State of Wisconsin'),
(811, 134, '_accolades_1_accolades_bullets_1_accolades_sub_bullets_0_accolades_sub_bullets', 'field_5b97d69f40931'),
(812, 134, 'accolades_1_accolades_bullets_1_accolades_sub_bullets_1_accolades_sub_bullets', 'Western District Court for the State of Wisconsin'),
(813, 134, '_accolades_1_accolades_bullets_1_accolades_sub_bullets_1_accolades_sub_bullets', 'field_5b97d69f40931'),
(814, 134, 'accolades_1_accolades_bullets_1_accolades_sub_bullets', '2'),
(815, 134, '_accolades_1_accolades_bullets_1_accolades_sub_bullets', 'field_5b96ec59d59d8'),
(816, 134, 'accolades_1_accolades_bullets_2_accolades_bullet', '1990 Licensed to Practice Law in the Supreme Court of the United States'),
(817, 134, '_accolades_1_accolades_bullets_2_accolades_bullet', 'field_5b96ec4cd59d7'),
(818, 134, 'accolades_1_accolades_bullets_2_accolades_sub_bullets', ''),
(819, 134, '_accolades_1_accolades_bullets_2_accolades_sub_bullets', 'field_5b96ec59d59d8'),
(820, 134, 'accolades_1_accolades_bullets_3_accolades_bullet', '1999 Licensed to Practice Law in the Seventh Circuit Court of Appeals'),
(821, 134, '_accolades_1_accolades_bullets_3_accolades_bullet', 'field_5b96ec4cd59d7'),
(822, 134, 'accolades_1_accolades_bullets_3_accolades_sub_bullets', ''),
(823, 134, '_accolades_1_accolades_bullets_3_accolades_sub_bullets', 'field_5b96ec59d59d8'),
(824, 134, 'accolades_1_accolades_bullets', '4'),
(825, 134, '_accolades_1_accolades_bullets', 'field_5b96ec0ad59d6'),
(826, 134, 'accolades_2_accolades_title', 'Education'),
(827, 134, '_accolades_2_accolades_title', 'field_5b96ebf2d59d5'),
(828, 134, 'accolades_2_accolades_bullets_0_accolades_bullet', '1972 Licensed to Practice Law in the State of Wisconsin'),
(829, 134, '_accolades_2_accolades_bullets_0_accolades_bullet', 'field_5b96ec4cd59d7'),
(830, 134, 'accolades_2_accolades_bullets_0_accolades_sub_bullets', ''),
(831, 134, '_accolades_2_accolades_bullets_0_accolades_sub_bullets', 'field_5b96ec59d59d8'),
(832, 134, 'accolades_2_accolades_bullets_1_accolades_bullet', 'University of Paris, France'),
(833, 134, '_accolades_2_accolades_bullets_1_accolades_bullet', 'field_5b96ec4cd59d7'),
(834, 134, 'accolades_2_accolades_bullets_1_accolades_sub_bullets', ''),
(835, 134, '_accolades_2_accolades_bullets_1_accolades_sub_bullets', 'field_5b96ec59d59d8'),
(836, 134, 'accolades_2_accolades_bullets_2_accolades_bullet', 'National University of Ireland, Ireland'),
(837, 134, '_accolades_2_accolades_bullets_2_accolades_bullet', 'field_5b96ec4cd59d7'),
(838, 134, 'accolades_2_accolades_bullets_2_accolades_sub_bullets', ''),
(839, 134, '_accolades_2_accolades_bullets_2_accolades_sub_bullets', 'field_5b96ec59d59d8'),
(840, 134, 'accolades_2_accolades_bullets_3_accolades_bullet', 'Marquette University (A.B., 1969)'),
(841, 134, '_accolades_2_accolades_bullets_3_accolades_bullet', 'field_5b96ec4cd59d7'),
(842, 134, 'accolades_2_accolades_bullets_3_accolades_sub_bullets', ''),
(843, 134, '_accolades_2_accolades_bullets_3_accolades_sub_bullets', 'field_5b96ec59d59d8'),
(844, 134, 'accolades_2_accolades_bullets_4_accolades_bullet', 'University of Wisconsin-Madison Law School (J.D., 1972)'),
(845, 134, '_accolades_2_accolades_bullets_4_accolades_bullet', 'field_5b96ec4cd59d7'),
(846, 134, 'accolades_2_accolades_bullets_4_accolades_sub_bullets', ''),
(847, 134, '_accolades_2_accolades_bullets_4_accolades_sub_bullets', 'field_5b96ec59d59d8'),
(848, 134, 'accolades_2_accolades_bullets', '5'),
(849, 134, '_accolades_2_accolades_bullets', 'field_5b96ec0ad59d6'),
(850, 134, 'accolades_3_accolades_title', 'Accomplishments'),
(851, 134, '_accolades_3_accolades_title', 'field_5b96ebf2d59d5'),
(852, 134, 'accolades_3_accolades_bullets_0_accolades_bullet', 'Multiple million dollar personal injury awards.'),
(853, 134, '_accolades_3_accolades_bullets_0_accolades_bullet', 'field_5b96ec4cd59d7'),
(854, 134, 'accolades_3_accolades_bullets_0_accolades_sub_bullets', ''),
(855, 134, '_accolades_3_accolades_bullets_0_accolades_sub_bullets', 'field_5b96ec59d59d8'),
(856, 134, 'accolades_3_accolades_bullets_1_accolades_bullet', 'Listed in the June, 1990 issue of Milwaukee Magazine as the top personal injury trial attorney in Milwaukee.'),
(857, 134, '_accolades_3_accolades_bullets_1_accolades_bullet', 'field_5b96ec4cd59d7'),
(858, 134, 'accolades_3_accolades_bullets_1_accolades_sub_bullets', ''),
(859, 134, '_accolades_3_accolades_bullets_1_accolades_sub_bullets', 'field_5b96ec59d59d8') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(860, 134, 'accolades_3_accolades_bullets_2_accolades_bullet', 'Continuously Listed in The Best Lawyers in America for Over 25 Consecutive Years'),
(861, 134, '_accolades_3_accolades_bullets_2_accolades_bullet', 'field_5b96ec4cd59d7'),
(862, 134, 'accolades_3_accolades_bullets_2_accolades_sub_bullets', ''),
(863, 134, '_accolades_3_accolades_bullets_2_accolades_sub_bullets', 'field_5b96ec59d59d8'),
(864, 134, 'accolades_3_accolades_bullets_3_accolades_bullet', 'Featured in Milwaukee Sentinel as one of four top attorneys in the "Million Dollar Club."'),
(865, 134, '_accolades_3_accolades_bullets_3_accolades_bullet', 'field_5b96ec4cd59d7'),
(866, 134, 'accolades_3_accolades_bullets_3_accolades_sub_bullets', ''),
(867, 134, '_accolades_3_accolades_bullets_3_accolades_sub_bullets', 'field_5b96ec59d59d8'),
(868, 134, 'accolades_3_accolades_bullets_4_accolades_bullet', 'Named in "Super Lawyers" Magazine as one of the Top 10 Super Lawyers in Wisconsin'),
(869, 134, '_accolades_3_accolades_bullets_4_accolades_bullet', 'field_5b96ec4cd59d7'),
(870, 134, 'accolades_3_accolades_bullets_4_accolades_sub_bullets', ''),
(871, 134, '_accolades_3_accolades_bullets_4_accolades_sub_bullets', 'field_5b96ec59d59d8'),
(872, 134, 'accolades_3_accolades_bullets', '5'),
(873, 134, '_accolades_3_accolades_bullets', 'field_5b96ec0ad59d6'),
(874, 134, 'accolades_slider_title', 'Accolades'),
(875, 134, '_accolades_slider_title', 'field_5b97dd6a89d15'),
(876, 134, 'accolades_logos_0_accolade_logo', '133'),
(877, 134, '_accolades_logos_0_accolade_logo', 'field_5b97dd37a64e3'),
(878, 134, 'accolades_logos_1_accolade_logo', '133'),
(879, 134, '_accolades_logos_1_accolade_logo', 'field_5b97dd37a64e3'),
(880, 134, 'accolades_logos_2_accolade_logo', '133'),
(881, 134, '_accolades_logos_2_accolade_logo', 'field_5b97dd37a64e3'),
(882, 134, 'accolades_logos_3_accolade_logo', '133'),
(883, 134, '_accolades_logos_3_accolade_logo', 'field_5b97dd37a64e3'),
(884, 134, 'accolades_logos_4_accolade_logo', '133'),
(885, 134, '_accolades_logos_4_accolade_logo', 'field_5b97dd37a64e3'),
(886, 134, 'accolades_logos_5_accolade_logo', '133'),
(887, 134, '_accolades_logos_5_accolade_logo', 'field_5b97dd37a64e3'),
(888, 134, 'accolades_logos', '6'),
(889, 134, '_accolades_logos', 'field_5b97dd2ea64e2'),
(890, 136, '_edit_last', '1'),
(891, 136, '_edit_lock', '1536686375:1'),
(892, 138, '_edit_last', '1'),
(893, 138, '_edit_lock', '1536682580:1'),
(894, 138, '_wp_page_template', 'template-bio.php'),
(895, 138, 'attorney_sub_header', ''),
(896, 138, '_attorney_sub_header', 'field_5b96eb6fd59d2'),
(897, 138, 'attorney_image', '122'),
(898, 138, '_attorney_image', 'field_5b96eb78d59d3'),
(899, 138, 'accolades', ''),
(900, 138, '_accolades', 'field_5b96ebe8d59d4'),
(901, 138, 'accolades_slider_title', ''),
(902, 138, '_accolades_slider_title', 'field_5b97dd6a89d15'),
(903, 138, 'accolades_logos', ''),
(904, 138, '_accolades_logos', 'field_5b97dd2ea64e2'),
(905, 139, 'attorney_sub_header', ''),
(906, 139, '_attorney_sub_header', 'field_5b96eb6fd59d2'),
(907, 139, 'attorney_image', '122'),
(908, 139, '_attorney_image', 'field_5b96eb78d59d3'),
(909, 139, 'accolades', ''),
(910, 139, '_accolades', 'field_5b96ebe8d59d4'),
(911, 139, 'accolades_slider_title', ''),
(912, 139, '_accolades_slider_title', 'field_5b97dd6a89d15'),
(913, 139, 'accolades_logos', ''),
(914, 139, '_accolades_logos', 'field_5b97dd2ea64e2'),
(915, 140, '_edit_last', '1'),
(916, 140, '_edit_lock', '1536682671:1'),
(917, 141, '_wp_attached_file', '2018/09/AP_img_AlFoeckler.jpg'),
(918, 141, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:315;s:6:"height";i:425;s:4:"file";s:29:"2018/09/AP_img_AlFoeckler.jpg";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:29:"AP_img_AlFoeckler-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:29:"AP_img_AlFoeckler-222x300.jpg";s:5:"width";i:222;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(919, 142, '_wp_attached_file', '2018/09/AP_img_BrettEckstein.jpg'),
(920, 142, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:315;s:6:"height";i:425;s:4:"file";s:32:"2018/09/AP_img_BrettEckstein.jpg";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:32:"AP_img_BrettEckstein-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:32:"AP_img_BrettEckstein-222x300.jpg";s:5:"width";i:222;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(921, 143, '_wp_attached_file', '2018/09/AP_img_EdwardRobinson.jpg'),
(922, 143, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:315;s:6:"height";i:425;s:4:"file";s:33:"2018/09/AP_img_EdwardRobinson.jpg";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:33:"AP_img_EdwardRobinson-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:33:"AP_img_EdwardRobinson-222x300.jpg";s:5:"width";i:222;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(923, 144, '_wp_attached_file', '2018/09/AP_img_JoshMinon.jpg'),
(924, 144, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:315;s:6:"height";i:425;s:4:"file";s:28:"2018/09/AP_img_JoshMinon.jpg";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:28:"AP_img_JoshMinon-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:28:"AP_img_JoshMinon-222x300.jpg";s:5:"width";i:222;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(925, 145, '_wp_attached_file', '2018/09/AP_img_MichaelCeriak.jpg'),
(926, 145, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:315;s:6:"height";i:425;s:4:"file";s:32:"2018/09/AP_img_MichaelCeriak.jpg";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:32:"AP_img_MichaelCeriak-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:32:"AP_img_MichaelCeriak-222x300.jpg";s:5:"width";i:222;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(927, 146, '_wp_attached_file', '2018/09/AP_img_RachelPotter.jpg'),
(928, 146, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:315;s:6:"height";i:425;s:4:"file";s:31:"2018/09/AP_img_RachelPotter.jpg";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:31:"AP_img_RachelPotter-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:31:"AP_img_RachelPotter-222x300.jpg";s:5:"width";i:222;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(929, 147, '_wp_attached_file', '2018/09/AP_img_RobertCrivello.jpg'),
(930, 147, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:315;s:6:"height";i:425;s:4:"file";s:33:"2018/09/AP_img_RobertCrivello.jpg";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:33:"AP_img_RobertCrivello-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:33:"AP_img_RobertCrivello-222x300.jpg";s:5:"width";i:222;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(931, 148, '_wp_attached_file', '2018/09/AP_img_SarahKass.jpg'),
(932, 148, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:315;s:6:"height";i:425;s:4:"file";s:28:"2018/09/AP_img_SarahKass.jpg";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:28:"AP_img_SarahKass-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:28:"AP_img_SarahKass-222x300.jpg";s:5:"width";i:222;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(933, 140, '_wp_page_template', 'template-bio.php'),
(934, 140, 'attorney_sub_header', ''),
(935, 140, '_attorney_sub_header', 'field_5b96eb6fd59d2'),
(936, 140, 'attorney_image', '143'),
(937, 140, '_attorney_image', 'field_5b96eb78d59d3'),
(938, 140, 'accolades', ''),
(939, 140, '_accolades', 'field_5b96ebe8d59d4'),
(940, 140, 'accolades_slider_title', ''),
(941, 140, '_accolades_slider_title', 'field_5b97dd6a89d15'),
(942, 140, 'accolades_logos', ''),
(943, 140, '_accolades_logos', 'field_5b97dd2ea64e2'),
(944, 149, 'attorney_sub_header', ''),
(945, 149, '_attorney_sub_header', 'field_5b96eb6fd59d2'),
(946, 149, 'attorney_image', '143'),
(947, 149, '_attorney_image', 'field_5b96eb78d59d3'),
(948, 149, 'accolades', ''),
(949, 149, '_accolades', 'field_5b96ebe8d59d4'),
(950, 149, 'accolades_slider_title', ''),
(951, 149, '_accolades_slider_title', 'field_5b97dd6a89d15'),
(952, 149, 'accolades_logos', ''),
(953, 149, '_accolades_logos', 'field_5b97dd2ea64e2'),
(954, 150, '_edit_last', '1'),
(955, 150, '_edit_lock', '1536682703:1'),
(956, 150, '_wp_page_template', 'template-bio.php'),
(957, 150, 'attorney_sub_header', ''),
(958, 150, '_attorney_sub_header', 'field_5b96eb6fd59d2'),
(959, 150, 'attorney_image', '148') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(960, 150, '_attorney_image', 'field_5b96eb78d59d3'),
(961, 150, 'accolades', ''),
(962, 150, '_accolades', 'field_5b96ebe8d59d4'),
(963, 150, 'accolades_slider_title', ''),
(964, 150, '_accolades_slider_title', 'field_5b97dd6a89d15'),
(965, 150, 'accolades_logos', ''),
(966, 150, '_accolades_logos', 'field_5b97dd2ea64e2'),
(967, 151, 'attorney_sub_header', ''),
(968, 151, '_attorney_sub_header', 'field_5b96eb6fd59d2'),
(969, 151, 'attorney_image', '148'),
(970, 151, '_attorney_image', 'field_5b96eb78d59d3'),
(971, 151, 'accolades', ''),
(972, 151, '_accolades', 'field_5b96ebe8d59d4'),
(973, 151, 'accolades_slider_title', ''),
(974, 151, '_accolades_slider_title', 'field_5b97dd6a89d15'),
(975, 151, 'accolades_logos', ''),
(976, 151, '_accolades_logos', 'field_5b97dd2ea64e2'),
(977, 152, '_edit_last', '1'),
(978, 152, '_edit_lock', '1536682767:1'),
(979, 152, '_wp_page_template', 'template-bio.php'),
(980, 152, 'attorney_sub_header', ''),
(981, 152, '_attorney_sub_header', 'field_5b96eb6fd59d2'),
(982, 152, 'attorney_image', '141'),
(983, 152, '_attorney_image', 'field_5b96eb78d59d3'),
(984, 152, 'accolades', ''),
(985, 152, '_accolades', 'field_5b96ebe8d59d4'),
(986, 152, 'accolades_slider_title', ''),
(987, 152, '_accolades_slider_title', 'field_5b97dd6a89d15'),
(988, 152, 'accolades_logos', ''),
(989, 152, '_accolades_logos', 'field_5b97dd2ea64e2'),
(990, 153, 'attorney_sub_header', ''),
(991, 153, '_attorney_sub_header', 'field_5b96eb6fd59d2'),
(992, 153, 'attorney_image', '141'),
(993, 153, '_attorney_image', 'field_5b96eb78d59d3'),
(994, 153, 'accolades', ''),
(995, 153, '_accolades', 'field_5b96ebe8d59d4'),
(996, 153, 'accolades_slider_title', ''),
(997, 153, '_accolades_slider_title', 'field_5b97dd6a89d15'),
(998, 153, 'accolades_logos', ''),
(999, 153, '_accolades_logos', 'field_5b97dd2ea64e2'),
(1000, 154, '_edit_last', '1'),
(1001, 154, '_edit_lock', '1536682836:1'),
(1002, 154, '_wp_page_template', 'template-bio.php'),
(1003, 154, 'attorney_sub_header', ''),
(1004, 154, '_attorney_sub_header', 'field_5b96eb6fd59d2'),
(1005, 154, 'attorney_image', '147'),
(1006, 154, '_attorney_image', 'field_5b96eb78d59d3'),
(1007, 154, 'accolades', ''),
(1008, 154, '_accolades', 'field_5b96ebe8d59d4'),
(1009, 154, 'accolades_slider_title', ''),
(1010, 154, '_accolades_slider_title', 'field_5b97dd6a89d15'),
(1011, 154, 'accolades_logos', ''),
(1012, 154, '_accolades_logos', 'field_5b97dd2ea64e2'),
(1013, 155, 'attorney_sub_header', ''),
(1014, 155, '_attorney_sub_header', 'field_5b96eb6fd59d2'),
(1015, 155, 'attorney_image', '147'),
(1016, 155, '_attorney_image', 'field_5b96eb78d59d3'),
(1017, 155, 'accolades', ''),
(1018, 155, '_accolades', 'field_5b96ebe8d59d4'),
(1019, 155, 'accolades_slider_title', ''),
(1020, 155, '_accolades_slider_title', 'field_5b97dd6a89d15'),
(1021, 155, 'accolades_logos', ''),
(1022, 155, '_accolades_logos', 'field_5b97dd2ea64e2'),
(1023, 156, '_edit_last', '1'),
(1024, 156, '_edit_lock', '1536682852:1'),
(1025, 156, '_wp_page_template', 'template-bio.php'),
(1026, 156, 'attorney_sub_header', ''),
(1027, 156, '_attorney_sub_header', 'field_5b96eb6fd59d2'),
(1028, 156, 'attorney_image', '142'),
(1029, 156, '_attorney_image', 'field_5b96eb78d59d3'),
(1030, 156, 'accolades', ''),
(1031, 156, '_accolades', 'field_5b96ebe8d59d4'),
(1032, 156, 'accolades_slider_title', ''),
(1033, 156, '_accolades_slider_title', 'field_5b97dd6a89d15'),
(1034, 156, 'accolades_logos', ''),
(1035, 156, '_accolades_logos', 'field_5b97dd2ea64e2'),
(1036, 157, 'attorney_sub_header', ''),
(1037, 157, '_attorney_sub_header', 'field_5b96eb6fd59d2'),
(1038, 157, 'attorney_image', '142'),
(1039, 157, '_attorney_image', 'field_5b96eb78d59d3'),
(1040, 157, 'accolades', ''),
(1041, 157, '_accolades', 'field_5b96ebe8d59d4'),
(1042, 157, 'accolades_slider_title', ''),
(1043, 157, '_accolades_slider_title', 'field_5b97dd6a89d15'),
(1044, 157, 'accolades_logos', ''),
(1045, 157, '_accolades_logos', 'field_5b97dd2ea64e2'),
(1046, 158, '_edit_last', '1'),
(1047, 158, '_edit_lock', '1536682914:1'),
(1048, 158, '_wp_page_template', 'template-bio.php'),
(1049, 158, 'attorney_sub_header', ''),
(1050, 158, '_attorney_sub_header', 'field_5b96eb6fd59d2'),
(1051, 158, 'attorney_image', '144'),
(1052, 158, '_attorney_image', 'field_5b96eb78d59d3'),
(1053, 158, 'accolades', ''),
(1054, 158, '_accolades', 'field_5b96ebe8d59d4'),
(1055, 158, 'accolades_slider_title', ''),
(1056, 158, '_accolades_slider_title', 'field_5b97dd6a89d15'),
(1057, 158, 'accolades_logos', ''),
(1058, 158, '_accolades_logos', 'field_5b97dd2ea64e2'),
(1059, 159, 'attorney_sub_header', '') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(1060, 159, '_attorney_sub_header', 'field_5b96eb6fd59d2'),
(1061, 159, 'attorney_image', '144'),
(1062, 159, '_attorney_image', 'field_5b96eb78d59d3'),
(1063, 159, 'accolades', ''),
(1064, 159, '_accolades', 'field_5b96ebe8d59d4'),
(1065, 159, 'accolades_slider_title', ''),
(1066, 159, '_accolades_slider_title', 'field_5b97dd6a89d15'),
(1067, 159, 'accolades_logos', ''),
(1068, 159, '_accolades_logos', 'field_5b97dd2ea64e2'),
(1069, 160, '_edit_last', '1'),
(1070, 160, '_edit_lock', '1536682964:1'),
(1071, 160, '_wp_page_template', 'template-bio.php'),
(1072, 160, 'attorney_sub_header', ''),
(1073, 160, '_attorney_sub_header', 'field_5b96eb6fd59d2'),
(1074, 160, 'attorney_image', '145'),
(1075, 160, '_attorney_image', 'field_5b96eb78d59d3'),
(1076, 160, 'accolades', ''),
(1077, 160, '_accolades', 'field_5b96ebe8d59d4'),
(1078, 160, 'accolades_slider_title', ''),
(1079, 160, '_accolades_slider_title', 'field_5b97dd6a89d15'),
(1080, 160, 'accolades_logos', ''),
(1081, 160, '_accolades_logos', 'field_5b97dd2ea64e2'),
(1082, 161, 'attorney_sub_header', ''),
(1083, 161, '_attorney_sub_header', 'field_5b96eb6fd59d2'),
(1084, 161, 'attorney_image', '145'),
(1085, 161, '_attorney_image', 'field_5b96eb78d59d3'),
(1086, 161, 'accolades', ''),
(1087, 161, '_accolades', 'field_5b96ebe8d59d4'),
(1088, 161, 'accolades_slider_title', ''),
(1089, 161, '_accolades_slider_title', 'field_5b97dd6a89d15'),
(1090, 161, 'accolades_logos', ''),
(1091, 161, '_accolades_logos', 'field_5b97dd2ea64e2'),
(1092, 162, '_edit_last', '1'),
(1093, 162, '_wp_page_template', 'template-bio.php'),
(1094, 162, 'attorney_sub_header', ''),
(1095, 162, '_attorney_sub_header', 'field_5b96eb6fd59d2'),
(1096, 162, 'attorney_image', '146'),
(1097, 162, '_attorney_image', 'field_5b96eb78d59d3'),
(1098, 162, 'accolades', ''),
(1099, 162, '_accolades', 'field_5b96ebe8d59d4'),
(1100, 162, 'accolades_slider_title', ''),
(1101, 162, '_accolades_slider_title', 'field_5b97dd6a89d15'),
(1102, 162, 'accolades_logos', ''),
(1103, 162, '_accolades_logos', 'field_5b97dd2ea64e2'),
(1104, 163, 'attorney_sub_header', ''),
(1105, 163, '_attorney_sub_header', 'field_5b96eb6fd59d2'),
(1106, 163, 'attorney_image', '146'),
(1107, 163, '_attorney_image', 'field_5b96eb78d59d3'),
(1108, 163, 'accolades', ''),
(1109, 163, '_accolades', 'field_5b96ebe8d59d4'),
(1110, 163, 'accolades_slider_title', ''),
(1111, 163, '_accolades_slider_title', 'field_5b97dd6a89d15'),
(1112, 163, 'accolades_logos', ''),
(1113, 163, '_accolades_logos', 'field_5b97dd2ea64e2'),
(1114, 162, '_edit_lock', '1536682985:1'),
(1115, 79, 'attorney_directory', '9'),
(1116, 79, '_attorney_directory', 'field_5b97ede6fef40'),
(1117, 164, 'attorney_directory', 'a:10:{i:0;s:2:"60";i:1;s:3:"138";i:2;s:3:"140";i:3;s:3:"150";i:4;s:3:"152";i:5;s:3:"154";i:6;s:3:"156";i:7;s:3:"158";i:8;s:3:"160";i:9;s:3:"162";}'),
(1118, 164, '_attorney_directory', 'field_5b97ea3662875'),
(1119, 79, 'attorney_directory_0_attorney_page_info', '60'),
(1120, 79, '_attorney_directory_0_attorney_page_info', 'field_5b97ee16fef42'),
(1121, 79, 'attorney_directory_0_attorney_position', 'Founder'),
(1122, 79, '_attorney_directory_0_attorney_position', 'field_5b97edf9fef41'),
(1123, 79, 'attorney_directory_1_attorney_page_info', '138'),
(1124, 79, '_attorney_directory_1_attorney_page_info', 'field_5b97ee16fef42'),
(1125, 79, 'attorney_directory_1_attorney_position', 'Co-Founder'),
(1126, 79, '_attorney_directory_1_attorney_position', 'field_5b97edf9fef41'),
(1127, 79, 'attorney_directory_2_attorney_page_info', '150'),
(1128, 79, '_attorney_directory_2_attorney_page_info', 'field_5b97ee16fef42'),
(1129, 79, 'attorney_directory_2_attorney_position', 'Attorney'),
(1130, 79, '_attorney_directory_2_attorney_position', 'field_5b97edf9fef41'),
(1131, 168, 'attorney_directory', '3'),
(1132, 168, '_attorney_directory', 'field_5b97ede6fef40'),
(1133, 168, 'attorney_directory_0_attorney_page_info', '60'),
(1134, 168, '_attorney_directory_0_attorney_page_info', 'field_5b97ee16fef42'),
(1135, 168, 'attorney_directory_0_attorney_position', 'Founder'),
(1136, 168, '_attorney_directory_0_attorney_position', 'field_5b97edf9fef41'),
(1137, 168, 'attorney_directory_1_attorney_page_info', '138'),
(1138, 168, '_attorney_directory_1_attorney_page_info', 'field_5b97ee16fef42'),
(1139, 168, 'attorney_directory_1_attorney_position', 'Co-Founder'),
(1140, 168, '_attorney_directory_1_attorney_position', 'field_5b97edf9fef41'),
(1141, 168, 'attorney_directory_2_attorney_page_info', '150'),
(1142, 168, '_attorney_directory_2_attorney_page_info', 'field_5b97ee16fef42'),
(1143, 168, 'attorney_directory_2_attorney_position', 'Attorney'),
(1144, 168, '_attorney_directory_2_attorney_position', 'field_5b97edf9fef41'),
(1145, 79, 'attorney_directory_3_attorney_page_info', '152'),
(1146, 79, '_attorney_directory_3_attorney_page_info', 'field_5b97ee16fef42'),
(1147, 79, 'attorney_directory_3_attorney_position', 'Lawyer'),
(1148, 79, '_attorney_directory_3_attorney_position', 'field_5b97edf9fef41'),
(1149, 79, 'attorney_directory_4_attorney_page_info', '154'),
(1150, 79, '_attorney_directory_4_attorney_page_info', 'field_5b97ee16fef42'),
(1151, 79, 'attorney_directory_4_attorney_position', 'Lawyer'),
(1152, 79, '_attorney_directory_4_attorney_position', 'field_5b97edf9fef41'),
(1153, 79, 'attorney_directory_5_attorney_page_info', '156'),
(1154, 79, '_attorney_directory_5_attorney_page_info', 'field_5b97ee16fef42'),
(1155, 79, 'attorney_directory_5_attorney_position', 'Lawyer'),
(1156, 79, '_attorney_directory_5_attorney_position', 'field_5b97edf9fef41'),
(1157, 79, 'attorney_directory_6_attorney_page_info', '158'),
(1158, 79, '_attorney_directory_6_attorney_page_info', 'field_5b97ee16fef42'),
(1159, 79, 'attorney_directory_6_attorney_position', 'Lawyer') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(1160, 79, '_attorney_directory_6_attorney_position', 'field_5b97edf9fef41'),
(1161, 79, 'attorney_directory_7_attorney_page_info', '160'),
(1162, 79, '_attorney_directory_7_attorney_page_info', 'field_5b97ee16fef42'),
(1163, 79, 'attorney_directory_7_attorney_position', 'Attorney'),
(1164, 79, '_attorney_directory_7_attorney_position', 'field_5b97edf9fef41'),
(1165, 79, 'attorney_directory_8_attorney_page_info', '162'),
(1166, 79, '_attorney_directory_8_attorney_page_info', 'field_5b97ee16fef42'),
(1167, 79, 'attorney_directory_8_attorney_position', 'Attorney'),
(1168, 79, '_attorney_directory_8_attorney_position', 'field_5b97edf9fef41'),
(1169, 169, 'attorney_directory', '9'),
(1170, 169, '_attorney_directory', 'field_5b97ede6fef40'),
(1171, 169, 'attorney_directory_0_attorney_page_info', '60'),
(1172, 169, '_attorney_directory_0_attorney_page_info', 'field_5b97ee16fef42'),
(1173, 169, 'attorney_directory_0_attorney_position', 'Founder'),
(1174, 169, '_attorney_directory_0_attorney_position', 'field_5b97edf9fef41'),
(1175, 169, 'attorney_directory_1_attorney_page_info', '138'),
(1176, 169, '_attorney_directory_1_attorney_page_info', 'field_5b97ee16fef42'),
(1177, 169, 'attorney_directory_1_attorney_position', 'Co-Founder'),
(1178, 169, '_attorney_directory_1_attorney_position', 'field_5b97edf9fef41'),
(1179, 169, 'attorney_directory_2_attorney_page_info', '150'),
(1180, 169, '_attorney_directory_2_attorney_page_info', 'field_5b97ee16fef42'),
(1181, 169, 'attorney_directory_2_attorney_position', 'Attorney'),
(1182, 169, '_attorney_directory_2_attorney_position', 'field_5b97edf9fef41'),
(1183, 169, 'attorney_directory_3_attorney_page_info', '152'),
(1184, 169, '_attorney_directory_3_attorney_page_info', 'field_5b97ee16fef42'),
(1185, 169, 'attorney_directory_3_attorney_position', 'Lawyer'),
(1186, 169, '_attorney_directory_3_attorney_position', 'field_5b97edf9fef41'),
(1187, 169, 'attorney_directory_4_attorney_page_info', '154'),
(1188, 169, '_attorney_directory_4_attorney_page_info', 'field_5b97ee16fef42'),
(1189, 169, 'attorney_directory_4_attorney_position', 'Lawyer'),
(1190, 169, '_attorney_directory_4_attorney_position', 'field_5b97edf9fef41'),
(1191, 169, 'attorney_directory_5_attorney_page_info', '156'),
(1192, 169, '_attorney_directory_5_attorney_page_info', 'field_5b97ee16fef42'),
(1193, 169, 'attorney_directory_5_attorney_position', 'Lawyer'),
(1194, 169, '_attorney_directory_5_attorney_position', 'field_5b97edf9fef41'),
(1195, 169, 'attorney_directory_6_attorney_page_info', '158'),
(1196, 169, '_attorney_directory_6_attorney_page_info', 'field_5b97ee16fef42'),
(1197, 169, 'attorney_directory_6_attorney_position', 'Lawyer'),
(1198, 169, '_attorney_directory_6_attorney_position', 'field_5b97edf9fef41'),
(1199, 169, 'attorney_directory_7_attorney_page_info', '160'),
(1200, 169, '_attorney_directory_7_attorney_page_info', 'field_5b97ee16fef42'),
(1201, 169, 'attorney_directory_7_attorney_position', 'Attorney'),
(1202, 169, '_attorney_directory_7_attorney_position', 'field_5b97edf9fef41'),
(1203, 169, 'attorney_directory_8_attorney_page_info', '162'),
(1204, 169, '_attorney_directory_8_attorney_page_info', 'field_5b97ee16fef42'),
(1205, 169, 'attorney_directory_8_attorney_position', 'Attorney'),
(1206, 169, '_attorney_directory_8_attorney_position', 'field_5b97edf9fef41'),
(1207, 170, '_wp_attached_file', '2018/09/AP_img_WilliamCannon.jpg'),
(1208, 170, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:315;s:6:"height";i:425;s:4:"file";s:32:"2018/09/AP_img_WilliamCannon.jpg";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:32:"AP_img_WilliamCannon-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:32:"AP_img_WilliamCannon-222x300.jpg";s:5:"width";i:222;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(1209, 171, 'attorney_sub_header', 'Wisconsin Personal Injury Attorney'),
(1210, 171, '_attorney_sub_header', 'field_5b96eb6fd59d2'),
(1211, 171, 'attorney_image', '170'),
(1212, 171, '_attorney_image', 'field_5b96eb78d59d3'),
(1213, 171, 'accolades_0_accolades_title', 'professional memberships'),
(1214, 171, '_accolades_0_accolades_title', 'field_5b96ebf2d59d5'),
(1215, 171, 'accolades_0_accolades_bullets', '6'),
(1216, 171, '_accolades_0_accolades_bullets', 'field_5b96ec0ad59d6'),
(1217, 171, 'accolades', '4'),
(1218, 171, '_accolades', 'field_5b96ebe8d59d4'),
(1219, 171, 'accolades_0_accolades_bullets_0_accolades_bullet', 'Wisconsin Association for Justice'),
(1220, 171, '_accolades_0_accolades_bullets_0_accolades_bullet', 'field_5b96ec4cd59d7'),
(1221, 171, 'accolades_0_accolades_bullets_0_accolades_sub_bullets', ''),
(1222, 171, '_accolades_0_accolades_bullets_0_accolades_sub_bullets', 'field_5b96ec59d59d8'),
(1223, 171, 'accolades_0_accolades_bullets_1_accolades_bullet', 'American Association for Justice'),
(1224, 171, '_accolades_0_accolades_bullets_1_accolades_bullet', 'field_5b96ec4cd59d7'),
(1225, 171, 'accolades_0_accolades_bullets_1_accolades_sub_bullets', ''),
(1226, 171, '_accolades_0_accolades_bullets_1_accolades_sub_bullets', 'field_5b96ec59d59d8'),
(1227, 171, 'accolades_0_accolades_bullets_2_accolades_bullet', 'Chairman, DPT Litigation Committee, (ATLA) 1984-1986'),
(1228, 171, '_accolades_0_accolades_bullets_2_accolades_bullet', 'field_5b96ec4cd59d7'),
(1229, 171, 'accolades_0_accolades_bullets_2_accolades_sub_bullets', ''),
(1230, 171, '_accolades_0_accolades_bullets_2_accolades_sub_bullets', 'field_5b96ec59d59d8'),
(1231, 171, 'accolades_0_accolades_bullets_3_accolades_bullet', 'Member, Board of Directors, Aquatic Injury Safety Litigation Group, (ATLA) 1987-1990'),
(1232, 171, '_accolades_0_accolades_bullets_3_accolades_bullet', 'field_5b96ec4cd59d7'),
(1233, 171, 'accolades_0_accolades_bullets_3_accolades_sub_bullets', ''),
(1234, 171, '_accolades_0_accolades_bullets_3_accolades_sub_bullets', 'field_5b96ec59d59d8'),
(1235, 171, 'accolades_0_accolades_bullets_4_accolades_bullet', 'Diplomate, American Board of Professional Liability Attorneys. (Nationally Board Certified)'),
(1236, 171, '_accolades_0_accolades_bullets_4_accolades_bullet', 'field_5b96ec4cd59d7'),
(1237, 171, 'accolades_0_accolades_bullets_4_accolades_sub_bullets', ''),
(1238, 171, '_accolades_0_accolades_bullets_4_accolades_sub_bullets', 'field_5b96ec59d59d8'),
(1239, 171, 'accolades_0_accolades_bullets_5_accolades_bullet', 'Board Certified as Trial Attorney by the National Board of Trial Advocacy'),
(1240, 171, '_accolades_0_accolades_bullets_5_accolades_bullet', 'field_5b96ec4cd59d7'),
(1241, 171, 'accolades_0_accolades_bullets_5_accolades_sub_bullets', ''),
(1242, 171, '_accolades_0_accolades_bullets_5_accolades_sub_bullets', 'field_5b96ec59d59d8'),
(1243, 171, 'accolades_1_accolades_title', 'Admitted'),
(1244, 171, '_accolades_1_accolades_title', 'field_5b96ebf2d59d5'),
(1245, 171, 'accolades_1_accolades_bullets_0_accolades_bullet', '1972 Licensed to Practice Law in the State of Wisconsin'),
(1246, 171, '_accolades_1_accolades_bullets_0_accolades_bullet', 'field_5b96ec4cd59d7'),
(1247, 171, 'accolades_1_accolades_bullets_0_accolades_sub_bullets', ''),
(1248, 171, '_accolades_1_accolades_bullets_0_accolades_sub_bullets', 'field_5b96ec59d59d8'),
(1249, 171, 'accolades_1_accolades_bullets_1_accolades_bullet', '1972 Licensed to Practice Law in the following Federal Courts:'),
(1250, 171, '_accolades_1_accolades_bullets_1_accolades_bullet', 'field_5b96ec4cd59d7'),
(1251, 171, 'accolades_1_accolades_bullets_1_accolades_sub_bullets_0_accolades_sub_bullets', 'Eastern District Court for the State of Wisconsin'),
(1252, 171, '_accolades_1_accolades_bullets_1_accolades_sub_bullets_0_accolades_sub_bullets', 'field_5b97d69f40931'),
(1253, 171, 'accolades_1_accolades_bullets_1_accolades_sub_bullets_1_accolades_sub_bullets', 'Western District Court for the State of Wisconsin'),
(1254, 171, '_accolades_1_accolades_bullets_1_accolades_sub_bullets_1_accolades_sub_bullets', 'field_5b97d69f40931'),
(1255, 171, 'accolades_1_accolades_bullets_1_accolades_sub_bullets', '2'),
(1256, 171, '_accolades_1_accolades_bullets_1_accolades_sub_bullets', 'field_5b96ec59d59d8'),
(1257, 171, 'accolades_1_accolades_bullets_2_accolades_bullet', '1990 Licensed to Practice Law in the Supreme Court of the United States'),
(1258, 171, '_accolades_1_accolades_bullets_2_accolades_bullet', 'field_5b96ec4cd59d7'),
(1259, 171, 'accolades_1_accolades_bullets_2_accolades_sub_bullets', '') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(1260, 171, '_accolades_1_accolades_bullets_2_accolades_sub_bullets', 'field_5b96ec59d59d8'),
(1261, 171, 'accolades_1_accolades_bullets_3_accolades_bullet', '1999 Licensed to Practice Law in the Seventh Circuit Court of Appeals'),
(1262, 171, '_accolades_1_accolades_bullets_3_accolades_bullet', 'field_5b96ec4cd59d7'),
(1263, 171, 'accolades_1_accolades_bullets_3_accolades_sub_bullets', ''),
(1264, 171, '_accolades_1_accolades_bullets_3_accolades_sub_bullets', 'field_5b96ec59d59d8'),
(1265, 171, 'accolades_1_accolades_bullets', '4'),
(1266, 171, '_accolades_1_accolades_bullets', 'field_5b96ec0ad59d6'),
(1267, 171, 'accolades_2_accolades_title', 'Education'),
(1268, 171, '_accolades_2_accolades_title', 'field_5b96ebf2d59d5'),
(1269, 171, 'accolades_2_accolades_bullets_0_accolades_bullet', '1972 Licensed to Practice Law in the State of Wisconsin'),
(1270, 171, '_accolades_2_accolades_bullets_0_accolades_bullet', 'field_5b96ec4cd59d7'),
(1271, 171, 'accolades_2_accolades_bullets_0_accolades_sub_bullets', ''),
(1272, 171, '_accolades_2_accolades_bullets_0_accolades_sub_bullets', 'field_5b96ec59d59d8'),
(1273, 171, 'accolades_2_accolades_bullets_1_accolades_bullet', 'University of Paris, France'),
(1274, 171, '_accolades_2_accolades_bullets_1_accolades_bullet', 'field_5b96ec4cd59d7'),
(1275, 171, 'accolades_2_accolades_bullets_1_accolades_sub_bullets', ''),
(1276, 171, '_accolades_2_accolades_bullets_1_accolades_sub_bullets', 'field_5b96ec59d59d8'),
(1277, 171, 'accolades_2_accolades_bullets_2_accolades_bullet', 'National University of Ireland, Ireland'),
(1278, 171, '_accolades_2_accolades_bullets_2_accolades_bullet', 'field_5b96ec4cd59d7'),
(1279, 171, 'accolades_2_accolades_bullets_2_accolades_sub_bullets', ''),
(1280, 171, '_accolades_2_accolades_bullets_2_accolades_sub_bullets', 'field_5b96ec59d59d8'),
(1281, 171, 'accolades_2_accolades_bullets_3_accolades_bullet', 'Marquette University (A.B., 1969)'),
(1282, 171, '_accolades_2_accolades_bullets_3_accolades_bullet', 'field_5b96ec4cd59d7'),
(1283, 171, 'accolades_2_accolades_bullets_3_accolades_sub_bullets', ''),
(1284, 171, '_accolades_2_accolades_bullets_3_accolades_sub_bullets', 'field_5b96ec59d59d8'),
(1285, 171, 'accolades_2_accolades_bullets_4_accolades_bullet', 'University of Wisconsin-Madison Law School (J.D., 1972)'),
(1286, 171, '_accolades_2_accolades_bullets_4_accolades_bullet', 'field_5b96ec4cd59d7'),
(1287, 171, 'accolades_2_accolades_bullets_4_accolades_sub_bullets', ''),
(1288, 171, '_accolades_2_accolades_bullets_4_accolades_sub_bullets', 'field_5b96ec59d59d8'),
(1289, 171, 'accolades_2_accolades_bullets', '5'),
(1290, 171, '_accolades_2_accolades_bullets', 'field_5b96ec0ad59d6'),
(1291, 171, 'accolades_3_accolades_title', 'Accomplishments'),
(1292, 171, '_accolades_3_accolades_title', 'field_5b96ebf2d59d5'),
(1293, 171, 'accolades_3_accolades_bullets_0_accolades_bullet', 'Multiple million dollar personal injury awards.'),
(1294, 171, '_accolades_3_accolades_bullets_0_accolades_bullet', 'field_5b96ec4cd59d7'),
(1295, 171, 'accolades_3_accolades_bullets_0_accolades_sub_bullets', ''),
(1296, 171, '_accolades_3_accolades_bullets_0_accolades_sub_bullets', 'field_5b96ec59d59d8'),
(1297, 171, 'accolades_3_accolades_bullets_1_accolades_bullet', 'Listed in the June, 1990 issue of Milwaukee Magazine as the top personal injury trial attorney in Milwaukee.'),
(1298, 171, '_accolades_3_accolades_bullets_1_accolades_bullet', 'field_5b96ec4cd59d7'),
(1299, 171, 'accolades_3_accolades_bullets_1_accolades_sub_bullets', ''),
(1300, 171, '_accolades_3_accolades_bullets_1_accolades_sub_bullets', 'field_5b96ec59d59d8'),
(1301, 171, 'accolades_3_accolades_bullets_2_accolades_bullet', 'Continuously Listed in The Best Lawyers in America for Over 25 Consecutive Years'),
(1302, 171, '_accolades_3_accolades_bullets_2_accolades_bullet', 'field_5b96ec4cd59d7'),
(1303, 171, 'accolades_3_accolades_bullets_2_accolades_sub_bullets', ''),
(1304, 171, '_accolades_3_accolades_bullets_2_accolades_sub_bullets', 'field_5b96ec59d59d8'),
(1305, 171, 'accolades_3_accolades_bullets_3_accolades_bullet', 'Featured in Milwaukee Sentinel as one of four top attorneys in the "Million Dollar Club."'),
(1306, 171, '_accolades_3_accolades_bullets_3_accolades_bullet', 'field_5b96ec4cd59d7'),
(1307, 171, 'accolades_3_accolades_bullets_3_accolades_sub_bullets', ''),
(1308, 171, '_accolades_3_accolades_bullets_3_accolades_sub_bullets', 'field_5b96ec59d59d8'),
(1309, 171, 'accolades_3_accolades_bullets_4_accolades_bullet', 'Named in "Super Lawyers" Magazine as one of the Top 10 Super Lawyers in Wisconsin'),
(1310, 171, '_accolades_3_accolades_bullets_4_accolades_bullet', 'field_5b96ec4cd59d7'),
(1311, 171, 'accolades_3_accolades_bullets_4_accolades_sub_bullets', ''),
(1312, 171, '_accolades_3_accolades_bullets_4_accolades_sub_bullets', 'field_5b96ec59d59d8'),
(1313, 171, 'accolades_3_accolades_bullets', '5'),
(1314, 171, '_accolades_3_accolades_bullets', 'field_5b96ec0ad59d6'),
(1315, 171, 'accolades_slider_title', 'Accolades'),
(1316, 171, '_accolades_slider_title', 'field_5b97dd6a89d15'),
(1317, 171, 'accolades_logos_0_accolade_logo', '133'),
(1318, 171, '_accolades_logos_0_accolade_logo', 'field_5b97dd37a64e3'),
(1319, 171, 'accolades_logos_1_accolade_logo', '133'),
(1320, 171, '_accolades_logos_1_accolade_logo', 'field_5b97dd37a64e3'),
(1321, 171, 'accolades_logos_2_accolade_logo', '133'),
(1322, 171, '_accolades_logos_2_accolade_logo', 'field_5b97dd37a64e3'),
(1323, 171, 'accolades_logos_3_accolade_logo', '133'),
(1324, 171, '_accolades_logos_3_accolade_logo', 'field_5b97dd37a64e3'),
(1325, 171, 'accolades_logos_4_accolade_logo', '133'),
(1326, 171, '_accolades_logos_4_accolade_logo', 'field_5b97dd37a64e3'),
(1327, 171, 'accolades_logos_5_accolade_logo', '133'),
(1328, 171, '_accolades_logos_5_accolade_logo', 'field_5b97dd37a64e3'),
(1329, 171, 'accolades_logos', '6'),
(1330, 171, '_accolades_logos', 'field_5b97dd2ea64e2'),
(1331, 172, '_edit_last', '1'),
(1332, 172, '_edit_lock', '1536703745:1'),
(1333, 52, 'testimonials_column_one_0_testimonial_quote', '“We are Speechless for all your hard work and Education.”'),
(1334, 52, '_testimonials_column_one_0_testimonial_quote', 'field_5b97f9e997db0'),
(1335, 52, 'testimonials_column_one_0_testimonial_content', 'We are speechless for all your hard work and dedication…Thank you. For all of your professionalism and class…Thank you. For everything you’ve had to deal with and put up with…Thank you. For always keeping us informed every step of the way…Thank you. For putting your time and heart into your work for us…Thank you. For being such a kind, caring soul…Thank you.'),
(1336, 52, '_testimonials_column_one_0_testimonial_content', 'field_5b97fa1b97db1'),
(1337, 52, 'testimonials_column_one_0_name', 'Teri J.'),
(1338, 52, '_testimonials_column_one_0_name', 'field_5b97fa2897db2'),
(1339, 52, 'testimonials_column_one', '4'),
(1340, 52, '_testimonials_column_one', 'field_5b97f9d397daf'),
(1341, 52, 'testimonials_column_two_0_testimonial_quote', '“You have helped me through this process”'),
(1342, 52, '_testimonials_column_two_0_testimonial_quote', 'field_5b97fa3797db4'),
(1343, 52, 'testimonials_column_two_0_testimonial_content', 'I’m writing to let you know how much you have helped me through this process. It’s surely been a sad time for me but the way you helped me get through this made it better. The manner in which you get things done was the best for me. You took the time to explain in detail what was going on and if you could tell by my voice that I wasn’t understanding, you said it again with an example. You also gave me suggestions which I really listened to. I know you’d say you’re doing your job, but there are different ways to do that job.\r\nYou did it in a caring way.'),
(1344, 52, '_testimonials_column_two_0_testimonial_content', 'field_5b97fa3797db5'),
(1345, 52, 'testimonials_column_two_0_name', 'Kathy S.'),
(1346, 52, '_testimonials_column_two_0_name', 'field_5b97fa3797db6'),
(1347, 52, 'testimonials_column_two', '3'),
(1348, 52, '_testimonials_column_two', 'field_5b97fa3797db3'),
(1349, 181, 'testimonials_column_one_0_testimonial_quote', '“We are Speechless for all your hard work and Education.”'),
(1350, 181, '_testimonials_column_one_0_testimonial_quote', 'field_5b97f9e997db0'),
(1351, 181, 'testimonials_column_one_0_testimonial_content', 'We are speechless for all your hard work and dedication…Thank you. For all of your professionalism and class…Thank you. For everything you’ve had to deal with and put up with…Thank you. For always keeping us informed every step of the way…Thank you. For putting your time and heart into your work for us…Thank you. For being such a kind, caring soul…Thank you.'),
(1352, 181, '_testimonials_column_one_0_testimonial_content', 'field_5b97fa1b97db1'),
(1353, 181, 'testimonials_column_one_0_name', 'Teri J.'),
(1354, 181, '_testimonials_column_one_0_name', 'field_5b97fa2897db2'),
(1355, 181, 'testimonials_column_one', '1'),
(1356, 181, '_testimonials_column_one', 'field_5b97f9d397daf'),
(1357, 181, 'testimonials_column_two_0_testimonial_quote', '“You have helped me through this process”'),
(1358, 181, '_testimonials_column_two_0_testimonial_quote', 'field_5b97fa3797db4'),
(1359, 181, 'testimonials_column_two_0_testimonial_content', 'I’m writing to let you know how much you have helped me through this process. It’s surely been a sad time for me but the way you helped me get through this made it better. The manner in which you get things done was the best for me. You took the time to explain in detail what was going on and if you could tell by my voice that I wasn’t understanding, you said it again with an example. You also gave me suggestions which I really listened to. I know you’d say you’re doing your job, but there are different ways to do that job. You did it in a caring way.') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(1360, 181, '_testimonials_column_two_0_testimonial_content', 'field_5b97fa3797db5'),
(1361, 181, 'testimonials_column_two_0_name', 'Kathy S.'),
(1362, 181, '_testimonials_column_two_0_name', 'field_5b97fa3797db6'),
(1363, 181, 'testimonials_column_two', '1'),
(1364, 181, '_testimonials_column_two', 'field_5b97fa3797db3'),
(1365, 52, 'testimonials_column_one_1_testimonial_quote', '“I am and will always be grateful for you!”'),
(1366, 52, '_testimonials_column_one_1_testimonial_quote', 'field_5b97f9e997db0'),
(1367, 52, 'testimonials_column_one_1_testimonial_content', 'Thank you so very much for all your help with my case. You really came through for me. I am and will always be grateful for you!'),
(1368, 52, '_testimonials_column_one_1_testimonial_content', 'field_5b97fa1b97db1'),
(1369, 52, 'testimonials_column_one_1_name', 'Scott W.'),
(1370, 52, '_testimonials_column_one_1_name', 'field_5b97fa2897db2'),
(1371, 52, 'testimonials_column_one_2_testimonial_quote', '“I can’t express enough the appreciation for your hard work and sacrifice.”'),
(1372, 52, '_testimonials_column_one_2_testimonial_quote', 'field_5b97f9e997db0'),
(1373, 52, 'testimonials_column_one_2_testimonial_content', 'I can’t express enough to you and your family the appreciation for your hard work and sacrifice. As well as your concern,\r\ncompassion and professionalism.'),
(1374, 52, '_testimonials_column_one_2_testimonial_content', 'field_5b97fa1b97db1'),
(1375, 52, 'testimonials_column_one_2_name', 'Shawn D.'),
(1376, 52, '_testimonials_column_one_2_name', 'field_5b97fa2897db2'),
(1377, 52, 'testimonials_column_one_3_testimonial_quote', '“Greatly Appreciated.”'),
(1378, 52, '_testimonials_column_one_3_testimonial_quote', 'field_5b97f9e997db0'),
(1379, 52, 'testimonials_column_one_3_testimonial_content', 'I want to thank you and your staff for the work you did to settle\r\nmy claim. It is greatly appreciated.'),
(1380, 52, '_testimonials_column_one_3_testimonial_content', 'field_5b97fa1b97db1'),
(1381, 52, 'testimonials_column_one_3_name', 'Gail B.'),
(1382, 52, '_testimonials_column_one_3_name', 'field_5b97fa2897db2'),
(1383, 182, 'testimonials_column_one_0_testimonial_quote', '“We are Speechless for all your hard work and Education.”'),
(1384, 182, '_testimonials_column_one_0_testimonial_quote', 'field_5b97f9e997db0'),
(1385, 182, 'testimonials_column_one_0_testimonial_content', 'We are speechless for all your hard work and dedication…Thank you. For all of your professionalism and class…Thank you. For everything you’ve had to deal with and put up with…Thank you. For always keeping us informed every step of the way…Thank you. For putting your time and heart into your work for us…Thank you. For being such a kind, caring soul…Thank you.'),
(1386, 182, '_testimonials_column_one_0_testimonial_content', 'field_5b97fa1b97db1'),
(1387, 182, 'testimonials_column_one_0_name', 'Teri J.'),
(1388, 182, '_testimonials_column_one_0_name', 'field_5b97fa2897db2'),
(1389, 182, 'testimonials_column_one', '4'),
(1390, 182, '_testimonials_column_one', 'field_5b97f9d397daf'),
(1391, 182, 'testimonials_column_two_0_testimonial_quote', '“You have helped me through this process”'),
(1392, 182, '_testimonials_column_two_0_testimonial_quote', 'field_5b97fa3797db4'),
(1393, 182, 'testimonials_column_two_0_testimonial_content', 'I’m writing to let you know how much you have helped me through this process. It’s surely been a sad time for me but the way you helped me get through this made it better. The manner in which you get things done was the best for me. You took the time to explain in detail what was going on and if you could tell by my voice that I wasn’t understanding, you said it again with an example. You also gave me suggestions which I really listened to. I know you’d say you’re doing your job, but there are different ways to do that job. You did it in a caring way.'),
(1394, 182, '_testimonials_column_two_0_testimonial_content', 'field_5b97fa3797db5'),
(1395, 182, 'testimonials_column_two_0_name', 'Kathy S.'),
(1396, 182, '_testimonials_column_two_0_name', 'field_5b97fa3797db6'),
(1397, 182, 'testimonials_column_two', '1'),
(1398, 182, '_testimonials_column_two', 'field_5b97fa3797db3'),
(1399, 182, 'testimonials_column_one_1_testimonial_quote', '“I am and will always be grateful for you!”'),
(1400, 182, '_testimonials_column_one_1_testimonial_quote', 'field_5b97f9e997db0'),
(1401, 182, 'testimonials_column_one_1_testimonial_content', 'Thank you so very much for all your help with my case. You really came through for me. I am and will always be grateful for you!'),
(1402, 182, '_testimonials_column_one_1_testimonial_content', 'field_5b97fa1b97db1'),
(1403, 182, 'testimonials_column_one_1_name', 'Scott W.'),
(1404, 182, '_testimonials_column_one_1_name', 'field_5b97fa2897db2'),
(1405, 182, 'testimonials_column_one_2_testimonial_quote', '“I can’t express enough the appreciation for your hard work and sacrifice.”'),
(1406, 182, '_testimonials_column_one_2_testimonial_quote', 'field_5b97f9e997db0'),
(1407, 182, 'testimonials_column_one_2_testimonial_content', 'I can’t express enough to you and your family the appreciation for your hard work and sacrifice. As well as your concern, compassion and professionalism.'),
(1408, 182, '_testimonials_column_one_2_testimonial_content', 'field_5b97fa1b97db1'),
(1409, 182, 'testimonials_column_one_2_name', 'Shawn D.'),
(1410, 182, '_testimonials_column_one_2_name', 'field_5b97fa2897db2'),
(1411, 182, 'testimonials_column_one_3_testimonial_quote', '“Greatly Appreciated.”'),
(1412, 182, '_testimonials_column_one_3_testimonial_quote', 'field_5b97f9e997db0'),
(1413, 182, 'testimonials_column_one_3_testimonial_content', 'I want to thank you and your staff for the work you did to settle my claim. It is greatly appreciated.'),
(1414, 182, '_testimonials_column_one_3_testimonial_content', 'field_5b97fa1b97db1'),
(1415, 182, 'testimonials_column_one_3_name', 'Gail B.'),
(1416, 182, '_testimonials_column_one_3_name', 'field_5b97fa2897db2'),
(1417, 52, 'testimonials_column_two_1_testimonial_quote', '“It has been a genuine pleasure to have your expertise, counsel \r\nand guidance.”'),
(1418, 52, '_testimonials_column_two_1_testimonial_quote', 'field_5b97fa3797db4'),
(1419, 52, 'testimonials_column_two_1_testimonial_content', 'Thank you for your excellent representation in my personal injury claim. It has been a genuine pleasure to have your expertise, counsel and guidance. I am very pleased with the result of your efforts on my behalf. Throughout these many months you have, at all times, been professional, articulate, detailed, compassionate, personable and supportive in every way needed. I cannot thank you enough for making this difficult, protracted and, at times, distasteful process tolerable. Your knowledge and expertise; your patience explaining each and every step; presenting scenarios; risks and/or benefits; answering my questions; was an enormous factor in ensuring that each discussion and choice I made was fully informed and made with complete confidence. As busy as I knew you were, I never felt rushed or that you were not giving my every concern, large or small,\r\nyour complete attention.'),
(1420, 52, '_testimonials_column_two_1_testimonial_content', 'field_5b97fa3797db5'),
(1421, 52, 'testimonials_column_two_1_name', 'Mary K.'),
(1422, 52, '_testimonials_column_two_1_name', 'field_5b97fa3797db6'),
(1423, 52, 'testimonials_column_two_2_testimonial_quote', '“We feel blessed to have found you.”'),
(1424, 52, '_testimonials_column_two_2_testimonial_quote', 'field_5b97fa3797db4'),
(1425, 52, 'testimonials_column_two_2_testimonial_content', 'I just want to express how grateful we are for all of your hard work and for what a great job you did for our case. You helped us through a difficult situation by being professional, competent and yet empathetic and understanding. Thank you for all of your hard work and encouragement – we feel blessed to have found you.'),
(1426, 52, '_testimonials_column_two_2_testimonial_content', 'field_5b97fa3797db5'),
(1427, 52, 'testimonials_column_two_2_name', 'Tim and Jennifer S.'),
(1428, 52, '_testimonials_column_two_2_name', 'field_5b97fa3797db6'),
(1435, 183, 'testimonials_column_one_0_testimonial_quote', '“We are Speechless for all your hard work and Education.”'),
(1436, 183, '_testimonials_column_one_0_testimonial_quote', 'field_5b97f9e997db0'),
(1437, 183, 'testimonials_column_one_0_testimonial_content', 'We are speechless for all your hard work and dedication…Thank you. For all of your professionalism and class…Thank you. For everything you’ve had to deal with and put up with…Thank you. For always keeping us informed every step of the way…Thank you. For putting your time and heart into your work for us…Thank you. For being such a kind, caring soul…Thank you.'),
(1438, 183, '_testimonials_column_one_0_testimonial_content', 'field_5b97fa1b97db1'),
(1439, 183, 'testimonials_column_one_0_name', 'Teri J.'),
(1440, 183, '_testimonials_column_one_0_name', 'field_5b97fa2897db2'),
(1441, 183, 'testimonials_column_one', '4'),
(1442, 183, '_testimonials_column_one', 'field_5b97f9d397daf'),
(1443, 183, 'testimonials_column_two_0_testimonial_quote', '“You have helped me through this process”'),
(1444, 183, '_testimonials_column_two_0_testimonial_quote', 'field_5b97fa3797db4'),
(1445, 183, 'testimonials_column_two_0_testimonial_content', 'I’m writing to let you know how much you have helped me through this process. It’s surely been a sad time for me but the way you helped me get through this made it better. The manner in which you get things done was the best for me. You took the time to explain in detail what was going on and if you could tell by my voice that I wasn’t understanding, you said it again with an example. You also gave me suggestions which I really listened to. I know you’d say you’re doing your job, but there are different ways to do that job. You did it in a caring way.'),
(1446, 183, '_testimonials_column_two_0_testimonial_content', 'field_5b97fa3797db5'),
(1447, 183, 'testimonials_column_two_0_name', 'Kathy S.'),
(1448, 183, '_testimonials_column_two_0_name', 'field_5b97fa3797db6'),
(1449, 183, 'testimonials_column_two', '4'),
(1450, 183, '_testimonials_column_two', 'field_5b97fa3797db3'),
(1451, 183, 'testimonials_column_one_1_testimonial_quote', '“I am and will always be grateful for you!”'),
(1452, 183, '_testimonials_column_one_1_testimonial_quote', 'field_5b97f9e997db0'),
(1453, 183, 'testimonials_column_one_1_testimonial_content', 'Thank you so very much for all your help with my case. You really came through for me. I am and will always be grateful for you!'),
(1454, 183, '_testimonials_column_one_1_testimonial_content', 'field_5b97fa1b97db1'),
(1455, 183, 'testimonials_column_one_1_name', 'Scott W.'),
(1456, 183, '_testimonials_column_one_1_name', 'field_5b97fa2897db2'),
(1457, 183, 'testimonials_column_one_2_testimonial_quote', '“I can’t express enough the appreciation for your hard work and sacrifice.”'),
(1458, 183, '_testimonials_column_one_2_testimonial_quote', 'field_5b97f9e997db0'),
(1459, 183, 'testimonials_column_one_2_testimonial_content', 'I can’t express enough to you and your family the appreciation for your hard work and sacrifice. As well as your concern, compassion and professionalism.'),
(1460, 183, '_testimonials_column_one_2_testimonial_content', 'field_5b97fa1b97db1'),
(1461, 183, 'testimonials_column_one_2_name', 'Shawn D.'),
(1462, 183, '_testimonials_column_one_2_name', 'field_5b97fa2897db2'),
(1463, 183, 'testimonials_column_one_3_testimonial_quote', '“Greatly Appreciated.”'),
(1464, 183, '_testimonials_column_one_3_testimonial_quote', 'field_5b97f9e997db0'),
(1465, 183, 'testimonials_column_one_3_testimonial_content', 'I want to thank you and your staff for the work you did to settle my claim. It is greatly appreciated.') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(1466, 183, '_testimonials_column_one_3_testimonial_content', 'field_5b97fa1b97db1'),
(1467, 183, 'testimonials_column_one_3_name', 'Gail B.'),
(1468, 183, '_testimonials_column_one_3_name', 'field_5b97fa2897db2'),
(1469, 183, 'testimonials_column_two_1_testimonial_quote', '“You have helped me through this process”'),
(1470, 183, '_testimonials_column_two_1_testimonial_quote', 'field_5b97fa3797db4'),
(1471, 183, 'testimonials_column_two_1_testimonial_content', 'I’m writing to let you know how much you have helped me through this process. It’s surely been a sad time for me but the way you helped me get through this made it better. The manner in which you get things done was the best for me. You took the time to explain in detail what was going on and if you could tell by my voice that I wasn’t understanding, you said it again with an example. You also gave me suggestions which I really listened to. I know you’d say you’re doing your job, but there are different ways to do that job. You did it in a caring way.'),
(1472, 183, '_testimonials_column_two_1_testimonial_content', 'field_5b97fa3797db5'),
(1473, 183, 'testimonials_column_two_1_name', 'Kathy S.'),
(1474, 183, '_testimonials_column_two_1_name', 'field_5b97fa3797db6'),
(1475, 183, 'testimonials_column_two_2_testimonial_quote', '“It has been a genuine pleasure to have your expertise, counsel and guidance.”'),
(1476, 183, '_testimonials_column_two_2_testimonial_quote', 'field_5b97fa3797db4'),
(1477, 183, 'testimonials_column_two_2_testimonial_content', 'Thank you for your excellent representation in my personal injury claim. It has been a genuine pleasure to have your expertise, counsel and guidance. I am very pleased with the result of your efforts on my behalf. Throughout these many months you have, at all times, been professional, articulate, detailed, compassionate, personable and supportive in every way needed. I cannot thank you enough for making this difficult, protracted and, at times, distasteful process tolerable. Your knowledge and expertise; your patience explaining each and every step; presenting scenarios; risks and/or benefits; answering my questions; was an enormous factor in ensuring that each discussion and choice I made was fully informed and made with complete confidence. As busy as I knew you were, I never felt rushed or that you were not giving my every concern, large or small, your complete attention.'),
(1478, 183, '_testimonials_column_two_2_testimonial_content', 'field_5b97fa3797db5'),
(1479, 183, 'testimonials_column_two_2_name', 'Mary K.'),
(1480, 183, '_testimonials_column_two_2_name', 'field_5b97fa3797db6'),
(1481, 183, 'testimonials_column_two_3_testimonial_quote', '“We feel blessed to have found you.”'),
(1482, 183, '_testimonials_column_two_3_testimonial_quote', 'field_5b97fa3797db4'),
(1483, 183, 'testimonials_column_two_3_testimonial_content', 'I just want to express how grateful we are for all of your hard work and for what a great job you did for our case. You helped us through a difficult situation by being professional, competent and yet empathetic and understanding. Thank you for all of your hard work and encouragement – we feel blessed to have found you.'),
(1484, 183, '_testimonials_column_two_3_testimonial_content', 'field_5b97fa3797db5'),
(1485, 183, 'testimonials_column_two_3_name', 'Tim and Jennifer S.'),
(1486, 183, '_testimonials_column_two_3_name', 'field_5b97fa3797db6'),
(1487, 184, 'testimonials_column_one_0_testimonial_quote', '“We are Speechless for all your hard work and Education.”'),
(1488, 184, '_testimonials_column_one_0_testimonial_quote', 'field_5b97f9e997db0'),
(1489, 184, 'testimonials_column_one_0_testimonial_content', 'We are speechless for all your hard work and dedication…Thank you. For all of your professionalism and class…Thank you. For everything you’ve had to deal with and put up with…Thank you. For always keeping us informed every step of the way…Thank you. For putting your time and heart into your work for us…Thank you. For being such a kind, caring soul…Thank you.'),
(1490, 184, '_testimonials_column_one_0_testimonial_content', 'field_5b97fa1b97db1'),
(1491, 184, 'testimonials_column_one_0_name', 'Teri J.'),
(1492, 184, '_testimonials_column_one_0_name', 'field_5b97fa2897db2'),
(1493, 184, 'testimonials_column_one', '4'),
(1494, 184, '_testimonials_column_one', 'field_5b97f9d397daf'),
(1495, 184, 'testimonials_column_two_0_testimonial_quote', '“You have helped me through this process”'),
(1496, 184, '_testimonials_column_two_0_testimonial_quote', 'field_5b97fa3797db4'),
(1497, 184, 'testimonials_column_two_0_testimonial_content', 'I’m writing to let you know how much you have helped me through this process. It’s surely been a sad time for me but the way you helped me get through this made it better. The manner in which you get things done was the best for me. You took the time to explain in detail what was going on and if you could tell by my voice that I wasn’t understanding, you said it again with an example. You also gave me suggestions which I really listened to. I know you’d say you’re doing your job, but there are different ways to do that job. You did it in a caring way.'),
(1498, 184, '_testimonials_column_two_0_testimonial_content', 'field_5b97fa3797db5'),
(1499, 184, 'testimonials_column_two_0_name', 'Kathy S.'),
(1500, 184, '_testimonials_column_two_0_name', 'field_5b97fa3797db6'),
(1501, 184, 'testimonials_column_two', '3'),
(1502, 184, '_testimonials_column_two', 'field_5b97fa3797db3'),
(1503, 184, 'testimonials_column_one_1_testimonial_quote', '“I am and will always be grateful for you!”'),
(1504, 184, '_testimonials_column_one_1_testimonial_quote', 'field_5b97f9e997db0'),
(1505, 184, 'testimonials_column_one_1_testimonial_content', 'Thank you so very much for all your help with my case. You really came through for me. I am and will always be grateful for you!'),
(1506, 184, '_testimonials_column_one_1_testimonial_content', 'field_5b97fa1b97db1'),
(1507, 184, 'testimonials_column_one_1_name', 'Scott W.'),
(1508, 184, '_testimonials_column_one_1_name', 'field_5b97fa2897db2'),
(1509, 184, 'testimonials_column_one_2_testimonial_quote', '“I can’t express enough the appreciation for your hard work and sacrifice.”'),
(1510, 184, '_testimonials_column_one_2_testimonial_quote', 'field_5b97f9e997db0'),
(1511, 184, 'testimonials_column_one_2_testimonial_content', 'I can’t express enough to you and your family the appreciation for your hard work and sacrifice. As well as your concern, compassion and professionalism.'),
(1512, 184, '_testimonials_column_one_2_testimonial_content', 'field_5b97fa1b97db1'),
(1513, 184, 'testimonials_column_one_2_name', 'Shawn D.'),
(1514, 184, '_testimonials_column_one_2_name', 'field_5b97fa2897db2'),
(1515, 184, 'testimonials_column_one_3_testimonial_quote', '“Greatly Appreciated.”'),
(1516, 184, '_testimonials_column_one_3_testimonial_quote', 'field_5b97f9e997db0'),
(1517, 184, 'testimonials_column_one_3_testimonial_content', 'I want to thank you and your staff for the work you did to settle my claim. It is greatly appreciated.'),
(1518, 184, '_testimonials_column_one_3_testimonial_content', 'field_5b97fa1b97db1'),
(1519, 184, 'testimonials_column_one_3_name', 'Gail B.'),
(1520, 184, '_testimonials_column_one_3_name', 'field_5b97fa2897db2'),
(1521, 184, 'testimonials_column_two_1_testimonial_quote', '“It has been a genuine pleasure to have your expertise, counsel and guidance.”'),
(1522, 184, '_testimonials_column_two_1_testimonial_quote', 'field_5b97fa3797db4'),
(1523, 184, 'testimonials_column_two_1_testimonial_content', 'Thank you for your excellent representation in my personal injury claim. It has been a genuine pleasure to have your expertise, counsel and guidance. I am very pleased with the result of your efforts on my behalf. Throughout these many months you have, at all times, been professional, articulate, detailed, compassionate, personable and supportive in every way needed. I cannot thank you enough for making this difficult, protracted and, at times, distasteful process tolerable. Your knowledge and expertise; your patience explaining each and every step; presenting scenarios; risks and/or benefits; answering my questions; was an enormous factor in ensuring that each discussion and choice I made was fully informed and made with complete confidence. As busy as I knew you were, I never felt rushed or that you were not giving my every concern, large or small, your complete attention.'),
(1524, 184, '_testimonials_column_two_1_testimonial_content', 'field_5b97fa3797db5'),
(1525, 184, 'testimonials_column_two_1_name', 'Mary K.'),
(1526, 184, '_testimonials_column_two_1_name', 'field_5b97fa3797db6'),
(1527, 184, 'testimonials_column_two_2_testimonial_quote', '“We feel blessed to have found you.”'),
(1528, 184, '_testimonials_column_two_2_testimonial_quote', 'field_5b97fa3797db4'),
(1529, 184, 'testimonials_column_two_2_testimonial_content', 'I just want to express how grateful we are for all of your hard work and for what a great job you did for our case. You helped us through a difficult situation by being professional, competent and yet empathetic and understanding. Thank you for all of your hard work and encouragement – we feel blessed to have found you.'),
(1530, 184, '_testimonials_column_two_2_testimonial_content', 'field_5b97fa3797db5'),
(1531, 184, 'testimonials_column_two_2_name', 'Tim and Jennifer S.'),
(1532, 184, '_testimonials_column_two_2_name', 'field_5b97fa3797db6'),
(1533, 185, 'testimonials_column_one_0_testimonial_quote', '“We are Speechless for all your hard work and Education.”'),
(1534, 185, '_testimonials_column_one_0_testimonial_quote', 'field_5b97f9e997db0'),
(1535, 185, 'testimonials_column_one_0_testimonial_content', 'We are speechless for all your hard work and dedication…Thank you. For all of your professionalism and class…Thank you. For everything you’ve had to deal with and put up with…Thank you. For always keeping us informed every step of the way…Thank you. For putting your time and heart into your work for us…Thank you. For being such a kind, caring soul…Thank you.'),
(1536, 185, '_testimonials_column_one_0_testimonial_content', 'field_5b97fa1b97db1'),
(1537, 185, 'testimonials_column_one_0_name', 'Teri J.'),
(1538, 185, '_testimonials_column_one_0_name', 'field_5b97fa2897db2'),
(1539, 185, 'testimonials_column_one', '4'),
(1540, 185, '_testimonials_column_one', 'field_5b97f9d397daf'),
(1541, 185, 'testimonials_column_two_0_testimonial_quote', '“You have helped me through this process”'),
(1542, 185, '_testimonials_column_two_0_testimonial_quote', 'field_5b97fa3797db4'),
(1543, 185, 'testimonials_column_two_0_testimonial_content', 'I’m writing to let you know how much you have helped me through this process. It’s surely been a sad time for me but the way you helped me get through this made it better. The manner in which you get things done was the best for me. You took the time to explain in detail what was going on and if you could tell by my voice that I wasn’t understanding, you said it again with an example. You also gave me suggestions which I really listened to. I know you’d say you’re doing your job, but there are different ways to do that job. You did it in a caring way.'),
(1544, 185, '_testimonials_column_two_0_testimonial_content', 'field_5b97fa3797db5'),
(1545, 185, 'testimonials_column_two_0_name', 'Kathy S.'),
(1546, 185, '_testimonials_column_two_0_name', 'field_5b97fa3797db6'),
(1547, 185, 'testimonials_column_two', '3'),
(1548, 185, '_testimonials_column_two', 'field_5b97fa3797db3'),
(1549, 185, 'testimonials_column_one_1_testimonial_quote', '“I am and will always be grateful for you!”'),
(1550, 185, '_testimonials_column_one_1_testimonial_quote', 'field_5b97f9e997db0'),
(1551, 185, 'testimonials_column_one_1_testimonial_content', 'Thank you so very much for all your help with my case. You really came through for me. I am and will always be grateful for you!'),
(1552, 185, '_testimonials_column_one_1_testimonial_content', 'field_5b97fa1b97db1'),
(1553, 185, 'testimonials_column_one_1_name', 'Scott W.'),
(1554, 185, '_testimonials_column_one_1_name', 'field_5b97fa2897db2'),
(1555, 185, 'testimonials_column_one_2_testimonial_quote', '“I can’t express enough the appreciation for your hard work and sacrifice.”'),
(1556, 185, '_testimonials_column_one_2_testimonial_quote', 'field_5b97f9e997db0'),
(1557, 185, 'testimonials_column_one_2_testimonial_content', 'I can’t express enough to you and your family the appreciation for your hard work and sacrifice. As well as your concern, compassion and professionalism.'),
(1558, 185, '_testimonials_column_one_2_testimonial_content', 'field_5b97fa1b97db1'),
(1559, 185, 'testimonials_column_one_2_name', 'Shawn D.'),
(1560, 185, '_testimonials_column_one_2_name', 'field_5b97fa2897db2'),
(1561, 185, 'testimonials_column_one_3_testimonial_quote', '“Greatly Appreciated.”'),
(1562, 185, '_testimonials_column_one_3_testimonial_quote', 'field_5b97f9e997db0'),
(1563, 185, 'testimonials_column_one_3_testimonial_content', 'I want to thank you and your staff for the work you did to settle my claim. It is greatly appreciated.'),
(1564, 185, '_testimonials_column_one_3_testimonial_content', 'field_5b97fa1b97db1'),
(1565, 185, 'testimonials_column_one_3_name', 'Gail B.') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(1566, 185, '_testimonials_column_one_3_name', 'field_5b97fa2897db2'),
(1567, 185, 'testimonials_column_two_1_testimonial_quote', '“It has been a genuine pleasure to have your expertise, counsel \r\nand guidance.”'),
(1568, 185, '_testimonials_column_two_1_testimonial_quote', 'field_5b97fa3797db4'),
(1569, 185, 'testimonials_column_two_1_testimonial_content', 'Thank you for your excellent representation in my personal injury claim. It has been a genuine pleasure to have your expertise, counsel and guidance. I am very pleased with the result of your efforts on my behalf. Throughout these many months you have, at all times, been professional, articulate, detailed, compassionate, personable and supportive in every way needed. I cannot thank you enough for making this difficult, protracted and, at times, distasteful process tolerable. Your knowledge and expertise; your patience explaining each and every step; presenting scenarios; risks and/or benefits; answering my questions; was an enormous factor in ensuring that each discussion and choice I made was fully informed and made with complete confidence. As busy as I knew you were, I never felt rushed or that you were not giving my every concern, large or small, your complete attention.'),
(1570, 185, '_testimonials_column_two_1_testimonial_content', 'field_5b97fa3797db5'),
(1571, 185, 'testimonials_column_two_1_name', 'Mary K.'),
(1572, 185, '_testimonials_column_two_1_name', 'field_5b97fa3797db6'),
(1573, 185, 'testimonials_column_two_2_testimonial_quote', '“We feel blessed to have found you.”'),
(1574, 185, '_testimonials_column_two_2_testimonial_quote', 'field_5b97fa3797db4'),
(1575, 185, 'testimonials_column_two_2_testimonial_content', 'I just want to express how grateful we are for all of your hard work and for what a great job you did for our case. You helped us through a difficult situation by being professional, competent and yet empathetic and understanding. Thank you for all of your hard work and encouragement – we feel blessed to have found you.'),
(1576, 185, '_testimonials_column_two_2_testimonial_content', 'field_5b97fa3797db5'),
(1577, 185, 'testimonials_column_two_2_name', 'Tim and Jennifer S.'),
(1578, 185, '_testimonials_column_two_2_name', 'field_5b97fa3797db6'),
(1579, 186, 'testimonials_column_one_0_testimonial_quote', '“We are Speechless for all your hard work and Education.”'),
(1580, 186, '_testimonials_column_one_0_testimonial_quote', 'field_5b97f9e997db0'),
(1581, 186, 'testimonials_column_one_0_testimonial_content', 'We are speechless for all your hard work and dedication…Thank you. For all of your professionalism and class…Thank you. For everything you’ve had to deal with and put up with…Thank you. For always keeping us informed every step of the way…Thank you. For putting your time and heart into your work for us…Thank you. For being such a kind, caring soul…Thank you.'),
(1582, 186, '_testimonials_column_one_0_testimonial_content', 'field_5b97fa1b97db1'),
(1583, 186, 'testimonials_column_one_0_name', 'Teri J.'),
(1584, 186, '_testimonials_column_one_0_name', 'field_5b97fa2897db2'),
(1585, 186, 'testimonials_column_one', '4'),
(1586, 186, '_testimonials_column_one', 'field_5b97f9d397daf'),
(1587, 186, 'testimonials_column_two_0_testimonial_quote', '“You have helped me through this process”'),
(1588, 186, '_testimonials_column_two_0_testimonial_quote', 'field_5b97fa3797db4'),
(1589, 186, 'testimonials_column_two_0_testimonial_content', 'I’m writing to let you know how much you have helped me through this process. It’s surely been a sad time for me but the way you helped me get through this made it better. The manner in which you get things done was the best for me. You took the time to explain in detail what was going on and if you could tell by my voice that I wasn’t understanding, you said it again with an example. You also gave me suggestions which I really listened to. I know you’d say you’re doing your job, but there are different ways to do that job. You did it in a caring way.'),
(1590, 186, '_testimonials_column_two_0_testimonial_content', 'field_5b97fa3797db5'),
(1591, 186, 'testimonials_column_two_0_name', 'Kathy S.'),
(1592, 186, '_testimonials_column_two_0_name', 'field_5b97fa3797db6'),
(1593, 186, 'testimonials_column_two', '3'),
(1594, 186, '_testimonials_column_two', 'field_5b97fa3797db3'),
(1595, 186, 'testimonials_column_one_1_testimonial_quote', '“I am and will always be grateful for you!”'),
(1596, 186, '_testimonials_column_one_1_testimonial_quote', 'field_5b97f9e997db0'),
(1597, 186, 'testimonials_column_one_1_testimonial_content', 'Thank you so very much for all your help with my case. You really came through for me. I am and will always be grateful for you!'),
(1598, 186, '_testimonials_column_one_1_testimonial_content', 'field_5b97fa1b97db1'),
(1599, 186, 'testimonials_column_one_1_name', 'Scott W.'),
(1600, 186, '_testimonials_column_one_1_name', 'field_5b97fa2897db2'),
(1601, 186, 'testimonials_column_one_2_testimonial_quote', '“I can’t express enough the appreciation for your hard work and sacrifice.”'),
(1602, 186, '_testimonials_column_one_2_testimonial_quote', 'field_5b97f9e997db0'),
(1603, 186, 'testimonials_column_one_2_testimonial_content', 'I can’t express enough to you and your family the appreciation for your hard work and sacrifice. As well as your concern, compassion and professionalism.'),
(1604, 186, '_testimonials_column_one_2_testimonial_content', 'field_5b97fa1b97db1'),
(1605, 186, 'testimonials_column_one_2_name', 'Shawn D.'),
(1606, 186, '_testimonials_column_one_2_name', 'field_5b97fa2897db2'),
(1607, 186, 'testimonials_column_one_3_testimonial_quote', '“Greatly Appreciated.”'),
(1608, 186, '_testimonials_column_one_3_testimonial_quote', 'field_5b97f9e997db0'),
(1609, 186, 'testimonials_column_one_3_testimonial_content', 'I want to thank you and your staff for the work you did to settle my claim. It is greatly appreciated.'),
(1610, 186, '_testimonials_column_one_3_testimonial_content', 'field_5b97fa1b97db1'),
(1611, 186, 'testimonials_column_one_3_name', 'Gail B.'),
(1612, 186, '_testimonials_column_one_3_name', 'field_5b97fa2897db2'),
(1613, 186, 'testimonials_column_two_1_testimonial_quote', '“It has been a genuine pleasure to have your expertise, counsel \r\nand guidance.”'),
(1614, 186, '_testimonials_column_two_1_testimonial_quote', 'field_5b97fa3797db4'),
(1615, 186, 'testimonials_column_two_1_testimonial_content', 'Thank you for your excellent representation in my personal injury claim. It has been a genuine pleasure to have your expertise, counsel and guidance. I am very pleased with the result of your efforts on my behalf. Throughout these many months you have, at all times, been professional, articulate, detailed, compassionate, personable and supportive in every way needed. I cannot thank you enough for making this difficult, protracted and, at times, distasteful process tolerable. Your knowledge and expertise; your patience explaining each and every step; presenting scenarios; risks and/or benefits; answering my questions; was an enormous factor in ensuring that each discussion and choice I made was fully informed and made with complete confidence. As busy as I knew you were, I never felt rushed or that you were not giving my every concern, large or small,\r\nyour complete attention.'),
(1616, 186, '_testimonials_column_two_1_testimonial_content', 'field_5b97fa3797db5'),
(1617, 186, 'testimonials_column_two_1_name', 'Mary K.'),
(1618, 186, '_testimonials_column_two_1_name', 'field_5b97fa3797db6'),
(1619, 186, 'testimonials_column_two_2_testimonial_quote', '“We feel blessed to have found you.”'),
(1620, 186, '_testimonials_column_two_2_testimonial_quote', 'field_5b97fa3797db4'),
(1621, 186, 'testimonials_column_two_2_testimonial_content', 'I just want to express how grateful we are for all of your hard work and for what a great job you did for our case. You helped us through a difficult situation by being professional, competent and yet empathetic and understanding. Thank you for all of your hard work and encouragement – we feel blessed to have found you.'),
(1622, 186, '_testimonials_column_two_2_testimonial_content', 'field_5b97fa3797db5'),
(1623, 186, 'testimonials_column_two_2_name', 'Tim and Jennifer S.'),
(1624, 186, '_testimonials_column_two_2_name', 'field_5b97fa3797db6'),
(1625, 187, 'testimonials_column_one_0_testimonial_quote', '“We are Speechless for all your hard work and Education.”'),
(1626, 187, '_testimonials_column_one_0_testimonial_quote', 'field_5b97f9e997db0'),
(1627, 187, 'testimonials_column_one_0_testimonial_content', 'We are speechless for all your hard work and dedication…Thank you. For all of your professionalism and class…Thank you. For everything you’ve had to deal with and put up with…Thank you. For always keeping us informed every step of the way…Thank you. For putting your time and heart into your work for us…Thank you. For being such a kind, caring soul…Thank you.'),
(1628, 187, '_testimonials_column_one_0_testimonial_content', 'field_5b97fa1b97db1'),
(1629, 187, 'testimonials_column_one_0_name', 'Teri J.'),
(1630, 187, '_testimonials_column_one_0_name', 'field_5b97fa2897db2'),
(1631, 187, 'testimonials_column_one', '4'),
(1632, 187, '_testimonials_column_one', 'field_5b97f9d397daf'),
(1633, 187, 'testimonials_column_two_0_testimonial_quote', '“You have helped me through this process”'),
(1634, 187, '_testimonials_column_two_0_testimonial_quote', 'field_5b97fa3797db4'),
(1635, 187, 'testimonials_column_two_0_testimonial_content', 'I’m writing to let you know how much you have helped me through this process. It’s surely been a sad time for me but the way you helped me get through this made it better. The manner in which you get things done was the best for me. You took the time to explain in detail what was going on and if you could tell by my voice that I wasn’t understanding, you said it again with an example. You also gave me suggestions which I really listened to. I know you’d say you’re doing your job, but there are different ways to do that job. You did it in a caring way.'),
(1636, 187, '_testimonials_column_two_0_testimonial_content', 'field_5b97fa3797db5'),
(1637, 187, 'testimonials_column_two_0_name', 'Kathy S.'),
(1638, 187, '_testimonials_column_two_0_name', 'field_5b97fa3797db6'),
(1639, 187, 'testimonials_column_two', '3'),
(1640, 187, '_testimonials_column_two', 'field_5b97fa3797db3'),
(1641, 187, 'testimonials_column_one_1_testimonial_quote', '“I am and will always be grateful for you!”'),
(1642, 187, '_testimonials_column_one_1_testimonial_quote', 'field_5b97f9e997db0'),
(1643, 187, 'testimonials_column_one_1_testimonial_content', 'Thank you so very much for all your help with my case. You really came through for me. I am and will always be grateful for you!'),
(1644, 187, '_testimonials_column_one_1_testimonial_content', 'field_5b97fa1b97db1'),
(1645, 187, 'testimonials_column_one_1_name', 'Scott W.'),
(1646, 187, '_testimonials_column_one_1_name', 'field_5b97fa2897db2'),
(1647, 187, 'testimonials_column_one_2_testimonial_quote', '“I can’t express enough the appreciation for your hard work and sacrifice.”'),
(1648, 187, '_testimonials_column_one_2_testimonial_quote', 'field_5b97f9e997db0'),
(1649, 187, 'testimonials_column_one_2_testimonial_content', 'I can’t express enough to you and your family the appreciation for your hard work and sacrifice. As well as your concern, compassion and professionalism.'),
(1650, 187, '_testimonials_column_one_2_testimonial_content', 'field_5b97fa1b97db1'),
(1651, 187, 'testimonials_column_one_2_name', 'Shawn D.'),
(1652, 187, '_testimonials_column_one_2_name', 'field_5b97fa2897db2'),
(1653, 187, 'testimonials_column_one_3_testimonial_quote', '“Greatly Appreciated.”'),
(1654, 187, '_testimonials_column_one_3_testimonial_quote', 'field_5b97f9e997db0'),
(1655, 187, 'testimonials_column_one_3_testimonial_content', 'I want to thank you and your staff for the work you did to settle\r\nmy claim. It is greatly appreciated.'),
(1656, 187, '_testimonials_column_one_3_testimonial_content', 'field_5b97fa1b97db1'),
(1657, 187, 'testimonials_column_one_3_name', 'Gail B.'),
(1658, 187, '_testimonials_column_one_3_name', 'field_5b97fa2897db2'),
(1659, 187, 'testimonials_column_two_1_testimonial_quote', '“It has been a genuine pleasure to have your expertise, counsel \r\nand guidance.”'),
(1660, 187, '_testimonials_column_two_1_testimonial_quote', 'field_5b97fa3797db4'),
(1661, 187, 'testimonials_column_two_1_testimonial_content', 'Thank you for your excellent representation in my personal injury claim. It has been a genuine pleasure to have your expertise, counsel and guidance. I am very pleased with the result of your efforts on my behalf. Throughout these many months you have, at all times, been professional, articulate, detailed, compassionate, personable and supportive in every way needed. I cannot thank you enough for making this difficult, protracted and, at times, distasteful process tolerable. Your knowledge and expertise; your patience explaining each and every step; presenting scenarios; risks and/or benefits; answering my questions; was an enormous factor in ensuring that each discussion and choice I made was fully informed and made with complete confidence. As busy as I knew you were, I never felt rushed or that you were not giving my every concern, large or small,\r\nyour complete attention.'),
(1662, 187, '_testimonials_column_two_1_testimonial_content', 'field_5b97fa3797db5'),
(1663, 187, 'testimonials_column_two_1_name', 'Mary K.'),
(1664, 187, '_testimonials_column_two_1_name', 'field_5b97fa3797db6'),
(1665, 187, 'testimonials_column_two_2_testimonial_quote', '“We feel blessed to have found you.”') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(1666, 187, '_testimonials_column_two_2_testimonial_quote', 'field_5b97fa3797db4'),
(1667, 187, 'testimonials_column_two_2_testimonial_content', 'I just want to express how grateful we are for all of your hard work and for what a great job you did for our case. You helped us through a difficult situation by being professional, competent and yet empathetic and understanding. Thank you for all of your hard work and encouragement – we feel blessed to have found you.'),
(1668, 187, '_testimonials_column_two_2_testimonial_content', 'field_5b97fa3797db5'),
(1669, 187, 'testimonials_column_two_2_name', 'Tim and Jennifer S.'),
(1670, 187, '_testimonials_column_two_2_name', 'field_5b97fa3797db6'),
(1671, 188, 'testimonials_column_one_0_testimonial_quote', '“We are Speechless for all your hard work and Education.”'),
(1672, 188, '_testimonials_column_one_0_testimonial_quote', 'field_5b97f9e997db0'),
(1673, 188, 'testimonials_column_one_0_testimonial_content', 'We are speechless for all your hard work and dedication…Thank you. For all of your professionalism and class…Thank you. For everything you’ve had to deal with and put up with…Thank you. For always keeping us informed every step of the way…Thank you. For putting your time and heart into your work for us…Thank you. For being such a kind, caring soul…Thank you.'),
(1674, 188, '_testimonials_column_one_0_testimonial_content', 'field_5b97fa1b97db1'),
(1675, 188, 'testimonials_column_one_0_name', 'Teri J.'),
(1676, 188, '_testimonials_column_one_0_name', 'field_5b97fa2897db2'),
(1677, 188, 'testimonials_column_one', '4'),
(1678, 188, '_testimonials_column_one', 'field_5b97f9d397daf'),
(1679, 188, 'testimonials_column_two_0_testimonial_quote', '“You have helped me through this process”'),
(1680, 188, '_testimonials_column_two_0_testimonial_quote', 'field_5b97fa3797db4'),
(1681, 188, 'testimonials_column_two_0_testimonial_content', 'I’m writing to let you know how much you have helped me through this process. It’s surely been a sad time for me but the way you helped me get through this made it better. The manner in which you get things done was the best for me. You took the time to explain in detail what was going on and if you could tell by my voice that I wasn’t understanding, you said it again with an example. You also gave me suggestions which I really listened to. I know you’d say you’re doing your job, but there are different ways to do that job. You did it in a caring way.'),
(1682, 188, '_testimonials_column_two_0_testimonial_content', 'field_5b97fa3797db5'),
(1683, 188, 'testimonials_column_two_0_name', 'Kathy S.'),
(1684, 188, '_testimonials_column_two_0_name', 'field_5b97fa3797db6'),
(1685, 188, 'testimonials_column_two', '3'),
(1686, 188, '_testimonials_column_two', 'field_5b97fa3797db3'),
(1687, 188, 'testimonials_column_one_1_testimonial_quote', '“I am and will always be grateful for you!”'),
(1688, 188, '_testimonials_column_one_1_testimonial_quote', 'field_5b97f9e997db0'),
(1689, 188, 'testimonials_column_one_1_testimonial_content', 'Thank you so very much for all your help with my case. You really came through for me. I am and will always be grateful for you!'),
(1690, 188, '_testimonials_column_one_1_testimonial_content', 'field_5b97fa1b97db1'),
(1691, 188, 'testimonials_column_one_1_name', 'Scott W.'),
(1692, 188, '_testimonials_column_one_1_name', 'field_5b97fa2897db2'),
(1693, 188, 'testimonials_column_one_2_testimonial_quote', '“I can’t express enough the appreciation for your hard work and sacrifice.”'),
(1694, 188, '_testimonials_column_one_2_testimonial_quote', 'field_5b97f9e997db0'),
(1695, 188, 'testimonials_column_one_2_testimonial_content', 'I can’t express enough to you and your family the appreciation for your hard work and sacrifice. As well as your concern,\r\ncompassion and professionalism.'),
(1696, 188, '_testimonials_column_one_2_testimonial_content', 'field_5b97fa1b97db1'),
(1697, 188, 'testimonials_column_one_2_name', 'Shawn D.'),
(1698, 188, '_testimonials_column_one_2_name', 'field_5b97fa2897db2'),
(1699, 188, 'testimonials_column_one_3_testimonial_quote', '“Greatly Appreciated.”'),
(1700, 188, '_testimonials_column_one_3_testimonial_quote', 'field_5b97f9e997db0'),
(1701, 188, 'testimonials_column_one_3_testimonial_content', 'I want to thank you and your staff for the work you did to settle\r\nmy claim. It is greatly appreciated.'),
(1702, 188, '_testimonials_column_one_3_testimonial_content', 'field_5b97fa1b97db1'),
(1703, 188, 'testimonials_column_one_3_name', 'Gail B.'),
(1704, 188, '_testimonials_column_one_3_name', 'field_5b97fa2897db2'),
(1705, 188, 'testimonials_column_two_1_testimonial_quote', '“It has been a genuine pleasure to have your expertise, counsel \r\nand guidance.”'),
(1706, 188, '_testimonials_column_two_1_testimonial_quote', 'field_5b97fa3797db4'),
(1707, 188, 'testimonials_column_two_1_testimonial_content', 'Thank you for your excellent representation in my personal injury claim. It has been a genuine pleasure to have your expertise, counsel and guidance. I am very pleased with the result of your efforts on my behalf. Throughout these many months you have, at all times, been professional, articulate, detailed, compassionate, personable and supportive in every way needed. I cannot thank you enough for making this difficult, protracted and, at times, distasteful process tolerable. Your knowledge and expertise; your patience explaining each and every step; presenting scenarios; risks and/or benefits; answering my questions; was an enormous factor in ensuring that each discussion and choice I made was fully informed and made with complete confidence. As busy as I knew you were, I never felt rushed or that you were not giving my every concern, large or small,\r\nyour complete attention.'),
(1708, 188, '_testimonials_column_two_1_testimonial_content', 'field_5b97fa3797db5'),
(1709, 188, 'testimonials_column_two_1_name', 'Mary K.'),
(1710, 188, '_testimonials_column_two_1_name', 'field_5b97fa3797db6'),
(1711, 188, 'testimonials_column_two_2_testimonial_quote', '“We feel blessed to have found you.”'),
(1712, 188, '_testimonials_column_two_2_testimonial_quote', 'field_5b97fa3797db4'),
(1713, 188, 'testimonials_column_two_2_testimonial_content', 'I just want to express how grateful we are for all of your hard work and for what a great job you did for our case. You helped us through a difficult situation by being professional, competent and yet empathetic and understanding. Thank you for all of your hard work and encouragement – we feel blessed to have found you.'),
(1714, 188, '_testimonials_column_two_2_testimonial_content', 'field_5b97fa3797db5'),
(1715, 188, 'testimonials_column_two_2_name', 'Tim and Jennifer S.'),
(1716, 188, '_testimonials_column_two_2_name', 'field_5b97fa3797db6'),
(1717, 189, 'testimonials_column_one_0_testimonial_quote', '“We are Speechless for all your hard work and Education.”'),
(1718, 189, '_testimonials_column_one_0_testimonial_quote', 'field_5b97f9e997db0'),
(1719, 189, 'testimonials_column_one_0_testimonial_content', 'We are speechless for all your hard work and dedication…Thank you. For all of your professionalism and class…Thank you. For everything you’ve had to deal with and put up with…Thank you. For always keeping us informed every step of the way…Thank you. For putting your time and heart into your work for us…Thank you. For being such a kind, caring soul…Thank you.'),
(1720, 189, '_testimonials_column_one_0_testimonial_content', 'field_5b97fa1b97db1'),
(1721, 189, 'testimonials_column_one_0_name', 'Teri J.'),
(1722, 189, '_testimonials_column_one_0_name', 'field_5b97fa2897db2'),
(1723, 189, 'testimonials_column_one', '4'),
(1724, 189, '_testimonials_column_one', 'field_5b97f9d397daf'),
(1725, 189, 'testimonials_column_two_0_testimonial_quote', '“You have helped me through this process”'),
(1726, 189, '_testimonials_column_two_0_testimonial_quote', 'field_5b97fa3797db4'),
(1727, 189, 'testimonials_column_two_0_testimonial_content', 'I’m writing to let you know how much you have helped me through this process. It’s surely been a sad time for me but the way you helped me get through this made it better. The manner in which you get things done was the best for me. You took the time to explain in detail what was going on and if you could tell by my voice that I wasn’t understanding, you said it again with an example. You also gave me suggestions which I really listened to. I know you’d say you’re doing your job, but there are\r\ndifferent ways to do that job. You did it in a caring way.'),
(1728, 189, '_testimonials_column_two_0_testimonial_content', 'field_5b97fa3797db5'),
(1729, 189, 'testimonials_column_two_0_name', 'Kathy S.'),
(1730, 189, '_testimonials_column_two_0_name', 'field_5b97fa3797db6'),
(1731, 189, 'testimonials_column_two', '3'),
(1732, 189, '_testimonials_column_two', 'field_5b97fa3797db3'),
(1733, 189, 'testimonials_column_one_1_testimonial_quote', '“I am and will always be grateful for you!”'),
(1734, 189, '_testimonials_column_one_1_testimonial_quote', 'field_5b97f9e997db0'),
(1735, 189, 'testimonials_column_one_1_testimonial_content', 'Thank you so very much for all your help with my case. You really came through for me. I am and will always be grateful for you!'),
(1736, 189, '_testimonials_column_one_1_testimonial_content', 'field_5b97fa1b97db1'),
(1737, 189, 'testimonials_column_one_1_name', 'Scott W.'),
(1738, 189, '_testimonials_column_one_1_name', 'field_5b97fa2897db2'),
(1739, 189, 'testimonials_column_one_2_testimonial_quote', '“I can’t express enough the appreciation for your hard work and sacrifice.”'),
(1740, 189, '_testimonials_column_one_2_testimonial_quote', 'field_5b97f9e997db0'),
(1741, 189, 'testimonials_column_one_2_testimonial_content', 'I can’t express enough to you and your family the appreciation for your hard work and sacrifice. As well as your concern,\r\ncompassion and professionalism.'),
(1742, 189, '_testimonials_column_one_2_testimonial_content', 'field_5b97fa1b97db1'),
(1743, 189, 'testimonials_column_one_2_name', 'Shawn D.'),
(1744, 189, '_testimonials_column_one_2_name', 'field_5b97fa2897db2'),
(1745, 189, 'testimonials_column_one_3_testimonial_quote', '“Greatly Appreciated.”'),
(1746, 189, '_testimonials_column_one_3_testimonial_quote', 'field_5b97f9e997db0'),
(1747, 189, 'testimonials_column_one_3_testimonial_content', 'I want to thank you and your staff for the work you did to settle\r\nmy claim. It is greatly appreciated.'),
(1748, 189, '_testimonials_column_one_3_testimonial_content', 'field_5b97fa1b97db1'),
(1749, 189, 'testimonials_column_one_3_name', 'Gail B.'),
(1750, 189, '_testimonials_column_one_3_name', 'field_5b97fa2897db2'),
(1751, 189, 'testimonials_column_two_1_testimonial_quote', '“It has been a genuine pleasure to have your expertise, counsel \r\nand guidance.”'),
(1752, 189, '_testimonials_column_two_1_testimonial_quote', 'field_5b97fa3797db4'),
(1753, 189, 'testimonials_column_two_1_testimonial_content', 'Thank you for your excellent representation in my personal injury claim. It has been a genuine pleasure to have your expertise, counsel and guidance. I am very pleased with the result of your efforts on my behalf. Throughout these many months you have, at all times, been professional, articulate, detailed, compassionate, personable and supportive in every way needed. I cannot thank you enough for making this difficult, protracted and, at times, distasteful process tolerable. Your knowledge and expertise; your patience explaining each and every step; presenting scenarios; risks and/or benefits; answering my questions; was an enormous factor in ensuring that each discussion and choice I made was fully informed and made with complete confidence. As busy as I knew you were, I never felt rushed or that you were not giving my every concern, large or small,\r\nyour complete attention.'),
(1754, 189, '_testimonials_column_two_1_testimonial_content', 'field_5b97fa3797db5'),
(1755, 189, 'testimonials_column_two_1_name', 'Mary K.'),
(1756, 189, '_testimonials_column_two_1_name', 'field_5b97fa3797db6'),
(1757, 189, 'testimonials_column_two_2_testimonial_quote', '“We feel blessed to have found you.”'),
(1758, 189, '_testimonials_column_two_2_testimonial_quote', 'field_5b97fa3797db4'),
(1759, 189, 'testimonials_column_two_2_testimonial_content', 'I just want to express how grateful we are for all of your hard work and for what a great job you did for our case. You helped us through a difficult situation by being professional, competent and yet empathetic and understanding. Thank you for all of your hard work and encouragement – we feel blessed to have found you.'),
(1760, 189, '_testimonials_column_two_2_testimonial_content', 'field_5b97fa3797db5'),
(1761, 189, 'testimonials_column_two_2_name', 'Tim and Jennifer S.'),
(1762, 189, '_testimonials_column_two_2_name', 'field_5b97fa3797db6'),
(1763, 190, 'testimonials_column_one_0_testimonial_quote', '“We are Speechless for all your hard work and Education.”'),
(1764, 190, '_testimonials_column_one_0_testimonial_quote', 'field_5b97f9e997db0'),
(1765, 190, 'testimonials_column_one_0_testimonial_content', 'We are speechless for all your hard work and dedication…Thank you. For all of your professionalism and class…Thank you. For everything you’ve had to deal with and put up with…Thank you. For always keeping us informed every step of the way…Thank you. For putting your time and heart into your work for us…Thank you. For being such a kind, caring soul…Thank you.') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(1766, 190, '_testimonials_column_one_0_testimonial_content', 'field_5b97fa1b97db1'),
(1767, 190, 'testimonials_column_one_0_name', 'Teri J.'),
(1768, 190, '_testimonials_column_one_0_name', 'field_5b97fa2897db2'),
(1769, 190, 'testimonials_column_one', '4'),
(1770, 190, '_testimonials_column_one', 'field_5b97f9d397daf'),
(1771, 190, 'testimonials_column_two_0_testimonial_quote', '“You have helped me through this process”'),
(1772, 190, '_testimonials_column_two_0_testimonial_quote', 'field_5b97fa3797db4'),
(1773, 190, 'testimonials_column_two_0_testimonial_content', 'I’m writing to let you know how much you have helped me through this process. It’s surely been a sad time for me but the way you helped me get through this made it better. The manner in which you get things done was the best for me. You took the time to explain in detail what was going on and if you could tell by my voice that I wasn’t understanding, you said it again with an example. You also gave me suggestions which I really listened to. I know you’d say you’re doing your job, but there are different ways to do that job.\r\nYou did it in a caring way.'),
(1774, 190, '_testimonials_column_two_0_testimonial_content', 'field_5b97fa3797db5'),
(1775, 190, 'testimonials_column_two_0_name', 'Kathy S.'),
(1776, 190, '_testimonials_column_two_0_name', 'field_5b97fa3797db6'),
(1777, 190, 'testimonials_column_two', '3'),
(1778, 190, '_testimonials_column_two', 'field_5b97fa3797db3'),
(1779, 190, 'testimonials_column_one_1_testimonial_quote', '“I am and will always be grateful for you!”'),
(1780, 190, '_testimonials_column_one_1_testimonial_quote', 'field_5b97f9e997db0'),
(1781, 190, 'testimonials_column_one_1_testimonial_content', 'Thank you so very much for all your help with my case. You really came through for me. I am and will always be grateful for you!'),
(1782, 190, '_testimonials_column_one_1_testimonial_content', 'field_5b97fa1b97db1'),
(1783, 190, 'testimonials_column_one_1_name', 'Scott W.'),
(1784, 190, '_testimonials_column_one_1_name', 'field_5b97fa2897db2'),
(1785, 190, 'testimonials_column_one_2_testimonial_quote', '“I can’t express enough the appreciation for your hard work and sacrifice.”'),
(1786, 190, '_testimonials_column_one_2_testimonial_quote', 'field_5b97f9e997db0'),
(1787, 190, 'testimonials_column_one_2_testimonial_content', 'I can’t express enough to you and your family the appreciation for your hard work and sacrifice. As well as your concern,\r\ncompassion and professionalism.'),
(1788, 190, '_testimonials_column_one_2_testimonial_content', 'field_5b97fa1b97db1'),
(1789, 190, 'testimonials_column_one_2_name', 'Shawn D.'),
(1790, 190, '_testimonials_column_one_2_name', 'field_5b97fa2897db2'),
(1791, 190, 'testimonials_column_one_3_testimonial_quote', '“Greatly Appreciated.”'),
(1792, 190, '_testimonials_column_one_3_testimonial_quote', 'field_5b97f9e997db0'),
(1793, 190, 'testimonials_column_one_3_testimonial_content', 'I want to thank you and your staff for the work you did to settle\r\nmy claim. It is greatly appreciated.'),
(1794, 190, '_testimonials_column_one_3_testimonial_content', 'field_5b97fa1b97db1'),
(1795, 190, 'testimonials_column_one_3_name', 'Gail B.'),
(1796, 190, '_testimonials_column_one_3_name', 'field_5b97fa2897db2'),
(1797, 190, 'testimonials_column_two_1_testimonial_quote', '“It has been a genuine pleasure to have your expertise, counsel \r\nand guidance.”'),
(1798, 190, '_testimonials_column_two_1_testimonial_quote', 'field_5b97fa3797db4'),
(1799, 190, 'testimonials_column_two_1_testimonial_content', 'Thank you for your excellent representation in my personal injury claim. It has been a genuine pleasure to have your expertise, counsel and guidance. I am very pleased with the result of your efforts on my behalf. Throughout these many months you have, at all times, been professional, articulate, detailed, compassionate, personable and supportive in every way needed. I cannot thank you enough for making this difficult, protracted and, at times, distasteful process tolerable. Your knowledge and expertise; your patience explaining each and every step; presenting scenarios; risks and/or benefits; answering my questions; was an enormous factor in ensuring that each discussion and choice I made was fully informed and made with complete confidence. As busy as I knew you were, I never felt rushed or that you were not giving my every concern, large or small,\r\nyour complete attention.'),
(1800, 190, '_testimonials_column_two_1_testimonial_content', 'field_5b97fa3797db5'),
(1801, 190, 'testimonials_column_two_1_name', 'Mary K.'),
(1802, 190, '_testimonials_column_two_1_name', 'field_5b97fa3797db6'),
(1803, 190, 'testimonials_column_two_2_testimonial_quote', '“We feel blessed to have found you.”'),
(1804, 190, '_testimonials_column_two_2_testimonial_quote', 'field_5b97fa3797db4'),
(1805, 190, 'testimonials_column_two_2_testimonial_content', 'I just want to express how grateful we are for all of your hard work and for what a great job you did for our case. You helped us through a difficult situation by being professional, competent and yet empathetic and understanding. Thank you for all of your hard work and encouragement – we feel blessed to have found you.'),
(1806, 190, '_testimonials_column_two_2_testimonial_content', 'field_5b97fa3797db5'),
(1807, 190, 'testimonials_column_two_2_name', 'Tim and Jennifer S.'),
(1808, 190, '_testimonials_column_two_2_name', 'field_5b97fa3797db6'),
(1809, 191, '_menu_item_type', 'post_type'),
(1810, 191, '_menu_item_menu_item_parent', '71'),
(1811, 191, '_menu_item_object_id', '12'),
(1812, 191, '_menu_item_object', 'page'),
(1813, 191, '_menu_item_target', ''),
(1814, 191, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(1815, 191, '_menu_item_xfn', ''),
(1816, 191, '_menu_item_url', ''),
(1818, 192, '_edit_last', '1'),
(1821, 192, '_edit_lock', '1536703780:1'),
(1822, 23, '_wp_trash_meta_status', 'publish'),
(1823, 23, '_wp_trash_meta_time', '1536704036'),
(1824, 23, '_wp_desired_post_slug', 'sample-post-5'),
(1825, 21, '_wp_trash_meta_status', 'publish'),
(1826, 21, '_wp_trash_meta_time', '1536704036'),
(1827, 21, '_wp_desired_post_slug', 'sample-post-4'),
(1828, 19, '_wp_trash_meta_status', 'publish'),
(1829, 19, '_wp_trash_meta_time', '1536704036'),
(1830, 19, '_wp_desired_post_slug', 'sample-post-3'),
(1831, 17, '_wp_trash_meta_status', 'publish'),
(1832, 17, '_wp_trash_meta_time', '1536704036'),
(1833, 17, '_wp_desired_post_slug', 'sample-post-2'),
(1834, 15, '_wp_trash_meta_status', 'publish'),
(1835, 15, '_wp_trash_meta_time', '1536704037'),
(1836, 15, '_wp_desired_post_slug', 'sample-post-1'),
(1839, 194, '_edit_last', '1'),
(1840, 194, '_edit_lock', '1536703780:1'),
(1843, 195, '_edit_last', '1'),
(1844, 195, '_edit_lock', '1536703780:1'),
(1847, 196, '_edit_last', '1'),
(1848, 196, '_edit_lock', '1536703780:1'),
(1851, 197, '_edit_last', '1'),
(1852, 197, '_edit_lock', '1536703780:1') ;

#
# End of data contents of table `wp_postmeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_posts`
#

DROP TABLE IF EXISTS `wp_posts`;


#
# Table structure of table `wp_posts`
#

CREATE TABLE `wp_posts` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_author` bigint(20) unsigned NOT NULL DEFAULT '0',
  `post_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_title` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_excerpt` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'publish',
  `comment_status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'open',
  `ping_status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'open',
  `post_password` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `post_name` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `to_ping` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `pinged` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content_filtered` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `guid` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `menu_order` int(11) NOT NULL DEFAULT '0',
  `post_type` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'post',
  `post_mime_type` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `post_name` (`post_name`(191)),
  KEY `type_status_date` (`post_type`,`post_status`,`post_date`,`ID`),
  KEY `post_parent` (`post_parent`),
  KEY `post_author` (`post_author`)
) ENGINE=InnoDB AUTO_INCREMENT=198 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_posts`
#
INSERT INTO `wp_posts` ( `ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(4, 1, '2017-12-27 00:03:52', '2017-12-27 00:03:52', 'a:7:{s:8:"location";a:1:{i:0;a:1:{i:0;a:3:{s:5:"param";s:12:"options_page";s:8:"operator";s:2:"==";s:5:"value";s:13:"theme-options";}}}s:8:"position";s:6:"normal";s:5:"style";s:7:"default";s:15:"label_placement";s:3:"top";s:21:"instruction_placement";s:5:"label";s:14:"hide_on_screen";s:0:"";s:11:"description";s:0:"";}', 'Theme Options', 'theme-options', 'publish', 'closed', 'closed', '', 'group_5a42e2e8d6530', '', '', '2018-01-23 02:49:05', '2018-01-23 02:49:05', '', 0, 'http://localhost:8888/?post_type=acf-field-group&#038;p=4', 0, 'acf-field-group', '', 0),
(5, 1, '2017-12-27 00:03:52', '2017-12-27 00:03:52', 'a:7:{s:4:"type";s:3:"tab";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"placement";s:3:"top";s:8:"endpoint";i:0;}', 'Header Scripts', '', 'publish', 'closed', 'closed', '', 'field_5a42e2ef5aee8', '', '', '2018-01-23 02:49:05', '2018-01-23 02:49:05', '', 4, 'http://localhost:8888/?post_type=acf-field&#038;p=5', 9, 'acf-field', '', 0),
(6, 1, '2017-12-27 00:03:52', '2017-12-27 00:03:52', 'a:12:{s:4:"type";s:8:"textarea";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:9:"maxlength";s:0:"";s:4:"rows";s:0:"";s:9:"new_lines";s:0:"";s:8:"readonly";i:0;s:8:"disabled";i:0;}', 'Schema Code', 'schema_code', 'publish', 'closed', 'closed', '', 'field_5a42e3275aee9', '', '', '2018-01-23 02:49:05', '2018-01-23 02:49:05', '', 4, 'http://localhost:8888/?post_type=acf-field&#038;p=6', 10, 'acf-field', '', 0),
(7, 1, '2017-12-27 00:03:52', '2017-12-27 00:03:52', 'a:12:{s:4:"type";s:8:"textarea";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:9:"maxlength";s:0:"";s:4:"rows";s:0:"";s:9:"new_lines";s:0:"";s:8:"readonly";i:0;s:8:"disabled";i:0;}', 'Analytics Code', 'analytics_code', 'publish', 'closed', 'closed', '', 'field_5a42e33c5aeea', '', '', '2018-01-23 02:49:05', '2018-01-23 02:49:05', '', 4, 'http://localhost:8888/?post_type=acf-field&#038;p=7', 11, 'acf-field', '', 0),
(8, 1, '2017-12-27 00:04:08', '2017-12-27 00:04:08', 'a:7:{s:4:"type";s:3:"tab";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"placement";s:3:"top";s:8:"endpoint";i:0;}', 'Firm Info', '', 'publish', 'closed', 'closed', '', 'field_5a42e36bdd9fd', '', '', '2017-12-27 00:07:39', '2017-12-27 00:07:39', '', 4, 'http://localhost:8888/?post_type=acf-field&#038;p=8', 0, 'acf-field', '', 0),
(10, 1, '2017-12-27 00:05:13', '2017-12-27 00:05:13', '', 'Home', '', 'publish', 'closed', 'closed', '', 'home', '', '', '2018-08-22 14:29:31', '2018-08-22 22:29:31', '', 0, 'http://localhost:8888/?page_id=10', 0, 'page', '', 0),
(11, 1, '2017-12-27 00:05:13', '2017-12-27 00:05:13', '', 'Home', '', 'inherit', 'closed', 'closed', '', '10-revision-v1', '', '', '2017-12-27 00:05:13', '2017-12-27 00:05:13', '', 10, 'http://localhost:8888/2017/12/27/10-revision-v1/', 0, 'revision', '', 0),
(12, 1, '2017-12-27 00:05:21', '2017-12-27 00:05:21', '', 'Blog', '', 'publish', 'closed', 'closed', '', 'blog', '', '', '2017-12-27 00:05:21', '2017-12-27 00:05:21', '', 0, 'http://localhost:8888/?page_id=12', 0, 'page', '', 0),
(13, 1, '2017-12-27 00:05:21', '2017-12-27 00:05:21', '', 'Blog', '', 'inherit', 'closed', 'closed', '', '12-revision-v1', '', '', '2017-12-27 00:05:21', '2017-12-27 00:05:21', '', 12, 'http://localhost:8888/2017/12/27/12-revision-v1/', 0, 'revision', '', 0),
(15, 1, '2017-12-27 00:08:31', '2017-12-27 00:08:31', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Auctor elit sed vulputate mi sit. Imperdiet sed euismod nisi porta lorem mollis aliquam. Urna et pharetra pharetra massa massa ultricies mi quis hendrerit. Malesuada fames ac turpis egestas integer eget aliquet. Nulla malesuada pellentesque elit eget gravida cum sociis natoque. Aenean vel elit scelerisque mauris pellentesque. Ac orci phasellus egestas tellus rutrum tellus pellentesque eu. Pellentesque adipiscing commodo elit at imperdiet dui accumsan sit. Enim facilisis gravida neque convallis a cras semper auctor neque. Cras semper auctor neque vitae.\r\n\r\nUt pharetra sit amet aliquam id diam. Nunc pulvinar sapien et ligula ullamcorper malesuada proin. Amet dictum sit amet justo donec. Urna et pharetra pharetra massa massa. Vulputate dignissim suspendisse in est ante in nibh mauris. Sem nulla pharetra diam sit amet nisl. Donec et odio pellentesque diam volutpat commodo. Quam pellentesque nec nam aliquam sem et. A diam sollicitudin tempor id eu nisl. Nisi scelerisque eu ultrices vitae auctor. Quam nulla porttitor massa id neque aliquam. Penatibus et magnis dis parturient montes nascetur ridiculus mus. Morbi quis commodo odio aenean sed adipiscing diam donec.\r\n\r\nEst lorem ipsum dolor sit amet consectetur adipiscing elit pellentesque. Integer enim neque volutpat ac tincidunt. Cursus euismod quis viverra nibh. Volutpat sed cras ornare arcu dui vivamus arcu felis. Aenean vel elit scelerisque mauris pellentesque pulvinar. Eget lorem dolor sed viverra ipsum nunc aliquet. Nibh tortor id aliquet lectus proin nibh nisl condimentum id. Hac habitasse platea dictumst vestibulum. In massa tempor nec feugiat. Mauris nunc congue nisi vitae suscipit tellus. Purus gravida quis blandit turpis. Volutpat lacus laoreet non curabitur gravida arcu. Fusce id velit ut tortor pretium. Suspendisse faucibus interdum posuere lorem ipsum dolor sit. Scelerisque in dictum non consectetur a. Massa massa ultricies mi quis hendrerit. Lacinia at quis risus sed vulputate odio ut enim blandit. Viverra ipsum nunc aliquet bibendum.\r\n\r\nMaecenas sed enim ut sem viverra aliquet eget sit. Sollicitudin tempor id eu nisl nunc mi ipsum faucibus. Ultrices mi tempus imperdiet nulla malesuada pellentesque elit eget. Id interdum velit laoreet id donec ultrices tincidunt arcu non. Egestas pretium aenean pharetra magna ac placerat. Senectus et netus et malesuada fames ac turpis. Purus in massa tempor nec feugiat nisl pretium fusce id. Habitasse platea dictumst vestibulum rhoncus est pellentesque elit ullamcorper dignissim. Sapien et ligula ullamcorper malesuada proin libero. Aliquam malesuada bibendum arcu vitae elementum curabitur vitae. Orci dapibus ultrices in iaculis nunc sed augue lacus viverra. Sem integer vitae justo eget magna fermentum iaculis eu.\r\n\r\nTempus imperdiet nulla malesuada pellentesque elit eget. Integer feugiat scelerisque varius morbi enim nunc faucibus a pellentesque. Ligula ullamcorper malesuada proin libero nunc consequat interdum. Etiam dignissim diam quis enim lobortis scelerisque. Neque vitae tempus quam pellentesque nec. Augue lacus viverra vitae congue. Mattis molestie a iaculis at erat pellentesque adipiscing. Mi ipsum faucibus vitae aliquet nec ullamcorper sit amet risus. Magnis dis parturient montes nascetur ridiculus mus mauris. Nunc consequat interdum varius sit amet mattis vulputate enim nulla. Enim ut sem viverra aliquet eget. Ut venenatis tellus in metus vulputate. Sed tempus urna et pharetra pharetra massa massa ultricies. Orci porta non pulvinar neque laoreet suspendisse interdum consectetur libero. Nec feugiat nisl pretium fusce id velit ut tortor. Urna nec tincidunt praesent semper. Bibendum at varius vel pharetra vel turpis nunc eget.', 'Sample Post 1', '', 'trash', 'open', 'open', '', 'sample-post-1__trashed', '', '', '2018-09-11 14:13:57', '2018-09-11 22:13:57', '', 0, 'http://localhost:8888/?p=15', 0, 'post', '', 0),
(16, 1, '2017-12-27 00:08:31', '2017-12-27 00:08:31', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Auctor elit sed vulputate mi sit. Imperdiet sed euismod nisi porta lorem mollis aliquam. Urna et pharetra pharetra massa massa ultricies mi quis hendrerit. Malesuada fames ac turpis egestas integer eget aliquet. Nulla malesuada pellentesque elit eget gravida cum sociis natoque. Aenean vel elit scelerisque mauris pellentesque. Ac orci phasellus egestas tellus rutrum tellus pellentesque eu. Pellentesque adipiscing commodo elit at imperdiet dui accumsan sit. Enim facilisis gravida neque convallis a cras semper auctor neque. Cras semper auctor neque vitae.\r\n\r\nUt pharetra sit amet aliquam id diam. Nunc pulvinar sapien et ligula ullamcorper malesuada proin. Amet dictum sit amet justo donec. Urna et pharetra pharetra massa massa. Vulputate dignissim suspendisse in est ante in nibh mauris. Sem nulla pharetra diam sit amet nisl. Donec et odio pellentesque diam volutpat commodo. Quam pellentesque nec nam aliquam sem et. A diam sollicitudin tempor id eu nisl. Nisi scelerisque eu ultrices vitae auctor. Quam nulla porttitor massa id neque aliquam. Penatibus et magnis dis parturient montes nascetur ridiculus mus. Morbi quis commodo odio aenean sed adipiscing diam donec.\r\n\r\nEst lorem ipsum dolor sit amet consectetur adipiscing elit pellentesque. Integer enim neque volutpat ac tincidunt. Cursus euismod quis viverra nibh. Volutpat sed cras ornare arcu dui vivamus arcu felis. Aenean vel elit scelerisque mauris pellentesque pulvinar. Eget lorem dolor sed viverra ipsum nunc aliquet. Nibh tortor id aliquet lectus proin nibh nisl condimentum id. Hac habitasse platea dictumst vestibulum. In massa tempor nec feugiat. Mauris nunc congue nisi vitae suscipit tellus. Purus gravida quis blandit turpis. Volutpat lacus laoreet non curabitur gravida arcu. Fusce id velit ut tortor pretium. Suspendisse faucibus interdum posuere lorem ipsum dolor sit. Scelerisque in dictum non consectetur a. Massa massa ultricies mi quis hendrerit. Lacinia at quis risus sed vulputate odio ut enim blandit. Viverra ipsum nunc aliquet bibendum.\r\n\r\nMaecenas sed enim ut sem viverra aliquet eget sit. Sollicitudin tempor id eu nisl nunc mi ipsum faucibus. Ultrices mi tempus imperdiet nulla malesuada pellentesque elit eget. Id interdum velit laoreet id donec ultrices tincidunt arcu non. Egestas pretium aenean pharetra magna ac placerat. Senectus et netus et malesuada fames ac turpis. Purus in massa tempor nec feugiat nisl pretium fusce id. Habitasse platea dictumst vestibulum rhoncus est pellentesque elit ullamcorper dignissim. Sapien et ligula ullamcorper malesuada proin libero. Aliquam malesuada bibendum arcu vitae elementum curabitur vitae. Orci dapibus ultrices in iaculis nunc sed augue lacus viverra. Sem integer vitae justo eget magna fermentum iaculis eu.\r\n\r\nTempus imperdiet nulla malesuada pellentesque elit eget. Integer feugiat scelerisque varius morbi enim nunc faucibus a pellentesque. Ligula ullamcorper malesuada proin libero nunc consequat interdum. Etiam dignissim diam quis enim lobortis scelerisque. Neque vitae tempus quam pellentesque nec. Augue lacus viverra vitae congue. Mattis molestie a iaculis at erat pellentesque adipiscing. Mi ipsum faucibus vitae aliquet nec ullamcorper sit amet risus. Magnis dis parturient montes nascetur ridiculus mus mauris. Nunc consequat interdum varius sit amet mattis vulputate enim nulla. Enim ut sem viverra aliquet eget. Ut venenatis tellus in metus vulputate. Sed tempus urna et pharetra pharetra massa massa ultricies. Orci porta non pulvinar neque laoreet suspendisse interdum consectetur libero. Nec feugiat nisl pretium fusce id velit ut tortor. Urna nec tincidunt praesent semper. Bibendum at varius vel pharetra vel turpis nunc eget.', 'Sample Post 1', '', 'inherit', 'closed', 'closed', '', '15-revision-v1', '', '', '2017-12-27 00:08:31', '2017-12-27 00:08:31', '', 15, 'http://localhost:8888/15-revision-v1/', 0, 'revision', '', 0),
(17, 1, '2017-12-27 00:08:44', '2017-12-27 00:08:44', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Auctor elit sed vulputate mi sit. Imperdiet sed euismod nisi porta lorem mollis aliquam. Urna et pharetra pharetra massa massa ultricies mi quis hendrerit. Malesuada fames ac turpis egestas integer eget aliquet. Nulla malesuada pellentesque elit eget gravida cum sociis natoque. Aenean vel elit scelerisque mauris pellentesque. Ac orci phasellus egestas tellus rutrum tellus pellentesque eu. Pellentesque adipiscing commodo elit at imperdiet dui accumsan sit. Enim facilisis gravida neque convallis a cras semper auctor neque. Cras semper auctor neque vitae.\r\n\r\nUt pharetra sit amet aliquam id diam. Nunc pulvinar sapien et ligula ullamcorper malesuada proin. Amet dictum sit amet justo donec. Urna et pharetra pharetra massa massa. Vulputate dignissim suspendisse in est ante in nibh mauris. Sem nulla pharetra diam sit amet nisl. Donec et odio pellentesque diam volutpat commodo. Quam pellentesque nec nam aliquam sem et. A diam sollicitudin tempor id eu nisl. Nisi scelerisque eu ultrices vitae auctor. Quam nulla porttitor massa id neque aliquam. Penatibus et magnis dis parturient montes nascetur ridiculus mus. Morbi quis commodo odio aenean sed adipiscing diam donec.\r\n\r\nEst lorem ipsum dolor sit amet consectetur adipiscing elit pellentesque. Integer enim neque volutpat ac tincidunt. Cursus euismod quis viverra nibh. Volutpat sed cras ornare arcu dui vivamus arcu felis. Aenean vel elit scelerisque mauris pellentesque pulvinar. Eget lorem dolor sed viverra ipsum nunc aliquet. Nibh tortor id aliquet lectus proin nibh nisl condimentum id. Hac habitasse platea dictumst vestibulum. In massa tempor nec feugiat. Mauris nunc congue nisi vitae suscipit tellus. Purus gravida quis blandit turpis. Volutpat lacus laoreet non curabitur gravida arcu. Fusce id velit ut tortor pretium. Suspendisse faucibus interdum posuere lorem ipsum dolor sit. Scelerisque in dictum non consectetur a. Massa massa ultricies mi quis hendrerit. Lacinia at quis risus sed vulputate odio ut enim blandit. Viverra ipsum nunc aliquet bibendum.\r\n\r\nMaecenas sed enim ut sem viverra aliquet eget sit. Sollicitudin tempor id eu nisl nunc mi ipsum faucibus. Ultrices mi tempus imperdiet nulla malesuada pellentesque elit eget. Id interdum velit laoreet id donec ultrices tincidunt arcu non. Egestas pretium aenean pharetra magna ac placerat. Senectus et netus et malesuada fames ac turpis. Purus in massa tempor nec feugiat nisl pretium fusce id. Habitasse platea dictumst vestibulum rhoncus est pellentesque elit ullamcorper dignissim. Sapien et ligula ullamcorper malesuada proin libero. Aliquam malesuada bibendum arcu vitae elementum curabitur vitae. Orci dapibus ultrices in iaculis nunc sed augue lacus viverra. Sem integer vitae justo eget magna fermentum iaculis eu.\r\n\r\nTempus imperdiet nulla malesuada pellentesque elit eget. Integer feugiat scelerisque varius morbi enim nunc faucibus a pellentesque. Ligula ullamcorper malesuada proin libero nunc consequat interdum. Etiam dignissim diam quis enim lobortis scelerisque. Neque vitae tempus quam pellentesque nec. Augue lacus viverra vitae congue. Mattis molestie a iaculis at erat pellentesque adipiscing. Mi ipsum faucibus vitae aliquet nec ullamcorper sit amet risus. Magnis dis parturient montes nascetur ridiculus mus mauris. Nunc consequat interdum varius sit amet mattis vulputate enim nulla. Enim ut sem viverra aliquet eget. Ut venenatis tellus in metus vulputate. Sed tempus urna et pharetra pharetra massa massa ultricies. Orci porta non pulvinar neque laoreet suspendisse interdum consectetur libero. Nec feugiat nisl pretium fusce id velit ut tortor. Urna nec tincidunt praesent semper. Bibendum at varius vel pharetra vel turpis nunc eget.', 'Sample Post 2', '', 'trash', 'open', 'open', '', 'sample-post-2__trashed', '', '', '2018-09-11 14:13:56', '2018-09-11 22:13:56', '', 0, 'http://localhost:8888/?p=17', 0, 'post', '', 0),
(18, 1, '2017-12-27 00:08:44', '2017-12-27 00:08:44', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Auctor elit sed vulputate mi sit. Imperdiet sed euismod nisi porta lorem mollis aliquam. Urna et pharetra pharetra massa massa ultricies mi quis hendrerit. Malesuada fames ac turpis egestas integer eget aliquet. Nulla malesuada pellentesque elit eget gravida cum sociis natoque. Aenean vel elit scelerisque mauris pellentesque. Ac orci phasellus egestas tellus rutrum tellus pellentesque eu. Pellentesque adipiscing commodo elit at imperdiet dui accumsan sit. Enim facilisis gravida neque convallis a cras semper auctor neque. Cras semper auctor neque vitae.\r\n\r\nUt pharetra sit amet aliquam id diam. Nunc pulvinar sapien et ligula ullamcorper malesuada proin. Amet dictum sit amet justo donec. Urna et pharetra pharetra massa massa. Vulputate dignissim suspendisse in est ante in nibh mauris. Sem nulla pharetra diam sit amet nisl. Donec et odio pellentesque diam volutpat commodo. Quam pellentesque nec nam aliquam sem et. A diam sollicitudin tempor id eu nisl. Nisi scelerisque eu ultrices vitae auctor. Quam nulla porttitor massa id neque aliquam. Penatibus et magnis dis parturient montes nascetur ridiculus mus. Morbi quis commodo odio aenean sed adipiscing diam donec.\r\n\r\nEst lorem ipsum dolor sit amet consectetur adipiscing elit pellentesque. Integer enim neque volutpat ac tincidunt. Cursus euismod quis viverra nibh. Volutpat sed cras ornare arcu dui vivamus arcu felis. Aenean vel elit scelerisque mauris pellentesque pulvinar. Eget lorem dolor sed viverra ipsum nunc aliquet. Nibh tortor id aliquet lectus proin nibh nisl condimentum id. Hac habitasse platea dictumst vestibulum. In massa tempor nec feugiat. Mauris nunc congue nisi vitae suscipit tellus. Purus gravida quis blandit turpis. Volutpat lacus laoreet non curabitur gravida arcu. Fusce id velit ut tortor pretium. Suspendisse faucibus interdum posuere lorem ipsum dolor sit. Scelerisque in dictum non consectetur a. Massa massa ultricies mi quis hendrerit. Lacinia at quis risus sed vulputate odio ut enim blandit. Viverra ipsum nunc aliquet bibendum.\r\n\r\nMaecenas sed enim ut sem viverra aliquet eget sit. Sollicitudin tempor id eu nisl nunc mi ipsum faucibus. Ultrices mi tempus imperdiet nulla malesuada pellentesque elit eget. Id interdum velit laoreet id donec ultrices tincidunt arcu non. Egestas pretium aenean pharetra magna ac placerat. Senectus et netus et malesuada fames ac turpis. Purus in massa tempor nec feugiat nisl pretium fusce id. Habitasse platea dictumst vestibulum rhoncus est pellentesque elit ullamcorper dignissim. Sapien et ligula ullamcorper malesuada proin libero. Aliquam malesuada bibendum arcu vitae elementum curabitur vitae. Orci dapibus ultrices in iaculis nunc sed augue lacus viverra. Sem integer vitae justo eget magna fermentum iaculis eu.\r\n\r\nTempus imperdiet nulla malesuada pellentesque elit eget. Integer feugiat scelerisque varius morbi enim nunc faucibus a pellentesque. Ligula ullamcorper malesuada proin libero nunc consequat interdum. Etiam dignissim diam quis enim lobortis scelerisque. Neque vitae tempus quam pellentesque nec. Augue lacus viverra vitae congue. Mattis molestie a iaculis at erat pellentesque adipiscing. Mi ipsum faucibus vitae aliquet nec ullamcorper sit amet risus. Magnis dis parturient montes nascetur ridiculus mus mauris. Nunc consequat interdum varius sit amet mattis vulputate enim nulla. Enim ut sem viverra aliquet eget. Ut venenatis tellus in metus vulputate. Sed tempus urna et pharetra pharetra massa massa ultricies. Orci porta non pulvinar neque laoreet suspendisse interdum consectetur libero. Nec feugiat nisl pretium fusce id velit ut tortor. Urna nec tincidunt praesent semper. Bibendum at varius vel pharetra vel turpis nunc eget.', 'Sample Post 2', '', 'inherit', 'closed', 'closed', '', '17-revision-v1', '', '', '2017-12-27 00:08:44', '2017-12-27 00:08:44', '', 17, 'http://localhost:8888/17-revision-v1/', 0, 'revision', '', 0),
(19, 1, '2017-12-27 00:08:56', '2017-12-27 00:08:56', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Auctor elit sed vulputate mi sit. Imperdiet sed euismod nisi porta lorem mollis aliquam. Urna et pharetra pharetra massa massa ultricies mi quis hendrerit. Malesuada fames ac turpis egestas integer eget aliquet. Nulla malesuada pellentesque elit eget gravida cum sociis natoque. Aenean vel elit scelerisque mauris pellentesque. Ac orci phasellus egestas tellus rutrum tellus pellentesque eu. Pellentesque adipiscing commodo elit at imperdiet dui accumsan sit. Enim facilisis gravida neque convallis a cras semper auctor neque. Cras semper auctor neque vitae.\r\n\r\nUt pharetra sit amet aliquam id diam. Nunc pulvinar sapien et ligula ullamcorper malesuada proin. Amet dictum sit amet justo donec. Urna et pharetra pharetra massa massa. Vulputate dignissim suspendisse in est ante in nibh mauris. Sem nulla pharetra diam sit amet nisl. Donec et odio pellentesque diam volutpat commodo. Quam pellentesque nec nam aliquam sem et. A diam sollicitudin tempor id eu nisl. Nisi scelerisque eu ultrices vitae auctor. Quam nulla porttitor massa id neque aliquam. Penatibus et magnis dis parturient montes nascetur ridiculus mus. Morbi quis commodo odio aenean sed adipiscing diam donec.\r\n\r\nEst lorem ipsum dolor sit amet consectetur adipiscing elit pellentesque. Integer enim neque volutpat ac tincidunt. Cursus euismod quis viverra nibh. Volutpat sed cras ornare arcu dui vivamus arcu felis. Aenean vel elit scelerisque mauris pellentesque pulvinar. Eget lorem dolor sed viverra ipsum nunc aliquet. Nibh tortor id aliquet lectus proin nibh nisl condimentum id. Hac habitasse platea dictumst vestibulum. In massa tempor nec feugiat. Mauris nunc congue nisi vitae suscipit tellus. Purus gravida quis blandit turpis. Volutpat lacus laoreet non curabitur gravida arcu. Fusce id velit ut tortor pretium. Suspendisse faucibus interdum posuere lorem ipsum dolor sit. Scelerisque in dictum non consectetur a. Massa massa ultricies mi quis hendrerit. Lacinia at quis risus sed vulputate odio ut enim blandit. Viverra ipsum nunc aliquet bibendum.\r\n\r\nMaecenas sed enim ut sem viverra aliquet eget sit. Sollicitudin tempor id eu nisl nunc mi ipsum faucibus. Ultrices mi tempus imperdiet nulla malesuada pellentesque elit eget. Id interdum velit laoreet id donec ultrices tincidunt arcu non. Egestas pretium aenean pharetra magna ac placerat. Senectus et netus et malesuada fames ac turpis. Purus in massa tempor nec feugiat nisl pretium fusce id. Habitasse platea dictumst vestibulum rhoncus est pellentesque elit ullamcorper dignissim. Sapien et ligula ullamcorper malesuada proin libero. Aliquam malesuada bibendum arcu vitae elementum curabitur vitae. Orci dapibus ultrices in iaculis nunc sed augue lacus viverra. Sem integer vitae justo eget magna fermentum iaculis eu.\r\n\r\nTempus imperdiet nulla malesuada pellentesque elit eget. Integer feugiat scelerisque varius morbi enim nunc faucibus a pellentesque. Ligula ullamcorper malesuada proin libero nunc consequat interdum. Etiam dignissim diam quis enim lobortis scelerisque. Neque vitae tempus quam pellentesque nec. Augue lacus viverra vitae congue. Mattis molestie a iaculis at erat pellentesque adipiscing. Mi ipsum faucibus vitae aliquet nec ullamcorper sit amet risus. Magnis dis parturient montes nascetur ridiculus mus mauris. Nunc consequat interdum varius sit amet mattis vulputate enim nulla. Enim ut sem viverra aliquet eget. Ut venenatis tellus in metus vulputate. Sed tempus urna et pharetra pharetra massa massa ultricies. Orci porta non pulvinar neque laoreet suspendisse interdum consectetur libero. Nec feugiat nisl pretium fusce id velit ut tortor. Urna nec tincidunt praesent semper. Bibendum at varius vel pharetra vel turpis nunc eget.', 'Sample Post 3', '', 'trash', 'open', 'open', '', 'sample-post-3__trashed', '', '', '2018-09-11 14:13:56', '2018-09-11 22:13:56', '', 0, 'http://localhost:8888/?p=19', 0, 'post', '', 0),
(20, 1, '2017-12-27 00:08:56', '2017-12-27 00:08:56', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Auctor elit sed vulputate mi sit. Imperdiet sed euismod nisi porta lorem mollis aliquam. Urna et pharetra pharetra massa massa ultricies mi quis hendrerit. Malesuada fames ac turpis egestas integer eget aliquet. Nulla malesuada pellentesque elit eget gravida cum sociis natoque. Aenean vel elit scelerisque mauris pellentesque. Ac orci phasellus egestas tellus rutrum tellus pellentesque eu. Pellentesque adipiscing commodo elit at imperdiet dui accumsan sit. Enim facilisis gravida neque convallis a cras semper auctor neque. Cras semper auctor neque vitae.\r\n\r\nUt pharetra sit amet aliquam id diam. Nunc pulvinar sapien et ligula ullamcorper malesuada proin. Amet dictum sit amet justo donec. Urna et pharetra pharetra massa massa. Vulputate dignissim suspendisse in est ante in nibh mauris. Sem nulla pharetra diam sit amet nisl. Donec et odio pellentesque diam volutpat commodo. Quam pellentesque nec nam aliquam sem et. A diam sollicitudin tempor id eu nisl. Nisi scelerisque eu ultrices vitae auctor. Quam nulla porttitor massa id neque aliquam. Penatibus et magnis dis parturient montes nascetur ridiculus mus. Morbi quis commodo odio aenean sed adipiscing diam donec.\r\n\r\nEst lorem ipsum dolor sit amet consectetur adipiscing elit pellentesque. Integer enim neque volutpat ac tincidunt. Cursus euismod quis viverra nibh. Volutpat sed cras ornare arcu dui vivamus arcu felis. Aenean vel elit scelerisque mauris pellentesque pulvinar. Eget lorem dolor sed viverra ipsum nunc aliquet. Nibh tortor id aliquet lectus proin nibh nisl condimentum id. Hac habitasse platea dictumst vestibulum. In massa tempor nec feugiat. Mauris nunc congue nisi vitae suscipit tellus. Purus gravida quis blandit turpis. Volutpat lacus laoreet non curabitur gravida arcu. Fusce id velit ut tortor pretium. Suspendisse faucibus interdum posuere lorem ipsum dolor sit. Scelerisque in dictum non consectetur a. Massa massa ultricies mi quis hendrerit. Lacinia at quis risus sed vulputate odio ut enim blandit. Viverra ipsum nunc aliquet bibendum.\r\n\r\nMaecenas sed enim ut sem viverra aliquet eget sit. Sollicitudin tempor id eu nisl nunc mi ipsum faucibus. Ultrices mi tempus imperdiet nulla malesuada pellentesque elit eget. Id interdum velit laoreet id donec ultrices tincidunt arcu non. Egestas pretium aenean pharetra magna ac placerat. Senectus et netus et malesuada fames ac turpis. Purus in massa tempor nec feugiat nisl pretium fusce id. Habitasse platea dictumst vestibulum rhoncus est pellentesque elit ullamcorper dignissim. Sapien et ligula ullamcorper malesuada proin libero. Aliquam malesuada bibendum arcu vitae elementum curabitur vitae. Orci dapibus ultrices in iaculis nunc sed augue lacus viverra. Sem integer vitae justo eget magna fermentum iaculis eu.\r\n\r\nTempus imperdiet nulla malesuada pellentesque elit eget. Integer feugiat scelerisque varius morbi enim nunc faucibus a pellentesque. Ligula ullamcorper malesuada proin libero nunc consequat interdum. Etiam dignissim diam quis enim lobortis scelerisque. Neque vitae tempus quam pellentesque nec. Augue lacus viverra vitae congue. Mattis molestie a iaculis at erat pellentesque adipiscing. Mi ipsum faucibus vitae aliquet nec ullamcorper sit amet risus. Magnis dis parturient montes nascetur ridiculus mus mauris. Nunc consequat interdum varius sit amet mattis vulputate enim nulla. Enim ut sem viverra aliquet eget. Ut venenatis tellus in metus vulputate. Sed tempus urna et pharetra pharetra massa massa ultricies. Orci porta non pulvinar neque laoreet suspendisse interdum consectetur libero. Nec feugiat nisl pretium fusce id velit ut tortor. Urna nec tincidunt praesent semper. Bibendum at varius vel pharetra vel turpis nunc eget.', 'Sample Post 3', '', 'inherit', 'closed', 'closed', '', '19-revision-v1', '', '', '2017-12-27 00:08:56', '2017-12-27 00:08:56', '', 19, 'http://localhost:8888/19-revision-v1/', 0, 'revision', '', 0),
(21, 1, '2017-12-27 00:09:07', '2017-12-27 00:09:07', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Auctor elit sed vulputate mi sit. Imperdiet sed euismod nisi porta lorem mollis aliquam. Urna et pharetra pharetra massa massa ultricies mi quis hendrerit. Malesuada fames ac turpis egestas integer eget aliquet. Nulla malesuada pellentesque elit eget gravida cum sociis natoque. Aenean vel elit scelerisque mauris pellentesque. Ac orci phasellus egestas tellus rutrum tellus pellentesque eu. Pellentesque adipiscing commodo elit at imperdiet dui accumsan sit. Enim facilisis gravida neque convallis a cras semper auctor neque. Cras semper auctor neque vitae.\r\n\r\nUt pharetra sit amet aliquam id diam. Nunc pulvinar sapien et ligula ullamcorper malesuada proin. Amet dictum sit amet justo donec. Urna et pharetra pharetra massa massa. Vulputate dignissim suspendisse in est ante in nibh mauris. Sem nulla pharetra diam sit amet nisl. Donec et odio pellentesque diam volutpat commodo. Quam pellentesque nec nam aliquam sem et. A diam sollicitudin tempor id eu nisl. Nisi scelerisque eu ultrices vitae auctor. Quam nulla porttitor massa id neque aliquam. Penatibus et magnis dis parturient montes nascetur ridiculus mus. Morbi quis commodo odio aenean sed adipiscing diam donec.\r\n\r\nEst lorem ipsum dolor sit amet consectetur adipiscing elit pellentesque. Integer enim neque volutpat ac tincidunt. Cursus euismod quis viverra nibh. Volutpat sed cras ornare arcu dui vivamus arcu felis. Aenean vel elit scelerisque mauris pellentesque pulvinar. Eget lorem dolor sed viverra ipsum nunc aliquet. Nibh tortor id aliquet lectus proin nibh nisl condimentum id. Hac habitasse platea dictumst vestibulum. In massa tempor nec feugiat. Mauris nunc congue nisi vitae suscipit tellus. Purus gravida quis blandit turpis. Volutpat lacus laoreet non curabitur gravida arcu. Fusce id velit ut tortor pretium. Suspendisse faucibus interdum posuere lorem ipsum dolor sit. Scelerisque in dictum non consectetur a. Massa massa ultricies mi quis hendrerit. Lacinia at quis risus sed vulputate odio ut enim blandit. Viverra ipsum nunc aliquet bibendum.\r\n\r\nMaecenas sed enim ut sem viverra aliquet eget sit. Sollicitudin tempor id eu nisl nunc mi ipsum faucibus. Ultrices mi tempus imperdiet nulla malesuada pellentesque elit eget. Id interdum velit laoreet id donec ultrices tincidunt arcu non. Egestas pretium aenean pharetra magna ac placerat. Senectus et netus et malesuada fames ac turpis. Purus in massa tempor nec feugiat nisl pretium fusce id. Habitasse platea dictumst vestibulum rhoncus est pellentesque elit ullamcorper dignissim. Sapien et ligula ullamcorper malesuada proin libero. Aliquam malesuada bibendum arcu vitae elementum curabitur vitae. Orci dapibus ultrices in iaculis nunc sed augue lacus viverra. Sem integer vitae justo eget magna fermentum iaculis eu.\r\n\r\nTempus imperdiet nulla malesuada pellentesque elit eget. Integer feugiat scelerisque varius morbi enim nunc faucibus a pellentesque. Ligula ullamcorper malesuada proin libero nunc consequat interdum. Etiam dignissim diam quis enim lobortis scelerisque. Neque vitae tempus quam pellentesque nec. Augue lacus viverra vitae congue. Mattis molestie a iaculis at erat pellentesque adipiscing. Mi ipsum faucibus vitae aliquet nec ullamcorper sit amet risus. Magnis dis parturient montes nascetur ridiculus mus mauris. Nunc consequat interdum varius sit amet mattis vulputate enim nulla. Enim ut sem viverra aliquet eget. Ut venenatis tellus in metus vulputate. Sed tempus urna et pharetra pharetra massa massa ultricies. Orci porta non pulvinar neque laoreet suspendisse interdum consectetur libero. Nec feugiat nisl pretium fusce id velit ut tortor. Urna nec tincidunt praesent semper. Bibendum at varius vel pharetra vel turpis nunc eget.', 'Sample Post 4', '', 'trash', 'open', 'open', '', 'sample-post-4__trashed', '', '', '2018-09-11 14:13:56', '2018-09-11 22:13:56', '', 0, 'http://localhost:8888/?p=21', 0, 'post', '', 0),
(22, 1, '2017-12-27 00:09:07', '2017-12-27 00:09:07', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Auctor elit sed vulputate mi sit. Imperdiet sed euismod nisi porta lorem mollis aliquam. Urna et pharetra pharetra massa massa ultricies mi quis hendrerit. Malesuada fames ac turpis egestas integer eget aliquet. Nulla malesuada pellentesque elit eget gravida cum sociis natoque. Aenean vel elit scelerisque mauris pellentesque. Ac orci phasellus egestas tellus rutrum tellus pellentesque eu. Pellentesque adipiscing commodo elit at imperdiet dui accumsan sit. Enim facilisis gravida neque convallis a cras semper auctor neque. Cras semper auctor neque vitae.\r\n\r\nUt pharetra sit amet aliquam id diam. Nunc pulvinar sapien et ligula ullamcorper malesuada proin. Amet dictum sit amet justo donec. Urna et pharetra pharetra massa massa. Vulputate dignissim suspendisse in est ante in nibh mauris. Sem nulla pharetra diam sit amet nisl. Donec et odio pellentesque diam volutpat commodo. Quam pellentesque nec nam aliquam sem et. A diam sollicitudin tempor id eu nisl. Nisi scelerisque eu ultrices vitae auctor. Quam nulla porttitor massa id neque aliquam. Penatibus et magnis dis parturient montes nascetur ridiculus mus. Morbi quis commodo odio aenean sed adipiscing diam donec.\r\n\r\nEst lorem ipsum dolor sit amet consectetur adipiscing elit pellentesque. Integer enim neque volutpat ac tincidunt. Cursus euismod quis viverra nibh. Volutpat sed cras ornare arcu dui vivamus arcu felis. Aenean vel elit scelerisque mauris pellentesque pulvinar. Eget lorem dolor sed viverra ipsum nunc aliquet. Nibh tortor id aliquet lectus proin nibh nisl condimentum id. Hac habitasse platea dictumst vestibulum. In massa tempor nec feugiat. Mauris nunc congue nisi vitae suscipit tellus. Purus gravida quis blandit turpis. Volutpat lacus laoreet non curabitur gravida arcu. Fusce id velit ut tortor pretium. Suspendisse faucibus interdum posuere lorem ipsum dolor sit. Scelerisque in dictum non consectetur a. Massa massa ultricies mi quis hendrerit. Lacinia at quis risus sed vulputate odio ut enim blandit. Viverra ipsum nunc aliquet bibendum.\r\n\r\nMaecenas sed enim ut sem viverra aliquet eget sit. Sollicitudin tempor id eu nisl nunc mi ipsum faucibus. Ultrices mi tempus imperdiet nulla malesuada pellentesque elit eget. Id interdum velit laoreet id donec ultrices tincidunt arcu non. Egestas pretium aenean pharetra magna ac placerat. Senectus et netus et malesuada fames ac turpis. Purus in massa tempor nec feugiat nisl pretium fusce id. Habitasse platea dictumst vestibulum rhoncus est pellentesque elit ullamcorper dignissim. Sapien et ligula ullamcorper malesuada proin libero. Aliquam malesuada bibendum arcu vitae elementum curabitur vitae. Orci dapibus ultrices in iaculis nunc sed augue lacus viverra. Sem integer vitae justo eget magna fermentum iaculis eu.\r\n\r\nTempus imperdiet nulla malesuada pellentesque elit eget. Integer feugiat scelerisque varius morbi enim nunc faucibus a pellentesque. Ligula ullamcorper malesuada proin libero nunc consequat interdum. Etiam dignissim diam quis enim lobortis scelerisque. Neque vitae tempus quam pellentesque nec. Augue lacus viverra vitae congue. Mattis molestie a iaculis at erat pellentesque adipiscing. Mi ipsum faucibus vitae aliquet nec ullamcorper sit amet risus. Magnis dis parturient montes nascetur ridiculus mus mauris. Nunc consequat interdum varius sit amet mattis vulputate enim nulla. Enim ut sem viverra aliquet eget. Ut venenatis tellus in metus vulputate. Sed tempus urna et pharetra pharetra massa massa ultricies. Orci porta non pulvinar neque laoreet suspendisse interdum consectetur libero. Nec feugiat nisl pretium fusce id velit ut tortor. Urna nec tincidunt praesent semper. Bibendum at varius vel pharetra vel turpis nunc eget.', 'Sample Post 4', '', 'inherit', 'closed', 'closed', '', '21-revision-v1', '', '', '2017-12-27 00:09:07', '2017-12-27 00:09:07', '', 21, 'http://localhost:8888/21-revision-v1/', 0, 'revision', '', 0),
(23, 1, '2017-12-27 00:09:20', '2017-12-27 00:09:20', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Auctor elit sed vulputate mi sit. Imperdiet sed euismod nisi porta lorem mollis aliquam. Urna et pharetra pharetra massa massa ultricies mi quis hendrerit. Malesuada fames ac turpis egestas integer eget aliquet. Nulla malesuada pellentesque elit eget gravida cum sociis natoque. Aenean vel elit scelerisque mauris pellentesque. Ac orci phasellus egestas tellus rutrum tellus pellentesque eu. Pellentesque adipiscing commodo elit at imperdiet dui accumsan sit. Enim facilisis gravida neque convallis a cras semper auctor neque. Cras semper auctor neque vitae.\r\n\r\nUt pharetra sit amet aliquam id diam. Nunc pulvinar sapien et ligula ullamcorper malesuada proin. Amet dictum sit amet justo donec. Urna et pharetra pharetra massa massa. Vulputate dignissim suspendisse in est ante in nibh mauris. Sem nulla pharetra diam sit amet nisl. Donec et odio pellentesque diam volutpat commodo. Quam pellentesque nec nam aliquam sem et. A diam sollicitudin tempor id eu nisl. Nisi scelerisque eu ultrices vitae auctor. Quam nulla porttitor massa id neque aliquam. Penatibus et magnis dis parturient montes nascetur ridiculus mus. Morbi quis commodo odio aenean sed adipiscing diam donec.\r\n\r\nEst lorem ipsum dolor sit amet consectetur adipiscing elit pellentesque. Integer enim neque volutpat ac tincidunt. Cursus euismod quis viverra nibh. Volutpat sed cras ornare arcu dui vivamus arcu felis. Aenean vel elit scelerisque mauris pellentesque pulvinar. Eget lorem dolor sed viverra ipsum nunc aliquet. Nibh tortor id aliquet lectus proin nibh nisl condimentum id. Hac habitasse platea dictumst vestibulum. In massa tempor nec feugiat. Mauris nunc congue nisi vitae suscipit tellus. Purus gravida quis blandit turpis. Volutpat lacus laoreet non curabitur gravida arcu. Fusce id velit ut tortor pretium. Suspendisse faucibus interdum posuere lorem ipsum dolor sit. Scelerisque in dictum non consectetur a. Massa massa ultricies mi quis hendrerit. Lacinia at quis risus sed vulputate odio ut enim blandit. Viverra ipsum nunc aliquet bibendum.\r\n\r\nMaecenas sed enim ut sem viverra aliquet eget sit. Sollicitudin tempor id eu nisl nunc mi ipsum faucibus. Ultrices mi tempus imperdiet nulla malesuada pellentesque elit eget. Id interdum velit laoreet id donec ultrices tincidunt arcu non. Egestas pretium aenean pharetra magna ac placerat. Senectus et netus et malesuada fames ac turpis. Purus in massa tempor nec feugiat nisl pretium fusce id. Habitasse platea dictumst vestibulum rhoncus est pellentesque elit ullamcorper dignissim. Sapien et ligula ullamcorper malesuada proin libero. Aliquam malesuada bibendum arcu vitae elementum curabitur vitae. Orci dapibus ultrices in iaculis nunc sed augue lacus viverra. Sem integer vitae justo eget magna fermentum iaculis eu.\r\n\r\nTempus imperdiet nulla malesuada pellentesque elit eget. Integer feugiat scelerisque varius morbi enim nunc faucibus a pellentesque. Ligula ullamcorper malesuada proin libero nunc consequat interdum. Etiam dignissim diam quis enim lobortis scelerisque. Neque vitae tempus quam pellentesque nec. Augue lacus viverra vitae congue. Mattis molestie a iaculis at erat pellentesque adipiscing. Mi ipsum faucibus vitae aliquet nec ullamcorper sit amet risus. Magnis dis parturient montes nascetur ridiculus mus mauris. Nunc consequat interdum varius sit amet mattis vulputate enim nulla. Enim ut sem viverra aliquet eget. Ut venenatis tellus in metus vulputate. Sed tempus urna et pharetra pharetra massa massa ultricies. Orci porta non pulvinar neque laoreet suspendisse interdum consectetur libero. Nec feugiat nisl pretium fusce id velit ut tortor. Urna nec tincidunt praesent semper. Bibendum at varius vel pharetra vel turpis nunc eget.', 'Sample Post 5', '', 'trash', 'open', 'open', '', 'sample-post-5__trashed', '', '', '2018-09-11 14:13:56', '2018-09-11 22:13:56', '', 0, 'http://localhost:8888/?p=23', 0, 'post', '', 0),
(24, 1, '2017-12-27 00:09:20', '2017-12-27 00:09:20', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Auctor elit sed vulputate mi sit. Imperdiet sed euismod nisi porta lorem mollis aliquam. Urna et pharetra pharetra massa massa ultricies mi quis hendrerit. Malesuada fames ac turpis egestas integer eget aliquet. Nulla malesuada pellentesque elit eget gravida cum sociis natoque. Aenean vel elit scelerisque mauris pellentesque. Ac orci phasellus egestas tellus rutrum tellus pellentesque eu. Pellentesque adipiscing commodo elit at imperdiet dui accumsan sit. Enim facilisis gravida neque convallis a cras semper auctor neque. Cras semper auctor neque vitae.\r\n\r\nUt pharetra sit amet aliquam id diam. Nunc pulvinar sapien et ligula ullamcorper malesuada proin. Amet dictum sit amet justo donec. Urna et pharetra pharetra massa massa. Vulputate dignissim suspendisse in est ante in nibh mauris. Sem nulla pharetra diam sit amet nisl. Donec et odio pellentesque diam volutpat commodo. Quam pellentesque nec nam aliquam sem et. A diam sollicitudin tempor id eu nisl. Nisi scelerisque eu ultrices vitae auctor. Quam nulla porttitor massa id neque aliquam. Penatibus et magnis dis parturient montes nascetur ridiculus mus. Morbi quis commodo odio aenean sed adipiscing diam donec.\r\n\r\nEst lorem ipsum dolor sit amet consectetur adipiscing elit pellentesque. Integer enim neque volutpat ac tincidunt. Cursus euismod quis viverra nibh. Volutpat sed cras ornare arcu dui vivamus arcu felis. Aenean vel elit scelerisque mauris pellentesque pulvinar. Eget lorem dolor sed viverra ipsum nunc aliquet. Nibh tortor id aliquet lectus proin nibh nisl condimentum id. Hac habitasse platea dictumst vestibulum. In massa tempor nec feugiat. Mauris nunc congue nisi vitae suscipit tellus. Purus gravida quis blandit turpis. Volutpat lacus laoreet non curabitur gravida arcu. Fusce id velit ut tortor pretium. Suspendisse faucibus interdum posuere lorem ipsum dolor sit. Scelerisque in dictum non consectetur a. Massa massa ultricies mi quis hendrerit. Lacinia at quis risus sed vulputate odio ut enim blandit. Viverra ipsum nunc aliquet bibendum.\r\n\r\nMaecenas sed enim ut sem viverra aliquet eget sit. Sollicitudin tempor id eu nisl nunc mi ipsum faucibus. Ultrices mi tempus imperdiet nulla malesuada pellentesque elit eget. Id interdum velit laoreet id donec ultrices tincidunt arcu non. Egestas pretium aenean pharetra magna ac placerat. Senectus et netus et malesuada fames ac turpis. Purus in massa tempor nec feugiat nisl pretium fusce id. Habitasse platea dictumst vestibulum rhoncus est pellentesque elit ullamcorper dignissim. Sapien et ligula ullamcorper malesuada proin libero. Aliquam malesuada bibendum arcu vitae elementum curabitur vitae. Orci dapibus ultrices in iaculis nunc sed augue lacus viverra. Sem integer vitae justo eget magna fermentum iaculis eu.\r\n\r\nTempus imperdiet nulla malesuada pellentesque elit eget. Integer feugiat scelerisque varius morbi enim nunc faucibus a pellentesque. Ligula ullamcorper malesuada proin libero nunc consequat interdum. Etiam dignissim diam quis enim lobortis scelerisque. Neque vitae tempus quam pellentesque nec. Augue lacus viverra vitae congue. Mattis molestie a iaculis at erat pellentesque adipiscing. Mi ipsum faucibus vitae aliquet nec ullamcorper sit amet risus. Magnis dis parturient montes nascetur ridiculus mus mauris. Nunc consequat interdum varius sit amet mattis vulputate enim nulla. Enim ut sem viverra aliquet eget. Ut venenatis tellus in metus vulputate. Sed tempus urna et pharetra pharetra massa massa ultricies. Orci porta non pulvinar neque laoreet suspendisse interdum consectetur libero. Nec feugiat nisl pretium fusce id velit ut tortor. Urna nec tincidunt praesent semper. Bibendum at varius vel pharetra vel turpis nunc eget.', 'Sample Post 5', '', 'inherit', 'closed', 'closed', '', '23-revision-v1', '', '', '2017-12-27 00:09:20', '2017-12-27 00:09:20', '', 23, 'http://localhost:8888/23-revision-v1/', 0, 'revision', '', 0),
(28, 1, '2018-01-23 02:41:42', '2018-01-23 02:41:42', 'a:12:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";s:8:"readonly";i:0;s:8:"disabled";i:0;}', 'Firm Number Local', 'firm_number_local', 'publish', 'closed', 'closed', '', 'field_5a66a0dc333dd', '', '', '2018-01-23 02:44:34', '2018-01-23 02:44:34', '', 4, 'http://localhost:8888/?post_type=acf-field&#038;p=28', 1, 'acf-field', '', 0),
(29, 1, '2018-01-23 02:44:34', '2018-01-23 02:44:34', 'a:12:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";s:8:"readonly";i:0;s:8:"disabled";i:0;}', 'Firm Number Toll Free', 'firm_number_toll_free', 'publish', 'closed', 'closed', '', 'field_5a66a16d94390', '', '', '2018-01-23 02:44:34', '2018-01-23 02:44:34', '', 4, 'http://localhost:8888/?post_type=acf-field&p=29', 2, 'acf-field', '', 0),
(30, 1, '2018-01-23 02:44:34', '2018-01-23 02:44:34', 'a:12:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";s:8:"readonly";i:0;s:8:"disabled";i:0;}', 'Main Wistia Video ID', 'main_wistia_video_id', 'publish', 'closed', 'closed', '', 'field_5a66a12694389', '', '', '2018-01-23 02:44:34', '2018-01-23 02:44:34', '', 4, 'http://localhost:8888/?post_type=acf-field&p=30', 3, 'acf-field', '', 0),
(31, 1, '2018-01-23 02:44:34', '2018-01-23 02:44:34', 'a:7:{s:4:"type";s:3:"tab";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"placement";s:3:"top";s:8:"endpoint";i:0;}', 'Social Media', '', 'publish', 'closed', 'closed', '', 'field_5a66a1369438a', '', '', '2018-01-23 02:49:05', '2018-01-23 02:49:05', '', 4, 'http://localhost:8888/?post_type=acf-field&#038;p=31', 12, 'acf-field', '', 0),
(32, 1, '2018-01-23 02:44:34', '2018-01-23 02:44:34', 'a:12:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";s:8:"readonly";i:0;s:8:"disabled";i:0;}', 'Facebook Link', 'facebook_link', 'publish', 'closed', 'closed', '', 'field_5a66a1409438b', '', '', '2018-01-23 02:49:05', '2018-01-23 02:49:05', '', 4, 'http://localhost:8888/?post_type=acf-field&#038;p=32', 13, 'acf-field', '', 0),
(33, 1, '2018-01-23 02:44:34', '2018-01-23 02:44:34', 'a:12:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";s:8:"readonly";i:0;s:8:"disabled";i:0;}', 'Google Plus Link', 'google_plus_link', 'publish', 'closed', 'closed', '', 'field_5a66a1489438c', '', '', '2018-01-23 02:49:05', '2018-01-23 02:49:05', '', 4, 'http://localhost:8888/?post_type=acf-field&#038;p=33', 14, 'acf-field', '', 0),
(34, 1, '2018-01-23 02:44:34', '2018-01-23 02:44:34', 'a:12:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";s:8:"readonly";i:0;s:8:"disabled";i:0;}', 'Twitter Link', 'twitter_link', 'publish', 'closed', 'closed', '', 'field_5a66a1529438d', '', '', '2018-01-23 02:49:05', '2018-01-23 02:49:05', '', 4, 'http://localhost:8888/?post_type=acf-field&#038;p=34', 15, 'acf-field', '', 0),
(35, 1, '2018-01-23 02:44:34', '2018-01-23 02:44:34', 'a:12:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";s:8:"readonly";i:0;s:8:"disabled";i:0;}', 'Linked In Link', 'linked_in_link', 'publish', 'closed', 'closed', '', 'field_5a66a15a9438e', '', '', '2018-01-23 02:49:05', '2018-01-23 02:49:05', '', 4, 'http://localhost:8888/?post_type=acf-field&#038;p=35', 16, 'acf-field', '', 0) ;
INSERT INTO `wp_posts` ( `ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(36, 1, '2018-01-23 02:44:34', '2018-01-23 02:44:34', 'a:12:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";s:8:"readonly";i:0;s:8:"disabled";i:0;}', 'Youtube Link', 'youtube_link', 'publish', 'closed', 'closed', '', 'field_5a66a1659438f', '', '', '2018-01-23 02:49:05', '2018-01-23 02:49:05', '', 4, 'http://localhost:8888/?post_type=acf-field&#038;p=36', 17, 'acf-field', '', 0),
(37, 1, '2018-01-23 02:45:06', '2018-01-23 02:45:06', '<pre>Thank you for your submission, we will contact you shortly.</pre>', 'Thank You', '', 'publish', 'closed', 'closed', '', 'thank-you', '', '', '2018-01-23 02:45:06', '2018-01-23 02:45:06', '', 0, 'http://localhost:8888/?page_id=37', 0, 'page', '', 0),
(38, 1, '2018-01-23 02:45:06', '2018-01-23 02:45:06', '<pre>Thank you for your submission, we will contact you shortly.</pre>', 'Thank You', '', 'inherit', 'closed', 'closed', '', '37-revision-v1', '', '', '2018-01-23 02:45:06', '2018-01-23 02:45:06', '', 37, 'http://localhost:8888/37-revision-v1/', 0, 'revision', '', 0),
(39, 1, '2018-01-23 03:09:27', '2018-01-23 03:09:27', '', 'Privacy Policy', '', 'publish', 'closed', 'closed', '', 'privacy-policy', '', '', '2018-01-23 03:09:27', '2018-01-23 03:09:27', '', 0, 'http://localhost:8888/?page_id=39', 0, 'page', '', 0),
(40, 1, '2018-01-23 02:47:22', '2018-01-23 02:47:22', '', 'Privacy Policy', '', 'inherit', 'closed', 'closed', '', '39-revision-v1', '', '', '2018-01-23 02:47:22', '2018-01-23 02:47:22', '', 39, 'http://localhost:8888/39-revision-v1/', 0, 'revision', '', 0),
(41, 1, '2018-01-23 02:49:05', '2018-01-23 02:49:05', 'a:7:{s:4:"type";s:3:"tab";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"placement";s:3:"top";s:8:"endpoint";i:0;}', 'Firm Location', '', 'publish', 'closed', 'closed', '', 'field_5a66a24928de4', '', '', '2018-01-23 02:49:05', '2018-01-23 02:49:05', '', 4, 'http://localhost:8888/?post_type=acf-field&p=41', 4, 'acf-field', '', 0),
(42, 1, '2018-01-23 02:49:05', '2018-01-23 02:49:05', 'a:12:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";s:8:"readonly";i:0;s:8:"disabled";i:0;}', 'Firm Street Address', 'firm_street_address', 'publish', 'closed', 'closed', '', 'field_5a66a25e28de5', '', '', '2018-01-23 02:49:05', '2018-01-23 02:49:05', '', 4, 'http://localhost:8888/?post_type=acf-field&p=42', 5, 'acf-field', '', 0),
(43, 1, '2018-01-23 02:49:05', '2018-01-23 02:49:05', 'a:12:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";s:8:"readonly";i:0;s:8:"disabled";i:0;}', 'Firm City State Zip', 'firm_city_state_zip', 'publish', 'closed', 'closed', '', 'field_5a66a27428de6', '', '', '2018-01-23 02:49:05', '2018-01-23 02:49:05', '', 4, 'http://localhost:8888/?post_type=acf-field&p=43', 6, 'acf-field', '', 0),
(44, 1, '2018-01-23 02:49:05', '2018-01-23 02:49:05', 'a:12:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";s:8:"readonly";i:0;s:8:"disabled";i:0;}', 'Firm Directions Link', 'firm_directions_link', 'publish', 'closed', 'closed', '', 'field_5a66a28528de7', '', '', '2018-01-23 02:49:05', '2018-01-23 02:49:05', '', 4, 'http://localhost:8888/?post_type=acf-field&p=44', 7, 'acf-field', '', 0),
(45, 1, '2018-01-23 02:49:05', '2018-01-23 02:49:05', 'a:12:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";s:8:"readonly";i:0;s:8:"disabled";i:0;}', 'Firm Map Embed', 'firm_map_embed', 'publish', 'closed', 'closed', '', 'field_5a66a29028de8', '', '', '2018-01-23 02:49:05', '2018-01-23 02:49:05', '', 4, 'http://localhost:8888/?post_type=acf-field&p=45', 8, 'acf-field', '', 0),
(46, 1, '2018-01-23 03:09:20', '2018-01-23 03:09:20', '', 'About', '', 'publish', 'closed', 'closed', '', 'about', '', '', '2018-01-23 03:09:20', '2018-01-23 03:09:20', '', 0, 'http://localhost:8888/?page_id=46', 0, 'page', '', 0),
(47, 1, '2018-01-23 03:09:20', '2018-01-23 03:09:20', '', 'About', '', 'inherit', 'closed', 'closed', '', '46-revision-v1', '', '', '2018-01-23 03:09:20', '2018-01-23 03:09:20', '', 46, 'http://localhost:8888/46-revision-v1/', 0, 'revision', '', 0),
(48, 1, '2018-01-23 03:09:52', '2018-01-23 03:09:52', '', 'Practice Areas', '', 'trash', 'closed', 'closed', '', 'practice-areas__trashed', '', '', '2018-08-22 11:48:51', '2018-08-22 19:48:51', '', 0, 'http://localhost:8888/?page_id=48', 0, 'page', '', 0),
(49, 1, '2018-01-23 03:09:50', '2018-01-23 03:09:50', '', 'Practice Areas', '', 'inherit', 'closed', 'closed', '', '48-revision-v1', '', '', '2018-01-23 03:09:50', '2018-01-23 03:09:50', '', 48, 'http://localhost:8888/48-revision-v1/', 0, 'revision', '', 0),
(50, 1, '2018-01-23 03:10:03', '2018-01-23 11:10:03', 'Cannon &amp; Dunphy S.C., was founded in 1985. No personal injury case is too big or too small for our lawyers. Over the past 30 years, we have recovered over $1 Billion in judgments and paid settlements. We have recovered more $10 Million judgments and paid settlements for our clients than any other Wisconsin law firm.* When you work with us, the same lawyers who achieved these results are the ones who will handle your case. This is our promise. The same level of skills and resources will be working for you, despite the size of your case whether it is a car accident, truck accident or nursing home abuse claim. To learn more about our philosophy, attorneys, and practice areas, or if you want to hear from past clients, visit our video center.\r\n\r\nUt enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.\r\n<h2>H2 Heading Style</h2>\r\n<ul>\r\n 	<li>Excepteur sint occaecat cupidatat non proident</li>\r\n 	<li>Sunt in culpa qui officia deserunt mollit anim</li>\r\n 	<li>Duis aute irure dolor in reprehenderit in voluptate velit esse cillum</li>\r\n 	<li>Eerpteur sint occaecat cupidatat non proident</li>\r\n</ul>\r\nUt enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.\r\n<blockquote>Proudly continuing a <span class="red">100 year</span> <span class="blue">family history</span> of four generations of lawyers representing people who have been wrongly injured.</blockquote>\r\n<h3>h3 heading style</h3>\r\nSed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.', 'Practice Area', '', 'publish', 'closed', 'closed', '', 'practice-area', '', '', '2018-09-07 09:21:29', '2018-09-07 17:21:29', '', 0, 'http://localhost:8888/?page_id=50', 0, 'page', '', 0),
(51, 1, '2018-01-23 03:10:03', '2018-01-23 03:10:03', '', 'Practice Area', '', 'inherit', 'closed', 'closed', '', '50-revision-v1', '', '', '2018-01-23 03:10:03', '2018-01-23 03:10:03', '', 50, 'http://localhost:8888/50-revision-v1/', 0, 'revision', '', 0),
(52, 1, '2018-01-23 03:10:21', '2018-01-23 11:10:21', '', 'Testimonials', '', 'publish', 'closed', 'closed', '', 'testimonials', '', '', '2018-09-11 09:39:10', '2018-09-11 17:39:10', '', 0, 'http://localhost:8888/?page_id=52', 0, 'page', '', 0),
(53, 1, '2018-01-23 03:10:21', '2018-01-23 03:10:21', '', 'Testimonials', '', 'inherit', 'closed', 'closed', '', '52-revision-v1', '', '', '2018-01-23 03:10:21', '2018-01-23 03:10:21', '', 52, 'http://localhost:8888/52-revision-v1/', 0, 'revision', '', 0),
(54, 1, '2018-01-23 03:10:28', '2018-01-23 03:10:28', '', 'Results', '', 'publish', 'closed', 'closed', '', 'results', '', '', '2018-01-23 03:10:28', '2018-01-23 03:10:28', '', 0, 'http://localhost:8888/?page_id=54', 0, 'page', '', 0),
(55, 1, '2018-01-23 03:10:28', '2018-01-23 03:10:28', '', 'Results', '', 'inherit', 'closed', 'closed', '', '54-revision-v1', '', '', '2018-01-23 03:10:28', '2018-01-23 03:10:28', '', 54, 'http://localhost:8888/54-revision-v1/', 0, 'revision', '', 0),
(56, 1, '2018-01-23 03:10:38', '2018-01-23 03:10:38', '', 'Contact', '', 'publish', 'closed', 'closed', '', 'contact', '', '', '2018-01-23 03:10:38', '2018-01-23 03:10:38', '', 0, 'http://localhost:8888/?page_id=56', 0, 'page', '', 0),
(57, 1, '2018-01-23 03:10:38', '2018-01-23 03:10:38', '', 'Contact', '', 'inherit', 'closed', 'closed', '', '56-revision-v1', '', '', '2018-01-23 03:10:38', '2018-01-23 03:10:38', '', 56, 'http://localhost:8888/56-revision-v1/', 0, 'revision', '', 0),
(58, 1, '2018-01-23 03:11:51', '2018-01-23 03:11:51', '', 'Attorneys', '', 'trash', 'closed', 'closed', '', 'attorneys__trashed', '', '', '2018-08-22 11:48:46', '2018-08-22 19:48:46', '', 0, 'http://localhost:8888/?page_id=58', 0, 'page', '', 0),
(59, 1, '2018-01-23 03:11:51', '2018-01-23 03:11:51', '', 'Attorneys', '', 'inherit', 'closed', 'closed', '', '58-revision-v1', '', '', '2018-01-23 03:11:51', '2018-01-23 03:11:51', '', 58, 'http://localhost:8888/58-revision-v1/', 0, 'revision', '', 0),
(60, 1, '2018-01-23 03:12:05', '2018-01-23 11:12:05', 'Attorney William M. Cannon is a member of one of Wisconsin\'s best-known and most prominent legal families extending over four generations of lawyers, beginning with his grandfather\'s admission to the Wisconsin Bar. This four-generation legal family has practiced continuously in Milwaukee and other communities throughout Wisconsin for over 100 years. Mr. Cannon has won more $10 million paid verdicts and settlements for his clients than any other lawyer in Wisconsin. His cases have been featured on the CBS program "60 Minutes" and the "ABC Evening National News". He has continuously been listed in The Best Lawyers in America for Over 25 consecutive years.\r\n\r\nRaymond J. Cannon. (Grandfather) Admitted to Wisconsin Bar, 1914. Partner in Milwaukee law firm of Cannon &amp; Waldron. U.S. Congressman, Milwaukee (4 th District) 1933-39. He was the most famous trial lawyer of his generation. Some of his famous clients were World Heavyweight Boxing Champion Jack Dempsey, Shoeless Joe Jackson (Chicago Black Sox Scandal) and Wallis Simpson. Between 1914-1921, he successfully tried and won over 100 consecutive jury trials, resulting in a banquet hosted by the Milwaukee Bar Association honoring him for this achievement. The Federal Defender Services of Wisconsin has named an award after him in memory of his trial accomplishments, "The Ray Cannon Justice Award".\r\n\r\nJudge Robert C. Cannon. (Father) Admitted to Wisconsin Bar, 1941. Milwaukee County Civil and Circuit Court Judge, successfully re-elected 1945-79; first Presiding Judge, Wisconsin Court of Appeals, 1979-82. Legal Advisor To Major League Baseball Players Association.\r\n\r\nKelly Gildea Cannon (great granddaughter of Raymond J. Cannon and daughter of William M. Cannon) is a graduate of Loyola University Chicago School of Law (J. D.) In Chicago, Illinois. She is licensed to practice law in Illinois and New York. She also has received her Masters of Law (LLM) in International Dispute Resolution at Kings College in London, England.', 'William M. Cannon', '', 'publish', 'closed', 'closed', '', 'william-m-cannon', '', '', '2018-09-11 08:51:17', '2018-09-11 16:51:17', '', 0, 'http://localhost:8888/?page_id=60', 0, 'page', '', 0),
(61, 1, '2018-01-23 03:12:05', '2018-01-23 03:12:05', '', 'Attorney Profile', '', 'inherit', 'closed', 'closed', '', '60-revision-v1', '', '', '2018-01-23 03:12:05', '2018-01-23 03:12:05', '', 60, 'http://localhost:8888/60-revision-v1/', 0, 'revision', '', 0),
(62, 1, '2018-01-23 03:12:18', '2018-01-23 03:12:18', '', 'Videos', '', 'publish', 'closed', 'closed', '', 'videos', '', '', '2018-01-23 03:12:18', '2018-01-23 03:12:18', '', 0, 'http://localhost:8888/?page_id=62', 0, 'page', '', 0),
(63, 1, '2018-01-23 03:12:18', '2018-01-23 03:12:18', '', 'Videos', '', 'inherit', 'closed', 'closed', '', '62-revision-v1', '', '', '2018-01-23 03:12:18', '2018-01-23 03:12:18', '', 62, 'http://localhost:8888/62-revision-v1/', 0, 'revision', '', 0),
(68, 1, '2018-08-22 11:46:14', '2018-08-22 19:46:14', '', 'About Us', '', 'trash', 'closed', 'closed', '', '__trashed', '', '', '2018-08-22 11:46:14', '2018-08-22 19:46:14', '', 0, 'http://cannon-demo.com/?page_id=68', 0, 'page', '', 0),
(69, 1, '2018-08-22 11:46:14', '2018-08-22 19:46:14', '', 'About Us', '', 'inherit', 'closed', 'closed', '', '68-revision-v1', '', '', '2018-08-22 11:46:14', '2018-08-22 19:46:14', '', 68, 'http://cannon-demo.com/68-revision-v1/', 0, 'revision', '', 0),
(70, 1, '2018-08-22 11:48:40', '2018-08-22 19:48:40', ' ', '', '', 'publish', 'closed', 'closed', '', '70', '', '', '2018-09-11 14:00:02', '2018-09-11 22:00:02', '', 0, 'http://cannon-demo.com/?p=70', 1, 'nav_menu_item', '', 0),
(71, 1, '2018-08-22 11:48:40', '2018-08-22 19:48:40', '', 'About', '', 'publish', 'closed', 'closed', '', 'about', '', '', '2018-09-11 14:00:02', '2018-09-11 22:00:02', '', 0, 'http://cannon-demo.com/?p=71', 2, 'nav_menu_item', '', 0),
(72, 1, '2018-08-22 11:48:40', '2018-08-22 19:48:40', ' ', '', '', 'publish', 'closed', 'closed', '', '72', '', '', '2018-09-11 14:00:02', '2018-09-11 22:00:02', '', 0, 'http://cannon-demo.com/?p=72', 3, 'nav_menu_item', '', 0),
(73, 1, '2018-08-22 11:48:40', '2018-08-22 19:48:40', '', 'Attorneys', '', 'publish', 'closed', 'closed', '', 'attorneys', '', '', '2018-09-11 14:00:02', '2018-09-11 22:00:02', '', 0, 'http://cannon-demo.com/?p=73', 5, 'nav_menu_item', '', 0),
(74, 1, '2018-08-22 11:48:40', '2018-08-22 19:48:40', ' ', '', '', 'publish', 'closed', 'closed', '', '74', '', '', '2018-09-11 14:00:02', '2018-09-11 22:00:02', '', 0, 'http://cannon-demo.com/?p=74', 6, 'nav_menu_item', '', 0),
(75, 1, '2018-08-22 11:48:40', '2018-08-22 19:48:40', ' ', '', '', 'publish', 'closed', 'closed', '', '75', '', '', '2018-09-11 14:00:02', '2018-09-11 22:00:02', '', 0, 'http://cannon-demo.com/?p=75', 11, 'nav_menu_item', '', 0),
(76, 1, '2018-08-22 11:48:40', '2018-08-22 19:48:40', ' ', '', '', 'publish', 'closed', 'closed', '', '76', '', '', '2018-09-11 14:00:02', '2018-09-11 22:00:02', '', 0, 'http://cannon-demo.com/?p=76', 12, 'nav_menu_item', '', 0),
(77, 1, '2018-08-22 11:48:40', '2018-08-22 19:48:40', ' ', '', '', 'publish', 'closed', 'closed', '', '77', '', '', '2018-09-11 14:00:02', '2018-09-11 22:00:02', '', 0, 'http://cannon-demo.com/?p=77', 13, 'nav_menu_item', '', 0),
(78, 1, '2018-08-22 11:48:40', '2018-08-22 19:48:40', ' ', '', '', 'publish', 'closed', 'closed', '', '78', '', '', '2018-09-11 14:00:02', '2018-09-11 22:00:02', '', 0, 'http://cannon-demo.com/?p=78', 14, 'nav_menu_item', '', 0),
(79, 1, '2018-08-23 08:01:14', '2018-08-23 16:01:14', '', 'Meet the Attorneys', '', 'publish', 'closed', 'closed', '', 'meet-the-attorneys', '', '', '2018-09-11 08:50:13', '2018-09-11 16:50:13', '', 0, 'http://cannon-demo.com/?page_id=79', 0, 'page', '', 0),
(80, 1, '2018-08-23 08:01:14', '2018-08-23 16:01:14', '', 'Meet the Team', '', 'inherit', 'closed', 'closed', '', '79-revision-v1', '', '', '2018-08-23 08:01:14', '2018-08-23 16:01:14', '', 79, 'http://cannon-demo.com/79-revision-v1/', 0, 'revision', '', 0),
(81, 1, '2018-08-23 08:01:26', '2018-08-23 16:01:26', ' ', '', '', 'publish', 'closed', 'closed', '', '81', '', '', '2018-09-11 14:00:02', '2018-09-11 22:00:02', '', 0, 'http://cannon-demo.com/?p=81', 7, 'nav_menu_item', '', 0),
(82, 1, '2018-08-23 10:10:06', '2018-08-23 18:10:06', '', 'Practice Areas', '', 'publish', 'closed', 'closed', '', 'practice-areas', '', '', '2018-09-11 14:00:02', '2018-09-11 22:00:02', '', 0, 'http://cannon-demo.com/?p=82', 8, 'nav_menu_item', '', 0),
(83, 1, '2018-08-23 10:10:06', '2018-08-23 18:10:06', ' ', '', '', 'publish', 'closed', 'closed', '', '83', '', '', '2018-09-11 14:00:02', '2018-09-11 22:00:02', '', 0, 'http://cannon-demo.com/?p=83', 9, 'nav_menu_item', '', 0),
(84, 1, '2018-09-05 07:43:05', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'open', 'open', '', '', '', '', '2018-09-05 07:43:05', '0000-00-00 00:00:00', '', 0, 'http://cannon-demo.com/?p=84', 0, 'post', '', 0),
(85, 1, '2018-09-06 13:16:29', '2018-09-06 21:16:29', '', 'PA One', '', 'publish', 'closed', 'closed', '', 'pa-one', '', '', '2018-09-07 13:51:37', '2018-09-07 21:51:37', '', 0, 'http://cannon-demo.com/?p=85', 1, 'nav_menu_item', '', 0),
(86, 1, '2018-09-06 13:16:29', '2018-09-06 21:16:29', ' ', '', '', 'publish', 'closed', 'closed', '', '86', '', '', '2018-09-07 13:51:37', '2018-09-07 21:51:37', '', 0, 'http://cannon-demo.com/?p=86', 2, 'nav_menu_item', '', 0),
(87, 1, '2018-09-06 13:16:44', '2018-09-06 21:16:44', '', 'Practice Area 2', '', 'publish', 'closed', 'closed', '', 'practice-area-2', '', '', '2018-09-06 13:16:44', '2018-09-06 21:16:44', '', 0, 'http://cannon-demo.com/?page_id=87', 0, 'page', '', 0),
(88, 1, '2018-09-06 13:16:44', '2018-09-06 21:16:44', '', 'Practice Area 2', '', 'inherit', 'closed', 'closed', '', '87-revision-v1', '', '', '2018-09-06 13:16:44', '2018-09-06 21:16:44', '', 87, 'http://cannon-demo.com/87-revision-v1/', 0, 'revision', '', 0),
(89, 1, '2018-09-06 13:16:57', '2018-09-06 21:16:57', '', 'Practice Area 3', '', 'publish', 'closed', 'closed', '', 'practice-area-3', '', '', '2018-09-06 13:16:57', '2018-09-06 21:16:57', '', 0, 'http://cannon-demo.com/?page_id=89', 0, 'page', '', 0),
(90, 1, '2018-09-06 13:16:57', '2018-09-06 21:16:57', '', 'Practice Area 3', '', 'inherit', 'closed', 'closed', '', '89-revision-v1', '', '', '2018-09-06 13:16:57', '2018-09-06 21:16:57', '', 89, 'http://cannon-demo.com/89-revision-v1/', 0, 'revision', '', 0),
(91, 1, '2018-09-06 13:17:13', '2018-09-06 21:17:13', '', 'Practice Area 4', '', 'publish', 'closed', 'closed', '', 'practice-area-4', '', '', '2018-09-06 13:17:13', '2018-09-06 21:17:13', '', 0, 'http://cannon-demo.com/?page_id=91', 0, 'page', '', 0),
(92, 1, '2018-09-06 13:17:13', '2018-09-06 21:17:13', '', 'Practice Area 4', '', 'inherit', 'closed', 'closed', '', '91-revision-v1', '', '', '2018-09-06 13:17:13', '2018-09-06 21:17:13', '', 91, 'http://cannon-demo.com/91-revision-v1/', 0, 'revision', '', 0),
(93, 1, '2018-09-06 13:17:26', '2018-09-06 21:17:26', '', 'Practice Area 5', '', 'publish', 'closed', 'closed', '', 'practice-area-5', '', '', '2018-09-06 13:17:26', '2018-09-06 21:17:26', '', 0, 'http://cannon-demo.com/?page_id=93', 0, 'page', '', 0),
(94, 1, '2018-09-06 13:17:26', '2018-09-06 21:17:26', '', 'Practice Area 5', '', 'inherit', 'closed', 'closed', '', '93-revision-v1', '', '', '2018-09-06 13:17:26', '2018-09-06 21:17:26', '', 93, 'http://cannon-demo.com/93-revision-v1/', 0, 'revision', '', 0),
(95, 1, '2018-09-06 13:18:28', '2018-09-06 21:18:28', '', 'PA Two', '', 'publish', 'closed', 'closed', '', 'pa-two', '', '', '2018-09-07 13:51:37', '2018-09-07 21:51:37', '', 0, 'http://cannon-demo.com/?p=95', 7, 'nav_menu_item', '', 0),
(96, 1, '2018-09-06 13:18:28', '2018-09-06 21:18:28', '', 'PA Three', '', 'publish', 'closed', 'closed', '', 'pa-three', '', '', '2018-09-07 13:51:37', '2018-09-07 21:51:37', '', 0, 'http://cannon-demo.com/?p=96', 10, 'nav_menu_item', '', 0),
(97, 1, '2018-09-06 13:18:28', '2018-09-06 21:18:28', ' ', '', '', 'publish', 'closed', 'closed', '', '97', '', '', '2018-09-07 13:51:37', '2018-09-07 21:51:37', '', 0, 'http://cannon-demo.com/?p=97', 11, 'nav_menu_item', '', 0),
(98, 1, '2018-09-06 13:18:28', '2018-09-06 21:18:28', ' ', '', '', 'publish', 'closed', 'closed', '', '98', '', '', '2018-09-07 13:51:37', '2018-09-07 21:51:37', '', 0, 'http://cannon-demo.com/?p=98', 9, 'nav_menu_item', '', 0),
(99, 1, '2018-09-06 13:18:28', '2018-09-06 21:18:28', ' ', '', '', 'publish', 'closed', 'closed', '', '99', '', '', '2018-09-07 13:51:37', '2018-09-07 21:51:37', '', 0, 'http://cannon-demo.com/?p=99', 8, 'nav_menu_item', '', 0),
(100, 1, '2018-09-06 13:18:28', '2018-09-06 21:18:28', ' ', '', '', 'publish', 'closed', 'closed', '', '100', '', '', '2018-09-07 13:51:37', '2018-09-07 21:51:37', '', 0, 'http://cannon-demo.com/?p=100', 3, 'nav_menu_item', '', 0),
(102, 1, '2018-09-07 09:21:29', '2018-09-07 17:21:29', 'Cannon &amp; Dunphy S.C., was founded in 1985. No personal injury case is too big or too small for our lawyers. Over the past 30 years, we have recovered over $1 Billion in judgments and paid settlements. We have recovered more $10 Million judgments and paid settlements for our clients than any other Wisconsin law firm.* When you work with us, the same lawyers who achieved these results are the ones who will handle your case. This is our promise. The same level of skills and resources will be working for you, despite the size of your case whether it is a car accident, truck accident or nursing home abuse claim. To learn more about our philosophy, attorneys, and practice areas, or if you want to hear from past clients, visit our video center.\r\n\r\nUt enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.\r\n<h2>H2 Heading Style</h2>\r\n<ul>\r\n 	<li>Excepteur sint occaecat cupidatat non proident</li>\r\n 	<li>Sunt in culpa qui officia deserunt mollit anim</li>\r\n 	<li>Duis aute irure dolor in reprehenderit in voluptate velit esse cillum</li>\r\n 	<li>Eerpteur sint occaecat cupidatat non proident</li>\r\n</ul>\r\nUt enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.\r\n<blockquote>Proudly continuing a <span class="red">100 year</span> <span class="blue">family history</span> of four generations of lawyers representing people who have been wrongly injured.</blockquote>\r\n<h3>h3 heading style</h3>\r\nSed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.', 'Practice Area', '', 'inherit', 'closed', 'closed', '', '50-revision-v1', '', '', '2018-09-07 09:21:29', '2018-09-07 17:21:29', '', 50, 'http://cannon-demo.com/50-revision-v1/', 0, 'revision', '', 0),
(103, 1, '2018-09-07 09:23:12', '2018-09-07 17:23:12', '', 'Practice Areas', '', 'publish', 'closed', 'closed', '', 'practice-areas', '', '', '2018-09-10 07:51:14', '2018-09-10 15:51:14', '', 0, 'http://cannon-demo.com/?page_id=103', 0, 'page', '', 0),
(104, 1, '2018-09-07 09:23:12', '2018-09-07 17:23:12', '', 'Practice Areas', '', 'inherit', 'closed', 'closed', '', '103-revision-v1', '', '', '2018-09-07 09:23:12', '2018-09-07 17:23:12', '', 103, 'http://cannon-demo.com/103-revision-v1/', 0, 'revision', '', 0),
(105, 1, '2018-09-07 09:24:47', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2018-09-07 09:24:47', '0000-00-00 00:00:00', '', 0, 'http://cannon-demo.com/?p=105', 1, 'nav_menu_item', '', 0),
(106, 1, '2018-09-07 09:25:13', '2018-09-07 17:25:13', '', 'View All +', '', 'publish', 'closed', 'closed', '', 'view-all', '', '', '2018-09-11 14:00:02', '2018-09-11 22:00:02', '', 0, 'http://cannon-demo.com/?p=106', 10, 'nav_menu_item', '', 0),
(107, 1, '2018-09-07 13:51:37', '2018-09-07 21:51:37', ' ', '', '', 'publish', 'closed', 'closed', '', '107', '', '', '2018-09-07 13:51:37', '2018-09-07 21:51:37', '', 0, 'http://cannon-demo.com/?p=107', 4, 'nav_menu_item', '', 0),
(108, 1, '2018-09-07 13:51:37', '2018-09-07 21:51:37', ' ', '', '', 'publish', 'closed', 'closed', '', '108', '', '', '2018-09-07 13:51:37', '2018-09-07 21:51:37', '', 0, 'http://cannon-demo.com/?p=108', 5, 'nav_menu_item', '', 0),
(109, 1, '2018-09-07 13:51:37', '2018-09-07 21:51:37', ' ', '', '', 'publish', 'closed', 'closed', '', '109', '', '', '2018-09-07 13:51:37', '2018-09-07 21:51:37', '', 0, 'http://cannon-demo.com/?p=109', 6, 'nav_menu_item', '', 0),
(110, 1, '2018-09-10 07:54:27', '2018-09-10 15:54:27', '', 'William M. Cannon', '', 'inherit', 'closed', 'closed', '', '60-revision-v1', '', '', '2018-09-10 07:54:27', '2018-09-10 15:54:27', '', 60, 'http://cannon-demo.com/60-revision-v1/', 0, 'revision', '', 0),
(111, 1, '2018-09-10 14:12:55', '2018-09-10 22:12:55', 'a:7:{s:8:"location";a:1:{i:0;a:1:{i:0;a:3:{s:5:"param";s:13:"post_template";s:8:"operator";s:2:"==";s:5:"value";s:16:"template-bio.php";}}}s:8:"position";s:6:"normal";s:5:"style";s:7:"default";s:15:"label_placement";s:3:"top";s:21:"instruction_placement";s:5:"label";s:14:"hide_on_screen";s:0:"";s:11:"description";s:0:"";}', 'Attorney Bio', 'attorney-bio', 'publish', 'closed', 'closed', '', 'group_5b96eb5a74a01', '', '', '2018-09-11 07:21:28', '2018-09-11 15:21:28', '', 0, 'http://cannon-demo.com/?post_type=acf-field-group&#038;p=111', 0, 'acf-field-group', '', 0),
(112, 1, '2018-09-10 14:12:55', '2018-09-10 22:12:55', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Attorney Sub Header', 'attorney_sub_header', 'publish', 'closed', 'closed', '', 'field_5b96eb6fd59d2', '', '', '2018-09-10 14:12:55', '2018-09-10 22:12:55', '', 111, 'http://cannon-demo.com/?post_type=acf-field&p=112', 0, 'acf-field', '', 0),
(113, 1, '2018-09-10 14:12:55', '2018-09-10 22:12:55', 'a:15:{s:4:"type";s:5:"image";s:12:"instructions";s:52:"Image needs to be 315px wide by 425px high and a jpg";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"return_format";s:5:"array";s:12:"preview_size";s:4:"full";s:7:"library";s:3:"all";s:9:"min_width";i:314;s:10:"min_height";i:424;s:8:"min_size";s:0:"";s:9:"max_width";i:316;s:10:"max_height";i:426;s:8:"max_size";s:0:"";s:10:"mime_types";s:3:"jpg";}', 'Attorney Image', 'attorney_image', 'publish', 'closed', 'closed', '', 'field_5b96eb78d59d3', '', '', '2018-09-10 14:12:55', '2018-09-10 22:12:55', '', 111, 'http://cannon-demo.com/?post_type=acf-field&p=113', 1, 'acf-field', '', 0) ;
INSERT INTO `wp_posts` ( `ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(114, 1, '2018-09-10 14:12:55', '2018-09-10 22:12:55', 'a:10:{s:4:"type";s:8:"repeater";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"collapsed";s:0:"";s:3:"min";s:0:"";s:3:"max";s:0:"";s:6:"layout";s:3:"row";s:12:"button_label";s:8:"Add List";}', 'Accolades', 'accolades', 'publish', 'closed', 'closed', '', 'field_5b96ebe8d59d4', '', '', '2018-09-11 07:05:33', '2018-09-11 15:05:33', '', 111, 'http://cannon-demo.com/?post_type=acf-field&#038;p=114', 2, 'acf-field', '', 0),
(115, 1, '2018-09-10 14:12:55', '2018-09-10 22:12:55', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Accolades Title', 'accolades_title', 'publish', 'closed', 'closed', '', 'field_5b96ebf2d59d5', '', '', '2018-09-10 14:12:55', '2018-09-10 22:12:55', '', 114, 'http://cannon-demo.com/?post_type=acf-field&p=115', 0, 'acf-field', '', 0),
(116, 1, '2018-09-10 14:12:55', '2018-09-10 22:12:55', 'a:10:{s:4:"type";s:8:"repeater";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"collapsed";s:0:"";s:3:"min";s:0:"";s:3:"max";s:0:"";s:6:"layout";s:3:"row";s:12:"button_label";s:10:"Add Bullet";}', 'Accolades Bullets', 'accolades_bullets', 'publish', 'closed', 'closed', '', 'field_5b96ec0ad59d6', '', '', '2018-09-11 07:05:02', '2018-09-11 15:05:02', '', 114, 'http://cannon-demo.com/?post_type=acf-field&#038;p=116', 1, 'acf-field', '', 0),
(117, 1, '2018-09-10 14:12:55', '2018-09-10 22:12:55', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Accolades Bullet', 'accolades_bullet', 'publish', 'closed', 'closed', '', 'field_5b96ec4cd59d7', '', '', '2018-09-10 14:12:55', '2018-09-10 22:12:55', '', 116, 'http://cannon-demo.com/?post_type=acf-field&p=117', 0, 'acf-field', '', 0),
(118, 1, '2018-09-10 14:12:55', '2018-09-10 22:12:55', 'a:10:{s:4:"type";s:8:"repeater";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"collapsed";s:0:"";s:3:"min";s:0:"";s:3:"max";s:0:"";s:6:"layout";s:3:"row";s:12:"button_label";s:14:"Add Sub Bullet";}', 'Accolades Sub Bullets', 'accolades_sub_bullets', 'publish', 'closed', 'closed', '', 'field_5b96ec59d59d8', '', '', '2018-09-11 07:05:02', '2018-09-11 15:05:02', '', 116, 'http://cannon-demo.com/?post_type=acf-field&#038;p=118', 1, 'acf-field', '', 0),
(119, 1, '2018-09-11 06:52:31', '2018-09-11 14:52:31', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Accolades Sub Bullets', 'accolades_sub_bullets', 'publish', 'closed', 'closed', '', 'field_5b97d69f40931', '', '', '2018-09-11 06:52:31', '2018-09-11 14:52:31', '', 118, 'http://cannon-demo.com/?post_type=acf-field&p=119', 0, 'acf-field', '', 0),
(120, 1, '2018-09-11 06:59:56', '2018-09-11 14:59:56', '', 'William M. Cannon', '', 'inherit', 'closed', 'closed', '', '60-revision-v1', '', '', '2018-09-11 06:59:56', '2018-09-11 14:59:56', '', 60, 'http://cannon-demo.com/60-revision-v1/', 0, 'revision', '', 0),
(121, 1, '2018-09-11 07:00:09', '2018-09-11 15:00:09', 'Attorney William M. Cannon is a member of one of Wisconsin\'s best-known and most prominent legal families extending over four generations of lawyers, beginning with his grandfather\'s admission to the Wisconsin Bar. This four-generation legal family has practiced continuously in Milwaukee and other communities throughout Wisconsin for over 100 years. Mr. Cannon has won more $10 million paid verdicts and settlements for his clients than any other lawyer in Wisconsin. His cases have been featured on the CBS program "60 Minutes" and the "ABC Evening National News". He has continuously been listed in The Best Lawyers in America for Over 25 consecutive years.\r\n\r\nRaymond J. Cannon. (Grandfather) Admitted to Wisconsin Bar, 1914. Partner in Milwaukee law firm of Cannon &amp; Waldron. U.S. Congressman, Milwaukee (4 th District) 1933-39. He was the most famous trial lawyer of his generation. Some of his famous clients were World Heavyweight Boxing Champion Jack Dempsey, Shoeless Joe Jackson (Chicago Black Sox Scandal) and Wallis Simpson. Between 1914-1921, he successfully tried and won over 100 consecutive jury trials, resulting in a banquet hosted by the Milwaukee Bar Association honoring him for this achievement. The Federal Defender Services of Wisconsin has named an award after him in memory of his trial accomplishments, "The Ray Cannon Justice Award".\r\n\r\nJudge Robert C. Cannon. (Father) Admitted to Wisconsin Bar, 1941. Milwaukee County Civil and Circuit Court Judge, successfully re-elected 1945-79; first Presiding Judge, Wisconsin Court of Appeals, 1979-82. Legal Advisor To Major League Baseball Players Association.\r\n\r\nKelly Gildea Cannon (great granddaughter of Raymond J. Cannon and daughter of William M. Cannon) is a graduate of Loyola University Chicago School of Law (J. D.) In Chicago, Illinois. She is licensed to practice law in Illinois and New York. She also has received her Masters of Law (LLM) in International Dispute Resolution at Kings College in London, England.', 'William M. Cannon', '', 'inherit', 'closed', 'closed', '', '60-revision-v1', '', '', '2018-09-11 07:00:09', '2018-09-11 15:00:09', '', 60, 'http://cannon-demo.com/60-revision-v1/', 0, 'revision', '', 0),
(122, 1, '2018-09-11 07:01:51', '2018-09-11 15:01:51', '', 'AP_img_PatrickDunphy', '', 'inherit', 'open', 'closed', '', 'ap_img_patrickdunphy', '', '', '2018-09-11 07:01:51', '2018-09-11 15:01:51', '', 60, 'http://cannon-demo.com/wp-content/uploads/2018/09/AP_img_PatrickDunphy.jpg', 0, 'attachment', 'image/jpeg', 0),
(123, 1, '2018-09-11 07:01:57', '2018-09-11 15:01:57', 'Attorney William M. Cannon is a member of one of Wisconsin\'s best-known and most prominent legal families extending over four generations of lawyers, beginning with his grandfather\'s admission to the Wisconsin Bar. This four-generation legal family has practiced continuously in Milwaukee and other communities throughout Wisconsin for over 100 years. Mr. Cannon has won more $10 million paid verdicts and settlements for his clients than any other lawyer in Wisconsin. His cases have been featured on the CBS program "60 Minutes" and the "ABC Evening National News". He has continuously been listed in The Best Lawyers in America for Over 25 consecutive years.\r\n\r\nRaymond J. Cannon. (Grandfather) Admitted to Wisconsin Bar, 1914. Partner in Milwaukee law firm of Cannon &amp; Waldron. U.S. Congressman, Milwaukee (4 th District) 1933-39. He was the most famous trial lawyer of his generation. Some of his famous clients were World Heavyweight Boxing Champion Jack Dempsey, Shoeless Joe Jackson (Chicago Black Sox Scandal) and Wallis Simpson. Between 1914-1921, he successfully tried and won over 100 consecutive jury trials, resulting in a banquet hosted by the Milwaukee Bar Association honoring him for this achievement. The Federal Defender Services of Wisconsin has named an award after him in memory of his trial accomplishments, "The Ray Cannon Justice Award".\r\n\r\nJudge Robert C. Cannon. (Father) Admitted to Wisconsin Bar, 1941. Milwaukee County Civil and Circuit Court Judge, successfully re-elected 1945-79; first Presiding Judge, Wisconsin Court of Appeals, 1979-82. Legal Advisor To Major League Baseball Players Association.\r\n\r\nKelly Gildea Cannon (great granddaughter of Raymond J. Cannon and daughter of William M. Cannon) is a graduate of Loyola University Chicago School of Law (J. D.) In Chicago, Illinois. She is licensed to practice law in Illinois and New York. She also has received her Masters of Law (LLM) in International Dispute Resolution at Kings College in London, England.', 'William M. Cannon', '', 'inherit', 'closed', 'closed', '', '60-revision-v1', '', '', '2018-09-11 07:01:57', '2018-09-11 15:01:57', '', 60, 'http://cannon-demo.com/60-revision-v1/', 0, 'revision', '', 0),
(124, 1, '2018-09-11 07:05:05', '2018-09-11 15:05:05', 'Attorney William M. Cannon is a member of one of Wisconsin\'s best-known and most prominent legal families extending over four generations of lawyers, beginning with his grandfather\'s admission to the Wisconsin Bar. This four-generation legal family has practiced continuously in Milwaukee and other communities throughout Wisconsin for over 100 years. Mr. Cannon has won more $10 million paid verdicts and settlements for his clients than any other lawyer in Wisconsin. His cases have been featured on the CBS program "60 Minutes" and the "ABC Evening National News". He has continuously been listed in The Best Lawyers in America for Over 25 consecutive years.\r\n\r\nRaymond J. Cannon. (Grandfather) Admitted to Wisconsin Bar, 1914. Partner in Milwaukee law firm of Cannon &amp; Waldron. U.S. Congressman, Milwaukee (4 th District) 1933-39. He was the most famous trial lawyer of his generation. Some of his famous clients were World Heavyweight Boxing Champion Jack Dempsey, Shoeless Joe Jackson (Chicago Black Sox Scandal) and Wallis Simpson. Between 1914-1921, he successfully tried and won over 100 consecutive jury trials, resulting in a banquet hosted by the Milwaukee Bar Association honoring him for this achievement. The Federal Defender Services of Wisconsin has named an award after him in memory of his trial accomplishments, "The Ray Cannon Justice Award".\r\n\r\nJudge Robert C. Cannon. (Father) Admitted to Wisconsin Bar, 1941. Milwaukee County Civil and Circuit Court Judge, successfully re-elected 1945-79; first Presiding Judge, Wisconsin Court of Appeals, 1979-82. Legal Advisor To Major League Baseball Players Association.\r\n\r\nKelly Gildea Cannon (great granddaughter of Raymond J. Cannon and daughter of William M. Cannon) is a graduate of Loyola University Chicago School of Law (J. D.) In Chicago, Illinois. She is licensed to practice law in Illinois and New York. She also has received her Masters of Law (LLM) in International Dispute Resolution at Kings College in London, England.', 'William M. Cannon', '', 'inherit', 'closed', 'closed', '', '60-revision-v1', '', '', '2018-09-11 07:05:05', '2018-09-11 15:05:05', '', 60, 'http://cannon-demo.com/60-revision-v1/', 0, 'revision', '', 0),
(125, 1, '2018-09-11 07:07:19', '2018-09-11 15:07:19', 'Attorney William M. Cannon is a member of one of Wisconsin\'s best-known and most prominent legal families extending over four generations of lawyers, beginning with his grandfather\'s admission to the Wisconsin Bar. This four-generation legal family has practiced continuously in Milwaukee and other communities throughout Wisconsin for over 100 years. Mr. Cannon has won more $10 million paid verdicts and settlements for his clients than any other lawyer in Wisconsin. His cases have been featured on the CBS program "60 Minutes" and the "ABC Evening National News". He has continuously been listed in The Best Lawyers in America for Over 25 consecutive years.\r\n\r\nRaymond J. Cannon. (Grandfather) Admitted to Wisconsin Bar, 1914. Partner in Milwaukee law firm of Cannon &amp; Waldron. U.S. Congressman, Milwaukee (4 th District) 1933-39. He was the most famous trial lawyer of his generation. Some of his famous clients were World Heavyweight Boxing Champion Jack Dempsey, Shoeless Joe Jackson (Chicago Black Sox Scandal) and Wallis Simpson. Between 1914-1921, he successfully tried and won over 100 consecutive jury trials, resulting in a banquet hosted by the Milwaukee Bar Association honoring him for this achievement. The Federal Defender Services of Wisconsin has named an award after him in memory of his trial accomplishments, "The Ray Cannon Justice Award".\r\n\r\nJudge Robert C. Cannon. (Father) Admitted to Wisconsin Bar, 1941. Milwaukee County Civil and Circuit Court Judge, successfully re-elected 1945-79; first Presiding Judge, Wisconsin Court of Appeals, 1979-82. Legal Advisor To Major League Baseball Players Association.\r\n\r\nKelly Gildea Cannon (great granddaughter of Raymond J. Cannon and daughter of William M. Cannon) is a graduate of Loyola University Chicago School of Law (J. D.) In Chicago, Illinois. She is licensed to practice law in Illinois and New York. She also has received her Masters of Law (LLM) in International Dispute Resolution at Kings College in London, England.', 'William M. Cannon', '', 'inherit', 'closed', 'closed', '', '60-revision-v1', '', '', '2018-09-11 07:07:19', '2018-09-11 15:07:19', '', 60, 'http://cannon-demo.com/60-revision-v1/', 0, 'revision', '', 0),
(126, 1, '2018-09-11 07:11:25', '2018-09-11 15:11:25', 'Attorney William M. Cannon is a member of one of Wisconsin\'s best-known and most prominent legal families extending over four generations of lawyers, beginning with his grandfather\'s admission to the Wisconsin Bar. This four-generation legal family has practiced continuously in Milwaukee and other communities throughout Wisconsin for over 100 years. Mr. Cannon has won more $10 million paid verdicts and settlements for his clients than any other lawyer in Wisconsin. His cases have been featured on the CBS program "60 Minutes" and the "ABC Evening National News". He has continuously been listed in The Best Lawyers in America for Over 25 consecutive years.\r\n\r\nRaymond J. Cannon. (Grandfather) Admitted to Wisconsin Bar, 1914. Partner in Milwaukee law firm of Cannon &amp; Waldron. U.S. Congressman, Milwaukee (4 th District) 1933-39. He was the most famous trial lawyer of his generation. Some of his famous clients were World Heavyweight Boxing Champion Jack Dempsey, Shoeless Joe Jackson (Chicago Black Sox Scandal) and Wallis Simpson. Between 1914-1921, he successfully tried and won over 100 consecutive jury trials, resulting in a banquet hosted by the Milwaukee Bar Association honoring him for this achievement. The Federal Defender Services of Wisconsin has named an award after him in memory of his trial accomplishments, "The Ray Cannon Justice Award".\r\n\r\nJudge Robert C. Cannon. (Father) Admitted to Wisconsin Bar, 1941. Milwaukee County Civil and Circuit Court Judge, successfully re-elected 1945-79; first Presiding Judge, Wisconsin Court of Appeals, 1979-82. Legal Advisor To Major League Baseball Players Association.\r\n\r\nKelly Gildea Cannon (great granddaughter of Raymond J. Cannon and daughter of William M. Cannon) is a graduate of Loyola University Chicago School of Law (J. D.) In Chicago, Illinois. She is licensed to practice law in Illinois and New York. She also has received her Masters of Law (LLM) in International Dispute Resolution at Kings College in London, England.', 'William M. Cannon', '', 'inherit', 'closed', 'closed', '', '60-revision-v1', '', '', '2018-09-11 07:11:25', '2018-09-11 15:11:25', '', 60, 'http://cannon-demo.com/60-revision-v1/', 0, 'revision', '', 0),
(127, 1, '2018-09-11 07:15:53', '2018-09-11 15:15:53', 'Attorney William M. Cannon is a member of one of Wisconsin\'s best-known and most prominent legal families extending over four generations of lawyers, beginning with his grandfather\'s admission to the Wisconsin Bar. This four-generation legal family has practiced continuously in Milwaukee and other communities throughout Wisconsin for over 100 years. Mr. Cannon has won more $10 million paid verdicts and settlements for his clients than any other lawyer in Wisconsin. His cases have been featured on the CBS program "60 Minutes" and the "ABC Evening National News". He has continuously been listed in The Best Lawyers in America for Over 25 consecutive years.\r\n\r\nRaymond J. Cannon. (Grandfather) Admitted to Wisconsin Bar, 1914. Partner in Milwaukee law firm of Cannon &amp; Waldron. U.S. Congressman, Milwaukee (4 th District) 1933-39. He was the most famous trial lawyer of his generation. Some of his famous clients were World Heavyweight Boxing Champion Jack Dempsey, Shoeless Joe Jackson (Chicago Black Sox Scandal) and Wallis Simpson. Between 1914-1921, he successfully tried and won over 100 consecutive jury trials, resulting in a banquet hosted by the Milwaukee Bar Association honoring him for this achievement. The Federal Defender Services of Wisconsin has named an award after him in memory of his trial accomplishments, "The Ray Cannon Justice Award".\r\n\r\nJudge Robert C. Cannon. (Father) Admitted to Wisconsin Bar, 1941. Milwaukee County Civil and Circuit Court Judge, successfully re-elected 1945-79; first Presiding Judge, Wisconsin Court of Appeals, 1979-82. Legal Advisor To Major League Baseball Players Association.\r\n\r\nKelly Gildea Cannon (great granddaughter of Raymond J. Cannon and daughter of William M. Cannon) is a graduate of Loyola University Chicago School of Law (J. D.) In Chicago, Illinois. She is licensed to practice law in Illinois and New York. She also has received her Masters of Law (LLM) in International Dispute Resolution at Kings College in London, England.', 'William M. Cannon', '', 'inherit', 'closed', 'closed', '', '60-revision-v1', '', '', '2018-09-11 07:15:53', '2018-09-11 15:15:53', '', 60, 'http://cannon-demo.com/60-revision-v1/', 0, 'revision', '', 0),
(128, 1, '2018-09-11 07:17:38', '2018-09-11 15:17:38', 'Attorney William M. Cannon is a member of one of Wisconsin\'s best-known and most prominent legal families extending over four generations of lawyers, beginning with his grandfather\'s admission to the Wisconsin Bar. This four-generation legal family has practiced continuously in Milwaukee and other communities throughout Wisconsin for over 100 years. Mr. Cannon has won more $10 million paid verdicts and settlements for his clients than any other lawyer in Wisconsin. His cases have been featured on the CBS program "60 Minutes" and the "ABC Evening National News". He has continuously been listed in The Best Lawyers in America for Over 25 consecutive years.\r\n\r\nRaymond J. Cannon. (Grandfather) Admitted to Wisconsin Bar, 1914. Partner in Milwaukee law firm of Cannon &amp; Waldron. U.S. Congressman, Milwaukee (4 th District) 1933-39. He was the most famous trial lawyer of his generation. Some of his famous clients were World Heavyweight Boxing Champion Jack Dempsey, Shoeless Joe Jackson (Chicago Black Sox Scandal) and Wallis Simpson. Between 1914-1921, he successfully tried and won over 100 consecutive jury trials, resulting in a banquet hosted by the Milwaukee Bar Association honoring him for this achievement. The Federal Defender Services of Wisconsin has named an award after him in memory of his trial accomplishments, "The Ray Cannon Justice Award".\r\n\r\nJudge Robert C. Cannon. (Father) Admitted to Wisconsin Bar, 1941. Milwaukee County Civil and Circuit Court Judge, successfully re-elected 1945-79; first Presiding Judge, Wisconsin Court of Appeals, 1979-82. Legal Advisor To Major League Baseball Players Association.\r\n\r\nKelly Gildea Cannon (great granddaughter of Raymond J. Cannon and daughter of William M. Cannon) is a graduate of Loyola University Chicago School of Law (J. D.) In Chicago, Illinois. She is licensed to practice law in Illinois and New York. She also has received her Masters of Law (LLM) in International Dispute Resolution at Kings College in London, England.', 'William M. Cannon', '', 'inherit', 'closed', 'closed', '', '60-revision-v1', '', '', '2018-09-11 07:17:38', '2018-09-11 15:17:38', '', 60, 'http://cannon-demo.com/60-revision-v1/', 0, 'revision', '', 0),
(129, 1, '2018-09-11 07:18:50', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2018-09-11 07:18:50', '0000-00-00 00:00:00', '', 0, 'http://cannon-demo.com/?post_type=acf-field-group&p=129', 0, 'acf-field-group', '', 0),
(130, 1, '2018-09-11 07:20:51', '2018-09-11 15:20:51', 'a:10:{s:4:"type";s:8:"repeater";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"collapsed";s:0:"";s:3:"min";s:0:"";s:3:"max";s:0:"";s:6:"layout";s:5:"table";s:12:"button_label";s:8:"Add Logo";}', 'Accolades Logos', 'accolades_logos', 'publish', 'closed', 'closed', '', 'field_5b97dd2ea64e2', '', '', '2018-09-11 07:21:28', '2018-09-11 15:21:28', '', 111, 'http://cannon-demo.com/?post_type=acf-field&#038;p=130', 4, 'acf-field', '', 0),
(131, 1, '2018-09-11 07:20:51', '2018-09-11 15:20:51', 'a:15:{s:4:"type";s:5:"image";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"return_format";s:5:"array";s:12:"preview_size";s:4:"full";s:7:"library";s:3:"all";s:9:"min_width";s:0:"";s:10:"min_height";s:0:"";s:8:"min_size";s:0:"";s:9:"max_width";s:0:"";s:10:"max_height";s:0:"";s:8:"max_size";s:0:"";s:10:"mime_types";s:0:"";}', 'Accolade Logo', 'accolade_logo', 'publish', 'closed', 'closed', '', 'field_5b97dd37a64e3', '', '', '2018-09-11 07:20:51', '2018-09-11 15:20:51', '', 130, 'http://cannon-demo.com/?post_type=acf-field&p=131', 0, 'acf-field', '', 0),
(132, 1, '2018-09-11 07:21:28', '2018-09-11 15:21:28', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Accolades Slider Title', 'accolades_slider_title', 'publish', 'closed', 'closed', '', 'field_5b97dd6a89d15', '', '', '2018-09-11 07:21:28', '2018-09-11 15:21:28', '', 111, 'http://cannon-demo.com/?post_type=acf-field&p=132', 3, 'acf-field', '', 0),
(133, 1, '2018-09-11 07:22:24', '2018-09-11 15:22:24', '', 'content1_logo_01', '', 'inherit', 'open', 'closed', '', 'content1_logo_01', '', '', '2018-09-11 07:22:24', '2018-09-11 15:22:24', '', 60, 'http://cannon-demo.com/wp-content/uploads/2018/09/content1_logo_01.png', 0, 'attachment', 'image/png', 0),
(134, 1, '2018-09-11 07:22:56', '2018-09-11 15:22:56', 'Attorney William M. Cannon is a member of one of Wisconsin\'s best-known and most prominent legal families extending over four generations of lawyers, beginning with his grandfather\'s admission to the Wisconsin Bar. This four-generation legal family has practiced continuously in Milwaukee and other communities throughout Wisconsin for over 100 years. Mr. Cannon has won more $10 million paid verdicts and settlements for his clients than any other lawyer in Wisconsin. His cases have been featured on the CBS program "60 Minutes" and the "ABC Evening National News". He has continuously been listed in The Best Lawyers in America for Over 25 consecutive years.\r\n\r\nRaymond J. Cannon. (Grandfather) Admitted to Wisconsin Bar, 1914. Partner in Milwaukee law firm of Cannon &amp; Waldron. U.S. Congressman, Milwaukee (4 th District) 1933-39. He was the most famous trial lawyer of his generation. Some of his famous clients were World Heavyweight Boxing Champion Jack Dempsey, Shoeless Joe Jackson (Chicago Black Sox Scandal) and Wallis Simpson. Between 1914-1921, he successfully tried and won over 100 consecutive jury trials, resulting in a banquet hosted by the Milwaukee Bar Association honoring him for this achievement. The Federal Defender Services of Wisconsin has named an award after him in memory of his trial accomplishments, "The Ray Cannon Justice Award".\r\n\r\nJudge Robert C. Cannon. (Father) Admitted to Wisconsin Bar, 1941. Milwaukee County Civil and Circuit Court Judge, successfully re-elected 1945-79; first Presiding Judge, Wisconsin Court of Appeals, 1979-82. Legal Advisor To Major League Baseball Players Association.\r\n\r\nKelly Gildea Cannon (great granddaughter of Raymond J. Cannon and daughter of William M. Cannon) is a graduate of Loyola University Chicago School of Law (J. D.) In Chicago, Illinois. She is licensed to practice law in Illinois and New York. She also has received her Masters of Law (LLM) in International Dispute Resolution at Kings College in London, England.', 'William M. Cannon', '', 'inherit', 'closed', 'closed', '', '60-revision-v1', '', '', '2018-09-11 07:22:56', '2018-09-11 15:22:56', '', 60, 'http://cannon-demo.com/60-revision-v1/', 0, 'revision', '', 0),
(135, 1, '2018-09-11 07:31:14', '2018-09-11 15:31:14', '', 'Meet the Attorneys', '', 'inherit', 'closed', 'closed', '', '79-revision-v1', '', '', '2018-09-11 07:31:14', '2018-09-11 15:31:14', '', 79, 'http://cannon-demo.com/79-revision-v1/', 0, 'revision', '', 0),
(136, 1, '2018-09-11 08:16:27', '2018-09-11 16:16:27', 'a:7:{s:8:"location";a:1:{i:0;a:1:{i:0;a:3:{s:5:"param";s:13:"post_template";s:8:"operator";s:2:"==";s:5:"value";s:21:"template-meetteam.php";}}}s:8:"position";s:6:"normal";s:5:"style";s:7:"default";s:15:"label_placement";s:3:"top";s:21:"instruction_placement";s:5:"label";s:14:"hide_on_screen";a:5:{i:0;s:11:"the_content";i:1;s:7:"excerpt";i:2;s:14:"featured_image";i:3;s:10:"categories";i:4;s:4:"tags";}s:11:"description";s:0:"";}', 'Attorney Directory', 'attorney-directory', 'publish', 'closed', 'closed', '', 'group_5b97ea2ed7674', '', '', '2018-09-11 08:33:26', '2018-09-11 16:33:26', '', 0, 'http://cannon-demo.com/?post_type=acf-field-group&#038;p=136', 0, 'acf-field-group', '', 0),
(138, 1, '2018-09-11 08:18:41', '2018-09-11 16:18:41', '', 'Patrick O. Dunphy', '', 'publish', 'closed', 'closed', '', 'patrick-o-dunphy', '', '', '2018-09-11 08:18:41', '2018-09-11 16:18:41', '', 0, 'http://cannon-demo.com/?page_id=138', 0, 'page', '', 0),
(139, 1, '2018-09-11 08:18:41', '2018-09-11 16:18:41', '', 'Patrick O. Dunphy', '', 'inherit', 'closed', 'closed', '', '138-revision-v1', '', '', '2018-09-11 08:18:41', '2018-09-11 16:18:41', '', 138, 'http://cannon-demo.com/138-revision-v1/', 0, 'revision', '', 0),
(140, 1, '2018-09-11 08:20:05', '2018-09-11 16:20:05', '', 'Edward E. Robinson', '', 'publish', 'closed', 'closed', '', 'edward-e-robinson', '', '', '2018-09-11 08:20:05', '2018-09-11 16:20:05', '', 0, 'http://cannon-demo.com/?page_id=140', 0, 'page', '', 0),
(141, 1, '2018-09-11 08:19:35', '2018-09-11 16:19:35', '', 'AP_img_AlFoeckler', '', 'inherit', 'open', 'closed', '', 'ap_img_alfoeckler', '', '', '2018-09-11 08:19:35', '2018-09-11 16:19:35', '', 140, 'http://cannon-demo.com/wp-content/uploads/2018/09/AP_img_AlFoeckler.jpg', 0, 'attachment', 'image/jpeg', 0),
(142, 1, '2018-09-11 08:19:36', '2018-09-11 16:19:36', '', 'AP_img_BrettEckstein', '', 'inherit', 'open', 'closed', '', 'ap_img_bretteckstein', '', '', '2018-09-11 08:19:36', '2018-09-11 16:19:36', '', 140, 'http://cannon-demo.com/wp-content/uploads/2018/09/AP_img_BrettEckstein.jpg', 0, 'attachment', 'image/jpeg', 0),
(143, 1, '2018-09-11 08:19:36', '2018-09-11 16:19:36', '', 'AP_img_EdwardRobinson', '', 'inherit', 'open', 'closed', '', 'ap_img_edwardrobinson', '', '', '2018-09-11 08:19:36', '2018-09-11 16:19:36', '', 140, 'http://cannon-demo.com/wp-content/uploads/2018/09/AP_img_EdwardRobinson.jpg', 0, 'attachment', 'image/jpeg', 0),
(144, 1, '2018-09-11 08:19:37', '2018-09-11 16:19:37', '', 'AP_img_JoshMinon', '', 'inherit', 'open', 'closed', '', 'ap_img_joshminon', '', '', '2018-09-11 08:19:37', '2018-09-11 16:19:37', '', 140, 'http://cannon-demo.com/wp-content/uploads/2018/09/AP_img_JoshMinon.jpg', 0, 'attachment', 'image/jpeg', 0),
(145, 1, '2018-09-11 08:19:37', '2018-09-11 16:19:37', '', 'AP_img_MichaelCeriak', '', 'inherit', 'open', 'closed', '', 'ap_img_michaelceriak', '', '', '2018-09-11 08:19:37', '2018-09-11 16:19:37', '', 140, 'http://cannon-demo.com/wp-content/uploads/2018/09/AP_img_MichaelCeriak.jpg', 0, 'attachment', 'image/jpeg', 0),
(146, 1, '2018-09-11 08:19:44', '2018-09-11 16:19:44', '', 'AP_img_RachelPotter', '', 'inherit', 'open', 'closed', '', 'ap_img_rachelpotter', '', '', '2018-09-11 08:19:44', '2018-09-11 16:19:44', '', 140, 'http://cannon-demo.com/wp-content/uploads/2018/09/AP_img_RachelPotter.jpg', 0, 'attachment', 'image/jpeg', 0),
(147, 1, '2018-09-11 08:19:44', '2018-09-11 16:19:44', '', 'AP_img_RobertCrivello', '', 'inherit', 'open', 'closed', '', 'ap_img_robertcrivello', '', '', '2018-09-11 08:19:44', '2018-09-11 16:19:44', '', 140, 'http://cannon-demo.com/wp-content/uploads/2018/09/AP_img_RobertCrivello.jpg', 0, 'attachment', 'image/jpeg', 0),
(148, 1, '2018-09-11 08:19:45', '2018-09-11 16:19:45', '', 'AP_img_SarahKass', '', 'inherit', 'open', 'closed', '', 'ap_img_sarahkass', '', '', '2018-09-11 08:19:45', '2018-09-11 16:19:45', '', 140, 'http://cannon-demo.com/wp-content/uploads/2018/09/AP_img_SarahKass.jpg', 0, 'attachment', 'image/jpeg', 0),
(149, 1, '2018-09-11 08:20:05', '2018-09-11 16:20:05', '', 'Edward E. Robinson', '', 'inherit', 'closed', 'closed', '', '140-revision-v1', '', '', '2018-09-11 08:20:05', '2018-09-11 16:20:05', '', 140, 'http://cannon-demo.com/140-revision-v1/', 0, 'revision', '', 0),
(150, 1, '2018-09-11 08:20:44', '2018-09-11 16:20:44', '', 'Sarah F. Kaas', '', 'publish', 'closed', 'closed', '', 'sarah-f-kaas', '', '', '2018-09-11 08:20:44', '2018-09-11 16:20:44', '', 0, 'http://cannon-demo.com/?page_id=150', 0, 'page', '', 0),
(151, 1, '2018-09-11 08:20:44', '2018-09-11 16:20:44', '', 'Sarah F. Kaas', '', 'inherit', 'closed', 'closed', '', '150-revision-v1', '', '', '2018-09-11 08:20:44', '2018-09-11 16:20:44', '', 150, 'http://cannon-demo.com/150-revision-v1/', 0, 'revision', '', 0),
(152, 1, '2018-09-11 08:21:46', '2018-09-11 16:21:46', '', 'Allan M. Foeckler', '', 'publish', 'closed', 'closed', '', 'allan-m-foeckler', '', '', '2018-09-11 08:21:46', '2018-09-11 16:21:46', '', 0, 'http://cannon-demo.com/?page_id=152', 0, 'page', '', 0),
(153, 1, '2018-09-11 08:21:46', '2018-09-11 16:21:46', '', 'Allan M. Foeckler', '', 'inherit', 'closed', 'closed', '', '152-revision-v1', '', '', '2018-09-11 08:21:46', '2018-09-11 16:21:46', '', 152, 'http://cannon-demo.com/152-revision-v1/', 0, 'revision', '', 0),
(154, 1, '2018-09-11 08:22:18', '2018-09-11 16:22:18', '', 'Robert D. Crivello', '', 'publish', 'closed', 'closed', '', 'robert-d-crivello', '', '', '2018-09-11 08:22:18', '2018-09-11 16:22:18', '', 0, 'http://cannon-demo.com/?page_id=154', 0, 'page', '', 0),
(155, 1, '2018-09-11 08:22:18', '2018-09-11 16:22:18', '', 'Robert D. Crivello', '', 'inherit', 'closed', 'closed', '', '154-revision-v1', '', '', '2018-09-11 08:22:18', '2018-09-11 16:22:18', '', 154, 'http://cannon-demo.com/154-revision-v1/', 0, 'revision', '', 0),
(156, 1, '2018-09-11 08:23:12', '2018-09-11 16:23:12', '', 'Brett A. Eckstein', '', 'publish', 'closed', 'closed', '', 'brett-a-eckstein', '', '', '2018-09-11 08:23:13', '2018-09-11 16:23:13', '', 0, 'http://cannon-demo.com/?page_id=156', 0, 'page', '', 0),
(157, 1, '2018-09-11 08:23:13', '2018-09-11 16:23:13', '', 'Brett A. Eckstein', '', 'inherit', 'closed', 'closed', '', '156-revision-v1', '', '', '2018-09-11 08:23:13', '2018-09-11 16:23:13', '', 156, 'http://cannon-demo.com/156-revision-v1/', 0, 'revision', '', 0),
(158, 1, '2018-09-11 08:23:45', '2018-09-11 16:23:45', '', 'Josh J. Minon', '', 'publish', 'closed', 'closed', '', 'josh-j-minon', '', '', '2018-09-11 08:23:45', '2018-09-11 16:23:45', '', 0, 'http://cannon-demo.com/?page_id=158', 0, 'page', '', 0),
(159, 1, '2018-09-11 08:23:45', '2018-09-11 16:23:45', '', 'Josh J. Minon', '', 'inherit', 'closed', 'closed', '', '158-revision-v1', '', '', '2018-09-11 08:23:45', '2018-09-11 16:23:45', '', 158, 'http://cannon-demo.com/158-revision-v1/', 0, 'revision', '', 0),
(160, 1, '2018-09-11 08:24:47', '2018-09-11 16:24:47', '', 'Michael J. Cerjak', '', 'publish', 'closed', 'closed', '', 'michael-j-cerjak', '', '', '2018-09-11 08:24:47', '2018-09-11 16:24:47', '', 0, 'http://cannon-demo.com/?page_id=160', 0, 'page', '', 0),
(161, 1, '2018-09-11 08:24:47', '2018-09-11 16:24:47', '', 'Michael J. Cerjak', '', 'inherit', 'closed', 'closed', '', '160-revision-v1', '', '', '2018-09-11 08:24:47', '2018-09-11 16:24:47', '', 160, 'http://cannon-demo.com/160-revision-v1/', 0, 'revision', '', 0),
(162, 1, '2018-09-11 08:25:21', '2018-09-11 16:25:21', '', 'Rachel E. Potter', '', 'publish', 'closed', 'closed', '', 'rachel-e-potter', '', '', '2018-09-11 08:25:21', '2018-09-11 16:25:21', '', 0, 'http://cannon-demo.com/?page_id=162', 0, 'page', '', 0),
(163, 1, '2018-09-11 08:25:21', '2018-09-11 16:25:21', '', 'Rachel E. Potter', '', 'inherit', 'closed', 'closed', '', '162-revision-v1', '', '', '2018-09-11 08:25:21', '2018-09-11 16:25:21', '', 162, 'http://cannon-demo.com/162-revision-v1/', 0, 'revision', '', 0),
(164, 1, '2018-09-11 08:29:27', '2018-09-11 16:29:27', '', 'Meet the Attorneys', '', 'inherit', 'closed', 'closed', '', '79-revision-v1', '', '', '2018-09-11 08:29:27', '2018-09-11 16:29:27', '', 79, 'http://cannon-demo.com/79-revision-v1/', 0, 'revision', '', 0),
(165, 1, '2018-09-11 08:33:05', '2018-09-11 16:33:05', 'a:10:{s:4:"type";s:8:"repeater";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"collapsed";s:0:"";s:3:"min";s:0:"";s:3:"max";s:0:"";s:6:"layout";s:3:"row";s:12:"button_label";s:12:"Add Attorney";}', 'Attorney Directory', 'attorney_directory', 'publish', 'closed', 'closed', '', 'field_5b97ede6fef40', '', '', '2018-09-11 08:33:05', '2018-09-11 16:33:05', '', 136, 'http://cannon-demo.com/?post_type=acf-field&p=165', 0, 'acf-field', '', 0),
(166, 1, '2018-09-11 08:33:05', '2018-09-11 16:33:05', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Attorney Position', 'attorney_position', 'publish', 'closed', 'closed', '', 'field_5b97edf9fef41', '', '', '2018-09-11 08:33:26', '2018-09-11 16:33:26', '', 165, 'http://cannon-demo.com/?post_type=acf-field&#038;p=166', 1, 'acf-field', '', 0),
(167, 1, '2018-09-11 08:33:05', '2018-09-11 16:33:05', 'a:11:{s:4:"type";s:11:"post_object";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"post_type";a:1:{i:0;s:4:"page";}s:8:"taxonomy";a:0:{}s:10:"allow_null";i:0;s:8:"multiple";i:0;s:13:"return_format";s:6:"object";s:2:"ui";i:1;}', 'Attorney Page Info', 'attorney_page_info', 'publish', 'closed', 'closed', '', 'field_5b97ee16fef42', '', '', '2018-09-11 08:33:26', '2018-09-11 16:33:26', '', 165, 'http://cannon-demo.com/?post_type=acf-field&#038;p=167', 0, 'acf-field', '', 0),
(168, 1, '2018-09-11 08:34:30', '2018-09-11 16:34:30', '', 'Meet the Attorneys', '', 'inherit', 'closed', 'closed', '', '79-revision-v1', '', '', '2018-09-11 08:34:30', '2018-09-11 16:34:30', '', 79, 'http://cannon-demo.com/79-revision-v1/', 0, 'revision', '', 0),
(169, 1, '2018-09-11 08:50:13', '2018-09-11 16:50:13', '', 'Meet the Attorneys', '', 'inherit', 'closed', 'closed', '', '79-revision-v1', '', '', '2018-09-11 08:50:13', '2018-09-11 16:50:13', '', 79, 'http://cannon-demo.com/79-revision-v1/', 0, 'revision', '', 0),
(170, 1, '2018-09-11 08:51:12', '2018-09-11 16:51:12', '', 'AP_img_WilliamCannon', '', 'inherit', 'open', 'closed', '', 'ap_img_williamcannon', '', '', '2018-09-11 08:51:12', '2018-09-11 16:51:12', '', 60, 'http://cannon-demo.com/wp-content/uploads/2018/09/AP_img_WilliamCannon.jpg', 0, 'attachment', 'image/jpeg', 0),
(171, 1, '2018-09-11 08:51:17', '2018-09-11 16:51:17', 'Attorney William M. Cannon is a member of one of Wisconsin\'s best-known and most prominent legal families extending over four generations of lawyers, beginning with his grandfather\'s admission to the Wisconsin Bar. This four-generation legal family has practiced continuously in Milwaukee and other communities throughout Wisconsin for over 100 years. Mr. Cannon has won more $10 million paid verdicts and settlements for his clients than any other lawyer in Wisconsin. His cases have been featured on the CBS program "60 Minutes" and the "ABC Evening National News". He has continuously been listed in The Best Lawyers in America for Over 25 consecutive years.\r\n\r\nRaymond J. Cannon. (Grandfather) Admitted to Wisconsin Bar, 1914. Partner in Milwaukee law firm of Cannon &amp; Waldron. U.S. Congressman, Milwaukee (4 th District) 1933-39. He was the most famous trial lawyer of his generation. Some of his famous clients were World Heavyweight Boxing Champion Jack Dempsey, Shoeless Joe Jackson (Chicago Black Sox Scandal) and Wallis Simpson. Between 1914-1921, he successfully tried and won over 100 consecutive jury trials, resulting in a banquet hosted by the Milwaukee Bar Association honoring him for this achievement. The Federal Defender Services of Wisconsin has named an award after him in memory of his trial accomplishments, "The Ray Cannon Justice Award".\r\n\r\nJudge Robert C. Cannon. (Father) Admitted to Wisconsin Bar, 1941. Milwaukee County Civil and Circuit Court Judge, successfully re-elected 1945-79; first Presiding Judge, Wisconsin Court of Appeals, 1979-82. Legal Advisor To Major League Baseball Players Association.\r\n\r\nKelly Gildea Cannon (great granddaughter of Raymond J. Cannon and daughter of William M. Cannon) is a graduate of Loyola University Chicago School of Law (J. D.) In Chicago, Illinois. She is licensed to practice law in Illinois and New York. She also has received her Masters of Law (LLM) in International Dispute Resolution at Kings College in London, England.', 'William M. Cannon', '', 'inherit', 'closed', 'closed', '', '60-revision-v1', '', '', '2018-09-11 08:51:17', '2018-09-11 16:51:17', '', 60, 'http://cannon-demo.com/60-revision-v1/', 0, 'revision', '', 0),
(172, 1, '2018-09-11 09:24:35', '2018-09-11 17:24:35', 'a:7:{s:8:"location";a:1:{i:0;a:1:{i:0;a:3:{s:5:"param";s:13:"post_template";s:8:"operator";s:2:"==";s:5:"value";s:25:"template-testimonials.php";}}}s:8:"position";s:6:"normal";s:5:"style";s:7:"default";s:15:"label_placement";s:3:"top";s:21:"instruction_placement";s:5:"label";s:14:"hide_on_screen";a:5:{i:0;s:11:"the_content";i:1;s:7:"excerpt";i:2;s:14:"featured_image";i:3;s:10:"categories";i:4;s:4:"tags";}s:11:"description";s:0:"";}', 'Testimonials', 'testimonials', 'publish', 'closed', 'closed', '', 'group_5b97f9b855a38', '', '', '2018-09-11 09:37:11', '2018-09-11 17:37:11', '', 0, 'http://cannon-demo.com/?post_type=acf-field-group&#038;p=172', 0, 'acf-field-group', '', 0),
(173, 1, '2018-09-11 09:24:35', '2018-09-11 17:24:35', 'a:10:{s:4:"type";s:8:"repeater";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"collapsed";s:0:"";s:3:"min";s:0:"";s:3:"max";s:0:"";s:6:"layout";s:3:"row";s:12:"button_label";s:15:"Add Testimonial";}', 'Testimonials Column One', 'testimonials_column_one', 'publish', 'closed', 'closed', '', 'field_5b97f9d397daf', '', '', '2018-09-11 09:24:35', '2018-09-11 17:24:35', '', 172, 'http://cannon-demo.com/?post_type=acf-field&p=173', 0, 'acf-field', '', 0),
(174, 1, '2018-09-11 09:24:35', '2018-09-11 17:24:35', 'a:10:{s:4:"type";s:8:"textarea";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:9:"maxlength";s:0:"";s:4:"rows";s:0:"";s:9:"new_lines";s:2:"br";}', 'Testimonial Quote', 'testimonial_quote', 'publish', 'closed', 'closed', '', 'field_5b97f9e997db0', '', '', '2018-09-11 09:35:27', '2018-09-11 17:35:27', '', 173, 'http://cannon-demo.com/?post_type=acf-field&#038;p=174', 0, 'acf-field', '', 0),
(175, 1, '2018-09-11 09:24:35', '2018-09-11 17:24:35', 'a:10:{s:4:"type";s:8:"textarea";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:9:"maxlength";s:0:"";s:4:"rows";s:0:"";s:9:"new_lines";s:2:"br";}', 'Testimonial Content', 'testimonial_content', 'publish', 'closed', 'closed', '', 'field_5b97fa1b97db1', '', '', '2018-09-11 09:37:11', '2018-09-11 17:37:11', '', 173, 'http://cannon-demo.com/?post_type=acf-field&#038;p=175', 1, 'acf-field', '', 0),
(176, 1, '2018-09-11 09:24:35', '2018-09-11 17:24:35', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Name', 'name', 'publish', 'closed', 'closed', '', 'field_5b97fa2897db2', '', '', '2018-09-11 09:24:35', '2018-09-11 17:24:35', '', 173, 'http://cannon-demo.com/?post_type=acf-field&p=176', 2, 'acf-field', '', 0),
(177, 1, '2018-09-11 09:24:35', '2018-09-11 17:24:35', 'a:10:{s:4:"type";s:8:"repeater";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"collapsed";s:0:"";s:3:"min";s:0:"";s:3:"max";s:0:"";s:6:"layout";s:3:"row";s:12:"button_label";s:15:"Add Testimonial";}', 'Testimonials Column Two', 'testimonials_column_two', 'publish', 'closed', 'closed', '', 'field_5b97fa3797db3', '', '', '2018-09-11 09:24:35', '2018-09-11 17:24:35', '', 172, 'http://cannon-demo.com/?post_type=acf-field&p=177', 1, 'acf-field', '', 0),
(178, 1, '2018-09-11 09:24:35', '2018-09-11 17:24:35', 'a:10:{s:4:"type";s:8:"textarea";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:9:"maxlength";s:0:"";s:4:"rows";s:0:"";s:9:"new_lines";s:2:"br";}', 'Testimonial Quote', 'testimonial_quote', 'publish', 'closed', 'closed', '', 'field_5b97fa3797db4', '', '', '2018-09-11 09:35:27', '2018-09-11 17:35:27', '', 177, 'http://cannon-demo.com/?post_type=acf-field&#038;p=178', 0, 'acf-field', '', 0),
(179, 1, '2018-09-11 09:24:35', '2018-09-11 17:24:35', 'a:10:{s:4:"type";s:8:"textarea";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:9:"maxlength";s:0:"";s:4:"rows";s:0:"";s:9:"new_lines";s:2:"br";}', 'Testimonial Content', 'testimonial_content', 'publish', 'closed', 'closed', '', 'field_5b97fa3797db5', '', '', '2018-09-11 09:37:11', '2018-09-11 17:37:11', '', 177, 'http://cannon-demo.com/?post_type=acf-field&#038;p=179', 1, 'acf-field', '', 0),
(180, 1, '2018-09-11 09:24:35', '2018-09-11 17:24:35', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Name', 'name', 'publish', 'closed', 'closed', '', 'field_5b97fa3797db6', '', '', '2018-09-11 09:24:35', '2018-09-11 17:24:35', '', 177, 'http://cannon-demo.com/?post_type=acf-field&p=180', 2, 'acf-field', '', 0),
(181, 1, '2018-09-11 09:25:43', '2018-09-11 17:25:43', '', 'Testimonials', '', 'inherit', 'closed', 'closed', '', '52-revision-v1', '', '', '2018-09-11 09:25:43', '2018-09-11 17:25:43', '', 52, 'http://cannon-demo.com/52-revision-v1/', 0, 'revision', '', 0),
(182, 1, '2018-09-11 09:29:15', '2018-09-11 17:29:15', '', 'Testimonials', '', 'inherit', 'closed', 'closed', '', '52-revision-v1', '', '', '2018-09-11 09:29:15', '2018-09-11 17:29:15', '', 52, 'http://cannon-demo.com/52-revision-v1/', 0, 'revision', '', 0),
(183, 1, '2018-09-11 09:31:12', '2018-09-11 17:31:12', '', 'Testimonials', '', 'inherit', 'closed', 'closed', '', '52-revision-v1', '', '', '2018-09-11 09:31:12', '2018-09-11 17:31:12', '', 52, 'http://cannon-demo.com/52-revision-v1/', 0, 'revision', '', 0),
(184, 1, '2018-09-11 09:32:46', '2018-09-11 17:32:46', '', 'Testimonials', '', 'inherit', 'closed', 'closed', '', '52-revision-v1', '', '', '2018-09-11 09:32:46', '2018-09-11 17:32:46', '', 52, 'http://cannon-demo.com/52-revision-v1/', 0, 'revision', '', 0),
(185, 1, '2018-09-11 09:35:44', '2018-09-11 17:35:44', '', 'Testimonials', '', 'inherit', 'closed', 'closed', '', '52-revision-v1', '', '', '2018-09-11 09:35:44', '2018-09-11 17:35:44', '', 52, 'http://cannon-demo.com/52-revision-v1/', 0, 'revision', '', 0),
(186, 1, '2018-09-11 09:37:37', '2018-09-11 17:37:37', '', 'Testimonials', '', 'inherit', 'closed', 'closed', '', '52-revision-v1', '', '', '2018-09-11 09:37:37', '2018-09-11 17:37:37', '', 52, 'http://cannon-demo.com/52-revision-v1/', 0, 'revision', '', 0),
(187, 1, '2018-09-11 09:38:00', '2018-09-11 17:38:00', '', 'Testimonials', '', 'inherit', 'closed', 'closed', '', '52-revision-v1', '', '', '2018-09-11 09:38:00', '2018-09-11 17:38:00', '', 52, 'http://cannon-demo.com/52-revision-v1/', 0, 'revision', '', 0),
(188, 1, '2018-09-11 09:38:25', '2018-09-11 17:38:25', '', 'Testimonials', '', 'inherit', 'closed', 'closed', '', '52-revision-v1', '', '', '2018-09-11 09:38:25', '2018-09-11 17:38:25', '', 52, 'http://cannon-demo.com/52-revision-v1/', 0, 'revision', '', 0),
(189, 1, '2018-09-11 09:38:50', '2018-09-11 17:38:50', '', 'Testimonials', '', 'inherit', 'closed', 'closed', '', '52-revision-v1', '', '', '2018-09-11 09:38:50', '2018-09-11 17:38:50', '', 52, 'http://cannon-demo.com/52-revision-v1/', 0, 'revision', '', 0),
(190, 1, '2018-09-11 09:39:10', '2018-09-11 17:39:10', '', 'Testimonials', '', 'inherit', 'closed', 'closed', '', '52-revision-v1', '', '', '2018-09-11 09:39:10', '2018-09-11 17:39:10', '', 52, 'http://cannon-demo.com/52-revision-v1/', 0, 'revision', '', 0),
(191, 1, '2018-09-11 14:00:02', '2018-09-11 22:00:02', ' ', '', '', 'publish', 'closed', 'closed', '', '191', '', '', '2018-09-11 14:00:02', '2018-09-11 22:00:02', '', 0, 'http://cannon-demo.com/?p=191', 4, 'nav_menu_item', '', 0),
(192, 1, '2018-09-11 14:11:55', '2018-09-11 22:11:55', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.\r\n\r\nLorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.\r\n\r\nLorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.\r\n\r\nLorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.\r\n\r\nLorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.', 'Title goes here eaque ipsa quae ab illo inventore two lines sed quia non numquam eius modi', '', 'publish', 'open', 'open', '', 'title-goes-here-eaque-ipsa-quae-ab-illo-inventore-two-lines-sed-quia-non-numquam-eius-modi', '', '', '2018-09-11 14:11:55', '2018-09-11 22:11:55', '', 0, 'http://cannon-demo.com/?p=192', 0, 'post', '', 0) ;
INSERT INTO `wp_posts` ( `ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(193, 1, '2018-09-11 14:11:55', '2018-09-11 22:11:55', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.\r\n\r\nLorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.\r\n\r\nLorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.\r\n\r\nLorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.\r\n\r\nLorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.', 'Title goes here eaque ipsa quae ab illo inventore two lines sed quia non numquam eius modi', '', 'inherit', 'closed', 'closed', '', '192-revision-v1', '', '', '2018-09-11 14:11:55', '2018-09-11 22:11:55', '', 192, 'http://cannon-demo.com/192-revision-v1/', 0, 'revision', '', 0),
(194, 1, '2018-09-11 14:14:00', '2018-09-11 22:14:00', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.\r\n\r\nLorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.\r\n\r\nLorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.\r\n\r\nLorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.\r\n\r\nLorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.', 'Title goes here eaque ipsa quae ab illo inventore two lines sed quia non numquam eius modi  Copy', '', 'publish', 'open', 'open', '', 'title-goes-here-eaque-ipsa-quae-ab-illo-inventore-two-lines-sed-quia-non-numquam-eius-modi-copy', '', '', '2018-09-11 14:14:00', '2018-09-11 22:14:00', '', 0, 'http://cannon-demo.com/title-goes-here-eaque-ipsa-quae-ab-illo-inventore-two-lines-sed-quia-non-numquam-eius-modi-copy/', 0, 'post', '', 0),
(195, 1, '2018-09-11 14:14:03', '2018-09-11 22:14:03', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.\r\n\r\nLorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.\r\n\r\nLorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.\r\n\r\nLorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.\r\n\r\nLorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.', 'Title goes here eaque ipsa quae ab illo inventore two lines sed quia non numquam eius modi  Copy', '', 'publish', 'open', 'open', '', 'title-goes-here-eaque-ipsa-quae-ab-illo-inventore-two-lines-sed-quia-non-numquam-eius-modi-copy-2', '', '', '2018-09-11 14:14:03', '2018-09-11 22:14:03', '', 0, 'http://cannon-demo.com/title-goes-here-eaque-ipsa-quae-ab-illo-inventore-two-lines-sed-quia-non-numquam-eius-modi-copy-2/', 0, 'post', '', 0),
(196, 1, '2018-09-11 14:14:05', '2018-09-11 22:14:05', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.\r\n\r\nLorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.\r\n\r\nLorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.\r\n\r\nLorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.\r\n\r\nLorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.', 'Title goes here eaque ipsa quae ab illo inventore two lines sed quia non numquam eius modi  Copy', '', 'publish', 'open', 'open', '', 'title-goes-here-eaque-ipsa-quae-ab-illo-inventore-two-lines-sed-quia-non-numquam-eius-modi-copy-3', '', '', '2018-09-11 14:14:05', '2018-09-11 22:14:05', '', 0, 'http://cannon-demo.com/title-goes-here-eaque-ipsa-quae-ab-illo-inventore-two-lines-sed-quia-non-numquam-eius-modi-copy-3/', 0, 'post', '', 0),
(197, 1, '2018-09-11 14:14:08', '2018-09-11 22:14:08', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.\r\n\r\nLorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.\r\n\r\nLorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.\r\n\r\nLorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.\r\n\r\nLorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.', 'Title goes here eaque ipsa quae ab illo inventore two lines sed quia non numquam eius modi  Copy', '', 'publish', 'open', 'open', '', 'title-goes-here-eaque-ipsa-quae-ab-illo-inventore-two-lines-sed-quia-non-numquam-eius-modi-copy-4', '', '', '2018-09-11 14:14:08', '2018-09-11 22:14:08', '', 0, 'http://cannon-demo.com/title-goes-here-eaque-ipsa-quae-ab-illo-inventore-two-lines-sed-quia-non-numquam-eius-modi-copy-4/', 0, 'post', '', 0) ;

#
# End of data contents of table `wp_posts`
# --------------------------------------------------------



#
# Delete any existing table `wp_rg_form`
#

DROP TABLE IF EXISTS `wp_rg_form`;


#
# Table structure of table `wp_rg_form`
#

CREATE TABLE `wp_rg_form` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(150) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `date_created` datetime NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `is_trash` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_rg_form`
#
INSERT INTO `wp_rg_form` ( `id`, `title`, `date_created`, `is_active`, `is_trash`) VALUES
(1, 'Contact', '2018-01-23 02:49:42', 1, 0) ;

#
# End of data contents of table `wp_rg_form`
# --------------------------------------------------------



#
# Delete any existing table `wp_rg_form_meta`
#

DROP TABLE IF EXISTS `wp_rg_form_meta`;


#
# Table structure of table `wp_rg_form_meta`
#

CREATE TABLE `wp_rg_form_meta` (
  `form_id` mediumint(8) unsigned NOT NULL,
  `display_meta` longtext COLLATE utf8mb4_unicode_520_ci,
  `entries_grid_meta` longtext COLLATE utf8mb4_unicode_520_ci,
  `confirmations` longtext COLLATE utf8mb4_unicode_520_ci,
  `notifications` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`form_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_rg_form_meta`
#
INSERT INTO `wp_rg_form_meta` ( `form_id`, `display_meta`, `entries_grid_meta`, `confirmations`, `notifications`) VALUES
(1, '{"title":"Contact","description":"","labelPlacement":"top_label","descriptionPlacement":"below","button":{"type":"text","text":"Submit","imageUrl":""},"fields":[],"version":"2.2.5","id":1,"notifications":{"5a66a2c69111e":{"id":"5a66a2c69111e","to":"{admin_email}","name":"Admin Notification","event":"form_submission","toType":"email","subject":"New submission from {form_title}","message":"{all_fields}"}},"confirmations":{"5a66a2c69162e":{"id":"5a66a2c69162e","name":"Default Confirmation","isDefault":true,"type":"message","message":"Thanks for contacting us! We will get in touch with you shortly.","url":"","pageId":"","queryString":""}},"subLabelPlacement":"below","cssClass":"","enableHoneypot":true,"enableAnimation":false,"save":{"enabled":false,"button":{"type":"link","text":"Save and Continue Later"}},"limitEntries":false,"limitEntriesCount":"","limitEntriesPeriod":"","limitEntriesMessage":"","scheduleForm":false,"scheduleStart":"","scheduleStartHour":"","scheduleStartMinute":"","scheduleStartAmpm":"","scheduleEnd":"","scheduleEndHour":"","scheduleEndMinute":"","scheduleEndAmpm":"","schedulePendingMessage":"","scheduleMessage":"","requireLogin":false,"requireLoginMessage":""}', NULL, '{"5a66a2c69162e":{"id":"5a66a2c69162e","name":"Default Confirmation","isDefault":true,"type":"page","message":"Thanks for contacting us! We will get in touch with you shortly.","url":"","pageId":37,"queryString":"","disableAutoformat":false,"conditionalLogic":[]}}', '{"5a66a2c69111e":{"isActive":true,"id":"5a66a2c69111e","name":"Admin Notification","service":"wordpress","event":"form_submission","to":"joe@1point21interactive.com","toType":"email","bcc":"","subject":"{Name:1} - Case Evaluation inquiry from clientname.com","message":"<div align=\\"center\\"><img src=\\"http:\\/\\/www.ilawyermarketing.com\\/images\\/ilawyerlogo.jpg\\" alt=\\"Website lead from iLawyerMarketing\\" \\/><\\/div>\\r\\n{all_fields}","from":"noreply@ilawyermarketing.org","fromName":"Clientwebsite.com","replyTo":"{Email: 3}","routing":null,"conditionalLogic":null,"disableAutoformat":false}}') ;

#
# End of data contents of table `wp_rg_form_meta`
# --------------------------------------------------------



#
# Delete any existing table `wp_rg_form_view`
#

DROP TABLE IF EXISTS `wp_rg_form_view`;


#
# Table structure of table `wp_rg_form_view`
#

CREATE TABLE `wp_rg_form_view` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `form_id` mediumint(8) unsigned NOT NULL,
  `date_created` datetime NOT NULL,
  `ip` char(15) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `count` mediumint(8) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `form_id` (`form_id`),
  KEY `date_created` (`date_created`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_rg_form_view`
#

#
# End of data contents of table `wp_rg_form_view`
# --------------------------------------------------------



#
# Delete any existing table `wp_rg_incomplete_submissions`
#

DROP TABLE IF EXISTS `wp_rg_incomplete_submissions`;


#
# Table structure of table `wp_rg_incomplete_submissions`
#

CREATE TABLE `wp_rg_incomplete_submissions` (
  `uuid` char(32) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `form_id` mediumint(8) unsigned NOT NULL,
  `date_created` datetime NOT NULL,
  `ip` varchar(39) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `source_url` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `submission` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  PRIMARY KEY (`uuid`),
  KEY `form_id` (`form_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_rg_incomplete_submissions`
#

#
# End of data contents of table `wp_rg_incomplete_submissions`
# --------------------------------------------------------



#
# Delete any existing table `wp_rg_lead`
#

DROP TABLE IF EXISTS `wp_rg_lead`;


#
# Table structure of table `wp_rg_lead`
#

CREATE TABLE `wp_rg_lead` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `form_id` mediumint(8) unsigned NOT NULL,
  `post_id` bigint(20) unsigned DEFAULT NULL,
  `date_created` datetime NOT NULL,
  `is_starred` tinyint(1) NOT NULL DEFAULT '0',
  `is_read` tinyint(1) NOT NULL DEFAULT '0',
  `ip` varchar(39) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `source_url` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_agent` varchar(250) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `currency` varchar(5) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `payment_status` varchar(15) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `payment_date` datetime DEFAULT NULL,
  `payment_amount` decimal(19,2) DEFAULT NULL,
  `transaction_id` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `is_fulfilled` tinyint(1) DEFAULT NULL,
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `transaction_type` tinyint(1) DEFAULT NULL,
  `status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'active',
  `payment_method` varchar(30) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `form_id` (`form_id`),
  KEY `status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_rg_lead`
#

#
# End of data contents of table `wp_rg_lead`
# --------------------------------------------------------



#
# Delete any existing table `wp_rg_lead_detail`
#

DROP TABLE IF EXISTS `wp_rg_lead_detail`;


#
# Table structure of table `wp_rg_lead_detail`
#

CREATE TABLE `wp_rg_lead_detail` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `lead_id` int(10) unsigned NOT NULL,
  `form_id` mediumint(8) unsigned NOT NULL,
  `field_number` float NOT NULL,
  `value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`id`),
  KEY `form_id` (`form_id`),
  KEY `lead_id` (`lead_id`),
  KEY `lead_field_number` (`lead_id`,`field_number`),
  KEY `lead_field_value` (`value`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_rg_lead_detail`
#

#
# End of data contents of table `wp_rg_lead_detail`
# --------------------------------------------------------



#
# Delete any existing table `wp_rg_lead_detail_long`
#

DROP TABLE IF EXISTS `wp_rg_lead_detail_long`;


#
# Table structure of table `wp_rg_lead_detail_long`
#

CREATE TABLE `wp_rg_lead_detail_long` (
  `lead_detail_id` bigint(20) unsigned NOT NULL,
  `value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`lead_detail_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_rg_lead_detail_long`
#

#
# End of data contents of table `wp_rg_lead_detail_long`
# --------------------------------------------------------



#
# Delete any existing table `wp_rg_lead_meta`
#

DROP TABLE IF EXISTS `wp_rg_lead_meta`;


#
# Table structure of table `wp_rg_lead_meta`
#

CREATE TABLE `wp_rg_lead_meta` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `form_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `lead_id` bigint(20) unsigned NOT NULL,
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`id`),
  KEY `lead_id` (`lead_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_rg_lead_meta`
#

#
# End of data contents of table `wp_rg_lead_meta`
# --------------------------------------------------------



#
# Delete any existing table `wp_rg_lead_notes`
#

DROP TABLE IF EXISTS `wp_rg_lead_notes`;


#
# Table structure of table `wp_rg_lead_notes`
#

CREATE TABLE `wp_rg_lead_notes` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `lead_id` int(10) unsigned NOT NULL,
  `user_name` varchar(250) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `user_id` bigint(20) DEFAULT NULL,
  `date_created` datetime NOT NULL,
  `value` longtext COLLATE utf8mb4_unicode_520_ci,
  `note_type` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `lead_id` (`lead_id`),
  KEY `lead_user_key` (`lead_id`,`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_rg_lead_notes`
#

#
# End of data contents of table `wp_rg_lead_notes`
# --------------------------------------------------------



#
# Delete any existing table `wp_term_relationships`
#

DROP TABLE IF EXISTS `wp_term_relationships`;


#
# Table structure of table `wp_term_relationships`
#

CREATE TABLE `wp_term_relationships` (
  `object_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_taxonomy_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_order` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  KEY `term_taxonomy_id` (`term_taxonomy_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_term_relationships`
#
INSERT INTO `wp_term_relationships` ( `object_id`, `term_taxonomy_id`, `term_order`) VALUES
(15, 1, 0),
(17, 1, 0),
(19, 1, 0),
(21, 1, 0),
(23, 1, 0),
(70, 2, 0),
(71, 2, 0),
(72, 2, 0),
(73, 2, 0),
(74, 2, 0),
(75, 2, 0),
(76, 2, 0),
(77, 2, 0),
(78, 2, 0),
(81, 2, 0),
(82, 2, 0),
(83, 2, 0),
(85, 3, 0),
(86, 3, 0),
(95, 3, 0),
(96, 3, 0),
(97, 3, 0),
(98, 3, 0),
(99, 3, 0),
(100, 3, 0),
(106, 2, 0),
(107, 3, 0),
(108, 3, 0),
(109, 3, 0),
(191, 2, 0),
(192, 1, 0),
(194, 1, 0),
(195, 1, 0),
(196, 1, 0),
(197, 1, 0) ;

#
# End of data contents of table `wp_term_relationships`
# --------------------------------------------------------



#
# Delete any existing table `wp_term_taxonomy`
#

DROP TABLE IF EXISTS `wp_term_taxonomy`;


#
# Table structure of table `wp_term_taxonomy`
#

CREATE TABLE `wp_term_taxonomy` (
  `term_taxonomy_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `taxonomy` varchar(32) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `description` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_taxonomy_id`),
  UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  KEY `taxonomy` (`taxonomy`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_term_taxonomy`
#
INSERT INTO `wp_term_taxonomy` ( `term_taxonomy_id`, `term_id`, `taxonomy`, `description`, `parent`, `count`) VALUES
(1, 1, 'category', '', 0, 5),
(2, 2, 'nav_menu', '', 0, 14),
(3, 3, 'nav_menu', '', 0, 11) ;

#
# End of data contents of table `wp_term_taxonomy`
# --------------------------------------------------------



#
# Delete any existing table `wp_termmeta`
#

DROP TABLE IF EXISTS `wp_termmeta`;


#
# Table structure of table `wp_termmeta`
#

CREATE TABLE `wp_termmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`meta_id`),
  KEY `term_id` (`term_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_termmeta`
#

#
# End of data contents of table `wp_termmeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_terms`
#

DROP TABLE IF EXISTS `wp_terms`;


#
# Table structure of table `wp_terms`
#

CREATE TABLE `wp_terms` (
  `term_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `slug` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `term_group` bigint(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_id`),
  KEY `slug` (`slug`(191)),
  KEY `name` (`name`(191))
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_terms`
#
INSERT INTO `wp_terms` ( `term_id`, `name`, `slug`, `term_group`) VALUES
(1, 'Uncategorized', 'uncategorized', 0),
(2, 'Main Menu', 'main-menu', 0),
(3, 'PA Sidebar Menu', 'pa-sidebar-menu', 0) ;

#
# End of data contents of table `wp_terms`
# --------------------------------------------------------



#
# Delete any existing table `wp_usermeta`
#

DROP TABLE IF EXISTS `wp_usermeta`;


#
# Table structure of table `wp_usermeta`
#

CREATE TABLE `wp_usermeta` (
  `umeta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`umeta_id`),
  KEY `user_id` (`user_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_usermeta`
#
INSERT INTO `wp_usermeta` ( `umeta_id`, `user_id`, `meta_key`, `meta_value`) VALUES
(1, 1, 'nickname', 'joe'),
(2, 1, 'first_name', ''),
(3, 1, 'last_name', ''),
(4, 1, 'description', ''),
(5, 1, 'rich_editing', 'true'),
(6, 1, 'comment_shortcuts', 'false'),
(7, 1, 'admin_color', 'fresh'),
(8, 1, 'use_ssl', '0'),
(9, 1, 'show_admin_bar_front', 'true'),
(10, 1, 'locale', ''),
(11, 1, 'wp_capabilities', 'a:1:{s:13:"administrator";b:1;}'),
(12, 1, 'wp_user_level', '10'),
(13, 1, 'dismissed_wp_pointers', 'wp496_privacy'),
(14, 1, 'show_welcome_panel', '1'),
(15, 1, 'session_tokens', 'a:3:{s:64:"33756b6d313d63d46f922b4c281dbefb9836e8431e613e498ef496f71cdb8833";a:4:{s:10:"expiration";i:1536767460;s:2:"ip";s:3:"::1";s:2:"ua";s:121:"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36";s:5:"login";i:1536594660;}s:64:"78408cefe9005fe06a2f16fd135587ab99e610ba69f6e9ce8065e92d2c2a8519";a:4:{s:10:"expiration";i:1536790099;s:2:"ip";s:3:"::1";s:2:"ua";s:121:"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36";s:5:"login";i:1536617299;}s:64:"9324ba42f7a81cb5c76e9734798740471d17feee5f14e9d5bf27ddab90910ff4";a:4:{s:10:"expiration";i:1536790416;s:2:"ip";s:3:"::1";s:2:"ua";s:121:"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36";s:5:"login";i:1536617616;}}'),
(16, 1, 'wp_user-settings', 'hidetb=1&editor=tinymce&libraryContent=browse&imgsize=full&posts_list_mode=list&mfold=o'),
(17, 1, 'wp_user-settings-time', '1531250034'),
(18, 1, 'wp_dashboard_quick_press_last_post_id', '84'),
(19, 1, 'community-events-location', 'a:1:{s:2:"ip";s:2:"::";}'),
(20, 1, 'managenav-menuscolumnshidden', 'a:5:{i:0;s:11:"link-target";i:1;s:11:"css-classes";i:2;s:3:"xfn";i:3;s:11:"description";i:4;s:15:"title-attribute";}'),
(21, 1, 'metaboxhidden_nav-menus', 'a:1:{i:0;s:12:"add-post_tag";}'),
(22, 1, 'nav_menu_recently_edited', '2'),
(23, 1, 'syntax_highlighting', 'true'),
(24, 1, 'acf_user_settings', 'a:0:{}'),
(25, 1, 'edit_page_per_page', '50') ;

#
# End of data contents of table `wp_usermeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_users`
#

DROP TABLE IF EXISTS `wp_users`;


#
# Table structure of table `wp_users`
#

CREATE TABLE `wp_users` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_login` varchar(60) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_pass` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_nicename` varchar(50) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_email` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_url` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_activation_key` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_status` int(11) NOT NULL DEFAULT '0',
  `display_name` varchar(250) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`ID`),
  KEY `user_login_key` (`user_login`),
  KEY `user_nicename` (`user_nicename`),
  KEY `user_email` (`user_email`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_users`
#
INSERT INTO `wp_users` ( `ID`, `user_login`, `user_pass`, `user_nicename`, `user_email`, `user_url`, `user_registered`, `user_activation_key`, `user_status`, `display_name`) VALUES
(1, '1p21.admin', '$P$BuC8KR5MOXu/yqXl/MVslXPHQZ5KiG1', '1p21-admin', 'joe.t.oconnor@gmail.com', '', '2017-12-26 23:55:11', '', 0, '1p21.admin') ;

#
# End of data contents of table `wp_users`
# --------------------------------------------------------

#
# Add constraints back in and apply any alter data queries.
#

