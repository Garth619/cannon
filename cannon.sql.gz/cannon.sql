-- phpMyAdmin SQL Dump
-- version 4.7.7
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Aug 31, 2018 at 03:02 PM
-- Server version: 5.6.38
-- PHP Version: 7.2.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `cannon`
--

-- --------------------------------------------------------

--
-- Table structure for table `wp_commentmeta`
--

CREATE TABLE `wp_commentmeta` (
  `meta_id` bigint(20) UNSIGNED NOT NULL,
  `comment_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

-- --------------------------------------------------------

--
-- Table structure for table `wp_comments`
--

CREATE TABLE `wp_comments` (
  `comment_ID` bigint(20) UNSIGNED NOT NULL,
  `comment_post_ID` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `comment_author` tinytext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `comment_author_email` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `comment_karma` int(11) NOT NULL DEFAULT '0',
  `comment_approved` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_type` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_parent` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `user_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

-- --------------------------------------------------------

--
-- Table structure for table `wp_gf_draft_submissions`
--

CREATE TABLE `wp_gf_draft_submissions` (
  `uuid` char(32) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `form_id` mediumint(8) UNSIGNED NOT NULL,
  `date_created` datetime NOT NULL,
  `ip` varchar(39) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `source_url` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `submission` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

-- --------------------------------------------------------

--
-- Table structure for table `wp_gf_entry`
--

CREATE TABLE `wp_gf_entry` (
  `id` int(10) UNSIGNED NOT NULL,
  `form_id` mediumint(8) UNSIGNED NOT NULL,
  `post_id` bigint(20) UNSIGNED DEFAULT NULL,
  `date_created` datetime NOT NULL,
  `date_updated` datetime DEFAULT NULL,
  `is_starred` tinyint(1) NOT NULL DEFAULT '0',
  `is_read` tinyint(1) NOT NULL DEFAULT '0',
  `ip` varchar(39) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `source_url` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_agent` varchar(250) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `currency` varchar(5) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `payment_status` varchar(15) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `payment_date` datetime DEFAULT NULL,
  `payment_amount` decimal(19,2) DEFAULT NULL,
  `payment_method` varchar(30) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `transaction_id` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `is_fulfilled` tinyint(1) DEFAULT NULL,
  `created_by` bigint(20) UNSIGNED DEFAULT NULL,
  `transaction_type` tinyint(1) DEFAULT NULL,
  `status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'active'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

-- --------------------------------------------------------

--
-- Table structure for table `wp_gf_entry_meta`
--

CREATE TABLE `wp_gf_entry_meta` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `form_id` mediumint(8) UNSIGNED NOT NULL DEFAULT '0',
  `entry_id` bigint(20) UNSIGNED NOT NULL,
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

-- --------------------------------------------------------

--
-- Table structure for table `wp_gf_entry_notes`
--

CREATE TABLE `wp_gf_entry_notes` (
  `id` int(10) UNSIGNED NOT NULL,
  `entry_id` int(10) UNSIGNED NOT NULL,
  `user_name` varchar(250) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `user_id` bigint(20) DEFAULT NULL,
  `date_created` datetime NOT NULL,
  `value` longtext COLLATE utf8mb4_unicode_520_ci,
  `note_type` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `sub_type` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

-- --------------------------------------------------------

--
-- Table structure for table `wp_gf_form`
--

CREATE TABLE `wp_gf_form` (
  `id` mediumint(8) UNSIGNED NOT NULL,
  `title` varchar(150) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `date_created` datetime NOT NULL,
  `date_updated` datetime DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `is_trash` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Dumping data for table `wp_gf_form`
--

INSERT INTO `wp_gf_form` (`id`, `title`, `date_created`, `date_updated`, `is_active`, `is_trash`) VALUES
(1, 'Contact', '2018-01-23 02:49:42', NULL, 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `wp_gf_form_meta`
--

CREATE TABLE `wp_gf_form_meta` (
  `form_id` mediumint(8) UNSIGNED NOT NULL,
  `display_meta` longtext COLLATE utf8mb4_unicode_520_ci,
  `entries_grid_meta` longtext COLLATE utf8mb4_unicode_520_ci,
  `confirmations` longtext COLLATE utf8mb4_unicode_520_ci,
  `notifications` longtext COLLATE utf8mb4_unicode_520_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Dumping data for table `wp_gf_form_meta`
--

INSERT INTO `wp_gf_form_meta` (`form_id`, `display_meta`, `entries_grid_meta`, `confirmations`, `notifications`) VALUES
(1, '{\"title\":\"Contact\",\"description\":\"\",\"labelPlacement\":\"top_label\",\"descriptionPlacement\":\"below\",\"button\":{\"type\":\"text\",\"text\":\"Submit\",\"imageUrl\":\"\"},\"fields\":[],\"version\":\"2.2.5\",\"id\":1,\"notifications\":{\"5a66a2c69111e\":{\"id\":\"5a66a2c69111e\",\"to\":\"{admin_email}\",\"name\":\"Admin Notification\",\"event\":\"form_submission\",\"toType\":\"email\",\"subject\":\"New submission from {form_title}\",\"message\":\"{all_fields}\"}},\"confirmations\":{\"5a66a2c69162e\":{\"id\":\"5a66a2c69162e\",\"name\":\"Default Confirmation\",\"isDefault\":true,\"type\":\"message\",\"message\":\"Thanks for contacting us! We will get in touch with you shortly.\",\"url\":\"\",\"pageId\":\"\",\"queryString\":\"\"}},\"subLabelPlacement\":\"below\",\"cssClass\":\"\",\"enableHoneypot\":true,\"enableAnimation\":false,\"save\":{\"enabled\":false,\"button\":{\"type\":\"link\",\"text\":\"Save and Continue Later\"}},\"limitEntries\":false,\"limitEntriesCount\":\"\",\"limitEntriesPeriod\":\"\",\"limitEntriesMessage\":\"\",\"scheduleForm\":false,\"scheduleStart\":\"\",\"scheduleStartHour\":\"\",\"scheduleStartMinute\":\"\",\"scheduleStartAmpm\":\"\",\"scheduleEnd\":\"\",\"scheduleEndHour\":\"\",\"scheduleEndMinute\":\"\",\"scheduleEndAmpm\":\"\",\"schedulePendingMessage\":\"\",\"scheduleMessage\":\"\",\"requireLogin\":false,\"requireLoginMessage\":\"\"}', NULL, '{\"5a66a2c69162e\":{\"id\":\"5a66a2c69162e\",\"name\":\"Default Confirmation\",\"isDefault\":true,\"type\":\"page\",\"message\":\"Thanks for contacting us! We will get in touch with you shortly.\",\"url\":\"\",\"pageId\":37,\"queryString\":\"\",\"disableAutoformat\":false,\"conditionalLogic\":[]}}', '{\"5a66a2c69111e\":{\"isActive\":true,\"id\":\"5a66a2c69111e\",\"name\":\"Admin Notification\",\"service\":\"wordpress\",\"event\":\"form_submission\",\"to\":\"joe@1point21interactive.com\",\"toType\":\"email\",\"bcc\":\"\",\"subject\":\"{Name:1} - Case Evaluation inquiry from clientname.com\",\"message\":\"<div align=\\\"center\\\"><img src=\\\"http:\\/\\/www.ilawyermarketing.com\\/images\\/ilawyerlogo.jpg\\\" alt=\\\"Website lead from iLawyerMarketing\\\" \\/><\\/div>\\r\\n{all_fields}\",\"from\":\"noreply@ilawyermarketing.org\",\"fromName\":\"Clientwebsite.com\",\"replyTo\":\"{Email: 3}\",\"routing\":null,\"conditionalLogic\":null,\"disableAutoformat\":false}}');

-- --------------------------------------------------------

--
-- Table structure for table `wp_gf_form_view`
--

CREATE TABLE `wp_gf_form_view` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `form_id` mediumint(8) UNSIGNED NOT NULL,
  `date_created` datetime NOT NULL,
  `ip` char(15) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `count` mediumint(8) UNSIGNED NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

-- --------------------------------------------------------

--
-- Table structure for table `wp_links`
--

CREATE TABLE `wp_links` (
  `link_id` bigint(20) UNSIGNED NOT NULL,
  `link_url` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_name` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_image` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_target` varchar(25) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_description` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_visible` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'Y',
  `link_owner` bigint(20) UNSIGNED NOT NULL DEFAULT '1',
  `link_rating` int(11) NOT NULL DEFAULT '0',
  `link_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `link_rel` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_notes` mediumtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `link_rss` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

-- --------------------------------------------------------

--
-- Table structure for table `wp_options`
--

CREATE TABLE `wp_options` (
  `option_id` bigint(20) UNSIGNED NOT NULL,
  `option_name` varchar(191) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `option_value` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `autoload` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'yes'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Dumping data for table `wp_options`
--

INSERT INTO `wp_options` (`option_id`, `option_name`, `option_value`, `autoload`) VALUES
(1, 'siteurl', 'http://cannon-demo.com', 'yes'),
(2, 'home', 'http://cannon-demo.com', 'yes'),
(3, 'blogname', 'Cannon &amp; Dunphy S.C.', 'yes'),
(4, 'blogdescription', '', 'yes'),
(5, 'users_can_register', '0', 'yes'),
(6, 'admin_email', 'joe.t.oconnor@gmail.com', 'yes'),
(7, 'start_of_week', '1', 'yes'),
(8, 'use_balanceTags', '0', 'yes'),
(9, 'use_smilies', '1', 'yes'),
(10, 'require_name_email', '1', 'yes'),
(11, 'comments_notify', '1', 'yes'),
(12, 'posts_per_rss', '10', 'yes'),
(13, 'rss_use_excerpt', '0', 'yes'),
(14, 'mailserver_url', 'mail.example.com', 'yes'),
(15, 'mailserver_login', 'login@example.com', 'yes'),
(16, 'mailserver_pass', 'password', 'yes'),
(17, 'mailserver_port', '110', 'yes'),
(18, 'default_category', '1', 'yes'),
(19, 'default_comment_status', 'open', 'yes'),
(20, 'default_ping_status', 'open', 'yes'),
(21, 'default_pingback_flag', '1', 'yes'),
(22, 'posts_per_page', '10', 'yes'),
(23, 'date_format', 'F j, Y', 'yes'),
(24, 'time_format', 'g:i a', 'yes'),
(25, 'links_updated_date_format', 'F j, Y g:i a', 'yes'),
(26, 'comment_moderation', '0', 'yes'),
(27, 'moderation_notify', '1', 'yes'),
(28, 'permalink_structure', '/%postname%/', 'yes'),
(29, 'rewrite_rules', 'a:88:{s:11:\"^wp-json/?$\";s:22:\"index.php?rest_route=/\";s:14:\"^wp-json/(.*)?\";s:33:\"index.php?rest_route=/$matches[1]\";s:21:\"^index.php/wp-json/?$\";s:22:\"index.php?rest_route=/\";s:24:\"^index.php/wp-json/(.*)?\";s:33:\"index.php?rest_route=/$matches[1]\";s:47:\"category/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:52:\"index.php?category_name=$matches[1]&feed=$matches[2]\";s:42:\"category/(.+?)/(feed|rdf|rss|rss2|atom)/?$\";s:52:\"index.php?category_name=$matches[1]&feed=$matches[2]\";s:23:\"category/(.+?)/embed/?$\";s:46:\"index.php?category_name=$matches[1]&embed=true\";s:35:\"category/(.+?)/page/?([0-9]{1,})/?$\";s:53:\"index.php?category_name=$matches[1]&paged=$matches[2]\";s:17:\"category/(.+?)/?$\";s:35:\"index.php?category_name=$matches[1]\";s:44:\"tag/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?tag=$matches[1]&feed=$matches[2]\";s:39:\"tag/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?tag=$matches[1]&feed=$matches[2]\";s:20:\"tag/([^/]+)/embed/?$\";s:36:\"index.php?tag=$matches[1]&embed=true\";s:32:\"tag/([^/]+)/page/?([0-9]{1,})/?$\";s:43:\"index.php?tag=$matches[1]&paged=$matches[2]\";s:14:\"tag/([^/]+)/?$\";s:25:\"index.php?tag=$matches[1]\";s:45:\"type/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?post_format=$matches[1]&feed=$matches[2]\";s:40:\"type/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?post_format=$matches[1]&feed=$matches[2]\";s:21:\"type/([^/]+)/embed/?$\";s:44:\"index.php?post_format=$matches[1]&embed=true\";s:33:\"type/([^/]+)/page/?([0-9]{1,})/?$\";s:51:\"index.php?post_format=$matches[1]&paged=$matches[2]\";s:15:\"type/([^/]+)/?$\";s:33:\"index.php?post_format=$matches[1]\";s:12:\"robots\\.txt$\";s:18:\"index.php?robots=1\";s:48:\".*wp-(atom|rdf|rss|rss2|feed|commentsrss2)\\.php$\";s:18:\"index.php?feed=old\";s:20:\".*wp-app\\.php(/.*)?$\";s:19:\"index.php?error=403\";s:18:\".*wp-register.php$\";s:23:\"index.php?register=true\";s:32:\"feed/(feed|rdf|rss|rss2|atom)/?$\";s:27:\"index.php?&feed=$matches[1]\";s:27:\"(feed|rdf|rss|rss2|atom)/?$\";s:27:\"index.php?&feed=$matches[1]\";s:8:\"embed/?$\";s:21:\"index.php?&embed=true\";s:20:\"page/?([0-9]{1,})/?$\";s:28:\"index.php?&paged=$matches[1]\";s:27:\"comment-page-([0-9]{1,})/?$\";s:39:\"index.php?&page_id=10&cpage=$matches[1]\";s:41:\"comments/feed/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?&feed=$matches[1]&withcomments=1\";s:36:\"comments/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?&feed=$matches[1]&withcomments=1\";s:17:\"comments/embed/?$\";s:21:\"index.php?&embed=true\";s:44:\"search/(.+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:40:\"index.php?s=$matches[1]&feed=$matches[2]\";s:39:\"search/(.+)/(feed|rdf|rss|rss2|atom)/?$\";s:40:\"index.php?s=$matches[1]&feed=$matches[2]\";s:20:\"search/(.+)/embed/?$\";s:34:\"index.php?s=$matches[1]&embed=true\";s:32:\"search/(.+)/page/?([0-9]{1,})/?$\";s:41:\"index.php?s=$matches[1]&paged=$matches[2]\";s:14:\"search/(.+)/?$\";s:23:\"index.php?s=$matches[1]\";s:47:\"author/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?author_name=$matches[1]&feed=$matches[2]\";s:42:\"author/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?author_name=$matches[1]&feed=$matches[2]\";s:23:\"author/([^/]+)/embed/?$\";s:44:\"index.php?author_name=$matches[1]&embed=true\";s:35:\"author/([^/]+)/page/?([0-9]{1,})/?$\";s:51:\"index.php?author_name=$matches[1]&paged=$matches[2]\";s:17:\"author/([^/]+)/?$\";s:33:\"index.php?author_name=$matches[1]\";s:69:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$\";s:80:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]\";s:64:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$\";s:80:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]\";s:45:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/embed/?$\";s:74:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&embed=true\";s:57:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/page/?([0-9]{1,})/?$\";s:81:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&paged=$matches[4]\";s:39:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/?$\";s:63:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]\";s:56:\"([0-9]{4})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$\";s:64:\"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]\";s:51:\"([0-9]{4})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$\";s:64:\"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]\";s:32:\"([0-9]{4})/([0-9]{1,2})/embed/?$\";s:58:\"index.php?year=$matches[1]&monthnum=$matches[2]&embed=true\";s:44:\"([0-9]{4})/([0-9]{1,2})/page/?([0-9]{1,})/?$\";s:65:\"index.php?year=$matches[1]&monthnum=$matches[2]&paged=$matches[3]\";s:26:\"([0-9]{4})/([0-9]{1,2})/?$\";s:47:\"index.php?year=$matches[1]&monthnum=$matches[2]\";s:43:\"([0-9]{4})/feed/(feed|rdf|rss|rss2|atom)/?$\";s:43:\"index.php?year=$matches[1]&feed=$matches[2]\";s:38:\"([0-9]{4})/(feed|rdf|rss|rss2|atom)/?$\";s:43:\"index.php?year=$matches[1]&feed=$matches[2]\";s:19:\"([0-9]{4})/embed/?$\";s:37:\"index.php?year=$matches[1]&embed=true\";s:31:\"([0-9]{4})/page/?([0-9]{1,})/?$\";s:44:\"index.php?year=$matches[1]&paged=$matches[2]\";s:13:\"([0-9]{4})/?$\";s:26:\"index.php?year=$matches[1]\";s:27:\".?.+?/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:37:\".?.+?/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:57:\".?.+?/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:52:\".?.+?/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:52:\".?.+?/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:33:\".?.+?/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:16:\"(.?.+?)/embed/?$\";s:41:\"index.php?pagename=$matches[1]&embed=true\";s:20:\"(.?.+?)/trackback/?$\";s:35:\"index.php?pagename=$matches[1]&tb=1\";s:40:\"(.?.+?)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:47:\"index.php?pagename=$matches[1]&feed=$matches[2]\";s:35:\"(.?.+?)/(feed|rdf|rss|rss2|atom)/?$\";s:47:\"index.php?pagename=$matches[1]&feed=$matches[2]\";s:28:\"(.?.+?)/page/?([0-9]{1,})/?$\";s:48:\"index.php?pagename=$matches[1]&paged=$matches[2]\";s:35:\"(.?.+?)/comment-page-([0-9]{1,})/?$\";s:48:\"index.php?pagename=$matches[1]&cpage=$matches[2]\";s:24:\"(.?.+?)(?:/([0-9]+))?/?$\";s:47:\"index.php?pagename=$matches[1]&page=$matches[2]\";s:27:\"[^/]+/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:37:\"[^/]+/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:57:\"[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:52:\"[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:52:\"[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:33:\"[^/]+/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:16:\"([^/]+)/embed/?$\";s:37:\"index.php?name=$matches[1]&embed=true\";s:20:\"([^/]+)/trackback/?$\";s:31:\"index.php?name=$matches[1]&tb=1\";s:40:\"([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:43:\"index.php?name=$matches[1]&feed=$matches[2]\";s:35:\"([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:43:\"index.php?name=$matches[1]&feed=$matches[2]\";s:28:\"([^/]+)/page/?([0-9]{1,})/?$\";s:44:\"index.php?name=$matches[1]&paged=$matches[2]\";s:35:\"([^/]+)/comment-page-([0-9]{1,})/?$\";s:44:\"index.php?name=$matches[1]&cpage=$matches[2]\";s:24:\"([^/]+)(?:/([0-9]+))?/?$\";s:43:\"index.php?name=$matches[1]&page=$matches[2]\";s:16:\"[^/]+/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:26:\"[^/]+/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:46:\"[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:41:\"[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:41:\"[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:22:\"[^/]+/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";}', 'yes'),
(30, 'hack_file', '0', 'yes'),
(31, 'blog_charset', 'UTF-8', 'yes'),
(32, 'moderation_keys', '', 'no'),
(33, 'active_plugins', 'a:6:{i:0;s:29:\"gravityforms/gravityforms.php\";i:1;s:57:\"advanced-custom-fields-nav-menu-field/fz-acf-nav-menu.php\";i:2;s:34:\"advanced-custom-fields-pro/acf.php\";i:3;s:19:\"akismet/akismet.php\";i:4;s:19:\"mailgun/mailgun.php\";i:5;s:39:\"wp-migrate-db-pro/wp-migrate-db-pro.php\";}', 'yes'),
(34, 'category_base', '', 'yes'),
(35, 'ping_sites', '', 'yes'),
(36, 'comment_max_links', '2', 'yes'),
(37, 'gmt_offset', '-8', 'yes'),
(38, 'default_email_category', '1', 'yes'),
(39, 'recently_edited', '', 'no'),
(40, 'template', 'cannon-dunphy', 'yes'),
(41, 'stylesheet', 'cannon-dunphy', 'yes'),
(42, 'comment_whitelist', '1', 'yes'),
(43, 'blacklist_keys', '', 'no'),
(44, 'comment_registration', '0', 'yes'),
(45, 'html_type', 'text/html', 'yes'),
(46, 'use_trackback', '0', 'yes'),
(47, 'default_role', 'subscriber', 'yes'),
(48, 'db_version', '38590', 'yes'),
(49, 'uploads_use_yearmonth_folders', '1', 'yes'),
(50, 'upload_path', '', 'yes'),
(51, 'blog_public', '0', 'yes'),
(52, 'default_link_category', '0', 'yes'),
(53, 'show_on_front', 'page', 'yes'),
(54, 'tag_base', '', 'yes'),
(55, 'show_avatars', '1', 'yes'),
(56, 'avatar_rating', 'G', 'yes'),
(57, 'upload_url_path', '', 'yes'),
(58, 'thumbnail_size_w', '150', 'yes'),
(59, 'thumbnail_size_h', '150', 'yes'),
(60, 'thumbnail_crop', '1', 'yes'),
(61, 'medium_size_w', '300', 'yes'),
(62, 'medium_size_h', '300', 'yes'),
(63, 'avatar_default', 'mystery', 'yes'),
(64, 'large_size_w', '1024', 'yes'),
(65, 'large_size_h', '1024', 'yes'),
(66, 'image_default_link_type', 'none', 'yes'),
(67, 'image_default_size', '', 'yes'),
(68, 'image_default_align', '', 'yes'),
(69, 'close_comments_for_old_posts', '0', 'yes'),
(70, 'close_comments_days_old', '14', 'yes'),
(71, 'thread_comments', '1', 'yes'),
(72, 'thread_comments_depth', '5', 'yes'),
(73, 'page_comments', '0', 'yes'),
(74, 'comments_per_page', '50', 'yes'),
(75, 'default_comments_page', 'newest', 'yes'),
(76, 'comment_order', 'asc', 'yes'),
(77, 'sticky_posts', 'a:0:{}', 'yes'),
(78, 'widget_categories', 'a:2:{i:2;a:4:{s:5:\"title\";s:0:\"\";s:5:\"count\";i:0;s:12:\"hierarchical\";i:0;s:8:\"dropdown\";i:0;}s:12:\"_multiwidget\";i:1;}', 'yes'),
(79, 'widget_text', 'a:0:{}', 'yes'),
(80, 'widget_rss', 'a:0:{}', 'yes'),
(81, 'uninstall_plugins', 'a:0:{}', 'no'),
(82, 'timezone_string', '', 'yes'),
(83, 'page_for_posts', '12', 'yes'),
(84, 'page_on_front', '10', 'yes'),
(85, 'default_post_format', '0', 'yes'),
(86, 'link_manager_enabled', '0', 'yes'),
(87, 'finished_splitting_shared_terms', '1', 'yes'),
(88, 'site_icon', '0', 'yes'),
(89, 'medium_large_size_w', '768', 'yes'),
(90, 'medium_large_size_h', '0', 'yes'),
(91, 'initial_db_version', '38590', 'yes'),
(92, 'wp_user_roles', 'a:5:{s:13:\"administrator\";a:2:{s:4:\"name\";s:13:\"Administrator\";s:12:\"capabilities\";a:61:{s:13:\"switch_themes\";b:1;s:11:\"edit_themes\";b:1;s:16:\"activate_plugins\";b:1;s:12:\"edit_plugins\";b:1;s:10:\"edit_users\";b:1;s:10:\"edit_files\";b:1;s:14:\"manage_options\";b:1;s:17:\"moderate_comments\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:12:\"upload_files\";b:1;s:6:\"import\";b:1;s:15:\"unfiltered_html\";b:1;s:10:\"edit_posts\";b:1;s:17:\"edit_others_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:10:\"edit_pages\";b:1;s:4:\"read\";b:1;s:8:\"level_10\";b:1;s:7:\"level_9\";b:1;s:7:\"level_8\";b:1;s:7:\"level_7\";b:1;s:7:\"level_6\";b:1;s:7:\"level_5\";b:1;s:7:\"level_4\";b:1;s:7:\"level_3\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:17:\"edit_others_pages\";b:1;s:20:\"edit_published_pages\";b:1;s:13:\"publish_pages\";b:1;s:12:\"delete_pages\";b:1;s:19:\"delete_others_pages\";b:1;s:22:\"delete_published_pages\";b:1;s:12:\"delete_posts\";b:1;s:19:\"delete_others_posts\";b:1;s:22:\"delete_published_posts\";b:1;s:20:\"delete_private_posts\";b:1;s:18:\"edit_private_posts\";b:1;s:18:\"read_private_posts\";b:1;s:20:\"delete_private_pages\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"read_private_pages\";b:1;s:12:\"delete_users\";b:1;s:12:\"create_users\";b:1;s:17:\"unfiltered_upload\";b:1;s:14:\"edit_dashboard\";b:1;s:14:\"update_plugins\";b:1;s:14:\"delete_plugins\";b:1;s:15:\"install_plugins\";b:1;s:13:\"update_themes\";b:1;s:14:\"install_themes\";b:1;s:11:\"update_core\";b:1;s:10:\"list_users\";b:1;s:12:\"remove_users\";b:1;s:13:\"promote_users\";b:1;s:18:\"edit_theme_options\";b:1;s:13:\"delete_themes\";b:1;s:6:\"export\";b:1;}}s:6:\"editor\";a:2:{s:4:\"name\";s:6:\"Editor\";s:12:\"capabilities\";a:34:{s:17:\"moderate_comments\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:12:\"upload_files\";b:1;s:15:\"unfiltered_html\";b:1;s:10:\"edit_posts\";b:1;s:17:\"edit_others_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:10:\"edit_pages\";b:1;s:4:\"read\";b:1;s:7:\"level_7\";b:1;s:7:\"level_6\";b:1;s:7:\"level_5\";b:1;s:7:\"level_4\";b:1;s:7:\"level_3\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:17:\"edit_others_pages\";b:1;s:20:\"edit_published_pages\";b:1;s:13:\"publish_pages\";b:1;s:12:\"delete_pages\";b:1;s:19:\"delete_others_pages\";b:1;s:22:\"delete_published_pages\";b:1;s:12:\"delete_posts\";b:1;s:19:\"delete_others_posts\";b:1;s:22:\"delete_published_posts\";b:1;s:20:\"delete_private_posts\";b:1;s:18:\"edit_private_posts\";b:1;s:18:\"read_private_posts\";b:1;s:20:\"delete_private_pages\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"read_private_pages\";b:1;}}s:6:\"author\";a:2:{s:4:\"name\";s:6:\"Author\";s:12:\"capabilities\";a:10:{s:12:\"upload_files\";b:1;s:10:\"edit_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:4:\"read\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:12:\"delete_posts\";b:1;s:22:\"delete_published_posts\";b:1;}}s:11:\"contributor\";a:2:{s:4:\"name\";s:11:\"Contributor\";s:12:\"capabilities\";a:5:{s:10:\"edit_posts\";b:1;s:4:\"read\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:12:\"delete_posts\";b:1;}}s:10:\"subscriber\";a:2:{s:4:\"name\";s:10:\"Subscriber\";s:12:\"capabilities\";a:2:{s:4:\"read\";b:1;s:7:\"level_0\";b:1;}}}', 'yes'),
(93, 'fresh_site', '0', 'yes'),
(94, 'widget_search', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(95, 'widget_recent-posts', 'a:2:{i:2;a:2:{s:5:\"title\";s:0:\"\";s:6:\"number\";i:5;}s:12:\"_multiwidget\";i:1;}', 'yes'),
(96, 'widget_recent-comments', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(97, 'widget_archives', 'a:2:{i:2;a:3:{s:5:\"title\";s:0:\"\";s:5:\"count\";i:0;s:8:\"dropdown\";i:0;}s:12:\"_multiwidget\";i:1;}', 'yes'),
(98, 'widget_meta', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(99, 'sidebars_widgets', 'a:5:{s:19:\"wp_inactive_widgets\";a:0:{}s:7:\"sidebar\";a:3:{i:0;s:14:\"recent-posts-2\";i:1;s:12:\"categories-2\";i:2;s:10:\"archives-2\";}s:16:\"category_sidebar\";a:0:{}s:15:\"archive_sidebar\";a:0:{}s:13:\"array_version\";i:3;}', 'yes'),
(100, 'widget_pages', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(101, 'widget_calendar', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(102, 'widget_media_audio', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(103, 'widget_media_image', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(104, 'widget_media_video', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(105, 'widget_tag_cloud', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(106, 'widget_nav_menu', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(107, 'cron', 'a:7:{i:1535750249;a:1:{s:34:\"wp_privacy_delete_old_export_files\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:6:\"hourly\";s:4:\"args\";a:0:{}s:8:\"interval\";i:3600;}}}i:1535759711;a:3:{s:16:\"wp_version_check\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}s:17:\"wp_update_plugins\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}s:16:\"wp_update_themes\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}}i:1535759724;a:1:{s:19:\"wp_scheduled_delete\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1535759736;a:1:{s:25:\"delete_expired_transients\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1535759821;a:1:{s:17:\"gravityforms_cron\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1535760104;a:1:{s:30:\"wp_scheduled_auto_draft_delete\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}s:7:\"version\";i:2;}', 'yes'),
(114, '_site_transient_update_themes', 'O:8:\"stdClass\":4:{s:12:\"last_checked\";i:1535729270;s:7:\"checked\";a:1:{s:13:\"cannon-dunphy\";s:0:\"\";}s:8:\"response\";a:0:{}s:12:\"translations\";a:0:{}}', 'no'),
(115, 'auth_key', 'K=3.iXnFZ [w&.2`S$kAD A@T^>g-U5E8om8tSv65JCiR};p13v!tT{Kb!L0&8eN', 'no'),
(116, 'auth_salt', 't-+MqB8q;PKo6_r6p<_(qQ1zzGNk:X(>U:#rY~JQ,kXdDY!Rj7I>rWbcf$9vR~cs', 'no'),
(117, 'logged_in_key', 'OsQxav}hN|Mn1`^c_|#S44R:Mb#Ya(Ofv%pV%jlt:9^*Jam|@;(,bsQkn)3#^?)R', 'no'),
(118, 'logged_in_salt', '{1W,O]W2qY3@~isBHBq[mW&-Tb>a{IunM~`SaMKB!6;kShfM1zxd8g@X[/L@|z`L', 'no'),
(120, 'nonce_key', '#PDsB]U|n}Vjk:?4TM-,k?V].s[vwflLa25vI-& }Li&]m#>mYczNkb]%ml_HwTU', 'no'),
(121, 'nonce_salt', 'tK^$AahAb0V}x<U?G{4yKZLIq:D3c&T8lHN@5J|IR/T;77M5lC<91}a|TjcpXuuF', 'no'),
(124, 'can_compress_scripts', '0', 'no'),
(139, 'widget_media_gallery', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(140, 'widget_custom_html', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(146, 'recently_activated', 'a:0:{}', 'yes'),
(148, 'mailgun', 'a:12:{s:6:\"useAPI\";s:1:\"1\";s:6:\"domain\";s:20:\"ilawyermarketing.org\";s:6:\"apiKey\";s:36:\"key-3b836150d2968b324f4b8471feeeb3c1\";s:8:\"username\";s:0:\"\";s:8:\"password\";s:0:\"\";s:6:\"secure\";s:1:\"1\";s:12:\"track-clicks\";s:8:\"htmlonly\";s:11:\"track-opens\";s:1:\"1\";s:12:\"from-address\";s:28:\"noreply@ilawyermarketing.org\";s:9:\"from-name\";s:28:\"\"Client/Site Name\" + Website\";s:13:\"override-from\";N;s:11:\"campaign-id\";s:0:\"\";}', 'yes'),
(149, 'widget_akismet_widget', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(150, 'widget_gform_widget', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(151, 'widget_list_widget', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(152, 'rg_form_version', '2.3.2', 'yes'),
(155, 'acf_version', '5.6.10', 'yes'),
(156, 'rg_gforms_key', '621e21584ab7936611e0d28422299c97', 'yes'),
(157, 'rg_gforms_disable_css', '1', 'yes'),
(158, 'rg_gforms_enable_html5', '', 'yes'),
(159, 'gform_enable_noconflict', '', 'yes'),
(160, 'rg_gforms_enable_akismet', '1', 'yes'),
(161, 'rg_gforms_captcha_public_key', '', 'yes'),
(162, 'rg_gforms_captcha_private_key', '', 'yes'),
(163, 'rg_gforms_currency', 'USD', 'yes'),
(164, 'rg_gforms_message', '<!--GFM-->', 'yes'),
(166, 'gravityformsaddon_gravityformswebapi_version', '1.0', 'yes'),
(167, 'gf_is_upgrading', '0', 'yes'),
(168, 'gf_previous_db_version', '2.2.5', 'yes'),
(175, 'acf_pro_license', 'YToyOntzOjM6ImtleSI7czo3MjoiYjNKa1pYSmZhV1E5TXpZd01EaDhkSGx3WlQxa1pYWmxiRzl3WlhKOFpHRjBaVDB5TURFMExUQTNMVEk0SURJd09qVXlPak0zIjtzOjM6InVybCI7czoyMToiaHR0cDovL2xvY2FsaG9zdDo4ODg4Ijt9', 'yes'),
(182, 'akismet_strictness', '0', 'yes'),
(183, 'akismet_show_user_comments_approved', '0', 'yes'),
(184, 'wordpress_api_key', '46c90999075a', 'yes'),
(185, 'akismet_spam_count', '2', 'yes'),
(201, 'theme_mods_twentyseventeen', 'a:1:{s:16:\"sidebars_widgets\";a:2:{s:4:\"time\";i:1514333141;s:4:\"data\";a:4:{s:19:\"wp_inactive_widgets\";a:0:{}s:9:\"sidebar-1\";a:6:{i:0;s:8:\"search-2\";i:1;s:14:\"recent-posts-2\";i:2;s:17:\"recent-comments-2\";i:3;s:10:\"archives-2\";i:4;s:12:\"categories-2\";i:5;s:6:\"meta-2\";}s:9:\"sidebar-2\";a:0:{}s:9:\"sidebar-3\";a:0:{}}}}', 'yes'),
(202, 'current_theme', '', 'yes'),
(203, 'theme_mods_joe-blank-theme', 'a:4:{i:0;b:0;s:18:\"nav_menu_locations\";a:0:{}s:18:\"custom_css_post_id\";i:-1;s:16:\"sidebars_widgets\";a:2:{s:4:\"time\";i:1534890347;s:4:\"data\";a:2:{s:19:\"wp_inactive_widgets\";a:0:{}s:12:\"blog_sidebar\";a:3:{i:0;s:14:\"recent-posts-2\";i:1;s:12:\"categories-2\";i:2;s:10:\"archives-2\";}}}}', 'yes'),
(204, 'theme_switched', '', 'yes'),
(283, 'category_children', 'a:0:{}', 'yes'),
(372, 'WPLANG', '', 'yes'),
(373, 'new_admin_email', 'joe.t.oconnor@gmail.com', 'yes'),
(402, 'gf_upgrade_lock', '', 'yes'),
(403, 'gform_sticky_admin_messages', 'a:0:{}', 'yes'),
(407, 'gf_submissions_block', '', 'yes'),
(408, 'gf_db_version', '2.3.2', 'yes'),
(409, 'gform_version_info', 'a:10:{s:12:\"is_valid_key\";b:1;s:6:\"reason\";s:0:\"\";s:7:\"version\";s:5:\"2.3.3\";s:3:\"url\";s:166:\"http://s3.amazonaws.com/gravityforms/releases/gravityforms_2.3.3.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1535902069&Signature=6807HGTLYaRZL%2FCnVbsbdReSjB4%3D\";s:15:\"expiration_time\";i:1538456400;s:9:\"offerings\";a:46:{s:12:\"gravityforms\";a:5:{s:12:\"is_available\";b:1;s:7:\"version\";s:5:\"2.3.3\";s:14:\"version_latest\";s:7:\"2.3.3.9\";s:3:\"url\";s:166:\"http://s3.amazonaws.com/gravityforms/releases/gravityforms_2.3.3.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1535902069&Signature=6807HGTLYaRZL%2FCnVbsbdReSjB4%3D\";s:10:\"url_latest\";s:166:\"http://s3.amazonaws.com/gravityforms/releases/gravityforms_2.3.3.9.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1535902069&Signature=8p8t8MCaOncHCS09DeDIwBtIvDo%3D\";}s:26:\"gravityformsactivecampaign\";a:5:{s:12:\"is_available\";b:1;s:7:\"version\";s:3:\"1.4\";s:14:\"version_latest\";s:5:\"1.4.5\";s:3:\"url\";s:189:\"http://s3.amazonaws.com/gravityforms/addons/activecampaign/gravityformsactivecampaign_1.4.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1535902069&Signature=mgjp6sVEcBoYgA334rmbBBkLdiI%3D\";s:10:\"url_latest\";s:191:\"http://s3.amazonaws.com/gravityforms/addons/activecampaign/gravityformsactivecampaign_1.4.5.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1535902069&Signature=aX0NoMCjXYxZWF3JLXcQkzgMiGk%3D\";}s:20:\"gravityformsagilecrm\";a:5:{s:12:\"is_available\";b:1;s:7:\"version\";s:3:\"1.2\";s:14:\"version_latest\";s:3:\"1.2\";s:3:\"url\";s:177:\"http://s3.amazonaws.com/gravityforms/addons/agilecrm/gravityformsagilecrm_1.2.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1535902069&Signature=2HPcYWTTBM61bFAFShbYGDp9DyM%3D\";s:10:\"url_latest\";s:177:\"http://s3.amazonaws.com/gravityforms/addons/agilecrm/gravityformsagilecrm_1.2.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1535902069&Signature=2HPcYWTTBM61bFAFShbYGDp9DyM%3D\";}s:24:\"gravityformsauthorizenet\";a:5:{s:12:\"is_available\";b:1;s:7:\"version\";s:3:\"2.6\";s:14:\"version_latest\";s:3:\"2.6\";s:3:\"url\";s:185:\"http://s3.amazonaws.com/gravityforms/addons/authorizenet/gravityformsauthorizenet_2.6.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1535902069&Signature=r2FCe8DntdQeCKVr31QdLLDSRMQ%3D\";s:10:\"url_latest\";s:185:\"http://s3.amazonaws.com/gravityforms/addons/authorizenet/gravityformsauthorizenet_2.6.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1535902069&Signature=r2FCe8DntdQeCKVr31QdLLDSRMQ%3D\";}s:18:\"gravityformsaweber\";a:5:{s:12:\"is_available\";b:1;s:7:\"version\";s:3:\"2.7\";s:14:\"version_latest\";s:5:\"2.7.1\";s:3:\"url\";s:173:\"http://s3.amazonaws.com/gravityforms/addons/aweber/gravityformsaweber_2.7.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1535902069&Signature=tjJhvuar6Rfjz0pubSr8HD3D8qk%3D\";s:10:\"url_latest\";s:177:\"http://s3.amazonaws.com/gravityforms/addons/aweber/gravityformsaweber_2.7.1.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1535902069&Signature=8r5B8NlyYIn5Bx82q%2FoVrLfvL64%3D\";}s:21:\"gravityformsbatchbook\";a:5:{s:12:\"is_available\";b:1;s:7:\"version\";s:3:\"1.3\";s:14:\"version_latest\";s:3:\"1.3\";s:3:\"url\";s:179:\"http://s3.amazonaws.com/gravityforms/addons/batchbook/gravityformsbatchbook_1.3.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1535902069&Signature=SVgCtfrmoNtxax6G5sI3r8DwYoc%3D\";s:10:\"url_latest\";s:179:\"http://s3.amazonaws.com/gravityforms/addons/batchbook/gravityformsbatchbook_1.3.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1535902069&Signature=SVgCtfrmoNtxax6G5sI3r8DwYoc%3D\";}s:18:\"gravityformsbreeze\";a:5:{s:12:\"is_available\";b:1;s:7:\"version\";s:3:\"1.3\";s:14:\"version_latest\";s:3:\"1.3\";s:3:\"url\";s:173:\"http://s3.amazonaws.com/gravityforms/addons/breeze/gravityformsbreeze_1.3.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1535902069&Signature=buHnWuXUFqwN6KlERwAyZNSyQuk%3D\";s:10:\"url_latest\";s:173:\"http://s3.amazonaws.com/gravityforms/addons/breeze/gravityformsbreeze_1.3.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1535902069&Signature=buHnWuXUFqwN6KlERwAyZNSyQuk%3D\";}s:27:\"gravityformscampaignmonitor\";a:5:{s:12:\"is_available\";b:1;s:7:\"version\";s:3:\"3.7\";s:14:\"version_latest\";s:3:\"3.7\";s:3:\"url\";s:195:\"http://s3.amazonaws.com/gravityforms/addons/campaignmonitor/gravityformscampaignmonitor_3.7.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1535902069&Signature=Bs%2Fjf2f6NnEqKIoWgz7R%2F9Vez8M%3D\";s:10:\"url_latest\";s:195:\"http://s3.amazonaws.com/gravityforms/addons/campaignmonitor/gravityformscampaignmonitor_3.7.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1535902069&Signature=Bs%2Fjf2f6NnEqKIoWgz7R%2F9Vez8M%3D\";}s:20:\"gravityformscampfire\";a:5:{s:12:\"is_available\";b:1;s:7:\"version\";s:3:\"1.1\";s:14:\"version_latest\";s:5:\"1.2.1\";s:3:\"url\";s:177:\"http://s3.amazonaws.com/gravityforms/addons/campfire/gravityformscampfire_1.1.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1535902069&Signature=Hn1OoM7m9srAfkWU2M4aZa7WJYo%3D\";s:10:\"url_latest\";s:181:\"http://s3.amazonaws.com/gravityforms/addons/campfire/gravityformscampfire_1.2.1.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1535902069&Signature=pnHTr9NcZ3zet4TJYMj1HAxAr%2Bk%3D\";}s:22:\"gravityformscapsulecrm\";a:5:{s:12:\"is_available\";b:1;s:7:\"version\";s:3:\"1.3\";s:14:\"version_latest\";s:3:\"1.3\";s:3:\"url\";s:185:\"http://s3.amazonaws.com/gravityforms/addons/capsulecrm/gravityformscapsulecrm_1.3.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1535902069&Signature=Awjhswdnt9xuqarn%2BztJWdjU%2FSw%3D\";s:10:\"url_latest\";s:185:\"http://s3.amazonaws.com/gravityforms/addons/capsulecrm/gravityformscapsulecrm_1.3.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1535902069&Signature=Awjhswdnt9xuqarn%2BztJWdjU%2FSw%3D\";}s:26:\"gravityformschainedselects\";a:5:{s:12:\"is_available\";b:1;s:7:\"version\";s:3:\"1.1\";s:14:\"version_latest\";s:3:\"1.1\";s:3:\"url\";s:189:\"http://s3.amazonaws.com/gravityforms/addons/chainedselects/gravityformschainedselects_1.1.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1535902069&Signature=LjW3M3pY3Ha8b6EDWJm56jkIDL0%3D\";s:10:\"url_latest\";s:189:\"http://s3.amazonaws.com/gravityforms/addons/chainedselects/gravityformschainedselects_1.1.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1535902069&Signature=LjW3M3pY3Ha8b6EDWJm56jkIDL0%3D\";}s:23:\"gravityformscleverreach\";a:5:{s:12:\"is_available\";b:1;s:7:\"version\";s:3:\"1.4\";s:14:\"version_latest\";s:3:\"1.4\";s:3:\"url\";s:185:\"http://s3.amazonaws.com/gravityforms/addons/cleverreach/gravityformscleverreach_1.4.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1535902069&Signature=wNFm%2BsonrlTIULwHUWzO79aWtGE%3D\";s:10:\"url_latest\";s:185:\"http://s3.amazonaws.com/gravityforms/addons/cleverreach/gravityformscleverreach_1.4.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1535902069&Signature=wNFm%2BsonrlTIULwHUWzO79aWtGE%3D\";}s:19:\"gravityformscoupons\";a:5:{s:12:\"is_available\";b:1;s:7:\"version\";s:3:\"2.6\";s:14:\"version_latest\";s:5:\"2.6.2\";s:3:\"url\";s:175:\"http://s3.amazonaws.com/gravityforms/addons/coupons/gravityformscoupons_2.6.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1535902069&Signature=4fVQuQ7JX7xOFnGS5kFVhYu6ZMQ%3D\";s:10:\"url_latest\";s:177:\"http://s3.amazonaws.com/gravityforms/addons/coupons/gravityformscoupons_2.6.2.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1535902069&Signature=uvBSlvAqs1wo3WSpNwiKFdf4tk4%3D\";}s:17:\"gravityformsdebug\";a:5:{s:12:\"is_available\";b:1;s:7:\"version\";s:0:\"\";s:14:\"version_latest\";s:10:\"1.0.beta10\";s:3:\"url\";s:0:\"\";s:10:\"url_latest\";s:182:\"http://s3.amazonaws.com/gravityforms/addons/debug/gravityformsdebug_1.0.beta10.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1535902069&Signature=%2FVaJJiAQbWnscEynwTDvFu%2BfyqU%3D\";}s:19:\"gravityformsdropbox\";a:5:{s:12:\"is_available\";b:1;s:7:\"version\";s:3:\"2.1\";s:14:\"version_latest\";s:5:\"2.1.1\";s:3:\"url\";s:175:\"http://s3.amazonaws.com/gravityforms/addons/dropbox/gravityformsdropbox_2.1.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1535902069&Signature=pcr2e0NNJfJdvQWJyiZvfQVLc9c%3D\";s:10:\"url_latest\";s:177:\"http://s3.amazonaws.com/gravityforms/addons/dropbox/gravityformsdropbox_2.1.1.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1535902069&Signature=hxjwTx6J3Y22HqXddaxFhPSfnYM%3D\";}s:16:\"gravityformsemma\";a:5:{s:12:\"is_available\";b:1;s:7:\"version\";s:3:\"1.2\";s:14:\"version_latest\";s:5:\"1.2.5\";s:3:\"url\";s:169:\"http://s3.amazonaws.com/gravityforms/addons/emma/gravityformsemma_1.2.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1535902069&Signature=rtBreHcfb8UHaLNz00CxqDSrazE%3D\";s:10:\"url_latest\";s:171:\"http://s3.amazonaws.com/gravityforms/addons/emma/gravityformsemma_1.2.5.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1535902069&Signature=ZRUqLo1pSfm4yIodoOtYQeNiizg%3D\";}s:22:\"gravityformsfreshbooks\";a:5:{s:12:\"is_available\";b:1;s:7:\"version\";s:3:\"2.5\";s:14:\"version_latest\";s:5:\"2.5.2\";s:3:\"url\";s:181:\"http://s3.amazonaws.com/gravityforms/addons/freshbooks/gravityformsfreshbooks_2.5.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1535902069&Signature=VKFLX5j7V3oT98GuJZkiZ7IK48Q%3D\";s:10:\"url_latest\";s:185:\"http://s3.amazonaws.com/gravityforms/addons/freshbooks/gravityformsfreshbooks_2.5.2.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1535902069&Signature=n1eX6EWSbwWwsVld0Gz%2F99lqobw%3D\";}s:23:\"gravityformsgetresponse\";a:5:{s:12:\"is_available\";b:1;s:7:\"version\";s:3:\"1.2\";s:14:\"version_latest\";s:3:\"1.2\";s:3:\"url\";s:183:\"http://s3.amazonaws.com/gravityforms/addons/getresponse/gravityformsgetresponse_1.2.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1535902069&Signature=ZULD3vmNZboXTwYRYafUq0qJTWM%3D\";s:10:\"url_latest\";s:183:\"http://s3.amazonaws.com/gravityforms/addons/getresponse/gravityformsgetresponse_1.2.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1535902069&Signature=ZULD3vmNZboXTwYRYafUq0qJTWM%3D\";}s:21:\"gravityformsgutenberg\";a:5:{s:12:\"is_available\";b:1;s:7:\"version\";s:10:\"1.0-beta-5\";s:14:\"version_latest\";s:10:\"1.0-beta-5\";s:3:\"url\";s:190:\"http://s3.amazonaws.com/gravityforms/addons/gutenberg/gravityformsgutenberg_1.0-beta-5.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1535902069&Signature=S3D%2B0t%2Bk3Gn5thaBFqGqktw6on4%3D\";s:10:\"url_latest\";s:190:\"http://s3.amazonaws.com/gravityforms/addons/gutenberg/gravityformsgutenberg_1.0-beta-5.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1535902069&Signature=S3D%2B0t%2Bk3Gn5thaBFqGqktw6on4%3D\";}s:21:\"gravityformshelpscout\";a:5:{s:12:\"is_available\";b:1;s:7:\"version\";s:3:\"1.5\";s:14:\"version_latest\";s:3:\"1.5\";s:3:\"url\";s:183:\"http://s3.amazonaws.com/gravityforms/addons/helpscout/gravityformshelpscout_1.5.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1535902069&Signature=dgWiJ5uv%2FdlVm8S9xI1tg34%2Bhew%3D\";s:10:\"url_latest\";s:183:\"http://s3.amazonaws.com/gravityforms/addons/helpscout/gravityformshelpscout_1.5.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1535902069&Signature=dgWiJ5uv%2FdlVm8S9xI1tg34%2Bhew%3D\";}s:20:\"gravityformshighrise\";a:5:{s:12:\"is_available\";b:1;s:7:\"version\";s:3:\"1.2\";s:14:\"version_latest\";s:5:\"1.2.3\";s:3:\"url\";s:177:\"http://s3.amazonaws.com/gravityforms/addons/highrise/gravityformshighrise_1.2.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1535902069&Signature=7bZUQWPUnx2CRPoZ2DR7LR25DlQ%3D\";s:10:\"url_latest\";s:179:\"http://s3.amazonaws.com/gravityforms/addons/highrise/gravityformshighrise_1.2.3.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1535902069&Signature=tBP5AeQPqTly6vs8VK3AfnAqL1k%3D\";}s:19:\"gravityformshipchat\";a:5:{s:12:\"is_available\";b:1;s:7:\"version\";s:3:\"1.2\";s:14:\"version_latest\";s:3:\"1.2\";s:3:\"url\";s:177:\"http://s3.amazonaws.com/gravityforms/addons/hipchat/gravityformshipchat_1.2.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1535902069&Signature=ItwK%2BfYi4n08OJbEIwmZNYiwY1Q%3D\";s:10:\"url_latest\";s:177:\"http://s3.amazonaws.com/gravityforms/addons/hipchat/gravityformshipchat_1.2.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1535902069&Signature=ItwK%2BfYi4n08OJbEIwmZNYiwY1Q%3D\";}s:20:\"gravityformsicontact\";a:5:{s:12:\"is_available\";b:1;s:7:\"version\";s:3:\"1.3\";s:14:\"version_latest\";s:3:\"1.3\";s:3:\"url\";s:179:\"http://s3.amazonaws.com/gravityforms/addons/icontact/gravityformsicontact_1.3.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1535902069&Signature=i43PXzXJzNWt%2B0PnSt5ahLomhhA%3D\";s:10:\"url_latest\";s:179:\"http://s3.amazonaws.com/gravityforms/addons/icontact/gravityformsicontact_1.3.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1535902069&Signature=i43PXzXJzNWt%2B0PnSt5ahLomhhA%3D\";}s:19:\"gravityformslogging\";a:5:{s:12:\"is_available\";b:1;s:7:\"version\";s:3:\"1.3\";s:14:\"version_latest\";s:5:\"1.3.1\";s:3:\"url\";s:175:\"http://s3.amazonaws.com/gravityforms/addons/logging/gravityformslogging_1.3.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1535902069&Signature=ybTYlb9aA4sfwUGM0tGYFGqhH6U%3D\";s:10:\"url_latest\";s:179:\"http://s3.amazonaws.com/gravityforms/addons/logging/gravityformslogging_1.3.1.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1535902069&Signature=dUdbt7Afe7pSQznG4LGB3wH%2BLbg%3D\";}s:19:\"gravityformsmadmimi\";a:5:{s:12:\"is_available\";b:1;s:7:\"version\";s:3:\"1.2\";s:14:\"version_latest\";s:3:\"1.2\";s:3:\"url\";s:175:\"http://s3.amazonaws.com/gravityforms/addons/madmimi/gravityformsmadmimi_1.2.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1535902069&Signature=sMvWcF55wsSedodjW3DHNxG7Hvk%3D\";s:10:\"url_latest\";s:175:\"http://s3.amazonaws.com/gravityforms/addons/madmimi/gravityformsmadmimi_1.2.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1535902069&Signature=sMvWcF55wsSedodjW3DHNxG7Hvk%3D\";}s:21:\"gravityformsmailchimp\";a:5:{s:12:\"is_available\";b:1;s:7:\"version\";s:3:\"4.3\";s:14:\"version_latest\";s:3:\"4.3\";s:3:\"url\";s:181:\"http://s3.amazonaws.com/gravityforms/addons/mailchimp/gravityformsmailchimp_4.3.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1535902069&Signature=QgQAlTgZ3XHWViXabzSE%2BX6L2OE%3D\";s:10:\"url_latest\";s:181:\"http://s3.amazonaws.com/gravityforms/addons/mailchimp/gravityformsmailchimp_4.3.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1535902069&Signature=QgQAlTgZ3XHWViXabzSE%2BX6L2OE%3D\";}s:26:\"gravityformspartialentries\";a:5:{s:12:\"is_available\";b:1;s:7:\"version\";s:3:\"1.2\";s:14:\"version_latest\";s:5:\"1.2.1\";s:3:\"url\";s:189:\"http://s3.amazonaws.com/gravityforms/addons/partialentries/gravityformspartialentries_1.2.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1535902069&Signature=11BYbzdUEvRB1jCGTZMZPubAa0s%3D\";s:10:\"url_latest\";s:193:\"http://s3.amazonaws.com/gravityforms/addons/partialentries/gravityformspartialentries_1.2.1.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1535902069&Signature=BMJ26Ztbb0xvZ67nsV%2F2jBVoCfk%3D\";}s:18:\"gravityformspaypal\";a:5:{s:12:\"is_available\";b:1;s:7:\"version\";s:3:\"3.1\";s:14:\"version_latest\";s:5:\"3.1.1\";s:3:\"url\";s:173:\"http://s3.amazonaws.com/gravityforms/addons/paypal/gravityformspaypal_3.1.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1535902069&Signature=s7Hs34q0iUoQ9aU4AsLrJTJ3qUE%3D\";s:10:\"url_latest\";s:179:\"http://s3.amazonaws.com/gravityforms/addons/paypal/gravityformspaypal_3.1.1.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1535902069&Signature=9%2B0gnieZeQvN1HkKakTVmQy%2BiVs%3D\";}s:33:\"gravityformspaypalexpresscheckout\";a:3:{s:12:\"is_available\";b:0;s:7:\"version\";s:0:\"\";s:14:\"version_latest\";N;}s:29:\"gravityformspaypalpaymentspro\";a:5:{s:12:\"is_available\";b:1;s:7:\"version\";s:3:\"2.3\";s:14:\"version_latest\";s:5:\"2.3.2\";s:3:\"url\";s:195:\"http://s3.amazonaws.com/gravityforms/addons/paypalpaymentspro/gravityformspaypalpaymentspro_2.3.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1535902069&Signature=meOgVaasUtgeLKxayTTsELqMnL4%3D\";s:10:\"url_latest\";s:199:\"http://s3.amazonaws.com/gravityforms/addons/paypalpaymentspro/gravityformspaypalpaymentspro_2.3.2.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1535902069&Signature=rM%2F3Tc6i2w5vYeA6B8oEMxPBOVs%3D\";}s:21:\"gravityformspaypalpro\";a:5:{s:12:\"is_available\";b:1;s:7:\"version\";s:5:\"1.8.1\";s:14:\"version_latest\";s:5:\"1.8.1\";s:3:\"url\";s:181:\"http://s3.amazonaws.com/gravityforms/addons/paypalpro/gravityformspaypalpro_1.8.1.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1535902069&Signature=wVmAP28bxphv5J1fyaPzI6ZMK3k%3D\";s:10:\"url_latest\";s:181:\"http://s3.amazonaws.com/gravityforms/addons/paypalpro/gravityformspaypalpro_1.8.1.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1535902069&Signature=wVmAP28bxphv5J1fyaPzI6ZMK3k%3D\";}s:20:\"gravityformspicatcha\";a:3:{s:12:\"is_available\";b:0;s:7:\"version\";s:3:\"2.0\";s:14:\"version_latest\";s:3:\"2.0\";}s:16:\"gravityformspipe\";a:5:{s:12:\"is_available\";b:1;s:7:\"version\";s:3:\"1.1\";s:14:\"version_latest\";s:3:\"1.1\";s:3:\"url\";s:171:\"http://s3.amazonaws.com/gravityforms/addons/pipe/gravityformspipe_1.1.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1535902069&Signature=xnCKa%2FbExFTr3Xl1IQO5Y7749OI%3D\";s:10:\"url_latest\";s:171:\"http://s3.amazonaws.com/gravityforms/addons/pipe/gravityformspipe_1.1.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1535902069&Signature=xnCKa%2FbExFTr3Xl1IQO5Y7749OI%3D\";}s:17:\"gravityformspolls\";a:5:{s:12:\"is_available\";b:1;s:7:\"version\";s:3:\"3.1\";s:14:\"version_latest\";s:5:\"3.1.4\";s:3:\"url\";s:171:\"http://s3.amazonaws.com/gravityforms/addons/polls/gravityformspolls_3.1.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1535902069&Signature=QmqUpy07BYGhgECNRXLBwRsbEhQ%3D\";s:10:\"url_latest\";s:173:\"http://s3.amazonaws.com/gravityforms/addons/polls/gravityformspolls_3.1.4.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1535902069&Signature=ZDOu40UoWhVKbAmaJrNHYFeekBE%3D\";}s:16:\"gravityformsquiz\";a:5:{s:12:\"is_available\";b:1;s:7:\"version\";s:3:\"3.1\";s:14:\"version_latest\";s:5:\"3.1.8\";s:3:\"url\";s:169:\"http://s3.amazonaws.com/gravityforms/addons/quiz/gravityformsquiz_3.1.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1535902069&Signature=UEQDkqMbrpR1hqEhdOByewRgbBQ%3D\";s:10:\"url_latest\";s:173:\"http://s3.amazonaws.com/gravityforms/addons/quiz/gravityformsquiz_3.1.8.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1535902069&Signature=TJIcA6uhLCCPBC%2F9syEk1N460SM%3D\";}s:19:\"gravityformsrestapi\";a:5:{s:12:\"is_available\";b:1;s:7:\"version\";s:10:\"2.0-beta-2\";s:14:\"version_latest\";s:10:\"2.0-beta-2\";s:3:\"url\";s:184:\"http://s3.amazonaws.com/gravityforms/addons/restapi/gravityformsrestapi_2.0-beta-2.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1535902069&Signature=XLI%2FhLJYLXE8L4jl6LdQ0kMpqXE%3D\";s:10:\"url_latest\";s:184:\"http://s3.amazonaws.com/gravityforms/addons/restapi/gravityformsrestapi_2.0-beta-2.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1535902069&Signature=XLI%2FhLJYLXE8L4jl6LdQ0kMpqXE%3D\";}s:21:\"gravityformssignature\";a:5:{s:12:\"is_available\";b:1;s:7:\"version\";s:5:\"3.5.1\";s:14:\"version_latest\";s:5:\"3.5.2\";s:3:\"url\";s:181:\"http://s3.amazonaws.com/gravityforms/addons/signature/gravityformssignature_3.5.1.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1535902069&Signature=GkchRQdJ5BImBJyUJ1zEMEsMSy0%3D\";s:10:\"url_latest\";s:181:\"http://s3.amazonaws.com/gravityforms/addons/signature/gravityformssignature_3.5.2.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1535902069&Signature=VvdgpAcgpngR5gQhoZBkf5AiOUc%3D\";}s:17:\"gravityformsslack\";a:5:{s:12:\"is_available\";b:1;s:7:\"version\";s:3:\"1.8\";s:14:\"version_latest\";s:3:\"1.8\";s:3:\"url\";s:171:\"http://s3.amazonaws.com/gravityforms/addons/slack/gravityformsslack_1.8.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1535902069&Signature=T4HLWVBUYHoX7uPKlYZDVtqT8r0%3D\";s:10:\"url_latest\";s:171:\"http://s3.amazonaws.com/gravityforms/addons/slack/gravityformsslack_1.8.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1535902069&Signature=T4HLWVBUYHoX7uPKlYZDVtqT8r0%3D\";}s:18:\"gravityformsstripe\";a:5:{s:12:\"is_available\";b:1;s:7:\"version\";s:3:\"2.5\";s:14:\"version_latest\";s:5:\"2.5.4\";s:3:\"url\";s:175:\"http://s3.amazonaws.com/gravityforms/addons/stripe/gravityformsstripe_2.5.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1535902069&Signature=eS%2Bix0t1FgDVs92cKp5QMGkgQXE%3D\";s:10:\"url_latest\";s:175:\"http://s3.amazonaws.com/gravityforms/addons/stripe/gravityformsstripe_2.5.4.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1535902069&Signature=uG7lpwKHHEiVip3nwQqCtTEJVJw%3D\";}s:18:\"gravityformssurvey\";a:5:{s:12:\"is_available\";b:1;s:7:\"version\";s:3:\"3.2\";s:14:\"version_latest\";s:5:\"3.2.2\";s:3:\"url\";s:173:\"http://s3.amazonaws.com/gravityforms/addons/survey/gravityformssurvey_3.2.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1535902069&Signature=muRXcc2oTqeRgZ0rdkFoSfmNOj0%3D\";s:10:\"url_latest\";s:179:\"http://s3.amazonaws.com/gravityforms/addons/survey/gravityformssurvey_3.2.2.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1535902069&Signature=5j72r%2F%2F3DH4rcafQmJtfQy6v6TM%3D\";}s:18:\"gravityformstrello\";a:5:{s:12:\"is_available\";b:1;s:7:\"version\";s:3:\"1.2\";s:14:\"version_latest\";s:5:\"1.2.2\";s:3:\"url\";s:173:\"http://s3.amazonaws.com/gravityforms/addons/trello/gravityformstrello_1.2.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1535902069&Signature=KhkLbvoErJjeOCES5Vwenk81qbE%3D\";s:10:\"url_latest\";s:175:\"http://s3.amazonaws.com/gravityforms/addons/trello/gravityformstrello_1.2.2.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1535902069&Signature=TJqZpNZ5QfEyP0A8UqklajyeD6Q%3D\";}s:18:\"gravityformstwilio\";a:5:{s:12:\"is_available\";b:1;s:7:\"version\";s:3:\"2.5\";s:14:\"version_latest\";s:5:\"2.5.1\";s:3:\"url\";s:175:\"http://s3.amazonaws.com/gravityforms/addons/twilio/gravityformstwilio_2.5.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1535902069&Signature=EQvaKnB4IGPsUVNsYJ%2BuSkq312M%3D\";s:10:\"url_latest\";s:177:\"http://s3.amazonaws.com/gravityforms/addons/twilio/gravityformstwilio_2.5.1.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1535902069&Signature=8WVjTQGuL3y%2BEPX41H7wYfV4v24%3D\";}s:28:\"gravityformsuserregistration\";a:5:{s:12:\"is_available\";b:1;s:7:\"version\";s:3:\"3.9\";s:14:\"version_latest\";s:5:\"3.9.5\";s:3:\"url\";s:193:\"http://s3.amazonaws.com/gravityforms/addons/userregistration/gravityformsuserregistration_3.9.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1535902069&Signature=7vhbBQV4eqk1Pz9xfIsOwkrnxGU%3D\";s:10:\"url_latest\";s:197:\"http://s3.amazonaws.com/gravityforms/addons/userregistration/gravityformsuserregistration_3.9.5.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1535902069&Signature=hHNo%2BoWyUgFPt8RZSy6Iaba7fcA%3D\";}s:20:\"gravityformswebhooks\";a:5:{s:12:\"is_available\";b:1;s:7:\"version\";s:3:\"1.1\";s:14:\"version_latest\";s:5:\"1.1.5\";s:3:\"url\";s:177:\"http://s3.amazonaws.com/gravityforms/addons/webhooks/gravityformswebhooks_1.1.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1535902069&Signature=NSFvmx7zJFzDxizCmDjiaj5T66Q%3D\";s:10:\"url_latest\";s:183:\"http://s3.amazonaws.com/gravityforms/addons/webhooks/gravityformswebhooks_1.1.5.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1535902069&Signature=cY3yJ%2BTzs53ZQdXaofLl90%2FFwy8%3D\";}s:18:\"gravityformszapier\";a:5:{s:12:\"is_available\";b:1;s:7:\"version\";s:3:\"3.0\";s:14:\"version_latest\";s:5:\"3.0.1\";s:3:\"url\";s:173:\"http://s3.amazonaws.com/gravityforms/addons/zapier/gravityformszapier_3.0.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1535902069&Signature=K74SxgOYvQsrfBijJuLGm3jwlPY%3D\";s:10:\"url_latest\";s:177:\"http://s3.amazonaws.com/gravityforms/addons/zapier/gravityformszapier_3.0.1.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1535902069&Signature=LLdUb6hNEfZEYfklGq56j%2Fecfq4%3D\";}s:19:\"gravityformszohocrm\";a:5:{s:12:\"is_available\";b:1;s:7:\"version\";s:3:\"1.5\";s:14:\"version_latest\";s:3:\"1.5\";s:3:\"url\";s:177:\"http://s3.amazonaws.com/gravityforms/addons/zohocrm/gravityformszohocrm_1.5.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1535902069&Signature=4c4prIFalzTPPL6dhQhejdEDO%2BY%3D\";s:10:\"url_latest\";s:177:\"http://s3.amazonaws.com/gravityforms/addons/zohocrm/gravityformszohocrm_1.5.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1535902069&Signature=4c4prIFalzTPPL6dhQhejdEDO%2BY%3D\";}}s:9:\"is_active\";s:1:\"1\";s:14:\"version_latest\";s:7:\"2.3.3.9\";s:10:\"url_latest\";s:166:\"http://s3.amazonaws.com/gravityforms/releases/gravityforms_2.3.3.9.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1535902069&Signature=8p8t8MCaOncHCS09DeDIwBtIvDo%3D\";s:9:\"timestamp\";i:1535729268;}', 'yes'),
(412, 'akismet_comment_form_privacy_notice', 'hide', 'yes'),
(419, '_site_transient_update_core', 'O:8:\"stdClass\":4:{s:7:\"updates\";a:2:{i:0;O:8:\"stdClass\":10:{s:8:\"response\";s:7:\"upgrade\";s:8:\"download\";s:59:\"https://downloads.wordpress.org/release/wordpress-4.9.8.zip\";s:6:\"locale\";s:5:\"en_US\";s:8:\"packages\";O:8:\"stdClass\":5:{s:4:\"full\";s:59:\"https://downloads.wordpress.org/release/wordpress-4.9.8.zip\";s:10:\"no_content\";s:70:\"https://downloads.wordpress.org/release/wordpress-4.9.8-no-content.zip\";s:11:\"new_bundled\";s:71:\"https://downloads.wordpress.org/release/wordpress-4.9.8-new-bundled.zip\";s:7:\"partial\";s:69:\"https://downloads.wordpress.org/release/wordpress-4.9.8-partial-7.zip\";s:8:\"rollback\";b:0;}s:7:\"current\";s:5:\"4.9.8\";s:7:\"version\";s:5:\"4.9.8\";s:11:\"php_version\";s:5:\"5.2.4\";s:13:\"mysql_version\";s:3:\"5.0\";s:11:\"new_bundled\";s:3:\"4.7\";s:15:\"partial_version\";s:5:\"4.9.7\";}i:1;O:8:\"stdClass\":11:{s:8:\"response\";s:10:\"autoupdate\";s:8:\"download\";s:59:\"https://downloads.wordpress.org/release/wordpress-4.9.8.zip\";s:6:\"locale\";s:5:\"en_US\";s:8:\"packages\";O:8:\"stdClass\":5:{s:4:\"full\";s:59:\"https://downloads.wordpress.org/release/wordpress-4.9.8.zip\";s:10:\"no_content\";s:70:\"https://downloads.wordpress.org/release/wordpress-4.9.8-no-content.zip\";s:11:\"new_bundled\";s:71:\"https://downloads.wordpress.org/release/wordpress-4.9.8-new-bundled.zip\";s:7:\"partial\";s:69:\"https://downloads.wordpress.org/release/wordpress-4.9.8-partial-7.zip\";s:8:\"rollback\";s:70:\"https://downloads.wordpress.org/release/wordpress-4.9.8-rollback-7.zip\";}s:7:\"current\";s:5:\"4.9.8\";s:7:\"version\";s:5:\"4.9.8\";s:11:\"php_version\";s:5:\"5.2.4\";s:13:\"mysql_version\";s:3:\"5.0\";s:11:\"new_bundled\";s:3:\"4.7\";s:15:\"partial_version\";s:5:\"4.9.7\";s:9:\"new_files\";s:0:\"\";}}s:12:\"last_checked\";i:1535729268;s:15:\"version_checked\";s:5:\"4.9.7\";s:12:\"translations\";a:0:{}}', 'no'),
(445, 'theme_mods_starter-theme-master', 'a:4:{i:0;b:0;s:18:\"nav_menu_locations\";a:0:{}s:18:\"custom_css_post_id\";i:-1;s:16:\"sidebars_widgets\";a:2:{s:4:\"time\";i:1534891316;s:4:\"data\";a:4:{s:19:\"wp_inactive_widgets\";a:0:{}s:7:\"sidebar\";a:3:{i:0;s:14:\"recent-posts-2\";i:1;s:12:\"categories-2\";i:2;s:10:\"archives-2\";}s:16:\"category_sidebar\";a:0:{}s:15:\"archive_sidebar\";a:0:{}}}}', 'yes'),
(449, 'theme_mods_cannon-dunphy', 'a:3:{i:0;b:0;s:18:\"nav_menu_locations\";a:1:{s:9:\"main_menu\";i:2;}s:18:\"custom_css_post_id\";i:-1;}', 'yes'),
(460, 'nav_menu_options', 'a:2:{i:0;b:0;s:8:\"auto_add\";a:0:{}}', 'yes'),
(492, 'wpmdb_settings', 'a:12:{s:3:\"key\";s:40:\"YKPsqKucz6JGHVuQfoIxdixJvEBlz9JlxpfrbZbg\";s:10:\"allow_pull\";b:0;s:10:\"allow_push\";b:0;s:8:\"profiles\";a:0:{}s:7:\"licence\";s:0:\"\";s:10:\"verify_ssl\";b:0;s:17:\"whitelist_plugins\";a:0:{}s:11:\"max_request\";i:1048576;s:22:\"delay_between_requests\";i:0;s:18:\"prog_tables_hidden\";b:1;s:21:\"pause_before_finalize\";b:0;s:28:\"compatibility_plugin_version\";s:3:\"1.1\";}', 'no'),
(493, 'wpmdb_schema_version', '1', 'no');
INSERT INTO `wp_options` (`option_id`, `option_name`, `option_value`, `autoload`) VALUES
(496, 'wpmdb_usage', 'a:2:{s:6:\"action\";s:8:\"savefile\";s:4:\"time\";i:1535148513;}', 'no'),
(497, 'wpmdb_state_timeout_5b8081e160e04', '1535234923', 'no'),
(498, 'wpmdb_state_5b8081e160e04', 'a:22:{s:6:\"action\";s:19:\"wpmdb_migrate_table\";s:6:\"intent\";s:8:\"savefile\";s:3:\"url\";s:0:\"\";s:9:\"form_data\";s:511:\"action=savefile&save_computer=1&gzip_file=1&connection_info=&import_find_replace=1&replace_old%5B%5D=&replace_new%5B%5D=&replace_old%5B%5D=%2F%2Fcannon-demo.com&replace_new%5B%5D=%2F%2Fcannon-demo.com&replace_old%5B%5D=%2FApplications%2FMAMP%2Fhtdocs%2Fcannon&replace_new%5B%5D=%2FApplications%2FMAMP%2Fhtdocs%2Fcannon&table_migrate_option=migrate_only_with_prefix&replace_guids=1&exclude_transients=1&backup_option=backup_only_with_prefix&save_migration_profile_option=new&create_new_profile=&remote_json_data=\";s:5:\"stage\";s:7:\"migrate\";s:5:\"nonce\";s:10:\"15838a23e1\";s:12:\"site_details\";a:1:{s:5:\"local\";a:10:{s:12:\"is_multisite\";s:5:\"false\";s:8:\"site_url\";s:22:\"http://cannon-demo.com\";s:8:\"home_url\";s:22:\"http://cannon-demo.com\";s:6:\"prefix\";s:3:\"wp_\";s:15:\"uploads_baseurl\";s:42:\"http://cannon-demo.com/wp-content/uploads/\";s:7:\"uploads\";a:6:{s:4:\"path\";s:59:\"/Applications/MAMP/htdocs/cannon/wp-content/uploads/2018/08\";s:3:\"url\";s:49:\"http://cannon-demo.com/wp-content/uploads/2018/08\";s:6:\"subdir\";s:8:\"/2018/08\";s:7:\"basedir\";s:51:\"/Applications/MAMP/htdocs/cannon/wp-content/uploads\";s:7:\"baseurl\";s:41:\"http://cannon-demo.com/wp-content/uploads\";s:5:\"error\";b:0;}s:11:\"uploads_dir\";s:33:\"wp-content/uploads/wp-migrate-db/\";s:8:\"subsites\";a:0:{}s:13:\"subsites_info\";a:0:{}s:20:\"is_subdomain_install\";s:5:\"false\";}}s:4:\"code\";i:200;s:7:\"message\";s:2:\"OK\";s:4:\"body\";s:11:\"{\"error\":0}\";s:9:\"dump_path\";s:108:\"/Applications/MAMP/htdocs/cannon/wp-content/uploads/wp-migrate-db/cannon-migrate-20180824220833-y4848.sql.gz\";s:13:\"dump_filename\";s:35:\"cannon-migrate-20180824220833-y4848\";s:8:\"dump_url\";s:98:\"http://cannon-demo.com/wp-content/uploads/wp-migrate-db/cannon-migrate-20180824220833-y4848.sql.gz\";s:10:\"db_version\";s:6:\"5.6.38\";s:8:\"site_url\";s:22:\"http://cannon-demo.com\";s:18:\"find_replace_pairs\";a:2:{s:11:\"replace_old\";a:2:{i:1;s:17:\"//cannon-demo.com\";i:2;s:32:\"/Applications/MAMP/htdocs/cannon\";}s:11:\"replace_new\";a:2:{i:1;s:17:\"//cannon-demo.com\";i:2;s:32:\"/Applications/MAMP/htdocs/cannon\";}}s:18:\"migration_state_id\";s:13:\"5b8081e160e04\";s:5:\"table\";s:8:\"wp_users\";s:11:\"current_row\";s:0:\"\";s:10:\"last_table\";s:1:\"1\";s:12:\"primary_keys\";s:0:\"\";s:4:\"gzip\";s:1:\"0\";}', 'no'),
(506, '_site_transient_timeout_theme_roots', '1535731070', 'no'),
(507, '_site_transient_theme_roots', 'a:1:{s:13:\"cannon-dunphy\";s:7:\"/themes\";}', 'no'),
(508, '_site_transient_update_plugins', 'O:8:\"stdClass\":5:{s:12:\"last_checked\";i:1535729271;s:7:\"checked\";a:14:{s:57:\"acf-content-analysis-for-yoast-seo/yoast-acf-analysis.php\";s:5:\"2.1.0\";s:57:\"advanced-custom-fields-nav-menu-field/fz-acf-nav-menu.php\";s:5:\"2.0.0\";s:41:\"acf-theme-code-pro/acf_theme_code_pro.php\";s:5:\"1.2.0\";s:34:\"advanced-custom-fields-pro/acf.php\";s:6:\"5.6.10\";s:19:\"akismet/akismet.php\";s:5:\"4.0.8\";s:19:\"bugherd/bugherd.php\";s:7:\"1.0.0.0\";s:29:\"gravityforms/gravityforms.php\";s:5:\"2.3.2\";s:41:\"better-wp-security/better-wp-security.php\";s:5:\"7.0.4\";s:19:\"mailgun/mailgun.php\";s:6:\"1.5.11\";s:24:\"simple-history/index.php\";s:6:\"2.26.1\";s:39:\"wp-migrate-db-pro/wp-migrate-db-pro.php\";s:5:\"1.8.1\";s:63:\"wp-migrate-db-pro-media-files/wp-migrate-db-pro-media-files.php\";s:5:\"1.4.9\";s:27:\"wp-super-cache/wp-cache.php\";s:5:\"1.6.2\";s:24:\"wordpress-seo/wp-seo.php\";s:3:\"7.9\";}s:8:\"response\";a:6:{s:41:\"better-wp-security/better-wp-security.php\";O:8:\"stdClass\":13:{s:2:\"id\";s:32:\"w.org/plugins/better-wp-security\";s:4:\"slug\";s:18:\"better-wp-security\";s:6:\"plugin\";s:41:\"better-wp-security/better-wp-security.php\";s:11:\"new_version\";s:5:\"7.1.0\";s:3:\"url\";s:49:\"https://wordpress.org/plugins/better-wp-security/\";s:7:\"package\";s:67:\"https://downloads.wordpress.org/plugin/better-wp-security.7.1.0.zip\";s:5:\"icons\";a:3:{s:2:\"2x\";s:70:\"https://ps.w.org/better-wp-security/assets/icon-256x256.jpg?rev=969999\";s:2:\"1x\";s:62:\"https://ps.w.org/better-wp-security/assets/icon.svg?rev=970042\";s:3:\"svg\";s:62:\"https://ps.w.org/better-wp-security/assets/icon.svg?rev=970042\";}s:7:\"banners\";a:1:{s:2:\"1x\";s:72:\"https://ps.w.org/better-wp-security/assets/banner-772x250.png?rev=881897\";}s:11:\"banners_rtl\";a:0:{}s:14:\"upgrade_notice\";s:100:\"<p>Version 7.1.0 contains important bug fixes and improvements. It is recommended for all users.</p>\";s:6:\"tested\";s:5:\"4.9.8\";s:12:\"requires_php\";s:3:\"5.2\";s:13:\"compatibility\";O:8:\"stdClass\":0:{}}s:19:\"mailgun/mailgun.php\";O:8:\"stdClass\":12:{s:2:\"id\";s:21:\"w.org/plugins/mailgun\";s:4:\"slug\";s:7:\"mailgun\";s:6:\"plugin\";s:19:\"mailgun/mailgun.php\";s:11:\"new_version\";s:8:\"1.5.13.1\";s:3:\"url\";s:38:\"https://wordpress.org/plugins/mailgun/\";s:7:\"package\";s:59:\"https://downloads.wordpress.org/plugin/mailgun.1.5.13.1.zip\";s:5:\"icons\";a:1:{s:7:\"default\";s:58:\"https://s.w.org/plugins/geopattern-icon/mailgun_6d494f.svg\";}s:7:\"banners\";a:1:{s:2:\"1x\";s:61:\"https://ps.w.org/mailgun/assets/banner-772x250.jpg?rev=628208\";}s:11:\"banners_rtl\";a:0:{}s:6:\"tested\";s:5:\"4.9.8\";s:12:\"requires_php\";b:0;s:13:\"compatibility\";O:8:\"stdClass\":0:{}}s:24:\"simple-history/index.php\";O:8:\"stdClass\":12:{s:2:\"id\";s:28:\"w.org/plugins/simple-history\";s:4:\"slug\";s:14:\"simple-history\";s:6:\"plugin\";s:24:\"simple-history/index.php\";s:11:\"new_version\";s:4:\"2.27\";s:3:\"url\";s:45:\"https://wordpress.org/plugins/simple-history/\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/plugin/simple-history.2.27.zip\";s:5:\"icons\";a:2:{s:2:\"1x\";s:59:\"https://ps.w.org/simple-history/assets/icon.svg?rev=1044051\";s:3:\"svg\";s:59:\"https://ps.w.org/simple-history/assets/icon.svg?rev=1044051\";}s:7:\"banners\";a:1:{s:2:\"1x\";s:69:\"https://ps.w.org/simple-history/assets/banner-772x250.png?rev=1045523\";}s:11:\"banners_rtl\";a:0:{}s:6:\"tested\";s:5:\"4.9.8\";s:12:\"requires_php\";s:3:\"5.3\";s:13:\"compatibility\";O:8:\"stdClass\":0:{}}s:27:\"wp-super-cache/wp-cache.php\";O:8:\"stdClass\":12:{s:2:\"id\";s:28:\"w.org/plugins/wp-super-cache\";s:4:\"slug\";s:14:\"wp-super-cache\";s:6:\"plugin\";s:27:\"wp-super-cache/wp-cache.php\";s:11:\"new_version\";s:5:\"1.6.4\";s:3:\"url\";s:45:\"https://wordpress.org/plugins/wp-super-cache/\";s:7:\"package\";s:63:\"https://downloads.wordpress.org/plugin/wp-super-cache.1.6.4.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:67:\"https://ps.w.org/wp-super-cache/assets/icon-256x256.png?rev=1095422\";s:2:\"1x\";s:67:\"https://ps.w.org/wp-super-cache/assets/icon-128x128.png?rev=1095422\";}s:7:\"banners\";a:2:{s:2:\"2x\";s:70:\"https://ps.w.org/wp-super-cache/assets/banner-1544x500.png?rev=1082414\";s:2:\"1x\";s:69:\"https://ps.w.org/wp-super-cache/assets/banner-772x250.png?rev=1082414\";}s:11:\"banners_rtl\";a:0:{}s:6:\"tested\";s:5:\"4.9.8\";s:12:\"requires_php\";s:5:\"5.2.4\";s:13:\"compatibility\";O:8:\"stdClass\":0:{}}s:24:\"wordpress-seo/wp-seo.php\";O:8:\"stdClass\":12:{s:2:\"id\";s:27:\"w.org/plugins/wordpress-seo\";s:4:\"slug\";s:13:\"wordpress-seo\";s:6:\"plugin\";s:24:\"wordpress-seo/wp-seo.php\";s:11:\"new_version\";s:3:\"8.1\";s:3:\"url\";s:44:\"https://wordpress.org/plugins/wordpress-seo/\";s:7:\"package\";s:60:\"https://downloads.wordpress.org/plugin/wordpress-seo.8.1.zip\";s:5:\"icons\";a:3:{s:2:\"2x\";s:66:\"https://ps.w.org/wordpress-seo/assets/icon-256x256.png?rev=1834347\";s:2:\"1x\";s:58:\"https://ps.w.org/wordpress-seo/assets/icon.svg?rev=1859687\";s:3:\"svg\";s:58:\"https://ps.w.org/wordpress-seo/assets/icon.svg?rev=1859687\";}s:7:\"banners\";a:2:{s:2:\"2x\";s:69:\"https://ps.w.org/wordpress-seo/assets/banner-1544x500.png?rev=1843435\";s:2:\"1x\";s:68:\"https://ps.w.org/wordpress-seo/assets/banner-772x250.png?rev=1843435\";}s:11:\"banners_rtl\";a:2:{s:2:\"2x\";s:73:\"https://ps.w.org/wordpress-seo/assets/banner-1544x500-rtl.png?rev=1843435\";s:2:\"1x\";s:72:\"https://ps.w.org/wordpress-seo/assets/banner-772x250-rtl.png?rev=1843435\";}s:6:\"tested\";s:5:\"4.9.8\";s:12:\"requires_php\";s:5:\"5.2.4\";s:13:\"compatibility\";O:8:\"stdClass\":0:{}}s:34:\"advanced-custom-fields-pro/acf.php\";O:8:\"stdClass\":8:{s:4:\"slug\";s:26:\"advanced-custom-fields-pro\";s:6:\"plugin\";s:34:\"advanced-custom-fields-pro/acf.php\";s:11:\"new_version\";s:5:\"5.7.4\";s:3:\"url\";s:37:\"https://www.advancedcustomfields.com/\";s:6:\"tested\";s:5:\"4.9.9\";s:7:\"package\";s:0:\"\";s:5:\"icons\";a:1:{s:7:\"default\";s:63:\"https://ps.w.org/advanced-custom-fields/assets/icon-256x256.png\";}s:7:\"banners\";a:1:{s:7:\"default\";s:66:\"https://ps.w.org/advanced-custom-fields/assets/banner-1544x500.jpg\";}}}s:12:\"translations\";a:0:{}s:9:\"no_update\";a:4:{s:57:\"acf-content-analysis-for-yoast-seo/yoast-acf-analysis.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:48:\"w.org/plugins/acf-content-analysis-for-yoast-seo\";s:4:\"slug\";s:34:\"acf-content-analysis-for-yoast-seo\";s:6:\"plugin\";s:57:\"acf-content-analysis-for-yoast-seo/yoast-acf-analysis.php\";s:11:\"new_version\";s:5:\"2.1.0\";s:3:\"url\";s:65:\"https://wordpress.org/plugins/acf-content-analysis-for-yoast-seo/\";s:7:\"package\";s:83:\"https://downloads.wordpress.org/plugin/acf-content-analysis-for-yoast-seo.2.1.0.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:87:\"https://ps.w.org/acf-content-analysis-for-yoast-seo/assets/icon-256x256.png?rev=1717503\";s:2:\"1x\";s:87:\"https://ps.w.org/acf-content-analysis-for-yoast-seo/assets/icon-128x128.png?rev=1717503\";}s:7:\"banners\";a:2:{s:2:\"2x\";s:90:\"https://ps.w.org/acf-content-analysis-for-yoast-seo/assets/banner-1544x500.png?rev=1717503\";s:2:\"1x\";s:89:\"https://ps.w.org/acf-content-analysis-for-yoast-seo/assets/banner-772x250.png?rev=1717503\";}s:11:\"banners_rtl\";a:0:{}}s:57:\"advanced-custom-fields-nav-menu-field/fz-acf-nav-menu.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:51:\"w.org/plugins/advanced-custom-fields-nav-menu-field\";s:4:\"slug\";s:37:\"advanced-custom-fields-nav-menu-field\";s:6:\"plugin\";s:57:\"advanced-custom-fields-nav-menu-field/fz-acf-nav-menu.php\";s:11:\"new_version\";s:5:\"2.0.0\";s:3:\"url\";s:68:\"https://wordpress.org/plugins/advanced-custom-fields-nav-menu-field/\";s:7:\"package\";s:86:\"https://downloads.wordpress.org/plugin/advanced-custom-fields-nav-menu-field.2.0.0.zip\";s:5:\"icons\";a:1:{s:7:\"default\";s:88:\"https://s.w.org/plugins/geopattern-icon/advanced-custom-fields-nav-menu-field_fdfdfd.svg\";}s:7:\"banners\";a:1:{s:2:\"1x\";s:91:\"https://ps.w.org/advanced-custom-fields-nav-menu-field/assets/banner-772x250.png?rev=733149\";}s:11:\"banners_rtl\";a:0:{}}s:19:\"akismet/akismet.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:21:\"w.org/plugins/akismet\";s:4:\"slug\";s:7:\"akismet\";s:6:\"plugin\";s:19:\"akismet/akismet.php\";s:11:\"new_version\";s:5:\"4.0.8\";s:3:\"url\";s:38:\"https://wordpress.org/plugins/akismet/\";s:7:\"package\";s:56:\"https://downloads.wordpress.org/plugin/akismet.4.0.8.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:59:\"https://ps.w.org/akismet/assets/icon-256x256.png?rev=969272\";s:2:\"1x\";s:59:\"https://ps.w.org/akismet/assets/icon-128x128.png?rev=969272\";}s:7:\"banners\";a:1:{s:2:\"1x\";s:61:\"https://ps.w.org/akismet/assets/banner-772x250.jpg?rev=479904\";}s:11:\"banners_rtl\";a:0:{}}s:19:\"bugherd/bugherd.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:21:\"w.org/plugins/bugherd\";s:4:\"slug\";s:7:\"bugherd\";s:6:\"plugin\";s:19:\"bugherd/bugherd.php\";s:11:\"new_version\";s:7:\"1.0.0.0\";s:3:\"url\";s:38:\"https://wordpress.org/plugins/bugherd/\";s:7:\"package\";s:50:\"https://downloads.wordpress.org/plugin/bugherd.zip\";s:5:\"icons\";a:1:{s:7:\"default\";s:58:\"https://s.w.org/plugins/geopattern-icon/bugherd_84a8a7.svg\";}s:7:\"banners\";a:1:{s:2:\"1x\";s:61:\"https://ps.w.org/bugherd/assets/banner-772x250.png?rev=587511\";}s:11:\"banners_rtl\";a:0:{}}}}', 'no');

-- --------------------------------------------------------

--
-- Table structure for table `wp_postmeta`
--

CREATE TABLE `wp_postmeta` (
  `meta_id` bigint(20) UNSIGNED NOT NULL,
  `post_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Dumping data for table `wp_postmeta`
--

INSERT INTO `wp_postmeta` (`meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(2, 4, '_edit_last', '1'),
(3, 4, '_edit_lock', '1516675607:1'),
(7, 10, '_edit_last', '1'),
(8, 10, '_edit_lock', '1535039893:1'),
(9, 12, '_edit_last', '1'),
(10, 12, '_edit_lock', '1514332978:1'),
(11, 10, '_wp_page_template', 'template-home.php'),
(16, 15, '_edit_last', '1'),
(19, 15, '_edit_lock', '1514333171:1'),
(20, 17, '_edit_last', '1'),
(23, 17, '_edit_lock', '1514333184:1'),
(24, 19, '_edit_last', '1'),
(25, 19, '_edit_lock', '1514333195:1'),
(28, 21, '_edit_last', '1'),
(29, 21, '_edit_lock', '1514333206:1'),
(32, 23, '_edit_last', '1'),
(33, 23, '_edit_lock', '1514333226:1'),
(36, 37, '_edit_last', '1'),
(37, 37, '_edit_lock', '1516675376:1'),
(38, 37, '_wp_page_template', 'default'),
(39, 39, '_edit_last', '1'),
(40, 39, '_wp_page_template', 'default'),
(41, 39, '_edit_lock', '1516676839:1'),
(42, 46, '_edit_last', '1'),
(43, 46, '_wp_page_template', 'default'),
(44, 46, '_edit_lock', '1516676818:1'),
(45, 48, '_edit_last', '1'),
(46, 48, '_wp_page_template', 'default'),
(47, 48, '_edit_lock', '1516676850:1'),
(48, 50, '_edit_last', '1'),
(49, 50, '_edit_lock', '1534967358:1'),
(50, 50, '_wp_page_template', 'default'),
(51, 52, '_edit_last', '1'),
(52, 52, '_wp_page_template', 'default'),
(53, 52, '_edit_lock', '1516676878:1'),
(54, 54, '_edit_last', '1'),
(55, 54, '_wp_page_template', 'default'),
(56, 54, '_edit_lock', '1516676888:1'),
(57, 56, '_edit_last', '1'),
(58, 56, '_wp_page_template', 'default'),
(59, 56, '_edit_lock', '1516676922:1'),
(60, 58, '_edit_last', '1'),
(61, 58, '_edit_lock', '1516676969:1'),
(62, 58, '_wp_page_template', 'default'),
(63, 60, '_edit_last', '1'),
(64, 60, '_edit_lock', '1534967352:1'),
(65, 60, '_wp_page_template', 'default'),
(66, 62, '_edit_last', '1'),
(67, 62, '_wp_page_template', 'default'),
(68, 62, '_edit_lock', '1516676996:1'),
(69, 68, '_edit_last', '1'),
(70, 68, '_edit_lock', '1534967167:1'),
(71, 68, '_wp_trash_meta_status', 'draft'),
(72, 68, '_wp_trash_meta_time', '1534967174'),
(73, 68, '_wp_desired_post_slug', ''),
(74, 70, '_menu_item_type', 'post_type'),
(75, 70, '_menu_item_menu_item_parent', '0'),
(76, 70, '_menu_item_object_id', '10'),
(77, 70, '_menu_item_object', 'page'),
(78, 70, '_menu_item_target', ''),
(79, 70, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(80, 70, '_menu_item_xfn', ''),
(81, 70, '_menu_item_url', ''),
(83, 71, '_menu_item_type', 'custom'),
(84, 71, '_menu_item_menu_item_parent', '0'),
(85, 71, '_menu_item_object_id', '71'),
(86, 71, '_menu_item_object', 'custom'),
(87, 71, '_menu_item_target', ''),
(88, 71, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(89, 71, '_menu_item_xfn', ''),
(90, 71, '_menu_item_url', ''),
(92, 72, '_menu_item_type', 'post_type'),
(93, 72, '_menu_item_menu_item_parent', '71'),
(94, 72, '_menu_item_object_id', '46'),
(95, 72, '_menu_item_object', 'page'),
(96, 72, '_menu_item_target', ''),
(97, 72, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(98, 72, '_menu_item_xfn', ''),
(99, 72, '_menu_item_url', ''),
(101, 73, '_menu_item_type', 'custom'),
(102, 73, '_menu_item_menu_item_parent', '0'),
(103, 73, '_menu_item_object_id', '73'),
(104, 73, '_menu_item_object', 'custom'),
(105, 73, '_menu_item_target', ''),
(106, 73, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(107, 73, '_menu_item_xfn', ''),
(108, 73, '_menu_item_url', ''),
(110, 74, '_menu_item_type', 'post_type'),
(111, 74, '_menu_item_menu_item_parent', '73'),
(112, 74, '_menu_item_object_id', '60'),
(113, 74, '_menu_item_object', 'page'),
(114, 74, '_menu_item_target', ''),
(115, 74, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(116, 74, '_menu_item_xfn', ''),
(117, 74, '_menu_item_url', ''),
(119, 75, '_menu_item_type', 'post_type'),
(120, 75, '_menu_item_menu_item_parent', '0'),
(121, 75, '_menu_item_object_id', '54'),
(122, 75, '_menu_item_object', 'page'),
(123, 75, '_menu_item_target', ''),
(124, 75, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(125, 75, '_menu_item_xfn', ''),
(126, 75, '_menu_item_url', ''),
(128, 76, '_menu_item_type', 'post_type'),
(129, 76, '_menu_item_menu_item_parent', '0'),
(130, 76, '_menu_item_object_id', '52'),
(131, 76, '_menu_item_object', 'page'),
(132, 76, '_menu_item_target', ''),
(133, 76, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(134, 76, '_menu_item_xfn', ''),
(135, 76, '_menu_item_url', ''),
(137, 77, '_menu_item_type', 'post_type'),
(138, 77, '_menu_item_menu_item_parent', '0'),
(139, 77, '_menu_item_object_id', '62'),
(140, 77, '_menu_item_object', 'page'),
(141, 77, '_menu_item_target', ''),
(142, 77, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(143, 77, '_menu_item_xfn', ''),
(144, 77, '_menu_item_url', ''),
(146, 78, '_menu_item_type', 'post_type'),
(147, 78, '_menu_item_menu_item_parent', '0'),
(148, 78, '_menu_item_object_id', '56'),
(149, 78, '_menu_item_object', 'page'),
(150, 78, '_menu_item_target', ''),
(151, 78, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(152, 78, '_menu_item_xfn', ''),
(153, 78, '_menu_item_url', ''),
(155, 58, '_wp_trash_meta_status', 'publish'),
(156, 58, '_wp_trash_meta_time', '1534967326'),
(157, 58, '_wp_desired_post_slug', 'attorneys'),
(158, 48, '_wp_trash_meta_status', 'publish'),
(159, 48, '_wp_trash_meta_time', '1534967331'),
(160, 48, '_wp_desired_post_slug', 'practice-areas'),
(161, 79, '_edit_last', '1'),
(162, 79, '_edit_lock', '1535039933:1'),
(163, 79, '_wp_page_template', 'default'),
(164, 81, '_menu_item_type', 'post_type'),
(165, 81, '_menu_item_menu_item_parent', '73'),
(166, 81, '_menu_item_object_id', '79'),
(167, 81, '_menu_item_object', 'page'),
(168, 81, '_menu_item_target', ''),
(169, 81, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(170, 81, '_menu_item_xfn', ''),
(171, 81, '_menu_item_url', ''),
(173, 82, '_menu_item_type', 'custom'),
(174, 82, '_menu_item_menu_item_parent', '0'),
(175, 82, '_menu_item_object_id', '82'),
(176, 82, '_menu_item_object', 'custom'),
(177, 82, '_menu_item_target', ''),
(178, 82, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(179, 82, '_menu_item_xfn', ''),
(180, 82, '_menu_item_url', ''),
(182, 83, '_menu_item_type', 'post_type'),
(183, 83, '_menu_item_menu_item_parent', '82'),
(184, 83, '_menu_item_object_id', '50'),
(185, 83, '_menu_item_object', 'page'),
(186, 83, '_menu_item_target', ''),
(187, 83, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(188, 83, '_menu_item_xfn', ''),
(189, 83, '_menu_item_url', '');

-- --------------------------------------------------------

--
-- Table structure for table `wp_posts`
--

CREATE TABLE `wp_posts` (
  `ID` bigint(20) UNSIGNED NOT NULL,
  `post_author` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `post_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_title` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_excerpt` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'publish',
  `comment_status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'open',
  `ping_status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'open',
  `post_password` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `post_name` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `to_ping` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `pinged` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content_filtered` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_parent` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `guid` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `menu_order` int(11) NOT NULL DEFAULT '0',
  `post_type` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'post',
  `post_mime_type` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_count` bigint(20) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Dumping data for table `wp_posts`
--

INSERT INTO `wp_posts` (`ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(4, 1, '2017-12-27 00:03:52', '2017-12-27 00:03:52', 'a:7:{s:8:\"location\";a:1:{i:0;a:1:{i:0;a:3:{s:5:\"param\";s:12:\"options_page\";s:8:\"operator\";s:2:\"==\";s:5:\"value\";s:13:\"theme-options\";}}}s:8:\"position\";s:6:\"normal\";s:5:\"style\";s:7:\"default\";s:15:\"label_placement\";s:3:\"top\";s:21:\"instruction_placement\";s:5:\"label\";s:14:\"hide_on_screen\";s:0:\"\";s:11:\"description\";s:0:\"\";}', 'Theme Options', 'theme-options', 'publish', 'closed', 'closed', '', 'group_5a42e2e8d6530', '', '', '2018-01-23 02:49:05', '2018-01-23 02:49:05', '', 0, 'http://localhost:8888/?post_type=acf-field-group&#038;p=4', 0, 'acf-field-group', '', 0),
(5, 1, '2017-12-27 00:03:52', '2017-12-27 00:03:52', 'a:7:{s:4:\"type\";s:3:\"tab\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:9:\"placement\";s:3:\"top\";s:8:\"endpoint\";i:0;}', 'Header Scripts', '', 'publish', 'closed', 'closed', '', 'field_5a42e2ef5aee8', '', '', '2018-01-23 02:49:05', '2018-01-23 02:49:05', '', 4, 'http://localhost:8888/?post_type=acf-field&#038;p=5', 9, 'acf-field', '', 0),
(6, 1, '2017-12-27 00:03:52', '2017-12-27 00:03:52', 'a:12:{s:4:\"type\";s:8:\"textarea\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";s:4:\"rows\";s:0:\"\";s:9:\"new_lines\";s:0:\"\";s:8:\"readonly\";i:0;s:8:\"disabled\";i:0;}', 'Schema Code', 'schema_code', 'publish', 'closed', 'closed', '', 'field_5a42e3275aee9', '', '', '2018-01-23 02:49:05', '2018-01-23 02:49:05', '', 4, 'http://localhost:8888/?post_type=acf-field&#038;p=6', 10, 'acf-field', '', 0),
(7, 1, '2017-12-27 00:03:52', '2017-12-27 00:03:52', 'a:12:{s:4:\"type\";s:8:\"textarea\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";s:4:\"rows\";s:0:\"\";s:9:\"new_lines\";s:0:\"\";s:8:\"readonly\";i:0;s:8:\"disabled\";i:0;}', 'Analytics Code', 'analytics_code', 'publish', 'closed', 'closed', '', 'field_5a42e33c5aeea', '', '', '2018-01-23 02:49:05', '2018-01-23 02:49:05', '', 4, 'http://localhost:8888/?post_type=acf-field&#038;p=7', 11, 'acf-field', '', 0),
(8, 1, '2017-12-27 00:04:08', '2017-12-27 00:04:08', 'a:7:{s:4:\"type\";s:3:\"tab\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:9:\"placement\";s:3:\"top\";s:8:\"endpoint\";i:0;}', 'Firm Info', '', 'publish', 'closed', 'closed', '', 'field_5a42e36bdd9fd', '', '', '2017-12-27 00:07:39', '2017-12-27 00:07:39', '', 4, 'http://localhost:8888/?post_type=acf-field&#038;p=8', 0, 'acf-field', '', 0),
(10, 1, '2017-12-27 00:05:13', '2017-12-27 00:05:13', '', 'Home', '', 'publish', 'closed', 'closed', '', 'home', '', '', '2018-08-22 14:29:31', '2018-08-22 22:29:31', '', 0, 'http://localhost:8888/?page_id=10', 0, 'page', '', 0),
(11, 1, '2017-12-27 00:05:13', '2017-12-27 00:05:13', '', 'Home', '', 'inherit', 'closed', 'closed', '', '10-revision-v1', '', '', '2017-12-27 00:05:13', '2017-12-27 00:05:13', '', 10, 'http://localhost:8888/2017/12/27/10-revision-v1/', 0, 'revision', '', 0),
(12, 1, '2017-12-27 00:05:21', '2017-12-27 00:05:21', '', 'Blog', '', 'publish', 'closed', 'closed', '', 'blog', '', '', '2017-12-27 00:05:21', '2017-12-27 00:05:21', '', 0, 'http://localhost:8888/?page_id=12', 0, 'page', '', 0),
(13, 1, '2017-12-27 00:05:21', '2017-12-27 00:05:21', '', 'Blog', '', 'inherit', 'closed', 'closed', '', '12-revision-v1', '', '', '2017-12-27 00:05:21', '2017-12-27 00:05:21', '', 12, 'http://localhost:8888/2017/12/27/12-revision-v1/', 0, 'revision', '', 0),
(15, 1, '2017-12-27 00:08:31', '2017-12-27 00:08:31', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Auctor elit sed vulputate mi sit. Imperdiet sed euismod nisi porta lorem mollis aliquam. Urna et pharetra pharetra massa massa ultricies mi quis hendrerit. Malesuada fames ac turpis egestas integer eget aliquet. Nulla malesuada pellentesque elit eget gravida cum sociis natoque. Aenean vel elit scelerisque mauris pellentesque. Ac orci phasellus egestas tellus rutrum tellus pellentesque eu. Pellentesque adipiscing commodo elit at imperdiet dui accumsan sit. Enim facilisis gravida neque convallis a cras semper auctor neque. Cras semper auctor neque vitae.\r\n\r\nUt pharetra sit amet aliquam id diam. Nunc pulvinar sapien et ligula ullamcorper malesuada proin. Amet dictum sit amet justo donec. Urna et pharetra pharetra massa massa. Vulputate dignissim suspendisse in est ante in nibh mauris. Sem nulla pharetra diam sit amet nisl. Donec et odio pellentesque diam volutpat commodo. Quam pellentesque nec nam aliquam sem et. A diam sollicitudin tempor id eu nisl. Nisi scelerisque eu ultrices vitae auctor. Quam nulla porttitor massa id neque aliquam. Penatibus et magnis dis parturient montes nascetur ridiculus mus. Morbi quis commodo odio aenean sed adipiscing diam donec.\r\n\r\nEst lorem ipsum dolor sit amet consectetur adipiscing elit pellentesque. Integer enim neque volutpat ac tincidunt. Cursus euismod quis viverra nibh. Volutpat sed cras ornare arcu dui vivamus arcu felis. Aenean vel elit scelerisque mauris pellentesque pulvinar. Eget lorem dolor sed viverra ipsum nunc aliquet. Nibh tortor id aliquet lectus proin nibh nisl condimentum id. Hac habitasse platea dictumst vestibulum. In massa tempor nec feugiat. Mauris nunc congue nisi vitae suscipit tellus. Purus gravida quis blandit turpis. Volutpat lacus laoreet non curabitur gravida arcu. Fusce id velit ut tortor pretium. Suspendisse faucibus interdum posuere lorem ipsum dolor sit. Scelerisque in dictum non consectetur a. Massa massa ultricies mi quis hendrerit. Lacinia at quis risus sed vulputate odio ut enim blandit. Viverra ipsum nunc aliquet bibendum.\r\n\r\nMaecenas sed enim ut sem viverra aliquet eget sit. Sollicitudin tempor id eu nisl nunc mi ipsum faucibus. Ultrices mi tempus imperdiet nulla malesuada pellentesque elit eget. Id interdum velit laoreet id donec ultrices tincidunt arcu non. Egestas pretium aenean pharetra magna ac placerat. Senectus et netus et malesuada fames ac turpis. Purus in massa tempor nec feugiat nisl pretium fusce id. Habitasse platea dictumst vestibulum rhoncus est pellentesque elit ullamcorper dignissim. Sapien et ligula ullamcorper malesuada proin libero. Aliquam malesuada bibendum arcu vitae elementum curabitur vitae. Orci dapibus ultrices in iaculis nunc sed augue lacus viverra. Sem integer vitae justo eget magna fermentum iaculis eu.\r\n\r\nTempus imperdiet nulla malesuada pellentesque elit eget. Integer feugiat scelerisque varius morbi enim nunc faucibus a pellentesque. Ligula ullamcorper malesuada proin libero nunc consequat interdum. Etiam dignissim diam quis enim lobortis scelerisque. Neque vitae tempus quam pellentesque nec. Augue lacus viverra vitae congue. Mattis molestie a iaculis at erat pellentesque adipiscing. Mi ipsum faucibus vitae aliquet nec ullamcorper sit amet risus. Magnis dis parturient montes nascetur ridiculus mus mauris. Nunc consequat interdum varius sit amet mattis vulputate enim nulla. Enim ut sem viverra aliquet eget. Ut venenatis tellus in metus vulputate. Sed tempus urna et pharetra pharetra massa massa ultricies. Orci porta non pulvinar neque laoreet suspendisse interdum consectetur libero. Nec feugiat nisl pretium fusce id velit ut tortor. Urna nec tincidunt praesent semper. Bibendum at varius vel pharetra vel turpis nunc eget.', 'Sample Post 1', '', 'publish', 'open', 'open', '', 'sample-post-1', '', '', '2017-12-27 00:08:31', '2017-12-27 00:08:31', '', 0, 'http://localhost:8888/?p=15', 0, 'post', '', 0),
(16, 1, '2017-12-27 00:08:31', '2017-12-27 00:08:31', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Auctor elit sed vulputate mi sit. Imperdiet sed euismod nisi porta lorem mollis aliquam. Urna et pharetra pharetra massa massa ultricies mi quis hendrerit. Malesuada fames ac turpis egestas integer eget aliquet. Nulla malesuada pellentesque elit eget gravida cum sociis natoque. Aenean vel elit scelerisque mauris pellentesque. Ac orci phasellus egestas tellus rutrum tellus pellentesque eu. Pellentesque adipiscing commodo elit at imperdiet dui accumsan sit. Enim facilisis gravida neque convallis a cras semper auctor neque. Cras semper auctor neque vitae.\r\n\r\nUt pharetra sit amet aliquam id diam. Nunc pulvinar sapien et ligula ullamcorper malesuada proin. Amet dictum sit amet justo donec. Urna et pharetra pharetra massa massa. Vulputate dignissim suspendisse in est ante in nibh mauris. Sem nulla pharetra diam sit amet nisl. Donec et odio pellentesque diam volutpat commodo. Quam pellentesque nec nam aliquam sem et. A diam sollicitudin tempor id eu nisl. Nisi scelerisque eu ultrices vitae auctor. Quam nulla porttitor massa id neque aliquam. Penatibus et magnis dis parturient montes nascetur ridiculus mus. Morbi quis commodo odio aenean sed adipiscing diam donec.\r\n\r\nEst lorem ipsum dolor sit amet consectetur adipiscing elit pellentesque. Integer enim neque volutpat ac tincidunt. Cursus euismod quis viverra nibh. Volutpat sed cras ornare arcu dui vivamus arcu felis. Aenean vel elit scelerisque mauris pellentesque pulvinar. Eget lorem dolor sed viverra ipsum nunc aliquet. Nibh tortor id aliquet lectus proin nibh nisl condimentum id. Hac habitasse platea dictumst vestibulum. In massa tempor nec feugiat. Mauris nunc congue nisi vitae suscipit tellus. Purus gravida quis blandit turpis. Volutpat lacus laoreet non curabitur gravida arcu. Fusce id velit ut tortor pretium. Suspendisse faucibus interdum posuere lorem ipsum dolor sit. Scelerisque in dictum non consectetur a. Massa massa ultricies mi quis hendrerit. Lacinia at quis risus sed vulputate odio ut enim blandit. Viverra ipsum nunc aliquet bibendum.\r\n\r\nMaecenas sed enim ut sem viverra aliquet eget sit. Sollicitudin tempor id eu nisl nunc mi ipsum faucibus. Ultrices mi tempus imperdiet nulla malesuada pellentesque elit eget. Id interdum velit laoreet id donec ultrices tincidunt arcu non. Egestas pretium aenean pharetra magna ac placerat. Senectus et netus et malesuada fames ac turpis. Purus in massa tempor nec feugiat nisl pretium fusce id. Habitasse platea dictumst vestibulum rhoncus est pellentesque elit ullamcorper dignissim. Sapien et ligula ullamcorper malesuada proin libero. Aliquam malesuada bibendum arcu vitae elementum curabitur vitae. Orci dapibus ultrices in iaculis nunc sed augue lacus viverra. Sem integer vitae justo eget magna fermentum iaculis eu.\r\n\r\nTempus imperdiet nulla malesuada pellentesque elit eget. Integer feugiat scelerisque varius morbi enim nunc faucibus a pellentesque. Ligula ullamcorper malesuada proin libero nunc consequat interdum. Etiam dignissim diam quis enim lobortis scelerisque. Neque vitae tempus quam pellentesque nec. Augue lacus viverra vitae congue. Mattis molestie a iaculis at erat pellentesque adipiscing. Mi ipsum faucibus vitae aliquet nec ullamcorper sit amet risus. Magnis dis parturient montes nascetur ridiculus mus mauris. Nunc consequat interdum varius sit amet mattis vulputate enim nulla. Enim ut sem viverra aliquet eget. Ut venenatis tellus in metus vulputate. Sed tempus urna et pharetra pharetra massa massa ultricies. Orci porta non pulvinar neque laoreet suspendisse interdum consectetur libero. Nec feugiat nisl pretium fusce id velit ut tortor. Urna nec tincidunt praesent semper. Bibendum at varius vel pharetra vel turpis nunc eget.', 'Sample Post 1', '', 'inherit', 'closed', 'closed', '', '15-revision-v1', '', '', '2017-12-27 00:08:31', '2017-12-27 00:08:31', '', 15, 'http://localhost:8888/15-revision-v1/', 0, 'revision', '', 0),
(17, 1, '2017-12-27 00:08:44', '2017-12-27 00:08:44', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Auctor elit sed vulputate mi sit. Imperdiet sed euismod nisi porta lorem mollis aliquam. Urna et pharetra pharetra massa massa ultricies mi quis hendrerit. Malesuada fames ac turpis egestas integer eget aliquet. Nulla malesuada pellentesque elit eget gravida cum sociis natoque. Aenean vel elit scelerisque mauris pellentesque. Ac orci phasellus egestas tellus rutrum tellus pellentesque eu. Pellentesque adipiscing commodo elit at imperdiet dui accumsan sit. Enim facilisis gravida neque convallis a cras semper auctor neque. Cras semper auctor neque vitae.\r\n\r\nUt pharetra sit amet aliquam id diam. Nunc pulvinar sapien et ligula ullamcorper malesuada proin. Amet dictum sit amet justo donec. Urna et pharetra pharetra massa massa. Vulputate dignissim suspendisse in est ante in nibh mauris. Sem nulla pharetra diam sit amet nisl. Donec et odio pellentesque diam volutpat commodo. Quam pellentesque nec nam aliquam sem et. A diam sollicitudin tempor id eu nisl. Nisi scelerisque eu ultrices vitae auctor. Quam nulla porttitor massa id neque aliquam. Penatibus et magnis dis parturient montes nascetur ridiculus mus. Morbi quis commodo odio aenean sed adipiscing diam donec.\r\n\r\nEst lorem ipsum dolor sit amet consectetur adipiscing elit pellentesque. Integer enim neque volutpat ac tincidunt. Cursus euismod quis viverra nibh. Volutpat sed cras ornare arcu dui vivamus arcu felis. Aenean vel elit scelerisque mauris pellentesque pulvinar. Eget lorem dolor sed viverra ipsum nunc aliquet. Nibh tortor id aliquet lectus proin nibh nisl condimentum id. Hac habitasse platea dictumst vestibulum. In massa tempor nec feugiat. Mauris nunc congue nisi vitae suscipit tellus. Purus gravida quis blandit turpis. Volutpat lacus laoreet non curabitur gravida arcu. Fusce id velit ut tortor pretium. Suspendisse faucibus interdum posuere lorem ipsum dolor sit. Scelerisque in dictum non consectetur a. Massa massa ultricies mi quis hendrerit. Lacinia at quis risus sed vulputate odio ut enim blandit. Viverra ipsum nunc aliquet bibendum.\r\n\r\nMaecenas sed enim ut sem viverra aliquet eget sit. Sollicitudin tempor id eu nisl nunc mi ipsum faucibus. Ultrices mi tempus imperdiet nulla malesuada pellentesque elit eget. Id interdum velit laoreet id donec ultrices tincidunt arcu non. Egestas pretium aenean pharetra magna ac placerat. Senectus et netus et malesuada fames ac turpis. Purus in massa tempor nec feugiat nisl pretium fusce id. Habitasse platea dictumst vestibulum rhoncus est pellentesque elit ullamcorper dignissim. Sapien et ligula ullamcorper malesuada proin libero. Aliquam malesuada bibendum arcu vitae elementum curabitur vitae. Orci dapibus ultrices in iaculis nunc sed augue lacus viverra. Sem integer vitae justo eget magna fermentum iaculis eu.\r\n\r\nTempus imperdiet nulla malesuada pellentesque elit eget. Integer feugiat scelerisque varius morbi enim nunc faucibus a pellentesque. Ligula ullamcorper malesuada proin libero nunc consequat interdum. Etiam dignissim diam quis enim lobortis scelerisque. Neque vitae tempus quam pellentesque nec. Augue lacus viverra vitae congue. Mattis molestie a iaculis at erat pellentesque adipiscing. Mi ipsum faucibus vitae aliquet nec ullamcorper sit amet risus. Magnis dis parturient montes nascetur ridiculus mus mauris. Nunc consequat interdum varius sit amet mattis vulputate enim nulla. Enim ut sem viverra aliquet eget. Ut venenatis tellus in metus vulputate. Sed tempus urna et pharetra pharetra massa massa ultricies. Orci porta non pulvinar neque laoreet suspendisse interdum consectetur libero. Nec feugiat nisl pretium fusce id velit ut tortor. Urna nec tincidunt praesent semper. Bibendum at varius vel pharetra vel turpis nunc eget.', 'Sample Post 2', '', 'publish', 'open', 'open', '', 'sample-post-2', '', '', '2017-12-27 00:08:44', '2017-12-27 00:08:44', '', 0, 'http://localhost:8888/?p=17', 0, 'post', '', 0),
(18, 1, '2017-12-27 00:08:44', '2017-12-27 00:08:44', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Auctor elit sed vulputate mi sit. Imperdiet sed euismod nisi porta lorem mollis aliquam. Urna et pharetra pharetra massa massa ultricies mi quis hendrerit. Malesuada fames ac turpis egestas integer eget aliquet. Nulla malesuada pellentesque elit eget gravida cum sociis natoque. Aenean vel elit scelerisque mauris pellentesque. Ac orci phasellus egestas tellus rutrum tellus pellentesque eu. Pellentesque adipiscing commodo elit at imperdiet dui accumsan sit. Enim facilisis gravida neque convallis a cras semper auctor neque. Cras semper auctor neque vitae.\r\n\r\nUt pharetra sit amet aliquam id diam. Nunc pulvinar sapien et ligula ullamcorper malesuada proin. Amet dictum sit amet justo donec. Urna et pharetra pharetra massa massa. Vulputate dignissim suspendisse in est ante in nibh mauris. Sem nulla pharetra diam sit amet nisl. Donec et odio pellentesque diam volutpat commodo. Quam pellentesque nec nam aliquam sem et. A diam sollicitudin tempor id eu nisl. Nisi scelerisque eu ultrices vitae auctor. Quam nulla porttitor massa id neque aliquam. Penatibus et magnis dis parturient montes nascetur ridiculus mus. Morbi quis commodo odio aenean sed adipiscing diam donec.\r\n\r\nEst lorem ipsum dolor sit amet consectetur adipiscing elit pellentesque. Integer enim neque volutpat ac tincidunt. Cursus euismod quis viverra nibh. Volutpat sed cras ornare arcu dui vivamus arcu felis. Aenean vel elit scelerisque mauris pellentesque pulvinar. Eget lorem dolor sed viverra ipsum nunc aliquet. Nibh tortor id aliquet lectus proin nibh nisl condimentum id. Hac habitasse platea dictumst vestibulum. In massa tempor nec feugiat. Mauris nunc congue nisi vitae suscipit tellus. Purus gravida quis blandit turpis. Volutpat lacus laoreet non curabitur gravida arcu. Fusce id velit ut tortor pretium. Suspendisse faucibus interdum posuere lorem ipsum dolor sit. Scelerisque in dictum non consectetur a. Massa massa ultricies mi quis hendrerit. Lacinia at quis risus sed vulputate odio ut enim blandit. Viverra ipsum nunc aliquet bibendum.\r\n\r\nMaecenas sed enim ut sem viverra aliquet eget sit. Sollicitudin tempor id eu nisl nunc mi ipsum faucibus. Ultrices mi tempus imperdiet nulla malesuada pellentesque elit eget. Id interdum velit laoreet id donec ultrices tincidunt arcu non. Egestas pretium aenean pharetra magna ac placerat. Senectus et netus et malesuada fames ac turpis. Purus in massa tempor nec feugiat nisl pretium fusce id. Habitasse platea dictumst vestibulum rhoncus est pellentesque elit ullamcorper dignissim. Sapien et ligula ullamcorper malesuada proin libero. Aliquam malesuada bibendum arcu vitae elementum curabitur vitae. Orci dapibus ultrices in iaculis nunc sed augue lacus viverra. Sem integer vitae justo eget magna fermentum iaculis eu.\r\n\r\nTempus imperdiet nulla malesuada pellentesque elit eget. Integer feugiat scelerisque varius morbi enim nunc faucibus a pellentesque. Ligula ullamcorper malesuada proin libero nunc consequat interdum. Etiam dignissim diam quis enim lobortis scelerisque. Neque vitae tempus quam pellentesque nec. Augue lacus viverra vitae congue. Mattis molestie a iaculis at erat pellentesque adipiscing. Mi ipsum faucibus vitae aliquet nec ullamcorper sit amet risus. Magnis dis parturient montes nascetur ridiculus mus mauris. Nunc consequat interdum varius sit amet mattis vulputate enim nulla. Enim ut sem viverra aliquet eget. Ut venenatis tellus in metus vulputate. Sed tempus urna et pharetra pharetra massa massa ultricies. Orci porta non pulvinar neque laoreet suspendisse interdum consectetur libero. Nec feugiat nisl pretium fusce id velit ut tortor. Urna nec tincidunt praesent semper. Bibendum at varius vel pharetra vel turpis nunc eget.', 'Sample Post 2', '', 'inherit', 'closed', 'closed', '', '17-revision-v1', '', '', '2017-12-27 00:08:44', '2017-12-27 00:08:44', '', 17, 'http://localhost:8888/17-revision-v1/', 0, 'revision', '', 0),
(19, 1, '2017-12-27 00:08:56', '2017-12-27 00:08:56', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Auctor elit sed vulputate mi sit. Imperdiet sed euismod nisi porta lorem mollis aliquam. Urna et pharetra pharetra massa massa ultricies mi quis hendrerit. Malesuada fames ac turpis egestas integer eget aliquet. Nulla malesuada pellentesque elit eget gravida cum sociis natoque. Aenean vel elit scelerisque mauris pellentesque. Ac orci phasellus egestas tellus rutrum tellus pellentesque eu. Pellentesque adipiscing commodo elit at imperdiet dui accumsan sit. Enim facilisis gravida neque convallis a cras semper auctor neque. Cras semper auctor neque vitae.\r\n\r\nUt pharetra sit amet aliquam id diam. Nunc pulvinar sapien et ligula ullamcorper malesuada proin. Amet dictum sit amet justo donec. Urna et pharetra pharetra massa massa. Vulputate dignissim suspendisse in est ante in nibh mauris. Sem nulla pharetra diam sit amet nisl. Donec et odio pellentesque diam volutpat commodo. Quam pellentesque nec nam aliquam sem et. A diam sollicitudin tempor id eu nisl. Nisi scelerisque eu ultrices vitae auctor. Quam nulla porttitor massa id neque aliquam. Penatibus et magnis dis parturient montes nascetur ridiculus mus. Morbi quis commodo odio aenean sed adipiscing diam donec.\r\n\r\nEst lorem ipsum dolor sit amet consectetur adipiscing elit pellentesque. Integer enim neque volutpat ac tincidunt. Cursus euismod quis viverra nibh. Volutpat sed cras ornare arcu dui vivamus arcu felis. Aenean vel elit scelerisque mauris pellentesque pulvinar. Eget lorem dolor sed viverra ipsum nunc aliquet. Nibh tortor id aliquet lectus proin nibh nisl condimentum id. Hac habitasse platea dictumst vestibulum. In massa tempor nec feugiat. Mauris nunc congue nisi vitae suscipit tellus. Purus gravida quis blandit turpis. Volutpat lacus laoreet non curabitur gravida arcu. Fusce id velit ut tortor pretium. Suspendisse faucibus interdum posuere lorem ipsum dolor sit. Scelerisque in dictum non consectetur a. Massa massa ultricies mi quis hendrerit. Lacinia at quis risus sed vulputate odio ut enim blandit. Viverra ipsum nunc aliquet bibendum.\r\n\r\nMaecenas sed enim ut sem viverra aliquet eget sit. Sollicitudin tempor id eu nisl nunc mi ipsum faucibus. Ultrices mi tempus imperdiet nulla malesuada pellentesque elit eget. Id interdum velit laoreet id donec ultrices tincidunt arcu non. Egestas pretium aenean pharetra magna ac placerat. Senectus et netus et malesuada fames ac turpis. Purus in massa tempor nec feugiat nisl pretium fusce id. Habitasse platea dictumst vestibulum rhoncus est pellentesque elit ullamcorper dignissim. Sapien et ligula ullamcorper malesuada proin libero. Aliquam malesuada bibendum arcu vitae elementum curabitur vitae. Orci dapibus ultrices in iaculis nunc sed augue lacus viverra. Sem integer vitae justo eget magna fermentum iaculis eu.\r\n\r\nTempus imperdiet nulla malesuada pellentesque elit eget. Integer feugiat scelerisque varius morbi enim nunc faucibus a pellentesque. Ligula ullamcorper malesuada proin libero nunc consequat interdum. Etiam dignissim diam quis enim lobortis scelerisque. Neque vitae tempus quam pellentesque nec. Augue lacus viverra vitae congue. Mattis molestie a iaculis at erat pellentesque adipiscing. Mi ipsum faucibus vitae aliquet nec ullamcorper sit amet risus. Magnis dis parturient montes nascetur ridiculus mus mauris. Nunc consequat interdum varius sit amet mattis vulputate enim nulla. Enim ut sem viverra aliquet eget. Ut venenatis tellus in metus vulputate. Sed tempus urna et pharetra pharetra massa massa ultricies. Orci porta non pulvinar neque laoreet suspendisse interdum consectetur libero. Nec feugiat nisl pretium fusce id velit ut tortor. Urna nec tincidunt praesent semper. Bibendum at varius vel pharetra vel turpis nunc eget.', 'Sample Post 3', '', 'publish', 'open', 'open', '', 'sample-post-3', '', '', '2017-12-27 00:08:56', '2017-12-27 00:08:56', '', 0, 'http://localhost:8888/?p=19', 0, 'post', '', 0),
(20, 1, '2017-12-27 00:08:56', '2017-12-27 00:08:56', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Auctor elit sed vulputate mi sit. Imperdiet sed euismod nisi porta lorem mollis aliquam. Urna et pharetra pharetra massa massa ultricies mi quis hendrerit. Malesuada fames ac turpis egestas integer eget aliquet. Nulla malesuada pellentesque elit eget gravida cum sociis natoque. Aenean vel elit scelerisque mauris pellentesque. Ac orci phasellus egestas tellus rutrum tellus pellentesque eu. Pellentesque adipiscing commodo elit at imperdiet dui accumsan sit. Enim facilisis gravida neque convallis a cras semper auctor neque. Cras semper auctor neque vitae.\r\n\r\nUt pharetra sit amet aliquam id diam. Nunc pulvinar sapien et ligula ullamcorper malesuada proin. Amet dictum sit amet justo donec. Urna et pharetra pharetra massa massa. Vulputate dignissim suspendisse in est ante in nibh mauris. Sem nulla pharetra diam sit amet nisl. Donec et odio pellentesque diam volutpat commodo. Quam pellentesque nec nam aliquam sem et. A diam sollicitudin tempor id eu nisl. Nisi scelerisque eu ultrices vitae auctor. Quam nulla porttitor massa id neque aliquam. Penatibus et magnis dis parturient montes nascetur ridiculus mus. Morbi quis commodo odio aenean sed adipiscing diam donec.\r\n\r\nEst lorem ipsum dolor sit amet consectetur adipiscing elit pellentesque. Integer enim neque volutpat ac tincidunt. Cursus euismod quis viverra nibh. Volutpat sed cras ornare arcu dui vivamus arcu felis. Aenean vel elit scelerisque mauris pellentesque pulvinar. Eget lorem dolor sed viverra ipsum nunc aliquet. Nibh tortor id aliquet lectus proin nibh nisl condimentum id. Hac habitasse platea dictumst vestibulum. In massa tempor nec feugiat. Mauris nunc congue nisi vitae suscipit tellus. Purus gravida quis blandit turpis. Volutpat lacus laoreet non curabitur gravida arcu. Fusce id velit ut tortor pretium. Suspendisse faucibus interdum posuere lorem ipsum dolor sit. Scelerisque in dictum non consectetur a. Massa massa ultricies mi quis hendrerit. Lacinia at quis risus sed vulputate odio ut enim blandit. Viverra ipsum nunc aliquet bibendum.\r\n\r\nMaecenas sed enim ut sem viverra aliquet eget sit. Sollicitudin tempor id eu nisl nunc mi ipsum faucibus. Ultrices mi tempus imperdiet nulla malesuada pellentesque elit eget. Id interdum velit laoreet id donec ultrices tincidunt arcu non. Egestas pretium aenean pharetra magna ac placerat. Senectus et netus et malesuada fames ac turpis. Purus in massa tempor nec feugiat nisl pretium fusce id. Habitasse platea dictumst vestibulum rhoncus est pellentesque elit ullamcorper dignissim. Sapien et ligula ullamcorper malesuada proin libero. Aliquam malesuada bibendum arcu vitae elementum curabitur vitae. Orci dapibus ultrices in iaculis nunc sed augue lacus viverra. Sem integer vitae justo eget magna fermentum iaculis eu.\r\n\r\nTempus imperdiet nulla malesuada pellentesque elit eget. Integer feugiat scelerisque varius morbi enim nunc faucibus a pellentesque. Ligula ullamcorper malesuada proin libero nunc consequat interdum. Etiam dignissim diam quis enim lobortis scelerisque. Neque vitae tempus quam pellentesque nec. Augue lacus viverra vitae congue. Mattis molestie a iaculis at erat pellentesque adipiscing. Mi ipsum faucibus vitae aliquet nec ullamcorper sit amet risus. Magnis dis parturient montes nascetur ridiculus mus mauris. Nunc consequat interdum varius sit amet mattis vulputate enim nulla. Enim ut sem viverra aliquet eget. Ut venenatis tellus in metus vulputate. Sed tempus urna et pharetra pharetra massa massa ultricies. Orci porta non pulvinar neque laoreet suspendisse interdum consectetur libero. Nec feugiat nisl pretium fusce id velit ut tortor. Urna nec tincidunt praesent semper. Bibendum at varius vel pharetra vel turpis nunc eget.', 'Sample Post 3', '', 'inherit', 'closed', 'closed', '', '19-revision-v1', '', '', '2017-12-27 00:08:56', '2017-12-27 00:08:56', '', 19, 'http://localhost:8888/19-revision-v1/', 0, 'revision', '', 0),
(21, 1, '2017-12-27 00:09:07', '2017-12-27 00:09:07', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Auctor elit sed vulputate mi sit. Imperdiet sed euismod nisi porta lorem mollis aliquam. Urna et pharetra pharetra massa massa ultricies mi quis hendrerit. Malesuada fames ac turpis egestas integer eget aliquet. Nulla malesuada pellentesque elit eget gravida cum sociis natoque. Aenean vel elit scelerisque mauris pellentesque. Ac orci phasellus egestas tellus rutrum tellus pellentesque eu. Pellentesque adipiscing commodo elit at imperdiet dui accumsan sit. Enim facilisis gravida neque convallis a cras semper auctor neque. Cras semper auctor neque vitae.\r\n\r\nUt pharetra sit amet aliquam id diam. Nunc pulvinar sapien et ligula ullamcorper malesuada proin. Amet dictum sit amet justo donec. Urna et pharetra pharetra massa massa. Vulputate dignissim suspendisse in est ante in nibh mauris. Sem nulla pharetra diam sit amet nisl. Donec et odio pellentesque diam volutpat commodo. Quam pellentesque nec nam aliquam sem et. A diam sollicitudin tempor id eu nisl. Nisi scelerisque eu ultrices vitae auctor. Quam nulla porttitor massa id neque aliquam. Penatibus et magnis dis parturient montes nascetur ridiculus mus. Morbi quis commodo odio aenean sed adipiscing diam donec.\r\n\r\nEst lorem ipsum dolor sit amet consectetur adipiscing elit pellentesque. Integer enim neque volutpat ac tincidunt. Cursus euismod quis viverra nibh. Volutpat sed cras ornare arcu dui vivamus arcu felis. Aenean vel elit scelerisque mauris pellentesque pulvinar. Eget lorem dolor sed viverra ipsum nunc aliquet. Nibh tortor id aliquet lectus proin nibh nisl condimentum id. Hac habitasse platea dictumst vestibulum. In massa tempor nec feugiat. Mauris nunc congue nisi vitae suscipit tellus. Purus gravida quis blandit turpis. Volutpat lacus laoreet non curabitur gravida arcu. Fusce id velit ut tortor pretium. Suspendisse faucibus interdum posuere lorem ipsum dolor sit. Scelerisque in dictum non consectetur a. Massa massa ultricies mi quis hendrerit. Lacinia at quis risus sed vulputate odio ut enim blandit. Viverra ipsum nunc aliquet bibendum.\r\n\r\nMaecenas sed enim ut sem viverra aliquet eget sit. Sollicitudin tempor id eu nisl nunc mi ipsum faucibus. Ultrices mi tempus imperdiet nulla malesuada pellentesque elit eget. Id interdum velit laoreet id donec ultrices tincidunt arcu non. Egestas pretium aenean pharetra magna ac placerat. Senectus et netus et malesuada fames ac turpis. Purus in massa tempor nec feugiat nisl pretium fusce id. Habitasse platea dictumst vestibulum rhoncus est pellentesque elit ullamcorper dignissim. Sapien et ligula ullamcorper malesuada proin libero. Aliquam malesuada bibendum arcu vitae elementum curabitur vitae. Orci dapibus ultrices in iaculis nunc sed augue lacus viverra. Sem integer vitae justo eget magna fermentum iaculis eu.\r\n\r\nTempus imperdiet nulla malesuada pellentesque elit eget. Integer feugiat scelerisque varius morbi enim nunc faucibus a pellentesque. Ligula ullamcorper malesuada proin libero nunc consequat interdum. Etiam dignissim diam quis enim lobortis scelerisque. Neque vitae tempus quam pellentesque nec. Augue lacus viverra vitae congue. Mattis molestie a iaculis at erat pellentesque adipiscing. Mi ipsum faucibus vitae aliquet nec ullamcorper sit amet risus. Magnis dis parturient montes nascetur ridiculus mus mauris. Nunc consequat interdum varius sit amet mattis vulputate enim nulla. Enim ut sem viverra aliquet eget. Ut venenatis tellus in metus vulputate. Sed tempus urna et pharetra pharetra massa massa ultricies. Orci porta non pulvinar neque laoreet suspendisse interdum consectetur libero. Nec feugiat nisl pretium fusce id velit ut tortor. Urna nec tincidunt praesent semper. Bibendum at varius vel pharetra vel turpis nunc eget.', 'Sample Post 4', '', 'publish', 'open', 'open', '', 'sample-post-4', '', '', '2017-12-27 00:09:07', '2017-12-27 00:09:07', '', 0, 'http://localhost:8888/?p=21', 0, 'post', '', 0),
(22, 1, '2017-12-27 00:09:07', '2017-12-27 00:09:07', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Auctor elit sed vulputate mi sit. Imperdiet sed euismod nisi porta lorem mollis aliquam. Urna et pharetra pharetra massa massa ultricies mi quis hendrerit. Malesuada fames ac turpis egestas integer eget aliquet. Nulla malesuada pellentesque elit eget gravida cum sociis natoque. Aenean vel elit scelerisque mauris pellentesque. Ac orci phasellus egestas tellus rutrum tellus pellentesque eu. Pellentesque adipiscing commodo elit at imperdiet dui accumsan sit. Enim facilisis gravida neque convallis a cras semper auctor neque. Cras semper auctor neque vitae.\r\n\r\nUt pharetra sit amet aliquam id diam. Nunc pulvinar sapien et ligula ullamcorper malesuada proin. Amet dictum sit amet justo donec. Urna et pharetra pharetra massa massa. Vulputate dignissim suspendisse in est ante in nibh mauris. Sem nulla pharetra diam sit amet nisl. Donec et odio pellentesque diam volutpat commodo. Quam pellentesque nec nam aliquam sem et. A diam sollicitudin tempor id eu nisl. Nisi scelerisque eu ultrices vitae auctor. Quam nulla porttitor massa id neque aliquam. Penatibus et magnis dis parturient montes nascetur ridiculus mus. Morbi quis commodo odio aenean sed adipiscing diam donec.\r\n\r\nEst lorem ipsum dolor sit amet consectetur adipiscing elit pellentesque. Integer enim neque volutpat ac tincidunt. Cursus euismod quis viverra nibh. Volutpat sed cras ornare arcu dui vivamus arcu felis. Aenean vel elit scelerisque mauris pellentesque pulvinar. Eget lorem dolor sed viverra ipsum nunc aliquet. Nibh tortor id aliquet lectus proin nibh nisl condimentum id. Hac habitasse platea dictumst vestibulum. In massa tempor nec feugiat. Mauris nunc congue nisi vitae suscipit tellus. Purus gravida quis blandit turpis. Volutpat lacus laoreet non curabitur gravida arcu. Fusce id velit ut tortor pretium. Suspendisse faucibus interdum posuere lorem ipsum dolor sit. Scelerisque in dictum non consectetur a. Massa massa ultricies mi quis hendrerit. Lacinia at quis risus sed vulputate odio ut enim blandit. Viverra ipsum nunc aliquet bibendum.\r\n\r\nMaecenas sed enim ut sem viverra aliquet eget sit. Sollicitudin tempor id eu nisl nunc mi ipsum faucibus. Ultrices mi tempus imperdiet nulla malesuada pellentesque elit eget. Id interdum velit laoreet id donec ultrices tincidunt arcu non. Egestas pretium aenean pharetra magna ac placerat. Senectus et netus et malesuada fames ac turpis. Purus in massa tempor nec feugiat nisl pretium fusce id. Habitasse platea dictumst vestibulum rhoncus est pellentesque elit ullamcorper dignissim. Sapien et ligula ullamcorper malesuada proin libero. Aliquam malesuada bibendum arcu vitae elementum curabitur vitae. Orci dapibus ultrices in iaculis nunc sed augue lacus viverra. Sem integer vitae justo eget magna fermentum iaculis eu.\r\n\r\nTempus imperdiet nulla malesuada pellentesque elit eget. Integer feugiat scelerisque varius morbi enim nunc faucibus a pellentesque. Ligula ullamcorper malesuada proin libero nunc consequat interdum. Etiam dignissim diam quis enim lobortis scelerisque. Neque vitae tempus quam pellentesque nec. Augue lacus viverra vitae congue. Mattis molestie a iaculis at erat pellentesque adipiscing. Mi ipsum faucibus vitae aliquet nec ullamcorper sit amet risus. Magnis dis parturient montes nascetur ridiculus mus mauris. Nunc consequat interdum varius sit amet mattis vulputate enim nulla. Enim ut sem viverra aliquet eget. Ut venenatis tellus in metus vulputate. Sed tempus urna et pharetra pharetra massa massa ultricies. Orci porta non pulvinar neque laoreet suspendisse interdum consectetur libero. Nec feugiat nisl pretium fusce id velit ut tortor. Urna nec tincidunt praesent semper. Bibendum at varius vel pharetra vel turpis nunc eget.', 'Sample Post 4', '', 'inherit', 'closed', 'closed', '', '21-revision-v1', '', '', '2017-12-27 00:09:07', '2017-12-27 00:09:07', '', 21, 'http://localhost:8888/21-revision-v1/', 0, 'revision', '', 0),
(23, 1, '2017-12-27 00:09:20', '2017-12-27 00:09:20', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Auctor elit sed vulputate mi sit. Imperdiet sed euismod nisi porta lorem mollis aliquam. Urna et pharetra pharetra massa massa ultricies mi quis hendrerit. Malesuada fames ac turpis egestas integer eget aliquet. Nulla malesuada pellentesque elit eget gravida cum sociis natoque. Aenean vel elit scelerisque mauris pellentesque. Ac orci phasellus egestas tellus rutrum tellus pellentesque eu. Pellentesque adipiscing commodo elit at imperdiet dui accumsan sit. Enim facilisis gravida neque convallis a cras semper auctor neque. Cras semper auctor neque vitae.\r\n\r\nUt pharetra sit amet aliquam id diam. Nunc pulvinar sapien et ligula ullamcorper malesuada proin. Amet dictum sit amet justo donec. Urna et pharetra pharetra massa massa. Vulputate dignissim suspendisse in est ante in nibh mauris. Sem nulla pharetra diam sit amet nisl. Donec et odio pellentesque diam volutpat commodo. Quam pellentesque nec nam aliquam sem et. A diam sollicitudin tempor id eu nisl. Nisi scelerisque eu ultrices vitae auctor. Quam nulla porttitor massa id neque aliquam. Penatibus et magnis dis parturient montes nascetur ridiculus mus. Morbi quis commodo odio aenean sed adipiscing diam donec.\r\n\r\nEst lorem ipsum dolor sit amet consectetur adipiscing elit pellentesque. Integer enim neque volutpat ac tincidunt. Cursus euismod quis viverra nibh. Volutpat sed cras ornare arcu dui vivamus arcu felis. Aenean vel elit scelerisque mauris pellentesque pulvinar. Eget lorem dolor sed viverra ipsum nunc aliquet. Nibh tortor id aliquet lectus proin nibh nisl condimentum id. Hac habitasse platea dictumst vestibulum. In massa tempor nec feugiat. Mauris nunc congue nisi vitae suscipit tellus. Purus gravida quis blandit turpis. Volutpat lacus laoreet non curabitur gravida arcu. Fusce id velit ut tortor pretium. Suspendisse faucibus interdum posuere lorem ipsum dolor sit. Scelerisque in dictum non consectetur a. Massa massa ultricies mi quis hendrerit. Lacinia at quis risus sed vulputate odio ut enim blandit. Viverra ipsum nunc aliquet bibendum.\r\n\r\nMaecenas sed enim ut sem viverra aliquet eget sit. Sollicitudin tempor id eu nisl nunc mi ipsum faucibus. Ultrices mi tempus imperdiet nulla malesuada pellentesque elit eget. Id interdum velit laoreet id donec ultrices tincidunt arcu non. Egestas pretium aenean pharetra magna ac placerat. Senectus et netus et malesuada fames ac turpis. Purus in massa tempor nec feugiat nisl pretium fusce id. Habitasse platea dictumst vestibulum rhoncus est pellentesque elit ullamcorper dignissim. Sapien et ligula ullamcorper malesuada proin libero. Aliquam malesuada bibendum arcu vitae elementum curabitur vitae. Orci dapibus ultrices in iaculis nunc sed augue lacus viverra. Sem integer vitae justo eget magna fermentum iaculis eu.\r\n\r\nTempus imperdiet nulla malesuada pellentesque elit eget. Integer feugiat scelerisque varius morbi enim nunc faucibus a pellentesque. Ligula ullamcorper malesuada proin libero nunc consequat interdum. Etiam dignissim diam quis enim lobortis scelerisque. Neque vitae tempus quam pellentesque nec. Augue lacus viverra vitae congue. Mattis molestie a iaculis at erat pellentesque adipiscing. Mi ipsum faucibus vitae aliquet nec ullamcorper sit amet risus. Magnis dis parturient montes nascetur ridiculus mus mauris. Nunc consequat interdum varius sit amet mattis vulputate enim nulla. Enim ut sem viverra aliquet eget. Ut venenatis tellus in metus vulputate. Sed tempus urna et pharetra pharetra massa massa ultricies. Orci porta non pulvinar neque laoreet suspendisse interdum consectetur libero. Nec feugiat nisl pretium fusce id velit ut tortor. Urna nec tincidunt praesent semper. Bibendum at varius vel pharetra vel turpis nunc eget.', 'Sample Post 5', '', 'publish', 'open', 'open', '', 'sample-post-5', '', '', '2017-12-27 00:09:20', '2017-12-27 00:09:20', '', 0, 'http://localhost:8888/?p=23', 0, 'post', '', 0),
(24, 1, '2017-12-27 00:09:20', '2017-12-27 00:09:20', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Auctor elit sed vulputate mi sit. Imperdiet sed euismod nisi porta lorem mollis aliquam. Urna et pharetra pharetra massa massa ultricies mi quis hendrerit. Malesuada fames ac turpis egestas integer eget aliquet. Nulla malesuada pellentesque elit eget gravida cum sociis natoque. Aenean vel elit scelerisque mauris pellentesque. Ac orci phasellus egestas tellus rutrum tellus pellentesque eu. Pellentesque adipiscing commodo elit at imperdiet dui accumsan sit. Enim facilisis gravida neque convallis a cras semper auctor neque. Cras semper auctor neque vitae.\r\n\r\nUt pharetra sit amet aliquam id diam. Nunc pulvinar sapien et ligula ullamcorper malesuada proin. Amet dictum sit amet justo donec. Urna et pharetra pharetra massa massa. Vulputate dignissim suspendisse in est ante in nibh mauris. Sem nulla pharetra diam sit amet nisl. Donec et odio pellentesque diam volutpat commodo. Quam pellentesque nec nam aliquam sem et. A diam sollicitudin tempor id eu nisl. Nisi scelerisque eu ultrices vitae auctor. Quam nulla porttitor massa id neque aliquam. Penatibus et magnis dis parturient montes nascetur ridiculus mus. Morbi quis commodo odio aenean sed adipiscing diam donec.\r\n\r\nEst lorem ipsum dolor sit amet consectetur adipiscing elit pellentesque. Integer enim neque volutpat ac tincidunt. Cursus euismod quis viverra nibh. Volutpat sed cras ornare arcu dui vivamus arcu felis. Aenean vel elit scelerisque mauris pellentesque pulvinar. Eget lorem dolor sed viverra ipsum nunc aliquet. Nibh tortor id aliquet lectus proin nibh nisl condimentum id. Hac habitasse platea dictumst vestibulum. In massa tempor nec feugiat. Mauris nunc congue nisi vitae suscipit tellus. Purus gravida quis blandit turpis. Volutpat lacus laoreet non curabitur gravida arcu. Fusce id velit ut tortor pretium. Suspendisse faucibus interdum posuere lorem ipsum dolor sit. Scelerisque in dictum non consectetur a. Massa massa ultricies mi quis hendrerit. Lacinia at quis risus sed vulputate odio ut enim blandit. Viverra ipsum nunc aliquet bibendum.\r\n\r\nMaecenas sed enim ut sem viverra aliquet eget sit. Sollicitudin tempor id eu nisl nunc mi ipsum faucibus. Ultrices mi tempus imperdiet nulla malesuada pellentesque elit eget. Id interdum velit laoreet id donec ultrices tincidunt arcu non. Egestas pretium aenean pharetra magna ac placerat. Senectus et netus et malesuada fames ac turpis. Purus in massa tempor nec feugiat nisl pretium fusce id. Habitasse platea dictumst vestibulum rhoncus est pellentesque elit ullamcorper dignissim. Sapien et ligula ullamcorper malesuada proin libero. Aliquam malesuada bibendum arcu vitae elementum curabitur vitae. Orci dapibus ultrices in iaculis nunc sed augue lacus viverra. Sem integer vitae justo eget magna fermentum iaculis eu.\r\n\r\nTempus imperdiet nulla malesuada pellentesque elit eget. Integer feugiat scelerisque varius morbi enim nunc faucibus a pellentesque. Ligula ullamcorper malesuada proin libero nunc consequat interdum. Etiam dignissim diam quis enim lobortis scelerisque. Neque vitae tempus quam pellentesque nec. Augue lacus viverra vitae congue. Mattis molestie a iaculis at erat pellentesque adipiscing. Mi ipsum faucibus vitae aliquet nec ullamcorper sit amet risus. Magnis dis parturient montes nascetur ridiculus mus mauris. Nunc consequat interdum varius sit amet mattis vulputate enim nulla. Enim ut sem viverra aliquet eget. Ut venenatis tellus in metus vulputate. Sed tempus urna et pharetra pharetra massa massa ultricies. Orci porta non pulvinar neque laoreet suspendisse interdum consectetur libero. Nec feugiat nisl pretium fusce id velit ut tortor. Urna nec tincidunt praesent semper. Bibendum at varius vel pharetra vel turpis nunc eget.', 'Sample Post 5', '', 'inherit', 'closed', 'closed', '', '23-revision-v1', '', '', '2017-12-27 00:09:20', '2017-12-27 00:09:20', '', 23, 'http://localhost:8888/23-revision-v1/', 0, 'revision', '', 0),
(28, 1, '2018-01-23 02:41:42', '2018-01-23 02:41:42', 'a:12:{s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";s:8:\"readonly\";i:0;s:8:\"disabled\";i:0;}', 'Firm Number Local', 'firm_number_local', 'publish', 'closed', 'closed', '', 'field_5a66a0dc333dd', '', '', '2018-01-23 02:44:34', '2018-01-23 02:44:34', '', 4, 'http://localhost:8888/?post_type=acf-field&#038;p=28', 1, 'acf-field', '', 0),
(29, 1, '2018-01-23 02:44:34', '2018-01-23 02:44:34', 'a:12:{s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";s:8:\"readonly\";i:0;s:8:\"disabled\";i:0;}', 'Firm Number Toll Free', 'firm_number_toll_free', 'publish', 'closed', 'closed', '', 'field_5a66a16d94390', '', '', '2018-01-23 02:44:34', '2018-01-23 02:44:34', '', 4, 'http://localhost:8888/?post_type=acf-field&p=29', 2, 'acf-field', '', 0),
(30, 1, '2018-01-23 02:44:34', '2018-01-23 02:44:34', 'a:12:{s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";s:8:\"readonly\";i:0;s:8:\"disabled\";i:0;}', 'Main Wistia Video ID', 'main_wistia_video_id', 'publish', 'closed', 'closed', '', 'field_5a66a12694389', '', '', '2018-01-23 02:44:34', '2018-01-23 02:44:34', '', 4, 'http://localhost:8888/?post_type=acf-field&p=30', 3, 'acf-field', '', 0),
(31, 1, '2018-01-23 02:44:34', '2018-01-23 02:44:34', 'a:7:{s:4:\"type\";s:3:\"tab\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:9:\"placement\";s:3:\"top\";s:8:\"endpoint\";i:0;}', 'Social Media', '', 'publish', 'closed', 'closed', '', 'field_5a66a1369438a', '', '', '2018-01-23 02:49:05', '2018-01-23 02:49:05', '', 4, 'http://localhost:8888/?post_type=acf-field&#038;p=31', 12, 'acf-field', '', 0),
(32, 1, '2018-01-23 02:44:34', '2018-01-23 02:44:34', 'a:12:{s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";s:8:\"readonly\";i:0;s:8:\"disabled\";i:0;}', 'Facebook Link', 'facebook_link', 'publish', 'closed', 'closed', '', 'field_5a66a1409438b', '', '', '2018-01-23 02:49:05', '2018-01-23 02:49:05', '', 4, 'http://localhost:8888/?post_type=acf-field&#038;p=32', 13, 'acf-field', '', 0),
(33, 1, '2018-01-23 02:44:34', '2018-01-23 02:44:34', 'a:12:{s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";s:8:\"readonly\";i:0;s:8:\"disabled\";i:0;}', 'Google Plus Link', 'google_plus_link', 'publish', 'closed', 'closed', '', 'field_5a66a1489438c', '', '', '2018-01-23 02:49:05', '2018-01-23 02:49:05', '', 4, 'http://localhost:8888/?post_type=acf-field&#038;p=33', 14, 'acf-field', '', 0),
(34, 1, '2018-01-23 02:44:34', '2018-01-23 02:44:34', 'a:12:{s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";s:8:\"readonly\";i:0;s:8:\"disabled\";i:0;}', 'Twitter Link', 'twitter_link', 'publish', 'closed', 'closed', '', 'field_5a66a1529438d', '', '', '2018-01-23 02:49:05', '2018-01-23 02:49:05', '', 4, 'http://localhost:8888/?post_type=acf-field&#038;p=34', 15, 'acf-field', '', 0);
INSERT INTO `wp_posts` (`ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(35, 1, '2018-01-23 02:44:34', '2018-01-23 02:44:34', 'a:12:{s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";s:8:\"readonly\";i:0;s:8:\"disabled\";i:0;}', 'Linked In Link', 'linked_in_link', 'publish', 'closed', 'closed', '', 'field_5a66a15a9438e', '', '', '2018-01-23 02:49:05', '2018-01-23 02:49:05', '', 4, 'http://localhost:8888/?post_type=acf-field&#038;p=35', 16, 'acf-field', '', 0),
(36, 1, '2018-01-23 02:44:34', '2018-01-23 02:44:34', 'a:12:{s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";s:8:\"readonly\";i:0;s:8:\"disabled\";i:0;}', 'Youtube Link', 'youtube_link', 'publish', 'closed', 'closed', '', 'field_5a66a1659438f', '', '', '2018-01-23 02:49:05', '2018-01-23 02:49:05', '', 4, 'http://localhost:8888/?post_type=acf-field&#038;p=36', 17, 'acf-field', '', 0),
(37, 1, '2018-01-23 02:45:06', '2018-01-23 02:45:06', '<pre>Thank you for your submission, we will contact you shortly.</pre>', 'Thank You', '', 'publish', 'closed', 'closed', '', 'thank-you', '', '', '2018-01-23 02:45:06', '2018-01-23 02:45:06', '', 0, 'http://localhost:8888/?page_id=37', 0, 'page', '', 0),
(38, 1, '2018-01-23 02:45:06', '2018-01-23 02:45:06', '<pre>Thank you for your submission, we will contact you shortly.</pre>', 'Thank You', '', 'inherit', 'closed', 'closed', '', '37-revision-v1', '', '', '2018-01-23 02:45:06', '2018-01-23 02:45:06', '', 37, 'http://localhost:8888/37-revision-v1/', 0, 'revision', '', 0),
(39, 1, '2018-01-23 03:09:27', '2018-01-23 03:09:27', '', 'Privacy Policy', '', 'publish', 'closed', 'closed', '', 'privacy-policy', '', '', '2018-01-23 03:09:27', '2018-01-23 03:09:27', '', 0, 'http://localhost:8888/?page_id=39', 0, 'page', '', 0),
(40, 1, '2018-01-23 02:47:22', '2018-01-23 02:47:22', '', 'Privacy Policy', '', 'inherit', 'closed', 'closed', '', '39-revision-v1', '', '', '2018-01-23 02:47:22', '2018-01-23 02:47:22', '', 39, 'http://localhost:8888/39-revision-v1/', 0, 'revision', '', 0),
(41, 1, '2018-01-23 02:49:05', '2018-01-23 02:49:05', 'a:7:{s:4:\"type\";s:3:\"tab\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:9:\"placement\";s:3:\"top\";s:8:\"endpoint\";i:0;}', 'Firm Location', '', 'publish', 'closed', 'closed', '', 'field_5a66a24928de4', '', '', '2018-01-23 02:49:05', '2018-01-23 02:49:05', '', 4, 'http://localhost:8888/?post_type=acf-field&p=41', 4, 'acf-field', '', 0),
(42, 1, '2018-01-23 02:49:05', '2018-01-23 02:49:05', 'a:12:{s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";s:8:\"readonly\";i:0;s:8:\"disabled\";i:0;}', 'Firm Street Address', 'firm_street_address', 'publish', 'closed', 'closed', '', 'field_5a66a25e28de5', '', '', '2018-01-23 02:49:05', '2018-01-23 02:49:05', '', 4, 'http://localhost:8888/?post_type=acf-field&p=42', 5, 'acf-field', '', 0),
(43, 1, '2018-01-23 02:49:05', '2018-01-23 02:49:05', 'a:12:{s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";s:8:\"readonly\";i:0;s:8:\"disabled\";i:0;}', 'Firm City State Zip', 'firm_city_state_zip', 'publish', 'closed', 'closed', '', 'field_5a66a27428de6', '', '', '2018-01-23 02:49:05', '2018-01-23 02:49:05', '', 4, 'http://localhost:8888/?post_type=acf-field&p=43', 6, 'acf-field', '', 0),
(44, 1, '2018-01-23 02:49:05', '2018-01-23 02:49:05', 'a:12:{s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";s:8:\"readonly\";i:0;s:8:\"disabled\";i:0;}', 'Firm Directions Link', 'firm_directions_link', 'publish', 'closed', 'closed', '', 'field_5a66a28528de7', '', '', '2018-01-23 02:49:05', '2018-01-23 02:49:05', '', 4, 'http://localhost:8888/?post_type=acf-field&p=44', 7, 'acf-field', '', 0),
(45, 1, '2018-01-23 02:49:05', '2018-01-23 02:49:05', 'a:12:{s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";s:8:\"readonly\";i:0;s:8:\"disabled\";i:0;}', 'Firm Map Embed', 'firm_map_embed', 'publish', 'closed', 'closed', '', 'field_5a66a29028de8', '', '', '2018-01-23 02:49:05', '2018-01-23 02:49:05', '', 4, 'http://localhost:8888/?post_type=acf-field&p=45', 8, 'acf-field', '', 0),
(46, 1, '2018-01-23 03:09:20', '2018-01-23 03:09:20', '', 'About', '', 'publish', 'closed', 'closed', '', 'about', '', '', '2018-01-23 03:09:20', '2018-01-23 03:09:20', '', 0, 'http://localhost:8888/?page_id=46', 0, 'page', '', 0),
(47, 1, '2018-01-23 03:09:20', '2018-01-23 03:09:20', '', 'About', '', 'inherit', 'closed', 'closed', '', '46-revision-v1', '', '', '2018-01-23 03:09:20', '2018-01-23 03:09:20', '', 46, 'http://localhost:8888/46-revision-v1/', 0, 'revision', '', 0),
(48, 1, '2018-01-23 03:09:52', '2018-01-23 03:09:52', '', 'Practice Areas', '', 'trash', 'closed', 'closed', '', 'practice-areas__trashed', '', '', '2018-08-22 11:48:51', '2018-08-22 19:48:51', '', 0, 'http://localhost:8888/?page_id=48', 0, 'page', '', 0),
(49, 1, '2018-01-23 03:09:50', '2018-01-23 03:09:50', '', 'Practice Areas', '', 'inherit', 'closed', 'closed', '', '48-revision-v1', '', '', '2018-01-23 03:09:50', '2018-01-23 03:09:50', '', 48, 'http://localhost:8888/48-revision-v1/', 0, 'revision', '', 0),
(50, 1, '2018-01-23 03:10:03', '2018-01-23 11:10:03', '', 'Practice Area', '', 'publish', 'closed', 'closed', '', 'practice-area', '', '', '2018-08-22 11:49:18', '2018-08-22 19:49:18', '', 0, 'http://localhost:8888/?page_id=50', 0, 'page', '', 0),
(51, 1, '2018-01-23 03:10:03', '2018-01-23 03:10:03', '', 'Practice Area', '', 'inherit', 'closed', 'closed', '', '50-revision-v1', '', '', '2018-01-23 03:10:03', '2018-01-23 03:10:03', '', 50, 'http://localhost:8888/50-revision-v1/', 0, 'revision', '', 0),
(52, 1, '2018-01-23 03:10:21', '2018-01-23 03:10:21', '', 'Testimonials', '', 'publish', 'closed', 'closed', '', 'testimonials', '', '', '2018-01-23 03:10:21', '2018-01-23 03:10:21', '', 0, 'http://localhost:8888/?page_id=52', 0, 'page', '', 0),
(53, 1, '2018-01-23 03:10:21', '2018-01-23 03:10:21', '', 'Testimonials', '', 'inherit', 'closed', 'closed', '', '52-revision-v1', '', '', '2018-01-23 03:10:21', '2018-01-23 03:10:21', '', 52, 'http://localhost:8888/52-revision-v1/', 0, 'revision', '', 0),
(54, 1, '2018-01-23 03:10:28', '2018-01-23 03:10:28', '', 'Results', '', 'publish', 'closed', 'closed', '', 'results', '', '', '2018-01-23 03:10:28', '2018-01-23 03:10:28', '', 0, 'http://localhost:8888/?page_id=54', 0, 'page', '', 0),
(55, 1, '2018-01-23 03:10:28', '2018-01-23 03:10:28', '', 'Results', '', 'inherit', 'closed', 'closed', '', '54-revision-v1', '', '', '2018-01-23 03:10:28', '2018-01-23 03:10:28', '', 54, 'http://localhost:8888/54-revision-v1/', 0, 'revision', '', 0),
(56, 1, '2018-01-23 03:10:38', '2018-01-23 03:10:38', '', 'Contact', '', 'publish', 'closed', 'closed', '', 'contact', '', '', '2018-01-23 03:10:38', '2018-01-23 03:10:38', '', 0, 'http://localhost:8888/?page_id=56', 0, 'page', '', 0),
(57, 1, '2018-01-23 03:10:38', '2018-01-23 03:10:38', '', 'Contact', '', 'inherit', 'closed', 'closed', '', '56-revision-v1', '', '', '2018-01-23 03:10:38', '2018-01-23 03:10:38', '', 56, 'http://localhost:8888/56-revision-v1/', 0, 'revision', '', 0),
(58, 1, '2018-01-23 03:11:51', '2018-01-23 03:11:51', '', 'Attorneys', '', 'trash', 'closed', 'closed', '', 'attorneys__trashed', '', '', '2018-08-22 11:48:46', '2018-08-22 19:48:46', '', 0, 'http://localhost:8888/?page_id=58', 0, 'page', '', 0),
(59, 1, '2018-01-23 03:11:51', '2018-01-23 03:11:51', '', 'Attorneys', '', 'inherit', 'closed', 'closed', '', '58-revision-v1', '', '', '2018-01-23 03:11:51', '2018-01-23 03:11:51', '', 58, 'http://localhost:8888/58-revision-v1/', 0, 'revision', '', 0),
(60, 1, '2018-01-23 03:12:05', '2018-01-23 11:12:05', '', 'Attorney Profile', '', 'publish', 'closed', 'closed', '', 'attorney-profile', '', '', '2018-08-22 11:49:12', '2018-08-22 19:49:12', '', 0, 'http://localhost:8888/?page_id=60', 0, 'page', '', 0),
(61, 1, '2018-01-23 03:12:05', '2018-01-23 03:12:05', '', 'Attorney Profile', '', 'inherit', 'closed', 'closed', '', '60-revision-v1', '', '', '2018-01-23 03:12:05', '2018-01-23 03:12:05', '', 60, 'http://localhost:8888/60-revision-v1/', 0, 'revision', '', 0),
(62, 1, '2018-01-23 03:12:18', '2018-01-23 03:12:18', '', 'Videos', '', 'publish', 'closed', 'closed', '', 'videos', '', '', '2018-01-23 03:12:18', '2018-01-23 03:12:18', '', 0, 'http://localhost:8888/?page_id=62', 0, 'page', '', 0),
(63, 1, '2018-01-23 03:12:18', '2018-01-23 03:12:18', '', 'Videos', '', 'inherit', 'closed', 'closed', '', '62-revision-v1', '', '', '2018-01-23 03:12:18', '2018-01-23 03:12:18', '', 62, 'http://localhost:8888/62-revision-v1/', 0, 'revision', '', 0),
(68, 1, '2018-08-22 11:46:14', '2018-08-22 19:46:14', '', 'About Us', '', 'trash', 'closed', 'closed', '', '__trashed', '', '', '2018-08-22 11:46:14', '2018-08-22 19:46:14', '', 0, 'http://cannon-demo.com/?page_id=68', 0, 'page', '', 0),
(69, 1, '2018-08-22 11:46:14', '2018-08-22 19:46:14', '', 'About Us', '', 'inherit', 'closed', 'closed', '', '68-revision-v1', '', '', '2018-08-22 11:46:14', '2018-08-22 19:46:14', '', 68, 'http://cannon-demo.com/68-revision-v1/', 0, 'revision', '', 0),
(70, 1, '2018-08-22 11:48:40', '2018-08-22 19:48:40', ' ', '', '', 'publish', 'closed', 'closed', '', '70', '', '', '2018-08-23 10:10:17', '2018-08-23 18:10:17', '', 0, 'http://cannon-demo.com/?p=70', 1, 'nav_menu_item', '', 0),
(71, 1, '2018-08-22 11:48:40', '2018-08-22 19:48:40', '', 'About', '', 'publish', 'closed', 'closed', '', 'about', '', '', '2018-08-23 10:10:17', '2018-08-23 18:10:17', '', 0, 'http://cannon-demo.com/?p=71', 2, 'nav_menu_item', '', 0),
(72, 1, '2018-08-22 11:48:40', '2018-08-22 19:48:40', ' ', '', '', 'publish', 'closed', 'closed', '', '72', '', '', '2018-08-23 10:10:17', '2018-08-23 18:10:17', '', 0, 'http://cannon-demo.com/?p=72', 3, 'nav_menu_item', '', 0),
(73, 1, '2018-08-22 11:48:40', '2018-08-22 19:48:40', '', 'Attorneys', '', 'publish', 'closed', 'closed', '', 'attorneys', '', '', '2018-08-23 10:10:18', '2018-08-23 18:10:18', '', 0, 'http://cannon-demo.com/?p=73', 4, 'nav_menu_item', '', 0),
(74, 1, '2018-08-22 11:48:40', '2018-08-22 19:48:40', ' ', '', '', 'publish', 'closed', 'closed', '', '74', '', '', '2018-08-23 10:10:18', '2018-08-23 18:10:18', '', 0, 'http://cannon-demo.com/?p=74', 5, 'nav_menu_item', '', 0),
(75, 1, '2018-08-22 11:48:40', '2018-08-22 19:48:40', ' ', '', '', 'publish', 'closed', 'closed', '', '75', '', '', '2018-08-23 10:10:18', '2018-08-23 18:10:18', '', 0, 'http://cannon-demo.com/?p=75', 9, 'nav_menu_item', '', 0),
(76, 1, '2018-08-22 11:48:40', '2018-08-22 19:48:40', ' ', '', '', 'publish', 'closed', 'closed', '', '76', '', '', '2018-08-23 10:10:18', '2018-08-23 18:10:18', '', 0, 'http://cannon-demo.com/?p=76', 10, 'nav_menu_item', '', 0),
(77, 1, '2018-08-22 11:48:40', '2018-08-22 19:48:40', ' ', '', '', 'publish', 'closed', 'closed', '', '77', '', '', '2018-08-23 10:10:18', '2018-08-23 18:10:18', '', 0, 'http://cannon-demo.com/?p=77', 11, 'nav_menu_item', '', 0),
(78, 1, '2018-08-22 11:48:40', '2018-08-22 19:48:40', ' ', '', '', 'publish', 'closed', 'closed', '', '78', '', '', '2018-08-23 10:10:18', '2018-08-23 18:10:18', '', 0, 'http://cannon-demo.com/?p=78', 12, 'nav_menu_item', '', 0),
(79, 1, '2018-08-23 08:01:14', '2018-08-23 16:01:14', '', 'Meet the Team', '', 'publish', 'closed', 'closed', '', 'meet-the-team', '', '', '2018-08-23 08:01:14', '2018-08-23 16:01:14', '', 0, 'http://cannon-demo.com/?page_id=79', 0, 'page', '', 0),
(80, 1, '2018-08-23 08:01:14', '2018-08-23 16:01:14', '', 'Meet the Team', '', 'inherit', 'closed', 'closed', '', '79-revision-v1', '', '', '2018-08-23 08:01:14', '2018-08-23 16:01:14', '', 79, 'http://cannon-demo.com/79-revision-v1/', 0, 'revision', '', 0),
(81, 1, '2018-08-23 08:01:26', '2018-08-23 16:01:26', ' ', '', '', 'publish', 'closed', 'closed', '', '81', '', '', '2018-08-23 10:10:18', '2018-08-23 18:10:18', '', 0, 'http://cannon-demo.com/?p=81', 6, 'nav_menu_item', '', 0),
(82, 1, '2018-08-23 10:10:06', '2018-08-23 18:10:06', '', 'Practice Areas', '', 'publish', 'closed', 'closed', '', 'practice-areas', '', '', '2018-08-23 10:10:18', '2018-08-23 18:10:18', '', 0, 'http://cannon-demo.com/?p=82', 7, 'nav_menu_item', '', 0),
(83, 1, '2018-08-23 10:10:06', '2018-08-23 18:10:06', ' ', '', '', 'publish', 'closed', 'closed', '', '83', '', '', '2018-08-23 10:10:18', '2018-08-23 18:10:18', '', 0, 'http://cannon-demo.com/?p=83', 8, 'nav_menu_item', '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `wp_rg_form`
--

CREATE TABLE `wp_rg_form` (
  `id` mediumint(8) UNSIGNED NOT NULL,
  `title` varchar(150) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `date_created` datetime NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `is_trash` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Dumping data for table `wp_rg_form`
--

INSERT INTO `wp_rg_form` (`id`, `title`, `date_created`, `is_active`, `is_trash`) VALUES
(1, 'Contact', '2018-01-23 02:49:42', 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `wp_rg_form_meta`
--

CREATE TABLE `wp_rg_form_meta` (
  `form_id` mediumint(8) UNSIGNED NOT NULL,
  `display_meta` longtext COLLATE utf8mb4_unicode_520_ci,
  `entries_grid_meta` longtext COLLATE utf8mb4_unicode_520_ci,
  `confirmations` longtext COLLATE utf8mb4_unicode_520_ci,
  `notifications` longtext COLLATE utf8mb4_unicode_520_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Dumping data for table `wp_rg_form_meta`
--

INSERT INTO `wp_rg_form_meta` (`form_id`, `display_meta`, `entries_grid_meta`, `confirmations`, `notifications`) VALUES
(1, '{\"title\":\"Contact\",\"description\":\"\",\"labelPlacement\":\"top_label\",\"descriptionPlacement\":\"below\",\"button\":{\"type\":\"text\",\"text\":\"Submit\",\"imageUrl\":\"\"},\"fields\":[],\"version\":\"2.2.5\",\"id\":1,\"notifications\":{\"5a66a2c69111e\":{\"id\":\"5a66a2c69111e\",\"to\":\"{admin_email}\",\"name\":\"Admin Notification\",\"event\":\"form_submission\",\"toType\":\"email\",\"subject\":\"New submission from {form_title}\",\"message\":\"{all_fields}\"}},\"confirmations\":{\"5a66a2c69162e\":{\"id\":\"5a66a2c69162e\",\"name\":\"Default Confirmation\",\"isDefault\":true,\"type\":\"message\",\"message\":\"Thanks for contacting us! We will get in touch with you shortly.\",\"url\":\"\",\"pageId\":\"\",\"queryString\":\"\"}},\"subLabelPlacement\":\"below\",\"cssClass\":\"\",\"enableHoneypot\":true,\"enableAnimation\":false,\"save\":{\"enabled\":false,\"button\":{\"type\":\"link\",\"text\":\"Save and Continue Later\"}},\"limitEntries\":false,\"limitEntriesCount\":\"\",\"limitEntriesPeriod\":\"\",\"limitEntriesMessage\":\"\",\"scheduleForm\":false,\"scheduleStart\":\"\",\"scheduleStartHour\":\"\",\"scheduleStartMinute\":\"\",\"scheduleStartAmpm\":\"\",\"scheduleEnd\":\"\",\"scheduleEndHour\":\"\",\"scheduleEndMinute\":\"\",\"scheduleEndAmpm\":\"\",\"schedulePendingMessage\":\"\",\"scheduleMessage\":\"\",\"requireLogin\":false,\"requireLoginMessage\":\"\"}', NULL, '{\"5a66a2c69162e\":{\"id\":\"5a66a2c69162e\",\"name\":\"Default Confirmation\",\"isDefault\":true,\"type\":\"page\",\"message\":\"Thanks for contacting us! We will get in touch with you shortly.\",\"url\":\"\",\"pageId\":37,\"queryString\":\"\",\"disableAutoformat\":false,\"conditionalLogic\":[]}}', '{\"5a66a2c69111e\":{\"isActive\":true,\"id\":\"5a66a2c69111e\",\"name\":\"Admin Notification\",\"service\":\"wordpress\",\"event\":\"form_submission\",\"to\":\"joe@1point21interactive.com\",\"toType\":\"email\",\"bcc\":\"\",\"subject\":\"{Name:1} - Case Evaluation inquiry from clientname.com\",\"message\":\"<div align=\\\"center\\\"><img src=\\\"http:\\/\\/www.ilawyermarketing.com\\/images\\/ilawyerlogo.jpg\\\" alt=\\\"Website lead from iLawyerMarketing\\\" \\/><\\/div>\\r\\n{all_fields}\",\"from\":\"noreply@ilawyermarketing.org\",\"fromName\":\"Clientwebsite.com\",\"replyTo\":\"{Email: 3}\",\"routing\":null,\"conditionalLogic\":null,\"disableAutoformat\":false}}');

-- --------------------------------------------------------

--
-- Table structure for table `wp_rg_form_view`
--

CREATE TABLE `wp_rg_form_view` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `form_id` mediumint(8) UNSIGNED NOT NULL,
  `date_created` datetime NOT NULL,
  `ip` char(15) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `count` mediumint(8) UNSIGNED NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

-- --------------------------------------------------------

--
-- Table structure for table `wp_rg_incomplete_submissions`
--

CREATE TABLE `wp_rg_incomplete_submissions` (
  `uuid` char(32) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `form_id` mediumint(8) UNSIGNED NOT NULL,
  `date_created` datetime NOT NULL,
  `ip` varchar(39) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `source_url` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `submission` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

-- --------------------------------------------------------

--
-- Table structure for table `wp_rg_lead`
--

CREATE TABLE `wp_rg_lead` (
  `id` int(10) UNSIGNED NOT NULL,
  `form_id` mediumint(8) UNSIGNED NOT NULL,
  `post_id` bigint(20) UNSIGNED DEFAULT NULL,
  `date_created` datetime NOT NULL,
  `is_starred` tinyint(1) NOT NULL DEFAULT '0',
  `is_read` tinyint(1) NOT NULL DEFAULT '0',
  `ip` varchar(39) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `source_url` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_agent` varchar(250) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `currency` varchar(5) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `payment_status` varchar(15) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `payment_date` datetime DEFAULT NULL,
  `payment_amount` decimal(19,2) DEFAULT NULL,
  `transaction_id` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `is_fulfilled` tinyint(1) DEFAULT NULL,
  `created_by` bigint(20) UNSIGNED DEFAULT NULL,
  `transaction_type` tinyint(1) DEFAULT NULL,
  `status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'active',
  `payment_method` varchar(30) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

-- --------------------------------------------------------

--
-- Table structure for table `wp_rg_lead_detail`
--

CREATE TABLE `wp_rg_lead_detail` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `lead_id` int(10) UNSIGNED NOT NULL,
  `form_id` mediumint(8) UNSIGNED NOT NULL,
  `field_number` float NOT NULL,
  `value` longtext COLLATE utf8mb4_unicode_520_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

-- --------------------------------------------------------

--
-- Table structure for table `wp_rg_lead_detail_long`
--

CREATE TABLE `wp_rg_lead_detail_long` (
  `lead_detail_id` bigint(20) UNSIGNED NOT NULL,
  `value` longtext COLLATE utf8mb4_unicode_520_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

-- --------------------------------------------------------

--
-- Table structure for table `wp_rg_lead_meta`
--

CREATE TABLE `wp_rg_lead_meta` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `form_id` mediumint(8) UNSIGNED NOT NULL DEFAULT '0',
  `lead_id` bigint(20) UNSIGNED NOT NULL,
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

-- --------------------------------------------------------

--
-- Table structure for table `wp_rg_lead_notes`
--

CREATE TABLE `wp_rg_lead_notes` (
  `id` int(10) UNSIGNED NOT NULL,
  `lead_id` int(10) UNSIGNED NOT NULL,
  `user_name` varchar(250) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `user_id` bigint(20) DEFAULT NULL,
  `date_created` datetime NOT NULL,
  `value` longtext COLLATE utf8mb4_unicode_520_ci,
  `note_type` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

-- --------------------------------------------------------

--
-- Table structure for table `wp_termmeta`
--

CREATE TABLE `wp_termmeta` (
  `meta_id` bigint(20) UNSIGNED NOT NULL,
  `term_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

-- --------------------------------------------------------

--
-- Table structure for table `wp_terms`
--

CREATE TABLE `wp_terms` (
  `term_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `slug` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `term_group` bigint(10) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Dumping data for table `wp_terms`
--

INSERT INTO `wp_terms` (`term_id`, `name`, `slug`, `term_group`) VALUES
(1, 'Uncategorized', 'uncategorized', 0),
(2, 'Main Menu', 'main-menu', 0);

-- --------------------------------------------------------

--
-- Table structure for table `wp_term_relationships`
--

CREATE TABLE `wp_term_relationships` (
  `object_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `term_taxonomy_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `term_order` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Dumping data for table `wp_term_relationships`
--

INSERT INTO `wp_term_relationships` (`object_id`, `term_taxonomy_id`, `term_order`) VALUES
(15, 1, 0),
(17, 1, 0),
(19, 1, 0),
(21, 1, 0),
(23, 1, 0),
(70, 2, 0),
(71, 2, 0),
(72, 2, 0),
(73, 2, 0),
(74, 2, 0),
(75, 2, 0),
(76, 2, 0),
(77, 2, 0),
(78, 2, 0),
(81, 2, 0),
(82, 2, 0),
(83, 2, 0);

-- --------------------------------------------------------

--
-- Table structure for table `wp_term_taxonomy`
--

CREATE TABLE `wp_term_taxonomy` (
  `term_taxonomy_id` bigint(20) UNSIGNED NOT NULL,
  `term_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `taxonomy` varchar(32) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `description` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `parent` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `count` bigint(20) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Dumping data for table `wp_term_taxonomy`
--

INSERT INTO `wp_term_taxonomy` (`term_taxonomy_id`, `term_id`, `taxonomy`, `description`, `parent`, `count`) VALUES
(1, 1, 'category', '', 0, 5),
(2, 2, 'nav_menu', '', 0, 12);

-- --------------------------------------------------------

--
-- Table structure for table `wp_usermeta`
--

CREATE TABLE `wp_usermeta` (
  `umeta_id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Dumping data for table `wp_usermeta`
--

INSERT INTO `wp_usermeta` (`umeta_id`, `user_id`, `meta_key`, `meta_value`) VALUES
(1, 1, 'nickname', 'joe'),
(2, 1, 'first_name', ''),
(3, 1, 'last_name', ''),
(4, 1, 'description', ''),
(5, 1, 'rich_editing', 'true'),
(6, 1, 'comment_shortcuts', 'false'),
(7, 1, 'admin_color', 'fresh'),
(8, 1, 'use_ssl', '0'),
(9, 1, 'show_admin_bar_front', 'true'),
(10, 1, 'locale', ''),
(11, 1, 'wp_capabilities', 'a:1:{s:13:\"administrator\";b:1;}'),
(12, 1, 'wp_user_level', '10'),
(13, 1, 'dismissed_wp_pointers', 'wp496_privacy'),
(14, 1, 'show_welcome_panel', '1'),
(15, 1, 'session_tokens', 'a:1:{s:64:\"3b3f0c277ff9cbd442381625310779a867f403cfdf560b42908d64efb899f98f\";a:4:{s:10:\"expiration\";i:1535304497;s:2:\"ip\";s:3:\"::1\";s:2:\"ua\";s:121:\"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36\";s:5:\"login\";i:1535131697;}}'),
(16, 1, 'wp_user-settings', 'hidetb=1&editor=tinymce&libraryContent=browse&imgsize=full&posts_list_mode=list&mfold=o'),
(17, 1, 'wp_user-settings-time', '1531250034'),
(18, 1, 'wp_dashboard_quick_press_last_post_id', '67'),
(19, 1, 'community-events-location', 'a:1:{s:2:\"ip\";s:2:\"::\";}'),
(20, 1, 'managenav-menuscolumnshidden', 'a:5:{i:0;s:11:\"link-target\";i:1;s:11:\"css-classes\";i:2;s:3:\"xfn\";i:3;s:11:\"description\";i:4;s:15:\"title-attribute\";}'),
(21, 1, 'metaboxhidden_nav-menus', 'a:1:{i:0;s:12:\"add-post_tag\";}'),
(22, 1, 'nav_menu_recently_edited', '2'),
(23, 1, 'syntax_highlighting', 'true');

-- --------------------------------------------------------

--
-- Table structure for table `wp_users`
--

CREATE TABLE `wp_users` (
  `ID` bigint(20) UNSIGNED NOT NULL,
  `user_login` varchar(60) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_pass` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_nicename` varchar(50) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_email` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_url` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_activation_key` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_status` int(11) NOT NULL DEFAULT '0',
  `display_name` varchar(250) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Dumping data for table `wp_users`
--

INSERT INTO `wp_users` (`ID`, `user_login`, `user_pass`, `user_nicename`, `user_email`, `user_url`, `user_registered`, `user_activation_key`, `user_status`, `display_name`) VALUES
(1, '1p21.admin', '$P$BuC8KR5MOXu/yqXl/MVslXPHQZ5KiG1', '1p21-admin', 'joe.t.oconnor@gmail.com', '', '2017-12-26 23:55:11', '', 0, '1p21.admin');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `wp_commentmeta`
--
ALTER TABLE `wp_commentmeta`
  ADD PRIMARY KEY (`meta_id`),
  ADD KEY `comment_id` (`comment_id`),
  ADD KEY `meta_key` (`meta_key`(191));

--
-- Indexes for table `wp_comments`
--
ALTER TABLE `wp_comments`
  ADD PRIMARY KEY (`comment_ID`),
  ADD KEY `comment_post_ID` (`comment_post_ID`),
  ADD KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  ADD KEY `comment_date_gmt` (`comment_date_gmt`),
  ADD KEY `comment_parent` (`comment_parent`),
  ADD KEY `comment_author_email` (`comment_author_email`(10));

--
-- Indexes for table `wp_gf_draft_submissions`
--
ALTER TABLE `wp_gf_draft_submissions`
  ADD PRIMARY KEY (`uuid`),
  ADD KEY `form_id` (`form_id`);

--
-- Indexes for table `wp_gf_entry`
--
ALTER TABLE `wp_gf_entry`
  ADD PRIMARY KEY (`id`),
  ADD KEY `form_id` (`form_id`),
  ADD KEY `form_id_status` (`form_id`,`status`);

--
-- Indexes for table `wp_gf_entry_meta`
--
ALTER TABLE `wp_gf_entry_meta`
  ADD PRIMARY KEY (`id`),
  ADD KEY `meta_key` (`meta_key`(191)),
  ADD KEY `entry_id` (`entry_id`),
  ADD KEY `meta_value` (`meta_value`(191));

--
-- Indexes for table `wp_gf_entry_notes`
--
ALTER TABLE `wp_gf_entry_notes`
  ADD PRIMARY KEY (`id`),
  ADD KEY `entry_id` (`entry_id`),
  ADD KEY `entry_user_key` (`entry_id`,`user_id`);

--
-- Indexes for table `wp_gf_form`
--
ALTER TABLE `wp_gf_form`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `wp_gf_form_meta`
--
ALTER TABLE `wp_gf_form_meta`
  ADD PRIMARY KEY (`form_id`);

--
-- Indexes for table `wp_gf_form_view`
--
ALTER TABLE `wp_gf_form_view`
  ADD PRIMARY KEY (`id`),
  ADD KEY `date_created` (`date_created`),
  ADD KEY `form_id` (`form_id`);

--
-- Indexes for table `wp_links`
--
ALTER TABLE `wp_links`
  ADD PRIMARY KEY (`link_id`),
  ADD KEY `link_visible` (`link_visible`);

--
-- Indexes for table `wp_options`
--
ALTER TABLE `wp_options`
  ADD PRIMARY KEY (`option_id`),
  ADD UNIQUE KEY `option_name` (`option_name`);

--
-- Indexes for table `wp_postmeta`
--
ALTER TABLE `wp_postmeta`
  ADD PRIMARY KEY (`meta_id`),
  ADD KEY `post_id` (`post_id`),
  ADD KEY `meta_key` (`meta_key`(191));

--
-- Indexes for table `wp_posts`
--
ALTER TABLE `wp_posts`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `post_name` (`post_name`(191)),
  ADD KEY `type_status_date` (`post_type`,`post_status`,`post_date`,`ID`),
  ADD KEY `post_parent` (`post_parent`),
  ADD KEY `post_author` (`post_author`);

--
-- Indexes for table `wp_rg_form`
--
ALTER TABLE `wp_rg_form`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `wp_rg_form_meta`
--
ALTER TABLE `wp_rg_form_meta`
  ADD PRIMARY KEY (`form_id`);

--
-- Indexes for table `wp_rg_form_view`
--
ALTER TABLE `wp_rg_form_view`
  ADD PRIMARY KEY (`id`),
  ADD KEY `form_id` (`form_id`),
  ADD KEY `date_created` (`date_created`);

--
-- Indexes for table `wp_rg_incomplete_submissions`
--
ALTER TABLE `wp_rg_incomplete_submissions`
  ADD PRIMARY KEY (`uuid`),
  ADD KEY `form_id` (`form_id`);

--
-- Indexes for table `wp_rg_lead`
--
ALTER TABLE `wp_rg_lead`
  ADD PRIMARY KEY (`id`),
  ADD KEY `form_id` (`form_id`),
  ADD KEY `status` (`status`);

--
-- Indexes for table `wp_rg_lead_detail`
--
ALTER TABLE `wp_rg_lead_detail`
  ADD PRIMARY KEY (`id`),
  ADD KEY `form_id` (`form_id`),
  ADD KEY `lead_id` (`lead_id`),
  ADD KEY `lead_field_number` (`lead_id`,`field_number`),
  ADD KEY `lead_field_value` (`value`(191));

--
-- Indexes for table `wp_rg_lead_detail_long`
--
ALTER TABLE `wp_rg_lead_detail_long`
  ADD PRIMARY KEY (`lead_detail_id`);

--
-- Indexes for table `wp_rg_lead_meta`
--
ALTER TABLE `wp_rg_lead_meta`
  ADD PRIMARY KEY (`id`),
  ADD KEY `lead_id` (`lead_id`);

--
-- Indexes for table `wp_rg_lead_notes`
--
ALTER TABLE `wp_rg_lead_notes`
  ADD PRIMARY KEY (`id`),
  ADD KEY `lead_id` (`lead_id`),
  ADD KEY `lead_user_key` (`lead_id`,`user_id`);

--
-- Indexes for table `wp_termmeta`
--
ALTER TABLE `wp_termmeta`
  ADD PRIMARY KEY (`meta_id`),
  ADD KEY `term_id` (`term_id`),
  ADD KEY `meta_key` (`meta_key`(191));

--
-- Indexes for table `wp_terms`
--
ALTER TABLE `wp_terms`
  ADD PRIMARY KEY (`term_id`),
  ADD KEY `slug` (`slug`(191)),
  ADD KEY `name` (`name`(191));

--
-- Indexes for table `wp_term_relationships`
--
ALTER TABLE `wp_term_relationships`
  ADD PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  ADD KEY `term_taxonomy_id` (`term_taxonomy_id`);

--
-- Indexes for table `wp_term_taxonomy`
--
ALTER TABLE `wp_term_taxonomy`
  ADD PRIMARY KEY (`term_taxonomy_id`),
  ADD UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  ADD KEY `taxonomy` (`taxonomy`);

--
-- Indexes for table `wp_usermeta`
--
ALTER TABLE `wp_usermeta`
  ADD PRIMARY KEY (`umeta_id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `meta_key` (`meta_key`(191));

--
-- Indexes for table `wp_users`
--
ALTER TABLE `wp_users`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `user_login_key` (`user_login`),
  ADD KEY `user_nicename` (`user_nicename`),
  ADD KEY `user_email` (`user_email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `wp_commentmeta`
--
ALTER TABLE `wp_commentmeta`
  MODIFY `meta_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wp_comments`
--
ALTER TABLE `wp_comments`
  MODIFY `comment_ID` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wp_gf_entry`
--
ALTER TABLE `wp_gf_entry`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wp_gf_entry_meta`
--
ALTER TABLE `wp_gf_entry_meta`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wp_gf_entry_notes`
--
ALTER TABLE `wp_gf_entry_notes`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wp_gf_form`
--
ALTER TABLE `wp_gf_form`
  MODIFY `id` mediumint(8) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `wp_gf_form_view`
--
ALTER TABLE `wp_gf_form_view`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wp_links`
--
ALTER TABLE `wp_links`
  MODIFY `link_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wp_options`
--
ALTER TABLE `wp_options`
  MODIFY `option_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=511;

--
-- AUTO_INCREMENT for table `wp_postmeta`
--
ALTER TABLE `wp_postmeta`
  MODIFY `meta_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=190;

--
-- AUTO_INCREMENT for table `wp_posts`
--
ALTER TABLE `wp_posts`
  MODIFY `ID` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=84;

--
-- AUTO_INCREMENT for table `wp_rg_form`
--
ALTER TABLE `wp_rg_form`
  MODIFY `id` mediumint(8) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `wp_rg_form_view`
--
ALTER TABLE `wp_rg_form_view`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wp_rg_lead`
--
ALTER TABLE `wp_rg_lead`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wp_rg_lead_detail`
--
ALTER TABLE `wp_rg_lead_detail`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wp_rg_lead_meta`
--
ALTER TABLE `wp_rg_lead_meta`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wp_rg_lead_notes`
--
ALTER TABLE `wp_rg_lead_notes`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wp_termmeta`
--
ALTER TABLE `wp_termmeta`
  MODIFY `meta_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wp_terms`
--
ALTER TABLE `wp_terms`
  MODIFY `term_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `wp_term_taxonomy`
--
ALTER TABLE `wp_term_taxonomy`
  MODIFY `term_taxonomy_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `wp_usermeta`
--
ALTER TABLE `wp_usermeta`
  MODIFY `umeta_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT for table `wp_users`
--
ALTER TABLE `wp_users`
  MODIFY `ID` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
