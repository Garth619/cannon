# WordPress MySQL database migration
#
# Generated: Friday 24. August 2018 22:08 UTC
# Hostname: localhost
# Database: `cannon`
# URL: //cannon-demo.com
# Path: /Applications/MAMP/htdocs/cannon
# Tables: wp_commentmeta, wp_comments, wp_gf_draft_submissions, wp_gf_entry, wp_gf_entry_meta, wp_gf_entry_notes, wp_gf_form, wp_gf_form_meta, wp_gf_form_view, wp_links, wp_options, wp_postmeta, wp_posts, wp_rg_form, wp_rg_form_meta, wp_rg_form_view, wp_rg_incomplete_submissions, wp_rg_lead, wp_rg_lead_detail, wp_rg_lead_detail_long, wp_rg_lead_meta, wp_rg_lead_notes, wp_term_relationships, wp_term_taxonomy, wp_termmeta, wp_terms, wp_usermeta, wp_users
# Table Prefix: wp_
# Post Types: revision, acf-field, acf-field-group, nav_menu_item, page, post
# Protocol: http
# Multisite: false
# Subsite Export: false
# --------------------------------------------------------

/*!40101 SET NAMES utf8mb4 */;

SET sql_mode='NO_AUTO_VALUE_ON_ZERO';



#
# Delete any existing table `wp_commentmeta`
#

DROP TABLE IF EXISTS `wp_commentmeta`;


#
# Table structure of table `wp_commentmeta`
#

CREATE TABLE `wp_commentmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`meta_id`),
  KEY `comment_id` (`comment_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_commentmeta`
#

#
# End of data contents of table `wp_commentmeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_comments`
#

DROP TABLE IF EXISTS `wp_comments`;


#
# Table structure of table `wp_comments`
#

CREATE TABLE `wp_comments` (
  `comment_ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_post_ID` bigint(20) unsigned NOT NULL DEFAULT '0',
  `comment_author` tinytext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `comment_author_email` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `comment_karma` int(11) NOT NULL DEFAULT '0',
  `comment_approved` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_type` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`comment_ID`),
  KEY `comment_post_ID` (`comment_post_ID`),
  KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  KEY `comment_date_gmt` (`comment_date_gmt`),
  KEY `comment_parent` (`comment_parent`),
  KEY `comment_author_email` (`comment_author_email`(10))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_comments`
#

#
# End of data contents of table `wp_comments`
# --------------------------------------------------------



#
# Delete any existing table `wp_gf_draft_submissions`
#

DROP TABLE IF EXISTS `wp_gf_draft_submissions`;


#
# Table structure of table `wp_gf_draft_submissions`
#

CREATE TABLE `wp_gf_draft_submissions` (
  `uuid` char(32) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `form_id` mediumint(8) unsigned NOT NULL,
  `date_created` datetime NOT NULL,
  `ip` varchar(39) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `source_url` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `submission` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  PRIMARY KEY (`uuid`),
  KEY `form_id` (`form_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_gf_draft_submissions`
#

#
# End of data contents of table `wp_gf_draft_submissions`
# --------------------------------------------------------



#
# Delete any existing table `wp_gf_entry`
#

DROP TABLE IF EXISTS `wp_gf_entry`;


#
# Table structure of table `wp_gf_entry`
#

CREATE TABLE `wp_gf_entry` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `form_id` mediumint(8) unsigned NOT NULL,
  `post_id` bigint(20) unsigned DEFAULT NULL,
  `date_created` datetime NOT NULL,
  `date_updated` datetime DEFAULT NULL,
  `is_starred` tinyint(1) NOT NULL DEFAULT '0',
  `is_read` tinyint(1) NOT NULL DEFAULT '0',
  `ip` varchar(39) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `source_url` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_agent` varchar(250) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `currency` varchar(5) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `payment_status` varchar(15) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `payment_date` datetime DEFAULT NULL,
  `payment_amount` decimal(19,2) DEFAULT NULL,
  `payment_method` varchar(30) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `transaction_id` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `is_fulfilled` tinyint(1) DEFAULT NULL,
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `transaction_type` tinyint(1) DEFAULT NULL,
  `status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'active',
  PRIMARY KEY (`id`),
  KEY `form_id` (`form_id`),
  KEY `form_id_status` (`form_id`,`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_gf_entry`
#

#
# End of data contents of table `wp_gf_entry`
# --------------------------------------------------------



#
# Delete any existing table `wp_gf_entry_meta`
#

DROP TABLE IF EXISTS `wp_gf_entry_meta`;


#
# Table structure of table `wp_gf_entry_meta`
#

CREATE TABLE `wp_gf_entry_meta` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `form_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `entry_id` bigint(20) unsigned NOT NULL,
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`id`),
  KEY `meta_key` (`meta_key`(191)),
  KEY `entry_id` (`entry_id`),
  KEY `meta_value` (`meta_value`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_gf_entry_meta`
#

#
# End of data contents of table `wp_gf_entry_meta`
# --------------------------------------------------------



#
# Delete any existing table `wp_gf_entry_notes`
#

DROP TABLE IF EXISTS `wp_gf_entry_notes`;


#
# Table structure of table `wp_gf_entry_notes`
#

CREATE TABLE `wp_gf_entry_notes` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `entry_id` int(10) unsigned NOT NULL,
  `user_name` varchar(250) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `user_id` bigint(20) DEFAULT NULL,
  `date_created` datetime NOT NULL,
  `value` longtext COLLATE utf8mb4_unicode_520_ci,
  `note_type` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `sub_type` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `entry_id` (`entry_id`),
  KEY `entry_user_key` (`entry_id`,`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_gf_entry_notes`
#

#
# End of data contents of table `wp_gf_entry_notes`
# --------------------------------------------------------



#
# Delete any existing table `wp_gf_form`
#

DROP TABLE IF EXISTS `wp_gf_form`;


#
# Table structure of table `wp_gf_form`
#

CREATE TABLE `wp_gf_form` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(150) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `date_created` datetime NOT NULL,
  `date_updated` datetime DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `is_trash` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_gf_form`
#
INSERT INTO `wp_gf_form` ( `id`, `title`, `date_created`, `date_updated`, `is_active`, `is_trash`) VALUES
(1, 'Contact', '2018-01-23 02:49:42', NULL, 1, 0) ;

#
# End of data contents of table `wp_gf_form`
# --------------------------------------------------------



#
# Delete any existing table `wp_gf_form_meta`
#

DROP TABLE IF EXISTS `wp_gf_form_meta`;


#
# Table structure of table `wp_gf_form_meta`
#

CREATE TABLE `wp_gf_form_meta` (
  `form_id` mediumint(8) unsigned NOT NULL,
  `display_meta` longtext COLLATE utf8mb4_unicode_520_ci,
  `entries_grid_meta` longtext COLLATE utf8mb4_unicode_520_ci,
  `confirmations` longtext COLLATE utf8mb4_unicode_520_ci,
  `notifications` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`form_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_gf_form_meta`
#
INSERT INTO `wp_gf_form_meta` ( `form_id`, `display_meta`, `entries_grid_meta`, `confirmations`, `notifications`) VALUES
(1, '{"title":"Contact","description":"","labelPlacement":"top_label","descriptionPlacement":"below","button":{"type":"text","text":"Submit","imageUrl":""},"fields":[],"version":"2.2.5","id":1,"notifications":{"5a66a2c69111e":{"id":"5a66a2c69111e","to":"{admin_email}","name":"Admin Notification","event":"form_submission","toType":"email","subject":"New submission from {form_title}","message":"{all_fields}"}},"confirmations":{"5a66a2c69162e":{"id":"5a66a2c69162e","name":"Default Confirmation","isDefault":true,"type":"message","message":"Thanks for contacting us! We will get in touch with you shortly.","url":"","pageId":"","queryString":""}},"subLabelPlacement":"below","cssClass":"","enableHoneypot":true,"enableAnimation":false,"save":{"enabled":false,"button":{"type":"link","text":"Save and Continue Later"}},"limitEntries":false,"limitEntriesCount":"","limitEntriesPeriod":"","limitEntriesMessage":"","scheduleForm":false,"scheduleStart":"","scheduleStartHour":"","scheduleStartMinute":"","scheduleStartAmpm":"","scheduleEnd":"","scheduleEndHour":"","scheduleEndMinute":"","scheduleEndAmpm":"","schedulePendingMessage":"","scheduleMessage":"","requireLogin":false,"requireLoginMessage":""}', NULL, '{"5a66a2c69162e":{"id":"5a66a2c69162e","name":"Default Confirmation","isDefault":true,"type":"page","message":"Thanks for contacting us! We will get in touch with you shortly.","url":"","pageId":37,"queryString":"","disableAutoformat":false,"conditionalLogic":[]}}', '{"5a66a2c69111e":{"isActive":true,"id":"5a66a2c69111e","name":"Admin Notification","service":"wordpress","event":"form_submission","to":"joe@1point21interactive.com","toType":"email","bcc":"","subject":"{Name:1} - Case Evaluation inquiry from clientname.com","message":"<div align=\\"center\\"><img src=\\"http:\\/\\/www.ilawyermarketing.com\\/images\\/ilawyerlogo.jpg\\" alt=\\"Website lead from iLawyerMarketing\\" \\/><\\/div>\\r\\n{all_fields}","from":"noreply@ilawyermarketing.org","fromName":"Clientwebsite.com","replyTo":"{Email: 3}","routing":null,"conditionalLogic":null,"disableAutoformat":false}}') ;

#
# End of data contents of table `wp_gf_form_meta`
# --------------------------------------------------------



#
# Delete any existing table `wp_gf_form_view`
#

DROP TABLE IF EXISTS `wp_gf_form_view`;


#
# Table structure of table `wp_gf_form_view`
#

CREATE TABLE `wp_gf_form_view` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `form_id` mediumint(8) unsigned NOT NULL,
  `date_created` datetime NOT NULL,
  `ip` char(15) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `count` mediumint(8) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `date_created` (`date_created`),
  KEY `form_id` (`form_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_gf_form_view`
#

#
# End of data contents of table `wp_gf_form_view`
# --------------------------------------------------------



#
# Delete any existing table `wp_links`
#

DROP TABLE IF EXISTS `wp_links`;


#
# Table structure of table `wp_links`
#

CREATE TABLE `wp_links` (
  `link_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `link_url` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_name` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_image` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_target` varchar(25) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_description` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_visible` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'Y',
  `link_owner` bigint(20) unsigned NOT NULL DEFAULT '1',
  `link_rating` int(11) NOT NULL DEFAULT '0',
  `link_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `link_rel` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_notes` mediumtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `link_rss` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`link_id`),
  KEY `link_visible` (`link_visible`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_links`
#

#
# End of data contents of table `wp_links`
# --------------------------------------------------------



#
# Delete any existing table `wp_options`
#

DROP TABLE IF EXISTS `wp_options`;


#
# Table structure of table `wp_options`
#

CREATE TABLE `wp_options` (
  `option_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `option_name` varchar(191) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `option_value` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `autoload` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'yes',
  PRIMARY KEY (`option_id`),
  UNIQUE KEY `option_name` (`option_name`)
) ENGINE=InnoDB AUTO_INCREMENT=499 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_options`
#
INSERT INTO `wp_options` ( `option_id`, `option_name`, `option_value`, `autoload`) VALUES
(1, 'siteurl', 'http://cannon-demo.com', 'yes'),
(2, 'home', 'http://cannon-demo.com', 'yes'),
(3, 'blogname', 'Cannon &amp; Dunphy S.C.', 'yes'),
(4, 'blogdescription', '', 'yes'),
(5, 'users_can_register', '0', 'yes'),
(6, 'admin_email', 'joe.t.oconnor@gmail.com', 'yes'),
(7, 'start_of_week', '1', 'yes'),
(8, 'use_balanceTags', '0', 'yes'),
(9, 'use_smilies', '1', 'yes'),
(10, 'require_name_email', '1', 'yes'),
(11, 'comments_notify', '1', 'yes'),
(12, 'posts_per_rss', '10', 'yes'),
(13, 'rss_use_excerpt', '0', 'yes'),
(14, 'mailserver_url', 'mail.example.com', 'yes'),
(15, 'mailserver_login', 'login@example.com', 'yes'),
(16, 'mailserver_pass', 'password', 'yes'),
(17, 'mailserver_port', '110', 'yes'),
(18, 'default_category', '1', 'yes'),
(19, 'default_comment_status', 'open', 'yes'),
(20, 'default_ping_status', 'open', 'yes'),
(21, 'default_pingback_flag', '1', 'yes'),
(22, 'posts_per_page', '10', 'yes'),
(23, 'date_format', 'F j, Y', 'yes'),
(24, 'time_format', 'g:i a', 'yes'),
(25, 'links_updated_date_format', 'F j, Y g:i a', 'yes'),
(26, 'comment_moderation', '0', 'yes'),
(27, 'moderation_notify', '1', 'yes'),
(28, 'permalink_structure', '/%postname%/', 'yes'),
(29, 'rewrite_rules', 'a:88:{s:11:"^wp-json/?$";s:22:"index.php?rest_route=/";s:14:"^wp-json/(.*)?";s:33:"index.php?rest_route=/$matches[1]";s:21:"^index.php/wp-json/?$";s:22:"index.php?rest_route=/";s:24:"^index.php/wp-json/(.*)?";s:33:"index.php?rest_route=/$matches[1]";s:47:"category/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:42:"category/(.+?)/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:23:"category/(.+?)/embed/?$";s:46:"index.php?category_name=$matches[1]&embed=true";s:35:"category/(.+?)/page/?([0-9]{1,})/?$";s:53:"index.php?category_name=$matches[1]&paged=$matches[2]";s:17:"category/(.+?)/?$";s:35:"index.php?category_name=$matches[1]";s:44:"tag/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:39:"tag/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:20:"tag/([^/]+)/embed/?$";s:36:"index.php?tag=$matches[1]&embed=true";s:32:"tag/([^/]+)/page/?([0-9]{1,})/?$";s:43:"index.php?tag=$matches[1]&paged=$matches[2]";s:14:"tag/([^/]+)/?$";s:25:"index.php?tag=$matches[1]";s:45:"type/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:40:"type/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:21:"type/([^/]+)/embed/?$";s:44:"index.php?post_format=$matches[1]&embed=true";s:33:"type/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?post_format=$matches[1]&paged=$matches[2]";s:15:"type/([^/]+)/?$";s:33:"index.php?post_format=$matches[1]";s:12:"robots\\.txt$";s:18:"index.php?robots=1";s:48:".*wp-(atom|rdf|rss|rss2|feed|commentsrss2)\\.php$";s:18:"index.php?feed=old";s:20:".*wp-app\\.php(/.*)?$";s:19:"index.php?error=403";s:18:".*wp-register.php$";s:23:"index.php?register=true";s:32:"feed/(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:27:"(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:8:"embed/?$";s:21:"index.php?&embed=true";s:20:"page/?([0-9]{1,})/?$";s:28:"index.php?&paged=$matches[1]";s:27:"comment-page-([0-9]{1,})/?$";s:39:"index.php?&page_id=10&cpage=$matches[1]";s:41:"comments/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:36:"comments/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:17:"comments/embed/?$";s:21:"index.php?&embed=true";s:44:"search/(.+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:39:"search/(.+)/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:20:"search/(.+)/embed/?$";s:34:"index.php?s=$matches[1]&embed=true";s:32:"search/(.+)/page/?([0-9]{1,})/?$";s:41:"index.php?s=$matches[1]&paged=$matches[2]";s:14:"search/(.+)/?$";s:23:"index.php?s=$matches[1]";s:47:"author/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:42:"author/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:23:"author/([^/]+)/embed/?$";s:44:"index.php?author_name=$matches[1]&embed=true";s:35:"author/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?author_name=$matches[1]&paged=$matches[2]";s:17:"author/([^/]+)/?$";s:33:"index.php?author_name=$matches[1]";s:69:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:64:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:45:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/embed/?$";s:74:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&embed=true";s:57:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:81:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&paged=$matches[4]";s:39:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/?$";s:63:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]";s:56:"([0-9]{4})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:51:"([0-9]{4})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:32:"([0-9]{4})/([0-9]{1,2})/embed/?$";s:58:"index.php?year=$matches[1]&monthnum=$matches[2]&embed=true";s:44:"([0-9]{4})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:65:"index.php?year=$matches[1]&monthnum=$matches[2]&paged=$matches[3]";s:26:"([0-9]{4})/([0-9]{1,2})/?$";s:47:"index.php?year=$matches[1]&monthnum=$matches[2]";s:43:"([0-9]{4})/feed/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:38:"([0-9]{4})/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:19:"([0-9]{4})/embed/?$";s:37:"index.php?year=$matches[1]&embed=true";s:31:"([0-9]{4})/page/?([0-9]{1,})/?$";s:44:"index.php?year=$matches[1]&paged=$matches[2]";s:13:"([0-9]{4})/?$";s:26:"index.php?year=$matches[1]";s:27:".?.+?/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:37:".?.+?/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:57:".?.+?/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:".?.+?/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:".?.+?/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:33:".?.+?/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:16:"(.?.+?)/embed/?$";s:41:"index.php?pagename=$matches[1]&embed=true";s:20:"(.?.+?)/trackback/?$";s:35:"index.php?pagename=$matches[1]&tb=1";s:40:"(.?.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:35:"(.?.+?)/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:28:"(.?.+?)/page/?([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&paged=$matches[2]";s:35:"(.?.+?)/comment-page-([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&cpage=$matches[2]";s:24:"(.?.+?)(?:/([0-9]+))?/?$";s:47:"index.php?pagename=$matches[1]&page=$matches[2]";s:27:"[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:37:"[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:57:"[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:"[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:"[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:33:"[^/]+/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:16:"([^/]+)/embed/?$";s:37:"index.php?name=$matches[1]&embed=true";s:20:"([^/]+)/trackback/?$";s:31:"index.php?name=$matches[1]&tb=1";s:40:"([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?name=$matches[1]&feed=$matches[2]";s:35:"([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?name=$matches[1]&feed=$matches[2]";s:28:"([^/]+)/page/?([0-9]{1,})/?$";s:44:"index.php?name=$matches[1]&paged=$matches[2]";s:35:"([^/]+)/comment-page-([0-9]{1,})/?$";s:44:"index.php?name=$matches[1]&cpage=$matches[2]";s:24:"([^/]+)(?:/([0-9]+))?/?$";s:43:"index.php?name=$matches[1]&page=$matches[2]";s:16:"[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:26:"[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:46:"[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:41:"[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:41:"[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:22:"[^/]+/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";}', 'yes'),
(30, 'hack_file', '0', 'yes'),
(31, 'blog_charset', 'UTF-8', 'yes'),
(32, 'moderation_keys', '', 'no'),
(33, 'active_plugins', 'a:6:{i:0;s:29:"gravityforms/gravityforms.php";i:1;s:57:"advanced-custom-fields-nav-menu-field/fz-acf-nav-menu.php";i:2;s:34:"advanced-custom-fields-pro/acf.php";i:3;s:19:"akismet/akismet.php";i:4;s:19:"mailgun/mailgun.php";i:5;s:39:"wp-migrate-db-pro/wp-migrate-db-pro.php";}', 'yes'),
(34, 'category_base', '', 'yes'),
(35, 'ping_sites', '', 'yes'),
(36, 'comment_max_links', '2', 'yes'),
(37, 'gmt_offset', '-8', 'yes'),
(38, 'default_email_category', '1', 'yes'),
(39, 'recently_edited', '', 'no'),
(40, 'template', 'cannon-dunphy', 'yes'),
(41, 'stylesheet', 'cannon-dunphy', 'yes'),
(42, 'comment_whitelist', '1', 'yes'),
(43, 'blacklist_keys', '', 'no'),
(44, 'comment_registration', '0', 'yes'),
(45, 'html_type', 'text/html', 'yes'),
(46, 'use_trackback', '0', 'yes'),
(47, 'default_role', 'subscriber', 'yes'),
(48, 'db_version', '38590', 'yes'),
(49, 'uploads_use_yearmonth_folders', '1', 'yes'),
(50, 'upload_path', '', 'yes'),
(51, 'blog_public', '0', 'yes'),
(52, 'default_link_category', '0', 'yes'),
(53, 'show_on_front', 'page', 'yes'),
(54, 'tag_base', '', 'yes'),
(55, 'show_avatars', '1', 'yes'),
(56, 'avatar_rating', 'G', 'yes'),
(57, 'upload_url_path', '', 'yes'),
(58, 'thumbnail_size_w', '150', 'yes'),
(59, 'thumbnail_size_h', '150', 'yes'),
(60, 'thumbnail_crop', '1', 'yes'),
(61, 'medium_size_w', '300', 'yes'),
(62, 'medium_size_h', '300', 'yes'),
(63, 'avatar_default', 'mystery', 'yes'),
(64, 'large_size_w', '1024', 'yes'),
(65, 'large_size_h', '1024', 'yes'),
(66, 'image_default_link_type', 'none', 'yes'),
(67, 'image_default_size', '', 'yes'),
(68, 'image_default_align', '', 'yes'),
(69, 'close_comments_for_old_posts', '0', 'yes'),
(70, 'close_comments_days_old', '14', 'yes'),
(71, 'thread_comments', '1', 'yes'),
(72, 'thread_comments_depth', '5', 'yes'),
(73, 'page_comments', '0', 'yes'),
(74, 'comments_per_page', '50', 'yes'),
(75, 'default_comments_page', 'newest', 'yes'),
(76, 'comment_order', 'asc', 'yes'),
(77, 'sticky_posts', 'a:0:{}', 'yes'),
(78, 'widget_categories', 'a:2:{i:2;a:4:{s:5:"title";s:0:"";s:5:"count";i:0;s:12:"hierarchical";i:0;s:8:"dropdown";i:0;}s:12:"_multiwidget";i:1;}', 'yes'),
(79, 'widget_text', 'a:0:{}', 'yes'),
(80, 'widget_rss', 'a:0:{}', 'yes'),
(81, 'uninstall_plugins', 'a:0:{}', 'no'),
(82, 'timezone_string', '', 'yes'),
(83, 'page_for_posts', '12', 'yes'),
(84, 'page_on_front', '10', 'yes'),
(85, 'default_post_format', '0', 'yes'),
(86, 'link_manager_enabled', '0', 'yes'),
(87, 'finished_splitting_shared_terms', '1', 'yes'),
(88, 'site_icon', '0', 'yes'),
(89, 'medium_large_size_w', '768', 'yes'),
(90, 'medium_large_size_h', '0', 'yes'),
(91, 'initial_db_version', '38590', 'yes'),
(92, 'wp_user_roles', 'a:5:{s:13:"administrator";a:2:{s:4:"name";s:13:"Administrator";s:12:"capabilities";a:61:{s:13:"switch_themes";b:1;s:11:"edit_themes";b:1;s:16:"activate_plugins";b:1;s:12:"edit_plugins";b:1;s:10:"edit_users";b:1;s:10:"edit_files";b:1;s:14:"manage_options";b:1;s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:6:"import";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:8:"level_10";b:1;s:7:"level_9";b:1;s:7:"level_8";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;s:12:"delete_users";b:1;s:12:"create_users";b:1;s:17:"unfiltered_upload";b:1;s:14:"edit_dashboard";b:1;s:14:"update_plugins";b:1;s:14:"delete_plugins";b:1;s:15:"install_plugins";b:1;s:13:"update_themes";b:1;s:14:"install_themes";b:1;s:11:"update_core";b:1;s:10:"list_users";b:1;s:12:"remove_users";b:1;s:13:"promote_users";b:1;s:18:"edit_theme_options";b:1;s:13:"delete_themes";b:1;s:6:"export";b:1;}}s:6:"editor";a:2:{s:4:"name";s:6:"Editor";s:12:"capabilities";a:34:{s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;}}s:6:"author";a:2:{s:4:"name";s:6:"Author";s:12:"capabilities";a:10:{s:12:"upload_files";b:1;s:10:"edit_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:4:"read";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;s:22:"delete_published_posts";b:1;}}s:11:"contributor";a:2:{s:4:"name";s:11:"Contributor";s:12:"capabilities";a:5:{s:10:"edit_posts";b:1;s:4:"read";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;}}s:10:"subscriber";a:2:{s:4:"name";s:10:"Subscriber";s:12:"capabilities";a:2:{s:4:"read";b:1;s:7:"level_0";b:1;}}}', 'yes'),
(93, 'fresh_site', '0', 'yes'),
(94, 'widget_search', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(95, 'widget_recent-posts', 'a:2:{i:2;a:2:{s:5:"title";s:0:"";s:6:"number";i:5;}s:12:"_multiwidget";i:1;}', 'yes'),
(96, 'widget_recent-comments', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(97, 'widget_archives', 'a:2:{i:2;a:3:{s:5:"title";s:0:"";s:5:"count";i:0;s:8:"dropdown";i:0;}s:12:"_multiwidget";i:1;}', 'yes'),
(98, 'widget_meta', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(99, 'sidebars_widgets', 'a:5:{s:19:"wp_inactive_widgets";a:0:{}s:7:"sidebar";a:3:{i:0;s:14:"recent-posts-2";i:1;s:12:"categories-2";i:2;s:10:"archives-2";}s:16:"category_sidebar";a:0:{}s:15:"archive_sidebar";a:0:{}s:13:"array_version";i:3;}', 'yes'),
(100, 'widget_pages', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes') ;
INSERT INTO `wp_options` ( `option_id`, `option_name`, `option_value`, `autoload`) VALUES
(101, 'widget_calendar', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(102, 'widget_media_audio', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(103, 'widget_media_image', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(104, 'widget_media_video', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(105, 'widget_tag_cloud', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(106, 'widget_nav_menu', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(107, 'cron', 'a:7:{i:1535149049;a:1:{s:34:"wp_privacy_delete_old_export_files";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:6:"hourly";s:4:"args";a:0:{}s:8:"interval";i:3600;}}}i:1535154911;a:3:{s:16:"wp_version_check";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:17:"wp_update_plugins";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:16:"wp_update_themes";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1535154924;a:1:{s:19:"wp_scheduled_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1535154936;a:1:{s:25:"delete_expired_transients";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1535155021;a:1:{s:17:"gravityforms_cron";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1535155304;a:1:{s:30:"wp_scheduled_auto_draft_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}s:7:"version";i:2;}', 'yes'),
(115, 'auth_key', 'K=3.iXnFZ [w&.2`S$kAD A@T^>g-U5E8om8tSv65JCiR};p13v!tT{Kb!L0&8eN', 'no'),
(116, 'auth_salt', 't-+MqB8q;PKo6_r6p<_(qQ1zzGNk:X(>U:#rY~JQ,kXdDY!Rj7I>rWbcf$9vR~cs', 'no'),
(117, 'logged_in_key', 'OsQxav}hN|Mn1`^c_|#S44R:Mb#Ya(Ofv%pV%jlt:9^*Jam|@;(,bsQkn)3#^?)R', 'no'),
(118, 'logged_in_salt', '{1W,O]W2qY3@~isBHBq[mW&-Tb>a{IunM~`SaMKB!6;kShfM1zxd8g@X[/L@|z`L', 'no'),
(120, 'nonce_key', '#PDsB]U|n}Vjk:?4TM-,k?V].s[vwflLa25vI-& }Li&]m#>mYczNkb]%ml_HwTU', 'no'),
(121, 'nonce_salt', 'tK^$AahAb0V}x<U?G{4yKZLIq:D3c&T8lHN@5J|IR/T;77M5lC<91}a|TjcpXuuF', 'no'),
(124, 'can_compress_scripts', '0', 'no'),
(139, 'widget_media_gallery', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(140, 'widget_custom_html', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(146, 'recently_activated', 'a:0:{}', 'yes'),
(148, 'mailgun', 'a:12:{s:6:"useAPI";s:1:"1";s:6:"domain";s:20:"ilawyermarketing.org";s:6:"apiKey";s:36:"key-3b836150d2968b324f4b8471feeeb3c1";s:8:"username";s:0:"";s:8:"password";s:0:"";s:6:"secure";s:1:"1";s:12:"track-clicks";s:8:"htmlonly";s:11:"track-opens";s:1:"1";s:12:"from-address";s:28:"noreply@ilawyermarketing.org";s:9:"from-name";s:28:""Client/Site Name" + Website";s:13:"override-from";N;s:11:"campaign-id";s:0:"";}', 'yes'),
(149, 'widget_akismet_widget', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(150, 'widget_gform_widget', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(151, 'widget_list_widget', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(152, 'rg_form_version', '2.3.2', 'yes'),
(155, 'acf_version', '5.6.10', 'yes'),
(156, 'rg_gforms_key', '621e21584ab7936611e0d28422299c97', 'yes'),
(157, 'rg_gforms_disable_css', '1', 'yes'),
(158, 'rg_gforms_enable_html5', '', 'yes'),
(159, 'gform_enable_noconflict', '', 'yes'),
(160, 'rg_gforms_enable_akismet', '1', 'yes'),
(161, 'rg_gforms_captcha_public_key', '', 'yes'),
(162, 'rg_gforms_captcha_private_key', '', 'yes'),
(163, 'rg_gforms_currency', 'USD', 'yes'),
(164, 'rg_gforms_message', '<!--GFM-->', 'yes'),
(166, 'gravityformsaddon_gravityformswebapi_version', '1.0', 'yes'),
(167, 'gf_is_upgrading', '0', 'yes'),
(168, 'gf_previous_db_version', '2.2.5', 'yes'),
(175, 'acf_pro_license', 'YToyOntzOjM6ImtleSI7czo3MjoiYjNKa1pYSmZhV1E5TXpZd01EaDhkSGx3WlQxa1pYWmxiRzl3WlhKOFpHRjBaVDB5TURFMExUQTNMVEk0SURJd09qVXlPak0zIjtzOjM6InVybCI7czoyMToiaHR0cDovL2xvY2FsaG9zdDo4ODg4Ijt9', 'yes'),
(182, 'akismet_strictness', '0', 'yes'),
(183, 'akismet_show_user_comments_approved', '0', 'yes'),
(184, 'wordpress_api_key', '46c90999075a', 'yes'),
(185, 'akismet_spam_count', '2', 'yes'),
(201, 'theme_mods_twentyseventeen', 'a:1:{s:16:"sidebars_widgets";a:2:{s:4:"time";i:1514333141;s:4:"data";a:4:{s:19:"wp_inactive_widgets";a:0:{}s:9:"sidebar-1";a:6:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";}s:9:"sidebar-2";a:0:{}s:9:"sidebar-3";a:0:{}}}}', 'yes'),
(202, 'current_theme', '', 'yes'),
(203, 'theme_mods_joe-blank-theme', 'a:4:{i:0;b:0;s:18:"nav_menu_locations";a:0:{}s:18:"custom_css_post_id";i:-1;s:16:"sidebars_widgets";a:2:{s:4:"time";i:1534890347;s:4:"data";a:2:{s:19:"wp_inactive_widgets";a:0:{}s:12:"blog_sidebar";a:3:{i:0;s:14:"recent-posts-2";i:1;s:12:"categories-2";i:2;s:10:"archives-2";}}}}', 'yes'),
(204, 'theme_switched', '', 'yes'),
(283, 'category_children', 'a:0:{}', 'yes'),
(372, 'WPLANG', '', 'yes'),
(373, 'new_admin_email', 'joe.t.oconnor@gmail.com', 'yes'),
(402, 'gf_upgrade_lock', '', 'yes'),
(403, 'gform_sticky_admin_messages', 'a:0:{}', 'yes'),
(407, 'gf_submissions_block', '', 'yes'),
(408, 'gf_db_version', '2.3.2', 'yes'),
(409, 'gform_version_info', 'a:10:{s:12:"is_valid_key";b:1;s:6:"reason";s:0:"";s:7:"version";s:5:"2.3.3";s:3:"url";s:170:"http://s3.amazonaws.com/gravityforms/releases/gravityforms_2.3.3.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1535294575&Signature=a%2BN%2F%2F6BBOOaxJy6kxouU3M9Qoac%3D";s:15:"expiration_time";i:1538456400;s:9:"offerings";a:46:{s:12:"gravityforms";a:5:{s:12:"is_available";b:1;s:7:"version";s:5:"2.3.3";s:14:"version_latest";s:7:"2.3.3.6";s:3:"url";s:170:"http://s3.amazonaws.com/gravityforms/releases/gravityforms_2.3.3.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1535294575&Signature=a%2BN%2F%2F6BBOOaxJy6kxouU3M9Qoac%3D";s:10:"url_latest";s:168:"http://s3.amazonaws.com/gravityforms/releases/gravityforms_2.3.3.6.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1535294575&Signature=qkAmKL5QKDVRMNCyu%2BrcEdmpgVg%3D";}s:26:"gravityformsactivecampaign";a:5:{s:12:"is_available";b:1;s:7:"version";s:3:"1.4";s:14:"version_latest";s:5:"1.4.5";s:3:"url";s:189:"http://s3.amazonaws.com/gravityforms/addons/activecampaign/gravityformsactivecampaign_1.4.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1535294575&Signature=z6I3ixwbWd3E5JEs2LID7eeDRNs%3D";s:10:"url_latest";s:191:"http://s3.amazonaws.com/gravityforms/addons/activecampaign/gravityformsactivecampaign_1.4.5.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1535294575&Signature=DtGfIchIh03INHhfVahRWZBX0LE%3D";}s:20:"gravityformsagilecrm";a:5:{s:12:"is_available";b:1;s:7:"version";s:3:"1.2";s:14:"version_latest";s:3:"1.2";s:3:"url";s:177:"http://s3.amazonaws.com/gravityforms/addons/agilecrm/gravityformsagilecrm_1.2.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1535294575&Signature=iD5MMnW4PRe753xaE9QbA84Cezg%3D";s:10:"url_latest";s:177:"http://s3.amazonaws.com/gravityforms/addons/agilecrm/gravityformsagilecrm_1.2.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1535294575&Signature=iD5MMnW4PRe753xaE9QbA84Cezg%3D";}s:24:"gravityformsauthorizenet";a:5:{s:12:"is_available";b:1;s:7:"version";s:3:"2.6";s:14:"version_latest";s:3:"2.6";s:3:"url";s:189:"http://s3.amazonaws.com/gravityforms/addons/authorizenet/gravityformsauthorizenet_2.6.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1535294575&Signature=78wWueaP4UxJctlqjbUjH%2FRKt%2B4%3D";s:10:"url_latest";s:189:"http://s3.amazonaws.com/gravityforms/addons/authorizenet/gravityformsauthorizenet_2.6.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1535294575&Signature=78wWueaP4UxJctlqjbUjH%2FRKt%2B4%3D";}s:18:"gravityformsaweber";a:5:{s:12:"is_available";b:1;s:7:"version";s:3:"2.7";s:14:"version_latest";s:5:"2.7.1";s:3:"url";s:175:"http://s3.amazonaws.com/gravityforms/addons/aweber/gravityformsaweber_2.7.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1535294575&Signature=ZBd9uoikMoETaFHMwuKFw%2BojReE%3D";s:10:"url_latest";s:175:"http://s3.amazonaws.com/gravityforms/addons/aweber/gravityformsaweber_2.7.1.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1535294575&Signature=ZSMO6an3fr3mpF41x5a3T70O7P4%3D";}s:21:"gravityformsbatchbook";a:5:{s:12:"is_available";b:1;s:7:"version";s:3:"1.3";s:14:"version_latest";s:3:"1.3";s:3:"url";s:181:"http://s3.amazonaws.com/gravityforms/addons/batchbook/gravityformsbatchbook_1.3.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1535294575&Signature=o0CAtCiQoz%2BSLd9uGvLLfPv2lNs%3D";s:10:"url_latest";s:181:"http://s3.amazonaws.com/gravityforms/addons/batchbook/gravityformsbatchbook_1.3.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1535294575&Signature=o0CAtCiQoz%2BSLd9uGvLLfPv2lNs%3D";}s:18:"gravityformsbreeze";a:5:{s:12:"is_available";b:1;s:7:"version";s:3:"1.3";s:14:"version_latest";s:3:"1.3";s:3:"url";s:173:"http://s3.amazonaws.com/gravityforms/addons/breeze/gravityformsbreeze_1.3.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1535294575&Signature=7OIXywtkdUaiaWgWVabdUCRbAHQ%3D";s:10:"url_latest";s:173:"http://s3.amazonaws.com/gravityforms/addons/breeze/gravityformsbreeze_1.3.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1535294575&Signature=7OIXywtkdUaiaWgWVabdUCRbAHQ%3D";}s:27:"gravityformscampaignmonitor";a:5:{s:12:"is_available";b:1;s:7:"version";s:3:"3.7";s:14:"version_latest";s:3:"3.7";s:3:"url";s:191:"http://s3.amazonaws.com/gravityforms/addons/campaignmonitor/gravityformscampaignmonitor_3.7.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1535294575&Signature=MxzafldHRjCvBNbMPtTeYWlYCVc%3D";s:10:"url_latest";s:191:"http://s3.amazonaws.com/gravityforms/addons/campaignmonitor/gravityformscampaignmonitor_3.7.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1535294575&Signature=MxzafldHRjCvBNbMPtTeYWlYCVc%3D";}s:20:"gravityformscampfire";a:5:{s:12:"is_available";b:1;s:7:"version";s:3:"1.1";s:14:"version_latest";s:5:"1.2.1";s:3:"url";s:177:"http://s3.amazonaws.com/gravityforms/addons/campfire/gravityformscampfire_1.1.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1535294575&Signature=bGCxAdy2BeamhR58N4qGcAgd384%3D";s:10:"url_latest";s:179:"http://s3.amazonaws.com/gravityforms/addons/campfire/gravityformscampfire_1.2.1.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1535294575&Signature=TcbgB8OewH0pH084NCrywq5hGCI%3D";}s:22:"gravityformscapsulecrm";a:5:{s:12:"is_available";b:1;s:7:"version";s:3:"1.3";s:14:"version_latest";s:3:"1.3";s:3:"url";s:185:"http://s3.amazonaws.com/gravityforms/addons/capsulecrm/gravityformscapsulecrm_1.3.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1535294575&Signature=N28OBGe9EvKvPjIfgZGr9F%2BGF%2Bs%3D";s:10:"url_latest";s:185:"http://s3.amazonaws.com/gravityforms/addons/capsulecrm/gravityformscapsulecrm_1.3.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1535294575&Signature=N28OBGe9EvKvPjIfgZGr9F%2BGF%2Bs%3D";}s:26:"gravityformschainedselects";a:5:{s:12:"is_available";b:1;s:7:"version";s:3:"1.1";s:14:"version_latest";s:3:"1.1";s:3:"url";s:191:"http://s3.amazonaws.com/gravityforms/addons/chainedselects/gravityformschainedselects_1.1.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1535294575&Signature=a%2BBIcziSjovwN3aJFbSmrvH8dZY%3D";s:10:"url_latest";s:191:"http://s3.amazonaws.com/gravityforms/addons/chainedselects/gravityformschainedselects_1.1.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1535294575&Signature=a%2BBIcziSjovwN3aJFbSmrvH8dZY%3D";}s:23:"gravityformscleverreach";a:5:{s:12:"is_available";b:1;s:7:"version";s:3:"1.4";s:14:"version_latest";s:3:"1.4";s:3:"url";s:183:"http://s3.amazonaws.com/gravityforms/addons/cleverreach/gravityformscleverreach_1.4.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1535294575&Signature=uA599raHa5hlEbCB3cULrS1rEoU%3D";s:10:"url_latest";s:183:"http://s3.amazonaws.com/gravityforms/addons/cleverreach/gravityformscleverreach_1.4.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1535294575&Signature=uA599raHa5hlEbCB3cULrS1rEoU%3D";}s:19:"gravityformscoupons";a:5:{s:12:"is_available";b:1;s:7:"version";s:3:"2.6";s:14:"version_latest";s:5:"2.6.2";s:3:"url";s:175:"http://s3.amazonaws.com/gravityforms/addons/coupons/gravityformscoupons_2.6.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1535294575&Signature=9kPlDVfcgaQW4Lu7sdc66JmyI3o%3D";s:10:"url_latest";s:177:"http://s3.amazonaws.com/gravityforms/addons/coupons/gravityformscoupons_2.6.2.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1535294575&Signature=OZzpUFGnKzoHMhhV4zsNOtDuSQ4%3D";}s:17:"gravityformsdebug";a:5:{s:12:"is_available";b:1;s:7:"version";s:0:"";s:14:"version_latest";s:10:"1.0.beta10";s:3:"url";s:0:"";s:10:"url_latest";s:178:"http://s3.amazonaws.com/gravityforms/addons/debug/gravityformsdebug_1.0.beta10.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1535294575&Signature=8lI7qiKYMdIpylZxwbo8GY9a8Ss%3D";}s:19:"gravityformsdropbox";a:5:{s:12:"is_available";b:1;s:7:"version";s:3:"2.1";s:14:"version_latest";s:5:"2.1.1";s:3:"url";s:177:"http://s3.amazonaws.com/gravityforms/addons/dropbox/gravityformsdropbox_2.1.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1535294575&Signature=FE0EXPR%2Bnot3ol7NE9wUT82Bsz4%3D";s:10:"url_latest";s:179:"http://s3.amazonaws.com/gravityforms/addons/dropbox/gravityformsdropbox_2.1.1.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1535294575&Signature=1HnRsvBODGmIRGcoCYdD6FEpm%2B8%3D";}s:16:"gravityformsemma";a:5:{s:12:"is_available";b:1;s:7:"version";s:3:"1.2";s:14:"version_latest";s:5:"1.2.5";s:3:"url";s:169:"http://s3.amazonaws.com/gravityforms/addons/emma/gravityformsemma_1.2.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1535294575&Signature=7xl9tlR5nAZcXYfDUgGZTDJfclw%3D";s:10:"url_latest";s:175:"http://s3.amazonaws.com/gravityforms/addons/emma/gravityformsemma_1.2.5.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1535294575&Signature=dI93%2Bqx9e3XRkTKroTm0zOK%2B2e8%3D";}s:22:"gravityformsfreshbooks";a:5:{s:12:"is_available";b:1;s:7:"version";s:3:"2.5";s:14:"version_latest";s:5:"2.5.2";s:3:"url";s:181:"http://s3.amazonaws.com/gravityforms/addons/freshbooks/gravityformsfreshbooks_2.5.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1535294575&Signature=GQMBssFhwsWYg0HzrCN08U28g5I%3D";s:10:"url_latest";s:183:"http://s3.amazonaws.com/gravityforms/addons/freshbooks/gravityformsfreshbooks_2.5.2.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1535294575&Signature=o8zBBnmBtR8xhcPjertBbVv21Qo%3D";}s:23:"gravityformsgetresponse";a:5:{s:12:"is_available";b:1;s:7:"version";s:3:"1.2";s:14:"version_latest";s:3:"1.2";s:3:"url";s:183:"http://s3.amazonaws.com/gravityforms/addons/getresponse/gravityformsgetresponse_1.2.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1535294575&Signature=oTpZLahdRBgKXTwhPulFNkKcWTc%3D";s:10:"url_latest";s:183:"http://s3.amazonaws.com/gravityforms/addons/getresponse/gravityformsgetresponse_1.2.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1535294575&Signature=oTpZLahdRBgKXTwhPulFNkKcWTc%3D";}s:21:"gravityformsgutenberg";a:5:{s:12:"is_available";b:1;s:7:"version";s:10:"1.0-beta-5";s:14:"version_latest";s:10:"1.0-beta-5";s:3:"url";s:186:"http://s3.amazonaws.com/gravityforms/addons/gutenberg/gravityformsgutenberg_1.0-beta-5.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1535294575&Signature=cqGZulh2q1gBYgxc1BamHlDbNfc%3D";s:10:"url_latest";s:186:"http://s3.amazonaws.com/gravityforms/addons/gutenberg/gravityformsgutenberg_1.0-beta-5.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1535294575&Signature=cqGZulh2q1gBYgxc1BamHlDbNfc%3D";}s:21:"gravityformshelpscout";a:5:{s:12:"is_available";b:1;s:7:"version";s:3:"1.5";s:14:"version_latest";s:3:"1.5";s:3:"url";s:183:"http://s3.amazonaws.com/gravityforms/addons/helpscout/gravityformshelpscout_1.5.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1535294575&Signature=zBegJPA%2FZSRGGXNU1a5uYq%2BmbtI%3D";s:10:"url_latest";s:183:"http://s3.amazonaws.com/gravityforms/addons/helpscout/gravityformshelpscout_1.5.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1535294575&Signature=zBegJPA%2FZSRGGXNU1a5uYq%2BmbtI%3D";}s:20:"gravityformshighrise";a:5:{s:12:"is_available";b:1;s:7:"version";s:3:"1.2";s:14:"version_latest";s:5:"1.2.3";s:3:"url";s:179:"http://s3.amazonaws.com/gravityforms/addons/highrise/gravityformshighrise_1.2.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1535294575&Signature=ETnMBCqX%2FDODWfwWEgY4wNUlvyw%3D";s:10:"url_latest";s:179:"http://s3.amazonaws.com/gravityforms/addons/highrise/gravityformshighrise_1.2.3.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1535294575&Signature=ylhNcxe7ZwmCZK0tJPnoRR6Lf7Q%3D";}s:19:"gravityformshipchat";a:5:{s:12:"is_available";b:1;s:7:"version";s:3:"1.2";s:14:"version_latest";s:3:"1.2";s:3:"url";s:177:"http://s3.amazonaws.com/gravityforms/addons/hipchat/gravityformshipchat_1.2.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1535294575&Signature=7ncpJB%2F2moK2S17CnAOHuSopGDk%3D";s:10:"url_latest";s:177:"http://s3.amazonaws.com/gravityforms/addons/hipchat/gravityformshipchat_1.2.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1535294575&Signature=7ncpJB%2F2moK2S17CnAOHuSopGDk%3D";}s:20:"gravityformsicontact";a:5:{s:12:"is_available";b:1;s:7:"version";s:3:"1.3";s:14:"version_latest";s:3:"1.3";s:3:"url";s:177:"http://s3.amazonaws.com/gravityforms/addons/icontact/gravityformsicontact_1.3.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1535294575&Signature=zFYWUBoeyjmu0Du86tDyd0B6Smo%3D";s:10:"url_latest";s:177:"http://s3.amazonaws.com/gravityforms/addons/icontact/gravityformsicontact_1.3.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1535294575&Signature=zFYWUBoeyjmu0Du86tDyd0B6Smo%3D";}s:19:"gravityformslogging";a:5:{s:12:"is_available";b:1;s:7:"version";s:3:"1.3";s:14:"version_latest";s:5:"1.3.1";s:3:"url";s:175:"http://s3.amazonaws.com/gravityforms/addons/logging/gravityformslogging_1.3.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1535294575&Signature=RGRRmRNDFTLYhHVrWRxLHFASKPE%3D";s:10:"url_latest";s:179:"http://s3.amazonaws.com/gravityforms/addons/logging/gravityformslogging_1.3.1.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1535294575&Signature=PvoTZLmBZWK66j1j461tBx%2BfHbI%3D";}s:19:"gravityformsmadmimi";a:5:{s:12:"is_available";b:1;s:7:"version";s:3:"1.2";s:14:"version_latest";s:3:"1.2";s:3:"url";s:177:"http://s3.amazonaws.com/gravityforms/addons/madmimi/gravityformsmadmimi_1.2.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1535294575&Signature=3lZ8ylz%2FzGltkVd8P0KoMiBYcJ8%3D";s:10:"url_latest";s:177:"http://s3.amazonaws.com/gravityforms/addons/madmimi/gravityformsmadmimi_1.2.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1535294575&Signature=3lZ8ylz%2FzGltkVd8P0KoMiBYcJ8%3D";}s:21:"gravityformsmailchimp";a:5:{s:12:"is_available";b:1;s:7:"version";s:3:"4.3";s:14:"version_latest";s:3:"4.3";s:3:"url";s:179:"http://s3.amazonaws.com/gravityforms/addons/mailchimp/gravityformsmailchimp_4.3.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1535294575&Signature=ZPQ8ws2deqAImWnWjUUinqazr9c%3D";s:10:"url_latest";s:179:"http://s3.amazonaws.com/gravityforms/addons/mailchimp/gravityformsmailchimp_4.3.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1535294575&Signature=ZPQ8ws2deqAImWnWjUUinqazr9c%3D";}s:26:"gravityformspartialentries";a:5:{s:12:"is_available";b:1;s:7:"version";s:3:"1.2";s:14:"version_latest";s:5:"1.2.1";s:3:"url";s:193:"http://s3.amazonaws.com/gravityforms/addons/partialentries/gravityformspartialentries_1.2.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1535294575&Signature=x%2FAosM%2Bw398eaTZqICnR0vCQJCs%3D";s:10:"url_latest";s:193:"http://s3.amazonaws.com/gravityforms/addons/partialentries/gravityformspartialentries_1.2.1.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1535294575&Signature=6rSLtgM4o4ms%2F4PmX6eEOR5Mhao%3D";}s:18:"gravityformspaypal";a:5:{s:12:"is_available";b:1;s:7:"version";s:3:"3.1";s:14:"version_latest";s:5:"3.1.1";s:3:"url";s:177:"http://s3.amazonaws.com/gravityforms/addons/paypal/gravityformspaypal_3.1.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1535294575&Signature=SykONQj45kCrrLmVJQ%2F03%2BBhkWA%3D";s:10:"url_latest";s:177:"http://s3.amazonaws.com/gravityforms/addons/paypal/gravityformspaypal_3.1.1.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1535294575&Signature=oqxC%2Fk0XqXgDnyQkyL7q6M9mHNE%3D";}s:33:"gravityformspaypalexpresscheckout";a:3:{s:12:"is_available";b:0;s:7:"version";s:0:"";s:14:"version_latest";N;}s:29:"gravityformspaypalpaymentspro";a:5:{s:12:"is_available";b:1;s:7:"version";s:3:"2.3";s:14:"version_latest";s:5:"2.3.2";s:3:"url";s:195:"http://s3.amazonaws.com/gravityforms/addons/paypalpaymentspro/gravityformspaypalpaymentspro_2.3.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1535294575&Signature=FBqwH2jq4PoWhWRN7qmtTVhRdZY%3D";s:10:"url_latest";s:199:"http://s3.amazonaws.com/gravityforms/addons/paypalpaymentspro/gravityformspaypalpaymentspro_2.3.2.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1535294575&Signature=eRH0d8Cs2ePBcEA9k%2Fht2ZSt3sY%3D";}s:21:"gravityformspaypalpro";a:5:{s:12:"is_available";b:1;s:7:"version";s:5:"1.8.1";s:14:"version_latest";s:5:"1.8.1";s:3:"url";s:187:"http://s3.amazonaws.com/gravityforms/addons/paypalpro/gravityformspaypalpro_1.8.1.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1535294575&Signature=1iz%2F%2BcalWDoBQJYumImW%2BXWgtlo%3D";s:10:"url_latest";s:187:"http://s3.amazonaws.com/gravityforms/addons/paypalpro/gravityformspaypalpro_1.8.1.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1535294575&Signature=1iz%2F%2BcalWDoBQJYumImW%2BXWgtlo%3D";}s:20:"gravityformspicatcha";a:3:{s:12:"is_available";b:0;s:7:"version";s:3:"2.0";s:14:"version_latest";s:3:"2.0";}s:16:"gravityformspipe";a:5:{s:12:"is_available";b:1;s:7:"version";s:3:"1.1";s:14:"version_latest";s:3:"1.1";s:3:"url";s:171:"http://s3.amazonaws.com/gravityforms/addons/pipe/gravityformspipe_1.1.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1535294575&Signature=tli9zEcf8%2B2d4NDltQv4lxCvJg4%3D";s:10:"url_latest";s:171:"http://s3.amazonaws.com/gravityforms/addons/pipe/gravityformspipe_1.1.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1535294575&Signature=tli9zEcf8%2B2d4NDltQv4lxCvJg4%3D";}s:17:"gravityformspolls";a:5:{s:12:"is_available";b:1;s:7:"version";s:3:"3.1";s:14:"version_latest";s:5:"3.1.4";s:3:"url";s:173:"http://s3.amazonaws.com/gravityforms/addons/polls/gravityformspolls_3.1.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1535294575&Signature=T6CJeeqB8qDuK%2Fla5kmnjWXSQfo%3D";s:10:"url_latest";s:175:"http://s3.amazonaws.com/gravityforms/addons/polls/gravityformspolls_3.1.4.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1535294575&Signature=2Mc9J%2BmCudj9gYzt69GNgMHBs3o%3D";}s:16:"gravityformsquiz";a:5:{s:12:"is_available";b:1;s:7:"version";s:3:"3.1";s:14:"version_latest";s:5:"3.1.8";s:3:"url";s:169:"http://s3.amazonaws.com/gravityforms/addons/quiz/gravityformsquiz_3.1.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1535294575&Signature=kKz7v9c6yTcRAm0zESKl9WS7mo8%3D";s:10:"url_latest";s:173:"http://s3.amazonaws.com/gravityforms/addons/quiz/gravityformsquiz_3.1.8.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1535294575&Signature=hrIfQZnWEvq1JSyVdvV5UX%2BmGdU%3D";}s:19:"gravityformsrestapi";a:5:{s:12:"is_available";b:1;s:7:"version";s:10:"2.0-beta-2";s:14:"version_latest";s:10:"2.0-beta-2";s:3:"url";s:186:"http://s3.amazonaws.com/gravityforms/addons/restapi/gravityformsrestapi_2.0-beta-2.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1535294575&Signature=XTHO%2BLBQxT9X3ZxrCWRT9icc2%2Bw%3D";s:10:"url_latest";s:186:"http://s3.amazonaws.com/gravityforms/addons/restapi/gravityformsrestapi_2.0-beta-2.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1535294575&Signature=XTHO%2BLBQxT9X3ZxrCWRT9icc2%2Bw%3D";}s:21:"gravityformssignature";a:5:{s:12:"is_available";b:1;s:7:"version";s:5:"3.5.1";s:14:"version_latest";s:5:"3.5.2";s:3:"url";s:181:"http://s3.amazonaws.com/gravityforms/addons/signature/gravityformssignature_3.5.1.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1535294575&Signature=0bLSMvbBxoaHhdktdm7T3pUXXGc%3D";s:10:"url_latest";s:183:"http://s3.amazonaws.com/gravityforms/addons/signature/gravityformssignature_3.5.2.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1535294575&Signature=gPR1G%2Fch1vwcmt1uWmnlKAfQZV8%3D";}s:17:"gravityformsslack";a:5:{s:12:"is_available";b:1;s:7:"version";s:3:"1.8";s:14:"version_latest";s:3:"1.8";s:3:"url";s:173:"http://s3.amazonaws.com/gravityforms/addons/slack/gravityformsslack_1.8.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1535294575&Signature=%2BIfouuMuOboLagCNivNr51ncIq4%3D";s:10:"url_latest";s:173:"http://s3.amazonaws.com/gravityforms/addons/slack/gravityformsslack_1.8.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1535294575&Signature=%2BIfouuMuOboLagCNivNr51ncIq4%3D";}s:18:"gravityformsstripe";a:5:{s:12:"is_available";b:1;s:7:"version";s:3:"2.5";s:14:"version_latest";s:5:"2.5.4";s:3:"url";s:173:"http://s3.amazonaws.com/gravityforms/addons/stripe/gravityformsstripe_2.5.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1535294575&Signature=GzOBRlGqrJsgzaaxgZ13DKZLuqE%3D";s:10:"url_latest";s:177:"http://s3.amazonaws.com/gravityforms/addons/stripe/gravityformsstripe_2.5.4.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1535294575&Signature=CzAPTvsaBKJPvDGHH7D%2FiMqPnpg%3D";}s:18:"gravityformssurvey";a:5:{s:12:"is_available";b:1;s:7:"version";s:3:"3.2";s:14:"version_latest";s:5:"3.2.2";s:3:"url";s:173:"http://s3.amazonaws.com/gravityforms/addons/survey/gravityformssurvey_3.2.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1535294575&Signature=5jSG1LeWncmOW5LsJL32sPNQAqI%3D";s:10:"url_latest";s:177:"http://s3.amazonaws.com/gravityforms/addons/survey/gravityformssurvey_3.2.2.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1535294575&Signature=pAr4PlrEfPnzDheFu%2BZRbcehhGw%3D";}s:18:"gravityformstrello";a:5:{s:12:"is_available";b:1;s:7:"version";s:3:"1.2";s:14:"version_latest";s:5:"1.2.2";s:3:"url";s:175:"http://s3.amazonaws.com/gravityforms/addons/trello/gravityformstrello_1.2.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1535294575&Signature=rEev3r80Q5rd14tpDVWRLxQyj%2Bs%3D";s:10:"url_latest";s:175:"http://s3.amazonaws.com/gravityforms/addons/trello/gravityformstrello_1.2.2.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1535294575&Signature=yFbYA2QqbX5R5YZnENC6D9VLOxc%3D";}s:18:"gravityformstwilio";a:5:{s:12:"is_available";b:1;s:7:"version";s:3:"2.5";s:14:"version_latest";s:5:"2.5.1";s:3:"url";s:175:"http://s3.amazonaws.com/gravityforms/addons/twilio/gravityformstwilio_2.5.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1535294575&Signature=rL3si9%2BljC0XlxNEcXIMUDdgjHc%3D";s:10:"url_latest";s:175:"http://s3.amazonaws.com/gravityforms/addons/twilio/gravityformstwilio_2.5.1.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1535294575&Signature=pQn6YiQHtKUdsqrRUrqNs7eBPvQ%3D";}s:28:"gravityformsuserregistration";a:5:{s:12:"is_available";b:1;s:7:"version";s:3:"3.9";s:14:"version_latest";s:5:"3.9.5";s:3:"url";s:199:"http://s3.amazonaws.com/gravityforms/addons/userregistration/gravityformsuserregistration_3.9.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1535294575&Signature=V0lEd4GguSThtSk%2Fj%2F%2FsaMssea0%3D";s:10:"url_latest";s:197:"http://s3.amazonaws.com/gravityforms/addons/userregistration/gravityformsuserregistration_3.9.5.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1535294575&Signature=ovweYWSBke%2BWCju8fyFrxOhalZw%3D";}s:20:"gravityformswebhooks";a:5:{s:12:"is_available";b:1;s:7:"version";s:3:"1.1";s:14:"version_latest";s:5:"1.1.5";s:3:"url";s:177:"http://s3.amazonaws.com/gravityforms/addons/webhooks/gravityformswebhooks_1.1.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1535294575&Signature=ni7EbmadbB3yM3irBeClIpvErl8%3D";s:10:"url_latest";s:181:"http://s3.amazonaws.com/gravityforms/addons/webhooks/gravityformswebhooks_1.1.5.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1535294575&Signature=jDVy6gt7jgp4wRdAFX%2Bccc8PQ4g%3D";}s:18:"gravityformszapier";a:5:{s:12:"is_available";b:1;s:7:"version";s:3:"3.0";s:14:"version_latest";s:5:"3.0.1";s:3:"url";s:173:"http://s3.amazonaws.com/gravityforms/addons/zapier/gravityformszapier_3.0.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1535294575&Signature=QM3SxjFV3gPqmq8aWnFveuxwTWg%3D";s:10:"url_latest";s:177:"http://s3.amazonaws.com/gravityforms/addons/zapier/gravityformszapier_3.0.1.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1535294575&Signature=raAEj%2BPs2lNYapQWP8CESX0wIUg%3D";}s:19:"gravityformszohocrm";a:5:{s:12:"is_available";b:1;s:7:"version";s:3:"1.5";s:14:"version_latest";s:3:"1.5";s:3:"url";s:175:"http://s3.amazonaws.com/gravityforms/addons/zohocrm/gravityformszohocrm_1.5.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1535294575&Signature=BUSyBNzxm1Vxf0qwPqxrvYTUb0o%3D";s:10:"url_latest";s:175:"http://s3.amazonaws.com/gravityforms/addons/zohocrm/gravityformszohocrm_1.5.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1535294575&Signature=BUSyBNzxm1Vxf0qwPqxrvYTUb0o%3D";}}s:9:"is_active";s:1:"1";s:14:"version_latest";s:7:"2.3.3.6";s:10:"url_latest";s:168:"http://s3.amazonaws.com/gravityforms/releases/gravityforms_2.3.3.6.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1535294575&Signature=qkAmKL5QKDVRMNCyu%2BrcEdmpgVg%3D";s:9:"timestamp";i:1535121774;}', 'yes'),
(412, 'akismet_comment_form_privacy_notice', 'hide', 'yes'),
(445, 'theme_mods_starter-theme-master', 'a:4:{i:0;b:0;s:18:"nav_menu_locations";a:0:{}s:18:"custom_css_post_id";i:-1;s:16:"sidebars_widgets";a:2:{s:4:"time";i:1534891316;s:4:"data";a:4:{s:19:"wp_inactive_widgets";a:0:{}s:7:"sidebar";a:3:{i:0;s:14:"recent-posts-2";i:1;s:12:"categories-2";i:2;s:10:"archives-2";}s:16:"category_sidebar";a:0:{}s:15:"archive_sidebar";a:0:{}}}}', 'yes'),
(449, 'theme_mods_cannon-dunphy', 'a:3:{i:0;b:0;s:18:"nav_menu_locations";a:1:{s:9:"main_menu";i:2;}s:18:"custom_css_post_id";i:-1;}', 'yes'),
(460, 'nav_menu_options', 'a:2:{i:0;b:0;s:8:"auto_add";a:0:{}}', 'yes'),
(496, 'wpmdb_usage', 'a:2:{s:6:"action";s:8:"savefile";s:4:"time";i:1535148513;}', 'no') ;

#
# End of data contents of table `wp_options`
# --------------------------------------------------------



#
# Delete any existing table `wp_postmeta`
#

DROP TABLE IF EXISTS `wp_postmeta`;


#
# Table structure of table `wp_postmeta`
#

CREATE TABLE `wp_postmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`meta_id`),
  KEY `post_id` (`post_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=190 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_postmeta`
#
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(2, 4, '_edit_last', '1'),
(3, 4, '_edit_lock', '1516675607:1'),
(7, 10, '_edit_last', '1'),
(8, 10, '_edit_lock', '1535039893:1'),
(9, 12, '_edit_last', '1'),
(10, 12, '_edit_lock', '1514332978:1'),
(11, 10, '_wp_page_template', 'template-home.php'),
(16, 15, '_edit_last', '1'),
(19, 15, '_edit_lock', '1514333171:1'),
(20, 17, '_edit_last', '1'),
(23, 17, '_edit_lock', '1514333184:1'),
(24, 19, '_edit_last', '1'),
(25, 19, '_edit_lock', '1514333195:1'),
(28, 21, '_edit_last', '1'),
(29, 21, '_edit_lock', '1514333206:1'),
(32, 23, '_edit_last', '1'),
(33, 23, '_edit_lock', '1514333226:1'),
(36, 37, '_edit_last', '1'),
(37, 37, '_edit_lock', '1516675376:1'),
(38, 37, '_wp_page_template', 'default'),
(39, 39, '_edit_last', '1'),
(40, 39, '_wp_page_template', 'default'),
(41, 39, '_edit_lock', '1516676839:1'),
(42, 46, '_edit_last', '1'),
(43, 46, '_wp_page_template', 'default'),
(44, 46, '_edit_lock', '1516676818:1'),
(45, 48, '_edit_last', '1'),
(46, 48, '_wp_page_template', 'default'),
(47, 48, '_edit_lock', '1516676850:1'),
(48, 50, '_edit_last', '1'),
(49, 50, '_edit_lock', '1534967358:1'),
(50, 50, '_wp_page_template', 'default'),
(51, 52, '_edit_last', '1'),
(52, 52, '_wp_page_template', 'default'),
(53, 52, '_edit_lock', '1516676878:1'),
(54, 54, '_edit_last', '1'),
(55, 54, '_wp_page_template', 'default'),
(56, 54, '_edit_lock', '1516676888:1'),
(57, 56, '_edit_last', '1'),
(58, 56, '_wp_page_template', 'default'),
(59, 56, '_edit_lock', '1516676922:1'),
(60, 58, '_edit_last', '1'),
(61, 58, '_edit_lock', '1516676969:1'),
(62, 58, '_wp_page_template', 'default'),
(63, 60, '_edit_last', '1'),
(64, 60, '_edit_lock', '1534967352:1'),
(65, 60, '_wp_page_template', 'default'),
(66, 62, '_edit_last', '1'),
(67, 62, '_wp_page_template', 'default'),
(68, 62, '_edit_lock', '1516676996:1'),
(69, 68, '_edit_last', '1'),
(70, 68, '_edit_lock', '1534967167:1'),
(71, 68, '_wp_trash_meta_status', 'draft'),
(72, 68, '_wp_trash_meta_time', '1534967174'),
(73, 68, '_wp_desired_post_slug', ''),
(74, 70, '_menu_item_type', 'post_type'),
(75, 70, '_menu_item_menu_item_parent', '0'),
(76, 70, '_menu_item_object_id', '10'),
(77, 70, '_menu_item_object', 'page'),
(78, 70, '_menu_item_target', ''),
(79, 70, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(80, 70, '_menu_item_xfn', ''),
(81, 70, '_menu_item_url', ''),
(83, 71, '_menu_item_type', 'custom'),
(84, 71, '_menu_item_menu_item_parent', '0'),
(85, 71, '_menu_item_object_id', '71'),
(86, 71, '_menu_item_object', 'custom'),
(87, 71, '_menu_item_target', ''),
(88, 71, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(89, 71, '_menu_item_xfn', ''),
(90, 71, '_menu_item_url', ''),
(92, 72, '_menu_item_type', 'post_type'),
(93, 72, '_menu_item_menu_item_parent', '71'),
(94, 72, '_menu_item_object_id', '46'),
(95, 72, '_menu_item_object', 'page'),
(96, 72, '_menu_item_target', ''),
(97, 72, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(98, 72, '_menu_item_xfn', ''),
(99, 72, '_menu_item_url', ''),
(101, 73, '_menu_item_type', 'custom'),
(102, 73, '_menu_item_menu_item_parent', '0'),
(103, 73, '_menu_item_object_id', '73'),
(104, 73, '_menu_item_object', 'custom'),
(105, 73, '_menu_item_target', ''),
(106, 73, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(107, 73, '_menu_item_xfn', ''),
(108, 73, '_menu_item_url', ''),
(110, 74, '_menu_item_type', 'post_type'),
(111, 74, '_menu_item_menu_item_parent', '73'),
(112, 74, '_menu_item_object_id', '60'),
(113, 74, '_menu_item_object', 'page'),
(114, 74, '_menu_item_target', ''),
(115, 74, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(116, 74, '_menu_item_xfn', ''),
(117, 74, '_menu_item_url', ''),
(119, 75, '_menu_item_type', 'post_type'),
(120, 75, '_menu_item_menu_item_parent', '0'),
(121, 75, '_menu_item_object_id', '54'),
(122, 75, '_menu_item_object', 'page'),
(123, 75, '_menu_item_target', '') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(124, 75, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(125, 75, '_menu_item_xfn', ''),
(126, 75, '_menu_item_url', ''),
(128, 76, '_menu_item_type', 'post_type'),
(129, 76, '_menu_item_menu_item_parent', '0'),
(130, 76, '_menu_item_object_id', '52'),
(131, 76, '_menu_item_object', 'page'),
(132, 76, '_menu_item_target', ''),
(133, 76, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(134, 76, '_menu_item_xfn', ''),
(135, 76, '_menu_item_url', ''),
(137, 77, '_menu_item_type', 'post_type'),
(138, 77, '_menu_item_menu_item_parent', '0'),
(139, 77, '_menu_item_object_id', '62'),
(140, 77, '_menu_item_object', 'page'),
(141, 77, '_menu_item_target', ''),
(142, 77, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(143, 77, '_menu_item_xfn', ''),
(144, 77, '_menu_item_url', ''),
(146, 78, '_menu_item_type', 'post_type'),
(147, 78, '_menu_item_menu_item_parent', '0'),
(148, 78, '_menu_item_object_id', '56'),
(149, 78, '_menu_item_object', 'page'),
(150, 78, '_menu_item_target', ''),
(151, 78, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(152, 78, '_menu_item_xfn', ''),
(153, 78, '_menu_item_url', ''),
(155, 58, '_wp_trash_meta_status', 'publish'),
(156, 58, '_wp_trash_meta_time', '1534967326'),
(157, 58, '_wp_desired_post_slug', 'attorneys'),
(158, 48, '_wp_trash_meta_status', 'publish'),
(159, 48, '_wp_trash_meta_time', '1534967331'),
(160, 48, '_wp_desired_post_slug', 'practice-areas'),
(161, 79, '_edit_last', '1'),
(162, 79, '_edit_lock', '1535039933:1'),
(163, 79, '_wp_page_template', 'default'),
(164, 81, '_menu_item_type', 'post_type'),
(165, 81, '_menu_item_menu_item_parent', '73'),
(166, 81, '_menu_item_object_id', '79'),
(167, 81, '_menu_item_object', 'page'),
(168, 81, '_menu_item_target', ''),
(169, 81, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(170, 81, '_menu_item_xfn', ''),
(171, 81, '_menu_item_url', ''),
(173, 82, '_menu_item_type', 'custom'),
(174, 82, '_menu_item_menu_item_parent', '0'),
(175, 82, '_menu_item_object_id', '82'),
(176, 82, '_menu_item_object', 'custom'),
(177, 82, '_menu_item_target', ''),
(178, 82, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(179, 82, '_menu_item_xfn', ''),
(180, 82, '_menu_item_url', ''),
(182, 83, '_menu_item_type', 'post_type'),
(183, 83, '_menu_item_menu_item_parent', '82'),
(184, 83, '_menu_item_object_id', '50'),
(185, 83, '_menu_item_object', 'page'),
(186, 83, '_menu_item_target', ''),
(187, 83, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(188, 83, '_menu_item_xfn', ''),
(189, 83, '_menu_item_url', '') ;

#
# End of data contents of table `wp_postmeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_posts`
#

DROP TABLE IF EXISTS `wp_posts`;


#
# Table structure of table `wp_posts`
#

CREATE TABLE `wp_posts` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_author` bigint(20) unsigned NOT NULL DEFAULT '0',
  `post_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_title` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_excerpt` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'publish',
  `comment_status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'open',
  `ping_status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'open',
  `post_password` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `post_name` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `to_ping` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `pinged` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content_filtered` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `guid` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `menu_order` int(11) NOT NULL DEFAULT '0',
  `post_type` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'post',
  `post_mime_type` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `post_name` (`post_name`(191)),
  KEY `type_status_date` (`post_type`,`post_status`,`post_date`,`ID`),
  KEY `post_parent` (`post_parent`),
  KEY `post_author` (`post_author`)
) ENGINE=InnoDB AUTO_INCREMENT=84 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_posts`
#
INSERT INTO `wp_posts` ( `ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(4, 1, '2017-12-27 00:03:52', '2017-12-27 00:03:52', 'a:7:{s:8:"location";a:1:{i:0;a:1:{i:0;a:3:{s:5:"param";s:12:"options_page";s:8:"operator";s:2:"==";s:5:"value";s:13:"theme-options";}}}s:8:"position";s:6:"normal";s:5:"style";s:7:"default";s:15:"label_placement";s:3:"top";s:21:"instruction_placement";s:5:"label";s:14:"hide_on_screen";s:0:"";s:11:"description";s:0:"";}', 'Theme Options', 'theme-options', 'publish', 'closed', 'closed', '', 'group_5a42e2e8d6530', '', '', '2018-01-23 02:49:05', '2018-01-23 02:49:05', '', 0, 'http://localhost:8888/?post_type=acf-field-group&#038;p=4', 0, 'acf-field-group', '', 0),
(5, 1, '2017-12-27 00:03:52', '2017-12-27 00:03:52', 'a:7:{s:4:"type";s:3:"tab";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"placement";s:3:"top";s:8:"endpoint";i:0;}', 'Header Scripts', '', 'publish', 'closed', 'closed', '', 'field_5a42e2ef5aee8', '', '', '2018-01-23 02:49:05', '2018-01-23 02:49:05', '', 4, 'http://localhost:8888/?post_type=acf-field&#038;p=5', 9, 'acf-field', '', 0),
(6, 1, '2017-12-27 00:03:52', '2017-12-27 00:03:52', 'a:12:{s:4:"type";s:8:"textarea";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:9:"maxlength";s:0:"";s:4:"rows";s:0:"";s:9:"new_lines";s:0:"";s:8:"readonly";i:0;s:8:"disabled";i:0;}', 'Schema Code', 'schema_code', 'publish', 'closed', 'closed', '', 'field_5a42e3275aee9', '', '', '2018-01-23 02:49:05', '2018-01-23 02:49:05', '', 4, 'http://localhost:8888/?post_type=acf-field&#038;p=6', 10, 'acf-field', '', 0),
(7, 1, '2017-12-27 00:03:52', '2017-12-27 00:03:52', 'a:12:{s:4:"type";s:8:"textarea";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:9:"maxlength";s:0:"";s:4:"rows";s:0:"";s:9:"new_lines";s:0:"";s:8:"readonly";i:0;s:8:"disabled";i:0;}', 'Analytics Code', 'analytics_code', 'publish', 'closed', 'closed', '', 'field_5a42e33c5aeea', '', '', '2018-01-23 02:49:05', '2018-01-23 02:49:05', '', 4, 'http://localhost:8888/?post_type=acf-field&#038;p=7', 11, 'acf-field', '', 0),
(8, 1, '2017-12-27 00:04:08', '2017-12-27 00:04:08', 'a:7:{s:4:"type";s:3:"tab";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"placement";s:3:"top";s:8:"endpoint";i:0;}', 'Firm Info', '', 'publish', 'closed', 'closed', '', 'field_5a42e36bdd9fd', '', '', '2017-12-27 00:07:39', '2017-12-27 00:07:39', '', 4, 'http://localhost:8888/?post_type=acf-field&#038;p=8', 0, 'acf-field', '', 0),
(10, 1, '2017-12-27 00:05:13', '2017-12-27 00:05:13', '', 'Home', '', 'publish', 'closed', 'closed', '', 'home', '', '', '2018-08-22 14:29:31', '2018-08-22 22:29:31', '', 0, 'http://localhost:8888/?page_id=10', 0, 'page', '', 0),
(11, 1, '2017-12-27 00:05:13', '2017-12-27 00:05:13', '', 'Home', '', 'inherit', 'closed', 'closed', '', '10-revision-v1', '', '', '2017-12-27 00:05:13', '2017-12-27 00:05:13', '', 10, 'http://localhost:8888/2017/12/27/10-revision-v1/', 0, 'revision', '', 0),
(12, 1, '2017-12-27 00:05:21', '2017-12-27 00:05:21', '', 'Blog', '', 'publish', 'closed', 'closed', '', 'blog', '', '', '2017-12-27 00:05:21', '2017-12-27 00:05:21', '', 0, 'http://localhost:8888/?page_id=12', 0, 'page', '', 0),
(13, 1, '2017-12-27 00:05:21', '2017-12-27 00:05:21', '', 'Blog', '', 'inherit', 'closed', 'closed', '', '12-revision-v1', '', '', '2017-12-27 00:05:21', '2017-12-27 00:05:21', '', 12, 'http://localhost:8888/2017/12/27/12-revision-v1/', 0, 'revision', '', 0),
(15, 1, '2017-12-27 00:08:31', '2017-12-27 00:08:31', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Auctor elit sed vulputate mi sit. Imperdiet sed euismod nisi porta lorem mollis aliquam. Urna et pharetra pharetra massa massa ultricies mi quis hendrerit. Malesuada fames ac turpis egestas integer eget aliquet. Nulla malesuada pellentesque elit eget gravida cum sociis natoque. Aenean vel elit scelerisque mauris pellentesque. Ac orci phasellus egestas tellus rutrum tellus pellentesque eu. Pellentesque adipiscing commodo elit at imperdiet dui accumsan sit. Enim facilisis gravida neque convallis a cras semper auctor neque. Cras semper auctor neque vitae.\r\n\r\nUt pharetra sit amet aliquam id diam. Nunc pulvinar sapien et ligula ullamcorper malesuada proin. Amet dictum sit amet justo donec. Urna et pharetra pharetra massa massa. Vulputate dignissim suspendisse in est ante in nibh mauris. Sem nulla pharetra diam sit amet nisl. Donec et odio pellentesque diam volutpat commodo. Quam pellentesque nec nam aliquam sem et. A diam sollicitudin tempor id eu nisl. Nisi scelerisque eu ultrices vitae auctor. Quam nulla porttitor massa id neque aliquam. Penatibus et magnis dis parturient montes nascetur ridiculus mus. Morbi quis commodo odio aenean sed adipiscing diam donec.\r\n\r\nEst lorem ipsum dolor sit amet consectetur adipiscing elit pellentesque. Integer enim neque volutpat ac tincidunt. Cursus euismod quis viverra nibh. Volutpat sed cras ornare arcu dui vivamus arcu felis. Aenean vel elit scelerisque mauris pellentesque pulvinar. Eget lorem dolor sed viverra ipsum nunc aliquet. Nibh tortor id aliquet lectus proin nibh nisl condimentum id. Hac habitasse platea dictumst vestibulum. In massa tempor nec feugiat. Mauris nunc congue nisi vitae suscipit tellus. Purus gravida quis blandit turpis. Volutpat lacus laoreet non curabitur gravida arcu. Fusce id velit ut tortor pretium. Suspendisse faucibus interdum posuere lorem ipsum dolor sit. Scelerisque in dictum non consectetur a. Massa massa ultricies mi quis hendrerit. Lacinia at quis risus sed vulputate odio ut enim blandit. Viverra ipsum nunc aliquet bibendum.\r\n\r\nMaecenas sed enim ut sem viverra aliquet eget sit. Sollicitudin tempor id eu nisl nunc mi ipsum faucibus. Ultrices mi tempus imperdiet nulla malesuada pellentesque elit eget. Id interdum velit laoreet id donec ultrices tincidunt arcu non. Egestas pretium aenean pharetra magna ac placerat. Senectus et netus et malesuada fames ac turpis. Purus in massa tempor nec feugiat nisl pretium fusce id. Habitasse platea dictumst vestibulum rhoncus est pellentesque elit ullamcorper dignissim. Sapien et ligula ullamcorper malesuada proin libero. Aliquam malesuada bibendum arcu vitae elementum curabitur vitae. Orci dapibus ultrices in iaculis nunc sed augue lacus viverra. Sem integer vitae justo eget magna fermentum iaculis eu.\r\n\r\nTempus imperdiet nulla malesuada pellentesque elit eget. Integer feugiat scelerisque varius morbi enim nunc faucibus a pellentesque. Ligula ullamcorper malesuada proin libero nunc consequat interdum. Etiam dignissim diam quis enim lobortis scelerisque. Neque vitae tempus quam pellentesque nec. Augue lacus viverra vitae congue. Mattis molestie a iaculis at erat pellentesque adipiscing. Mi ipsum faucibus vitae aliquet nec ullamcorper sit amet risus. Magnis dis parturient montes nascetur ridiculus mus mauris. Nunc consequat interdum varius sit amet mattis vulputate enim nulla. Enim ut sem viverra aliquet eget. Ut venenatis tellus in metus vulputate. Sed tempus urna et pharetra pharetra massa massa ultricies. Orci porta non pulvinar neque laoreet suspendisse interdum consectetur libero. Nec feugiat nisl pretium fusce id velit ut tortor. Urna nec tincidunt praesent semper. Bibendum at varius vel pharetra vel turpis nunc eget.', 'Sample Post 1', '', 'publish', 'open', 'open', '', 'sample-post-1', '', '', '2017-12-27 00:08:31', '2017-12-27 00:08:31', '', 0, 'http://localhost:8888/?p=15', 0, 'post', '', 0),
(16, 1, '2017-12-27 00:08:31', '2017-12-27 00:08:31', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Auctor elit sed vulputate mi sit. Imperdiet sed euismod nisi porta lorem mollis aliquam. Urna et pharetra pharetra massa massa ultricies mi quis hendrerit. Malesuada fames ac turpis egestas integer eget aliquet. Nulla malesuada pellentesque elit eget gravida cum sociis natoque. Aenean vel elit scelerisque mauris pellentesque. Ac orci phasellus egestas tellus rutrum tellus pellentesque eu. Pellentesque adipiscing commodo elit at imperdiet dui accumsan sit. Enim facilisis gravida neque convallis a cras semper auctor neque. Cras semper auctor neque vitae.\r\n\r\nUt pharetra sit amet aliquam id diam. Nunc pulvinar sapien et ligula ullamcorper malesuada proin. Amet dictum sit amet justo donec. Urna et pharetra pharetra massa massa. Vulputate dignissim suspendisse in est ante in nibh mauris. Sem nulla pharetra diam sit amet nisl. Donec et odio pellentesque diam volutpat commodo. Quam pellentesque nec nam aliquam sem et. A diam sollicitudin tempor id eu nisl. Nisi scelerisque eu ultrices vitae auctor. Quam nulla porttitor massa id neque aliquam. Penatibus et magnis dis parturient montes nascetur ridiculus mus. Morbi quis commodo odio aenean sed adipiscing diam donec.\r\n\r\nEst lorem ipsum dolor sit amet consectetur adipiscing elit pellentesque. Integer enim neque volutpat ac tincidunt. Cursus euismod quis viverra nibh. Volutpat sed cras ornare arcu dui vivamus arcu felis. Aenean vel elit scelerisque mauris pellentesque pulvinar. Eget lorem dolor sed viverra ipsum nunc aliquet. Nibh tortor id aliquet lectus proin nibh nisl condimentum id. Hac habitasse platea dictumst vestibulum. In massa tempor nec feugiat. Mauris nunc congue nisi vitae suscipit tellus. Purus gravida quis blandit turpis. Volutpat lacus laoreet non curabitur gravida arcu. Fusce id velit ut tortor pretium. Suspendisse faucibus interdum posuere lorem ipsum dolor sit. Scelerisque in dictum non consectetur a. Massa massa ultricies mi quis hendrerit. Lacinia at quis risus sed vulputate odio ut enim blandit. Viverra ipsum nunc aliquet bibendum.\r\n\r\nMaecenas sed enim ut sem viverra aliquet eget sit. Sollicitudin tempor id eu nisl nunc mi ipsum faucibus. Ultrices mi tempus imperdiet nulla malesuada pellentesque elit eget. Id interdum velit laoreet id donec ultrices tincidunt arcu non. Egestas pretium aenean pharetra magna ac placerat. Senectus et netus et malesuada fames ac turpis. Purus in massa tempor nec feugiat nisl pretium fusce id. Habitasse platea dictumst vestibulum rhoncus est pellentesque elit ullamcorper dignissim. Sapien et ligula ullamcorper malesuada proin libero. Aliquam malesuada bibendum arcu vitae elementum curabitur vitae. Orci dapibus ultrices in iaculis nunc sed augue lacus viverra. Sem integer vitae justo eget magna fermentum iaculis eu.\r\n\r\nTempus imperdiet nulla malesuada pellentesque elit eget. Integer feugiat scelerisque varius morbi enim nunc faucibus a pellentesque. Ligula ullamcorper malesuada proin libero nunc consequat interdum. Etiam dignissim diam quis enim lobortis scelerisque. Neque vitae tempus quam pellentesque nec. Augue lacus viverra vitae congue. Mattis molestie a iaculis at erat pellentesque adipiscing. Mi ipsum faucibus vitae aliquet nec ullamcorper sit amet risus. Magnis dis parturient montes nascetur ridiculus mus mauris. Nunc consequat interdum varius sit amet mattis vulputate enim nulla. Enim ut sem viverra aliquet eget. Ut venenatis tellus in metus vulputate. Sed tempus urna et pharetra pharetra massa massa ultricies. Orci porta non pulvinar neque laoreet suspendisse interdum consectetur libero. Nec feugiat nisl pretium fusce id velit ut tortor. Urna nec tincidunt praesent semper. Bibendum at varius vel pharetra vel turpis nunc eget.', 'Sample Post 1', '', 'inherit', 'closed', 'closed', '', '15-revision-v1', '', '', '2017-12-27 00:08:31', '2017-12-27 00:08:31', '', 15, 'http://localhost:8888/15-revision-v1/', 0, 'revision', '', 0),
(17, 1, '2017-12-27 00:08:44', '2017-12-27 00:08:44', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Auctor elit sed vulputate mi sit. Imperdiet sed euismod nisi porta lorem mollis aliquam. Urna et pharetra pharetra massa massa ultricies mi quis hendrerit. Malesuada fames ac turpis egestas integer eget aliquet. Nulla malesuada pellentesque elit eget gravida cum sociis natoque. Aenean vel elit scelerisque mauris pellentesque. Ac orci phasellus egestas tellus rutrum tellus pellentesque eu. Pellentesque adipiscing commodo elit at imperdiet dui accumsan sit. Enim facilisis gravida neque convallis a cras semper auctor neque. Cras semper auctor neque vitae.\r\n\r\nUt pharetra sit amet aliquam id diam. Nunc pulvinar sapien et ligula ullamcorper malesuada proin. Amet dictum sit amet justo donec. Urna et pharetra pharetra massa massa. Vulputate dignissim suspendisse in est ante in nibh mauris. Sem nulla pharetra diam sit amet nisl. Donec et odio pellentesque diam volutpat commodo. Quam pellentesque nec nam aliquam sem et. A diam sollicitudin tempor id eu nisl. Nisi scelerisque eu ultrices vitae auctor. Quam nulla porttitor massa id neque aliquam. Penatibus et magnis dis parturient montes nascetur ridiculus mus. Morbi quis commodo odio aenean sed adipiscing diam donec.\r\n\r\nEst lorem ipsum dolor sit amet consectetur adipiscing elit pellentesque. Integer enim neque volutpat ac tincidunt. Cursus euismod quis viverra nibh. Volutpat sed cras ornare arcu dui vivamus arcu felis. Aenean vel elit scelerisque mauris pellentesque pulvinar. Eget lorem dolor sed viverra ipsum nunc aliquet. Nibh tortor id aliquet lectus proin nibh nisl condimentum id. Hac habitasse platea dictumst vestibulum. In massa tempor nec feugiat. Mauris nunc congue nisi vitae suscipit tellus. Purus gravida quis blandit turpis. Volutpat lacus laoreet non curabitur gravida arcu. Fusce id velit ut tortor pretium. Suspendisse faucibus interdum posuere lorem ipsum dolor sit. Scelerisque in dictum non consectetur a. Massa massa ultricies mi quis hendrerit. Lacinia at quis risus sed vulputate odio ut enim blandit. Viverra ipsum nunc aliquet bibendum.\r\n\r\nMaecenas sed enim ut sem viverra aliquet eget sit. Sollicitudin tempor id eu nisl nunc mi ipsum faucibus. Ultrices mi tempus imperdiet nulla malesuada pellentesque elit eget. Id interdum velit laoreet id donec ultrices tincidunt arcu non. Egestas pretium aenean pharetra magna ac placerat. Senectus et netus et malesuada fames ac turpis. Purus in massa tempor nec feugiat nisl pretium fusce id. Habitasse platea dictumst vestibulum rhoncus est pellentesque elit ullamcorper dignissim. Sapien et ligula ullamcorper malesuada proin libero. Aliquam malesuada bibendum arcu vitae elementum curabitur vitae. Orci dapibus ultrices in iaculis nunc sed augue lacus viverra. Sem integer vitae justo eget magna fermentum iaculis eu.\r\n\r\nTempus imperdiet nulla malesuada pellentesque elit eget. Integer feugiat scelerisque varius morbi enim nunc faucibus a pellentesque. Ligula ullamcorper malesuada proin libero nunc consequat interdum. Etiam dignissim diam quis enim lobortis scelerisque. Neque vitae tempus quam pellentesque nec. Augue lacus viverra vitae congue. Mattis molestie a iaculis at erat pellentesque adipiscing. Mi ipsum faucibus vitae aliquet nec ullamcorper sit amet risus. Magnis dis parturient montes nascetur ridiculus mus mauris. Nunc consequat interdum varius sit amet mattis vulputate enim nulla. Enim ut sem viverra aliquet eget. Ut venenatis tellus in metus vulputate. Sed tempus urna et pharetra pharetra massa massa ultricies. Orci porta non pulvinar neque laoreet suspendisse interdum consectetur libero. Nec feugiat nisl pretium fusce id velit ut tortor. Urna nec tincidunt praesent semper. Bibendum at varius vel pharetra vel turpis nunc eget.', 'Sample Post 2', '', 'publish', 'open', 'open', '', 'sample-post-2', '', '', '2017-12-27 00:08:44', '2017-12-27 00:08:44', '', 0, 'http://localhost:8888/?p=17', 0, 'post', '', 0),
(18, 1, '2017-12-27 00:08:44', '2017-12-27 00:08:44', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Auctor elit sed vulputate mi sit. Imperdiet sed euismod nisi porta lorem mollis aliquam. Urna et pharetra pharetra massa massa ultricies mi quis hendrerit. Malesuada fames ac turpis egestas integer eget aliquet. Nulla malesuada pellentesque elit eget gravida cum sociis natoque. Aenean vel elit scelerisque mauris pellentesque. Ac orci phasellus egestas tellus rutrum tellus pellentesque eu. Pellentesque adipiscing commodo elit at imperdiet dui accumsan sit. Enim facilisis gravida neque convallis a cras semper auctor neque. Cras semper auctor neque vitae.\r\n\r\nUt pharetra sit amet aliquam id diam. Nunc pulvinar sapien et ligula ullamcorper malesuada proin. Amet dictum sit amet justo donec. Urna et pharetra pharetra massa massa. Vulputate dignissim suspendisse in est ante in nibh mauris. Sem nulla pharetra diam sit amet nisl. Donec et odio pellentesque diam volutpat commodo. Quam pellentesque nec nam aliquam sem et. A diam sollicitudin tempor id eu nisl. Nisi scelerisque eu ultrices vitae auctor. Quam nulla porttitor massa id neque aliquam. Penatibus et magnis dis parturient montes nascetur ridiculus mus. Morbi quis commodo odio aenean sed adipiscing diam donec.\r\n\r\nEst lorem ipsum dolor sit amet consectetur adipiscing elit pellentesque. Integer enim neque volutpat ac tincidunt. Cursus euismod quis viverra nibh. Volutpat sed cras ornare arcu dui vivamus arcu felis. Aenean vel elit scelerisque mauris pellentesque pulvinar. Eget lorem dolor sed viverra ipsum nunc aliquet. Nibh tortor id aliquet lectus proin nibh nisl condimentum id. Hac habitasse platea dictumst vestibulum. In massa tempor nec feugiat. Mauris nunc congue nisi vitae suscipit tellus. Purus gravida quis blandit turpis. Volutpat lacus laoreet non curabitur gravida arcu. Fusce id velit ut tortor pretium. Suspendisse faucibus interdum posuere lorem ipsum dolor sit. Scelerisque in dictum non consectetur a. Massa massa ultricies mi quis hendrerit. Lacinia at quis risus sed vulputate odio ut enim blandit. Viverra ipsum nunc aliquet bibendum.\r\n\r\nMaecenas sed enim ut sem viverra aliquet eget sit. Sollicitudin tempor id eu nisl nunc mi ipsum faucibus. Ultrices mi tempus imperdiet nulla malesuada pellentesque elit eget. Id interdum velit laoreet id donec ultrices tincidunt arcu non. Egestas pretium aenean pharetra magna ac placerat. Senectus et netus et malesuada fames ac turpis. Purus in massa tempor nec feugiat nisl pretium fusce id. Habitasse platea dictumst vestibulum rhoncus est pellentesque elit ullamcorper dignissim. Sapien et ligula ullamcorper malesuada proin libero. Aliquam malesuada bibendum arcu vitae elementum curabitur vitae. Orci dapibus ultrices in iaculis nunc sed augue lacus viverra. Sem integer vitae justo eget magna fermentum iaculis eu.\r\n\r\nTempus imperdiet nulla malesuada pellentesque elit eget. Integer feugiat scelerisque varius morbi enim nunc faucibus a pellentesque. Ligula ullamcorper malesuada proin libero nunc consequat interdum. Etiam dignissim diam quis enim lobortis scelerisque. Neque vitae tempus quam pellentesque nec. Augue lacus viverra vitae congue. Mattis molestie a iaculis at erat pellentesque adipiscing. Mi ipsum faucibus vitae aliquet nec ullamcorper sit amet risus. Magnis dis parturient montes nascetur ridiculus mus mauris. Nunc consequat interdum varius sit amet mattis vulputate enim nulla. Enim ut sem viverra aliquet eget. Ut venenatis tellus in metus vulputate. Sed tempus urna et pharetra pharetra massa massa ultricies. Orci porta non pulvinar neque laoreet suspendisse interdum consectetur libero. Nec feugiat nisl pretium fusce id velit ut tortor. Urna nec tincidunt praesent semper. Bibendum at varius vel pharetra vel turpis nunc eget.', 'Sample Post 2', '', 'inherit', 'closed', 'closed', '', '17-revision-v1', '', '', '2017-12-27 00:08:44', '2017-12-27 00:08:44', '', 17, 'http://localhost:8888/17-revision-v1/', 0, 'revision', '', 0),
(19, 1, '2017-12-27 00:08:56', '2017-12-27 00:08:56', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Auctor elit sed vulputate mi sit. Imperdiet sed euismod nisi porta lorem mollis aliquam. Urna et pharetra pharetra massa massa ultricies mi quis hendrerit. Malesuada fames ac turpis egestas integer eget aliquet. Nulla malesuada pellentesque elit eget gravida cum sociis natoque. Aenean vel elit scelerisque mauris pellentesque. Ac orci phasellus egestas tellus rutrum tellus pellentesque eu. Pellentesque adipiscing commodo elit at imperdiet dui accumsan sit. Enim facilisis gravida neque convallis a cras semper auctor neque. Cras semper auctor neque vitae.\r\n\r\nUt pharetra sit amet aliquam id diam. Nunc pulvinar sapien et ligula ullamcorper malesuada proin. Amet dictum sit amet justo donec. Urna et pharetra pharetra massa massa. Vulputate dignissim suspendisse in est ante in nibh mauris. Sem nulla pharetra diam sit amet nisl. Donec et odio pellentesque diam volutpat commodo. Quam pellentesque nec nam aliquam sem et. A diam sollicitudin tempor id eu nisl. Nisi scelerisque eu ultrices vitae auctor. Quam nulla porttitor massa id neque aliquam. Penatibus et magnis dis parturient montes nascetur ridiculus mus. Morbi quis commodo odio aenean sed adipiscing diam donec.\r\n\r\nEst lorem ipsum dolor sit amet consectetur adipiscing elit pellentesque. Integer enim neque volutpat ac tincidunt. Cursus euismod quis viverra nibh. Volutpat sed cras ornare arcu dui vivamus arcu felis. Aenean vel elit scelerisque mauris pellentesque pulvinar. Eget lorem dolor sed viverra ipsum nunc aliquet. Nibh tortor id aliquet lectus proin nibh nisl condimentum id. Hac habitasse platea dictumst vestibulum. In massa tempor nec feugiat. Mauris nunc congue nisi vitae suscipit tellus. Purus gravida quis blandit turpis. Volutpat lacus laoreet non curabitur gravida arcu. Fusce id velit ut tortor pretium. Suspendisse faucibus interdum posuere lorem ipsum dolor sit. Scelerisque in dictum non consectetur a. Massa massa ultricies mi quis hendrerit. Lacinia at quis risus sed vulputate odio ut enim blandit. Viverra ipsum nunc aliquet bibendum.\r\n\r\nMaecenas sed enim ut sem viverra aliquet eget sit. Sollicitudin tempor id eu nisl nunc mi ipsum faucibus. Ultrices mi tempus imperdiet nulla malesuada pellentesque elit eget. Id interdum velit laoreet id donec ultrices tincidunt arcu non. Egestas pretium aenean pharetra magna ac placerat. Senectus et netus et malesuada fames ac turpis. Purus in massa tempor nec feugiat nisl pretium fusce id. Habitasse platea dictumst vestibulum rhoncus est pellentesque elit ullamcorper dignissim. Sapien et ligula ullamcorper malesuada proin libero. Aliquam malesuada bibendum arcu vitae elementum curabitur vitae. Orci dapibus ultrices in iaculis nunc sed augue lacus viverra. Sem integer vitae justo eget magna fermentum iaculis eu.\r\n\r\nTempus imperdiet nulla malesuada pellentesque elit eget. Integer feugiat scelerisque varius morbi enim nunc faucibus a pellentesque. Ligula ullamcorper malesuada proin libero nunc consequat interdum. Etiam dignissim diam quis enim lobortis scelerisque. Neque vitae tempus quam pellentesque nec. Augue lacus viverra vitae congue. Mattis molestie a iaculis at erat pellentesque adipiscing. Mi ipsum faucibus vitae aliquet nec ullamcorper sit amet risus. Magnis dis parturient montes nascetur ridiculus mus mauris. Nunc consequat interdum varius sit amet mattis vulputate enim nulla. Enim ut sem viverra aliquet eget. Ut venenatis tellus in metus vulputate. Sed tempus urna et pharetra pharetra massa massa ultricies. Orci porta non pulvinar neque laoreet suspendisse interdum consectetur libero. Nec feugiat nisl pretium fusce id velit ut tortor. Urna nec tincidunt praesent semper. Bibendum at varius vel pharetra vel turpis nunc eget.', 'Sample Post 3', '', 'publish', 'open', 'open', '', 'sample-post-3', '', '', '2017-12-27 00:08:56', '2017-12-27 00:08:56', '', 0, 'http://localhost:8888/?p=19', 0, 'post', '', 0),
(20, 1, '2017-12-27 00:08:56', '2017-12-27 00:08:56', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Auctor elit sed vulputate mi sit. Imperdiet sed euismod nisi porta lorem mollis aliquam. Urna et pharetra pharetra massa massa ultricies mi quis hendrerit. Malesuada fames ac turpis egestas integer eget aliquet. Nulla malesuada pellentesque elit eget gravida cum sociis natoque. Aenean vel elit scelerisque mauris pellentesque. Ac orci phasellus egestas tellus rutrum tellus pellentesque eu. Pellentesque adipiscing commodo elit at imperdiet dui accumsan sit. Enim facilisis gravida neque convallis a cras semper auctor neque. Cras semper auctor neque vitae.\r\n\r\nUt pharetra sit amet aliquam id diam. Nunc pulvinar sapien et ligula ullamcorper malesuada proin. Amet dictum sit amet justo donec. Urna et pharetra pharetra massa massa. Vulputate dignissim suspendisse in est ante in nibh mauris. Sem nulla pharetra diam sit amet nisl. Donec et odio pellentesque diam volutpat commodo. Quam pellentesque nec nam aliquam sem et. A diam sollicitudin tempor id eu nisl. Nisi scelerisque eu ultrices vitae auctor. Quam nulla porttitor massa id neque aliquam. Penatibus et magnis dis parturient montes nascetur ridiculus mus. Morbi quis commodo odio aenean sed adipiscing diam donec.\r\n\r\nEst lorem ipsum dolor sit amet consectetur adipiscing elit pellentesque. Integer enim neque volutpat ac tincidunt. Cursus euismod quis viverra nibh. Volutpat sed cras ornare arcu dui vivamus arcu felis. Aenean vel elit scelerisque mauris pellentesque pulvinar. Eget lorem dolor sed viverra ipsum nunc aliquet. Nibh tortor id aliquet lectus proin nibh nisl condimentum id. Hac habitasse platea dictumst vestibulum. In massa tempor nec feugiat. Mauris nunc congue nisi vitae suscipit tellus. Purus gravida quis blandit turpis. Volutpat lacus laoreet non curabitur gravida arcu. Fusce id velit ut tortor pretium. Suspendisse faucibus interdum posuere lorem ipsum dolor sit. Scelerisque in dictum non consectetur a. Massa massa ultricies mi quis hendrerit. Lacinia at quis risus sed vulputate odio ut enim blandit. Viverra ipsum nunc aliquet bibendum.\r\n\r\nMaecenas sed enim ut sem viverra aliquet eget sit. Sollicitudin tempor id eu nisl nunc mi ipsum faucibus. Ultrices mi tempus imperdiet nulla malesuada pellentesque elit eget. Id interdum velit laoreet id donec ultrices tincidunt arcu non. Egestas pretium aenean pharetra magna ac placerat. Senectus et netus et malesuada fames ac turpis. Purus in massa tempor nec feugiat nisl pretium fusce id. Habitasse platea dictumst vestibulum rhoncus est pellentesque elit ullamcorper dignissim. Sapien et ligula ullamcorper malesuada proin libero. Aliquam malesuada bibendum arcu vitae elementum curabitur vitae. Orci dapibus ultrices in iaculis nunc sed augue lacus viverra. Sem integer vitae justo eget magna fermentum iaculis eu.\r\n\r\nTempus imperdiet nulla malesuada pellentesque elit eget. Integer feugiat scelerisque varius morbi enim nunc faucibus a pellentesque. Ligula ullamcorper malesuada proin libero nunc consequat interdum. Etiam dignissim diam quis enim lobortis scelerisque. Neque vitae tempus quam pellentesque nec. Augue lacus viverra vitae congue. Mattis molestie a iaculis at erat pellentesque adipiscing. Mi ipsum faucibus vitae aliquet nec ullamcorper sit amet risus. Magnis dis parturient montes nascetur ridiculus mus mauris. Nunc consequat interdum varius sit amet mattis vulputate enim nulla. Enim ut sem viverra aliquet eget. Ut venenatis tellus in metus vulputate. Sed tempus urna et pharetra pharetra massa massa ultricies. Orci porta non pulvinar neque laoreet suspendisse interdum consectetur libero. Nec feugiat nisl pretium fusce id velit ut tortor. Urna nec tincidunt praesent semper. Bibendum at varius vel pharetra vel turpis nunc eget.', 'Sample Post 3', '', 'inherit', 'closed', 'closed', '', '19-revision-v1', '', '', '2017-12-27 00:08:56', '2017-12-27 00:08:56', '', 19, 'http://localhost:8888/19-revision-v1/', 0, 'revision', '', 0),
(21, 1, '2017-12-27 00:09:07', '2017-12-27 00:09:07', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Auctor elit sed vulputate mi sit. Imperdiet sed euismod nisi porta lorem mollis aliquam. Urna et pharetra pharetra massa massa ultricies mi quis hendrerit. Malesuada fames ac turpis egestas integer eget aliquet. Nulla malesuada pellentesque elit eget gravida cum sociis natoque. Aenean vel elit scelerisque mauris pellentesque. Ac orci phasellus egestas tellus rutrum tellus pellentesque eu. Pellentesque adipiscing commodo elit at imperdiet dui accumsan sit. Enim facilisis gravida neque convallis a cras semper auctor neque. Cras semper auctor neque vitae.\r\n\r\nUt pharetra sit amet aliquam id diam. Nunc pulvinar sapien et ligula ullamcorper malesuada proin. Amet dictum sit amet justo donec. Urna et pharetra pharetra massa massa. Vulputate dignissim suspendisse in est ante in nibh mauris. Sem nulla pharetra diam sit amet nisl. Donec et odio pellentesque diam volutpat commodo. Quam pellentesque nec nam aliquam sem et. A diam sollicitudin tempor id eu nisl. Nisi scelerisque eu ultrices vitae auctor. Quam nulla porttitor massa id neque aliquam. Penatibus et magnis dis parturient montes nascetur ridiculus mus. Morbi quis commodo odio aenean sed adipiscing diam donec.\r\n\r\nEst lorem ipsum dolor sit amet consectetur adipiscing elit pellentesque. Integer enim neque volutpat ac tincidunt. Cursus euismod quis viverra nibh. Volutpat sed cras ornare arcu dui vivamus arcu felis. Aenean vel elit scelerisque mauris pellentesque pulvinar. Eget lorem dolor sed viverra ipsum nunc aliquet. Nibh tortor id aliquet lectus proin nibh nisl condimentum id. Hac habitasse platea dictumst vestibulum. In massa tempor nec feugiat. Mauris nunc congue nisi vitae suscipit tellus. Purus gravida quis blandit turpis. Volutpat lacus laoreet non curabitur gravida arcu. Fusce id velit ut tortor pretium. Suspendisse faucibus interdum posuere lorem ipsum dolor sit. Scelerisque in dictum non consectetur a. Massa massa ultricies mi quis hendrerit. Lacinia at quis risus sed vulputate odio ut enim blandit. Viverra ipsum nunc aliquet bibendum.\r\n\r\nMaecenas sed enim ut sem viverra aliquet eget sit. Sollicitudin tempor id eu nisl nunc mi ipsum faucibus. Ultrices mi tempus imperdiet nulla malesuada pellentesque elit eget. Id interdum velit laoreet id donec ultrices tincidunt arcu non. Egestas pretium aenean pharetra magna ac placerat. Senectus et netus et malesuada fames ac turpis. Purus in massa tempor nec feugiat nisl pretium fusce id. Habitasse platea dictumst vestibulum rhoncus est pellentesque elit ullamcorper dignissim. Sapien et ligula ullamcorper malesuada proin libero. Aliquam malesuada bibendum arcu vitae elementum curabitur vitae. Orci dapibus ultrices in iaculis nunc sed augue lacus viverra. Sem integer vitae justo eget magna fermentum iaculis eu.\r\n\r\nTempus imperdiet nulla malesuada pellentesque elit eget. Integer feugiat scelerisque varius morbi enim nunc faucibus a pellentesque. Ligula ullamcorper malesuada proin libero nunc consequat interdum. Etiam dignissim diam quis enim lobortis scelerisque. Neque vitae tempus quam pellentesque nec. Augue lacus viverra vitae congue. Mattis molestie a iaculis at erat pellentesque adipiscing. Mi ipsum faucibus vitae aliquet nec ullamcorper sit amet risus. Magnis dis parturient montes nascetur ridiculus mus mauris. Nunc consequat interdum varius sit amet mattis vulputate enim nulla. Enim ut sem viverra aliquet eget. Ut venenatis tellus in metus vulputate. Sed tempus urna et pharetra pharetra massa massa ultricies. Orci porta non pulvinar neque laoreet suspendisse interdum consectetur libero. Nec feugiat nisl pretium fusce id velit ut tortor. Urna nec tincidunt praesent semper. Bibendum at varius vel pharetra vel turpis nunc eget.', 'Sample Post 4', '', 'publish', 'open', 'open', '', 'sample-post-4', '', '', '2017-12-27 00:09:07', '2017-12-27 00:09:07', '', 0, 'http://localhost:8888/?p=21', 0, 'post', '', 0),
(22, 1, '2017-12-27 00:09:07', '2017-12-27 00:09:07', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Auctor elit sed vulputate mi sit. Imperdiet sed euismod nisi porta lorem mollis aliquam. Urna et pharetra pharetra massa massa ultricies mi quis hendrerit. Malesuada fames ac turpis egestas integer eget aliquet. Nulla malesuada pellentesque elit eget gravida cum sociis natoque. Aenean vel elit scelerisque mauris pellentesque. Ac orci phasellus egestas tellus rutrum tellus pellentesque eu. Pellentesque adipiscing commodo elit at imperdiet dui accumsan sit. Enim facilisis gravida neque convallis a cras semper auctor neque. Cras semper auctor neque vitae.\r\n\r\nUt pharetra sit amet aliquam id diam. Nunc pulvinar sapien et ligula ullamcorper malesuada proin. Amet dictum sit amet justo donec. Urna et pharetra pharetra massa massa. Vulputate dignissim suspendisse in est ante in nibh mauris. Sem nulla pharetra diam sit amet nisl. Donec et odio pellentesque diam volutpat commodo. Quam pellentesque nec nam aliquam sem et. A diam sollicitudin tempor id eu nisl. Nisi scelerisque eu ultrices vitae auctor. Quam nulla porttitor massa id neque aliquam. Penatibus et magnis dis parturient montes nascetur ridiculus mus. Morbi quis commodo odio aenean sed adipiscing diam donec.\r\n\r\nEst lorem ipsum dolor sit amet consectetur adipiscing elit pellentesque. Integer enim neque volutpat ac tincidunt. Cursus euismod quis viverra nibh. Volutpat sed cras ornare arcu dui vivamus arcu felis. Aenean vel elit scelerisque mauris pellentesque pulvinar. Eget lorem dolor sed viverra ipsum nunc aliquet. Nibh tortor id aliquet lectus proin nibh nisl condimentum id. Hac habitasse platea dictumst vestibulum. In massa tempor nec feugiat. Mauris nunc congue nisi vitae suscipit tellus. Purus gravida quis blandit turpis. Volutpat lacus laoreet non curabitur gravida arcu. Fusce id velit ut tortor pretium. Suspendisse faucibus interdum posuere lorem ipsum dolor sit. Scelerisque in dictum non consectetur a. Massa massa ultricies mi quis hendrerit. Lacinia at quis risus sed vulputate odio ut enim blandit. Viverra ipsum nunc aliquet bibendum.\r\n\r\nMaecenas sed enim ut sem viverra aliquet eget sit. Sollicitudin tempor id eu nisl nunc mi ipsum faucibus. Ultrices mi tempus imperdiet nulla malesuada pellentesque elit eget. Id interdum velit laoreet id donec ultrices tincidunt arcu non. Egestas pretium aenean pharetra magna ac placerat. Senectus et netus et malesuada fames ac turpis. Purus in massa tempor nec feugiat nisl pretium fusce id. Habitasse platea dictumst vestibulum rhoncus est pellentesque elit ullamcorper dignissim. Sapien et ligula ullamcorper malesuada proin libero. Aliquam malesuada bibendum arcu vitae elementum curabitur vitae. Orci dapibus ultrices in iaculis nunc sed augue lacus viverra. Sem integer vitae justo eget magna fermentum iaculis eu.\r\n\r\nTempus imperdiet nulla malesuada pellentesque elit eget. Integer feugiat scelerisque varius morbi enim nunc faucibus a pellentesque. Ligula ullamcorper malesuada proin libero nunc consequat interdum. Etiam dignissim diam quis enim lobortis scelerisque. Neque vitae tempus quam pellentesque nec. Augue lacus viverra vitae congue. Mattis molestie a iaculis at erat pellentesque adipiscing. Mi ipsum faucibus vitae aliquet nec ullamcorper sit amet risus. Magnis dis parturient montes nascetur ridiculus mus mauris. Nunc consequat interdum varius sit amet mattis vulputate enim nulla. Enim ut sem viverra aliquet eget. Ut venenatis tellus in metus vulputate. Sed tempus urna et pharetra pharetra massa massa ultricies. Orci porta non pulvinar neque laoreet suspendisse interdum consectetur libero. Nec feugiat nisl pretium fusce id velit ut tortor. Urna nec tincidunt praesent semper. Bibendum at varius vel pharetra vel turpis nunc eget.', 'Sample Post 4', '', 'inherit', 'closed', 'closed', '', '21-revision-v1', '', '', '2017-12-27 00:09:07', '2017-12-27 00:09:07', '', 21, 'http://localhost:8888/21-revision-v1/', 0, 'revision', '', 0),
(23, 1, '2017-12-27 00:09:20', '2017-12-27 00:09:20', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Auctor elit sed vulputate mi sit. Imperdiet sed euismod nisi porta lorem mollis aliquam. Urna et pharetra pharetra massa massa ultricies mi quis hendrerit. Malesuada fames ac turpis egestas integer eget aliquet. Nulla malesuada pellentesque elit eget gravida cum sociis natoque. Aenean vel elit scelerisque mauris pellentesque. Ac orci phasellus egestas tellus rutrum tellus pellentesque eu. Pellentesque adipiscing commodo elit at imperdiet dui accumsan sit. Enim facilisis gravida neque convallis a cras semper auctor neque. Cras semper auctor neque vitae.\r\n\r\nUt pharetra sit amet aliquam id diam. Nunc pulvinar sapien et ligula ullamcorper malesuada proin. Amet dictum sit amet justo donec. Urna et pharetra pharetra massa massa. Vulputate dignissim suspendisse in est ante in nibh mauris. Sem nulla pharetra diam sit amet nisl. Donec et odio pellentesque diam volutpat commodo. Quam pellentesque nec nam aliquam sem et. A diam sollicitudin tempor id eu nisl. Nisi scelerisque eu ultrices vitae auctor. Quam nulla porttitor massa id neque aliquam. Penatibus et magnis dis parturient montes nascetur ridiculus mus. Morbi quis commodo odio aenean sed adipiscing diam donec.\r\n\r\nEst lorem ipsum dolor sit amet consectetur adipiscing elit pellentesque. Integer enim neque volutpat ac tincidunt. Cursus euismod quis viverra nibh. Volutpat sed cras ornare arcu dui vivamus arcu felis. Aenean vel elit scelerisque mauris pellentesque pulvinar. Eget lorem dolor sed viverra ipsum nunc aliquet. Nibh tortor id aliquet lectus proin nibh nisl condimentum id. Hac habitasse platea dictumst vestibulum. In massa tempor nec feugiat. Mauris nunc congue nisi vitae suscipit tellus. Purus gravida quis blandit turpis. Volutpat lacus laoreet non curabitur gravida arcu. Fusce id velit ut tortor pretium. Suspendisse faucibus interdum posuere lorem ipsum dolor sit. Scelerisque in dictum non consectetur a. Massa massa ultricies mi quis hendrerit. Lacinia at quis risus sed vulputate odio ut enim blandit. Viverra ipsum nunc aliquet bibendum.\r\n\r\nMaecenas sed enim ut sem viverra aliquet eget sit. Sollicitudin tempor id eu nisl nunc mi ipsum faucibus. Ultrices mi tempus imperdiet nulla malesuada pellentesque elit eget. Id interdum velit laoreet id donec ultrices tincidunt arcu non. Egestas pretium aenean pharetra magna ac placerat. Senectus et netus et malesuada fames ac turpis. Purus in massa tempor nec feugiat nisl pretium fusce id. Habitasse platea dictumst vestibulum rhoncus est pellentesque elit ullamcorper dignissim. Sapien et ligula ullamcorper malesuada proin libero. Aliquam malesuada bibendum arcu vitae elementum curabitur vitae. Orci dapibus ultrices in iaculis nunc sed augue lacus viverra. Sem integer vitae justo eget magna fermentum iaculis eu.\r\n\r\nTempus imperdiet nulla malesuada pellentesque elit eget. Integer feugiat scelerisque varius morbi enim nunc faucibus a pellentesque. Ligula ullamcorper malesuada proin libero nunc consequat interdum. Etiam dignissim diam quis enim lobortis scelerisque. Neque vitae tempus quam pellentesque nec. Augue lacus viverra vitae congue. Mattis molestie a iaculis at erat pellentesque adipiscing. Mi ipsum faucibus vitae aliquet nec ullamcorper sit amet risus. Magnis dis parturient montes nascetur ridiculus mus mauris. Nunc consequat interdum varius sit amet mattis vulputate enim nulla. Enim ut sem viverra aliquet eget. Ut venenatis tellus in metus vulputate. Sed tempus urna et pharetra pharetra massa massa ultricies. Orci porta non pulvinar neque laoreet suspendisse interdum consectetur libero. Nec feugiat nisl pretium fusce id velit ut tortor. Urna nec tincidunt praesent semper. Bibendum at varius vel pharetra vel turpis nunc eget.', 'Sample Post 5', '', 'publish', 'open', 'open', '', 'sample-post-5', '', '', '2017-12-27 00:09:20', '2017-12-27 00:09:20', '', 0, 'http://localhost:8888/?p=23', 0, 'post', '', 0),
(24, 1, '2017-12-27 00:09:20', '2017-12-27 00:09:20', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Auctor elit sed vulputate mi sit. Imperdiet sed euismod nisi porta lorem mollis aliquam. Urna et pharetra pharetra massa massa ultricies mi quis hendrerit. Malesuada fames ac turpis egestas integer eget aliquet. Nulla malesuada pellentesque elit eget gravida cum sociis natoque. Aenean vel elit scelerisque mauris pellentesque. Ac orci phasellus egestas tellus rutrum tellus pellentesque eu. Pellentesque adipiscing commodo elit at imperdiet dui accumsan sit. Enim facilisis gravida neque convallis a cras semper auctor neque. Cras semper auctor neque vitae.\r\n\r\nUt pharetra sit amet aliquam id diam. Nunc pulvinar sapien et ligula ullamcorper malesuada proin. Amet dictum sit amet justo donec. Urna et pharetra pharetra massa massa. Vulputate dignissim suspendisse in est ante in nibh mauris. Sem nulla pharetra diam sit amet nisl. Donec et odio pellentesque diam volutpat commodo. Quam pellentesque nec nam aliquam sem et. A diam sollicitudin tempor id eu nisl. Nisi scelerisque eu ultrices vitae auctor. Quam nulla porttitor massa id neque aliquam. Penatibus et magnis dis parturient montes nascetur ridiculus mus. Morbi quis commodo odio aenean sed adipiscing diam donec.\r\n\r\nEst lorem ipsum dolor sit amet consectetur adipiscing elit pellentesque. Integer enim neque volutpat ac tincidunt. Cursus euismod quis viverra nibh. Volutpat sed cras ornare arcu dui vivamus arcu felis. Aenean vel elit scelerisque mauris pellentesque pulvinar. Eget lorem dolor sed viverra ipsum nunc aliquet. Nibh tortor id aliquet lectus proin nibh nisl condimentum id. Hac habitasse platea dictumst vestibulum. In massa tempor nec feugiat. Mauris nunc congue nisi vitae suscipit tellus. Purus gravida quis blandit turpis. Volutpat lacus laoreet non curabitur gravida arcu. Fusce id velit ut tortor pretium. Suspendisse faucibus interdum posuere lorem ipsum dolor sit. Scelerisque in dictum non consectetur a. Massa massa ultricies mi quis hendrerit. Lacinia at quis risus sed vulputate odio ut enim blandit. Viverra ipsum nunc aliquet bibendum.\r\n\r\nMaecenas sed enim ut sem viverra aliquet eget sit. Sollicitudin tempor id eu nisl nunc mi ipsum faucibus. Ultrices mi tempus imperdiet nulla malesuada pellentesque elit eget. Id interdum velit laoreet id donec ultrices tincidunt arcu non. Egestas pretium aenean pharetra magna ac placerat. Senectus et netus et malesuada fames ac turpis. Purus in massa tempor nec feugiat nisl pretium fusce id. Habitasse platea dictumst vestibulum rhoncus est pellentesque elit ullamcorper dignissim. Sapien et ligula ullamcorper malesuada proin libero. Aliquam malesuada bibendum arcu vitae elementum curabitur vitae. Orci dapibus ultrices in iaculis nunc sed augue lacus viverra. Sem integer vitae justo eget magna fermentum iaculis eu.\r\n\r\nTempus imperdiet nulla malesuada pellentesque elit eget. Integer feugiat scelerisque varius morbi enim nunc faucibus a pellentesque. Ligula ullamcorper malesuada proin libero nunc consequat interdum. Etiam dignissim diam quis enim lobortis scelerisque. Neque vitae tempus quam pellentesque nec. Augue lacus viverra vitae congue. Mattis molestie a iaculis at erat pellentesque adipiscing. Mi ipsum faucibus vitae aliquet nec ullamcorper sit amet risus. Magnis dis parturient montes nascetur ridiculus mus mauris. Nunc consequat interdum varius sit amet mattis vulputate enim nulla. Enim ut sem viverra aliquet eget. Ut venenatis tellus in metus vulputate. Sed tempus urna et pharetra pharetra massa massa ultricies. Orci porta non pulvinar neque laoreet suspendisse interdum consectetur libero. Nec feugiat nisl pretium fusce id velit ut tortor. Urna nec tincidunt praesent semper. Bibendum at varius vel pharetra vel turpis nunc eget.', 'Sample Post 5', '', 'inherit', 'closed', 'closed', '', '23-revision-v1', '', '', '2017-12-27 00:09:20', '2017-12-27 00:09:20', '', 23, 'http://localhost:8888/23-revision-v1/', 0, 'revision', '', 0),
(28, 1, '2018-01-23 02:41:42', '2018-01-23 02:41:42', 'a:12:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";s:8:"readonly";i:0;s:8:"disabled";i:0;}', 'Firm Number Local', 'firm_number_local', 'publish', 'closed', 'closed', '', 'field_5a66a0dc333dd', '', '', '2018-01-23 02:44:34', '2018-01-23 02:44:34', '', 4, 'http://localhost:8888/?post_type=acf-field&#038;p=28', 1, 'acf-field', '', 0),
(29, 1, '2018-01-23 02:44:34', '2018-01-23 02:44:34', 'a:12:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";s:8:"readonly";i:0;s:8:"disabled";i:0;}', 'Firm Number Toll Free', 'firm_number_toll_free', 'publish', 'closed', 'closed', '', 'field_5a66a16d94390', '', '', '2018-01-23 02:44:34', '2018-01-23 02:44:34', '', 4, 'http://localhost:8888/?post_type=acf-field&p=29', 2, 'acf-field', '', 0),
(30, 1, '2018-01-23 02:44:34', '2018-01-23 02:44:34', 'a:12:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";s:8:"readonly";i:0;s:8:"disabled";i:0;}', 'Main Wistia Video ID', 'main_wistia_video_id', 'publish', 'closed', 'closed', '', 'field_5a66a12694389', '', '', '2018-01-23 02:44:34', '2018-01-23 02:44:34', '', 4, 'http://localhost:8888/?post_type=acf-field&p=30', 3, 'acf-field', '', 0),
(31, 1, '2018-01-23 02:44:34', '2018-01-23 02:44:34', 'a:7:{s:4:"type";s:3:"tab";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"placement";s:3:"top";s:8:"endpoint";i:0;}', 'Social Media', '', 'publish', 'closed', 'closed', '', 'field_5a66a1369438a', '', '', '2018-01-23 02:49:05', '2018-01-23 02:49:05', '', 4, 'http://localhost:8888/?post_type=acf-field&#038;p=31', 12, 'acf-field', '', 0),
(32, 1, '2018-01-23 02:44:34', '2018-01-23 02:44:34', 'a:12:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";s:8:"readonly";i:0;s:8:"disabled";i:0;}', 'Facebook Link', 'facebook_link', 'publish', 'closed', 'closed', '', 'field_5a66a1409438b', '', '', '2018-01-23 02:49:05', '2018-01-23 02:49:05', '', 4, 'http://localhost:8888/?post_type=acf-field&#038;p=32', 13, 'acf-field', '', 0),
(33, 1, '2018-01-23 02:44:34', '2018-01-23 02:44:34', 'a:12:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";s:8:"readonly";i:0;s:8:"disabled";i:0;}', 'Google Plus Link', 'google_plus_link', 'publish', 'closed', 'closed', '', 'field_5a66a1489438c', '', '', '2018-01-23 02:49:05', '2018-01-23 02:49:05', '', 4, 'http://localhost:8888/?post_type=acf-field&#038;p=33', 14, 'acf-field', '', 0),
(34, 1, '2018-01-23 02:44:34', '2018-01-23 02:44:34', 'a:12:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";s:8:"readonly";i:0;s:8:"disabled";i:0;}', 'Twitter Link', 'twitter_link', 'publish', 'closed', 'closed', '', 'field_5a66a1529438d', '', '', '2018-01-23 02:49:05', '2018-01-23 02:49:05', '', 4, 'http://localhost:8888/?post_type=acf-field&#038;p=34', 15, 'acf-field', '', 0),
(35, 1, '2018-01-23 02:44:34', '2018-01-23 02:44:34', 'a:12:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";s:8:"readonly";i:0;s:8:"disabled";i:0;}', 'Linked In Link', 'linked_in_link', 'publish', 'closed', 'closed', '', 'field_5a66a15a9438e', '', '', '2018-01-23 02:49:05', '2018-01-23 02:49:05', '', 4, 'http://localhost:8888/?post_type=acf-field&#038;p=35', 16, 'acf-field', '', 0) ;
INSERT INTO `wp_posts` ( `ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(36, 1, '2018-01-23 02:44:34', '2018-01-23 02:44:34', 'a:12:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";s:8:"readonly";i:0;s:8:"disabled";i:0;}', 'Youtube Link', 'youtube_link', 'publish', 'closed', 'closed', '', 'field_5a66a1659438f', '', '', '2018-01-23 02:49:05', '2018-01-23 02:49:05', '', 4, 'http://localhost:8888/?post_type=acf-field&#038;p=36', 17, 'acf-field', '', 0),
(37, 1, '2018-01-23 02:45:06', '2018-01-23 02:45:06', '<pre>Thank you for your submission, we will contact you shortly.</pre>', 'Thank You', '', 'publish', 'closed', 'closed', '', 'thank-you', '', '', '2018-01-23 02:45:06', '2018-01-23 02:45:06', '', 0, 'http://localhost:8888/?page_id=37', 0, 'page', '', 0),
(38, 1, '2018-01-23 02:45:06', '2018-01-23 02:45:06', '<pre>Thank you for your submission, we will contact you shortly.</pre>', 'Thank You', '', 'inherit', 'closed', 'closed', '', '37-revision-v1', '', '', '2018-01-23 02:45:06', '2018-01-23 02:45:06', '', 37, 'http://localhost:8888/37-revision-v1/', 0, 'revision', '', 0),
(39, 1, '2018-01-23 03:09:27', '2018-01-23 03:09:27', '', 'Privacy Policy', '', 'publish', 'closed', 'closed', '', 'privacy-policy', '', '', '2018-01-23 03:09:27', '2018-01-23 03:09:27', '', 0, 'http://localhost:8888/?page_id=39', 0, 'page', '', 0),
(40, 1, '2018-01-23 02:47:22', '2018-01-23 02:47:22', '', 'Privacy Policy', '', 'inherit', 'closed', 'closed', '', '39-revision-v1', '', '', '2018-01-23 02:47:22', '2018-01-23 02:47:22', '', 39, 'http://localhost:8888/39-revision-v1/', 0, 'revision', '', 0),
(41, 1, '2018-01-23 02:49:05', '2018-01-23 02:49:05', 'a:7:{s:4:"type";s:3:"tab";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"placement";s:3:"top";s:8:"endpoint";i:0;}', 'Firm Location', '', 'publish', 'closed', 'closed', '', 'field_5a66a24928de4', '', '', '2018-01-23 02:49:05', '2018-01-23 02:49:05', '', 4, 'http://localhost:8888/?post_type=acf-field&p=41', 4, 'acf-field', '', 0),
(42, 1, '2018-01-23 02:49:05', '2018-01-23 02:49:05', 'a:12:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";s:8:"readonly";i:0;s:8:"disabled";i:0;}', 'Firm Street Address', 'firm_street_address', 'publish', 'closed', 'closed', '', 'field_5a66a25e28de5', '', '', '2018-01-23 02:49:05', '2018-01-23 02:49:05', '', 4, 'http://localhost:8888/?post_type=acf-field&p=42', 5, 'acf-field', '', 0),
(43, 1, '2018-01-23 02:49:05', '2018-01-23 02:49:05', 'a:12:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";s:8:"readonly";i:0;s:8:"disabled";i:0;}', 'Firm City State Zip', 'firm_city_state_zip', 'publish', 'closed', 'closed', '', 'field_5a66a27428de6', '', '', '2018-01-23 02:49:05', '2018-01-23 02:49:05', '', 4, 'http://localhost:8888/?post_type=acf-field&p=43', 6, 'acf-field', '', 0),
(44, 1, '2018-01-23 02:49:05', '2018-01-23 02:49:05', 'a:12:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";s:8:"readonly";i:0;s:8:"disabled";i:0;}', 'Firm Directions Link', 'firm_directions_link', 'publish', 'closed', 'closed', '', 'field_5a66a28528de7', '', '', '2018-01-23 02:49:05', '2018-01-23 02:49:05', '', 4, 'http://localhost:8888/?post_type=acf-field&p=44', 7, 'acf-field', '', 0),
(45, 1, '2018-01-23 02:49:05', '2018-01-23 02:49:05', 'a:12:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";s:8:"readonly";i:0;s:8:"disabled";i:0;}', 'Firm Map Embed', 'firm_map_embed', 'publish', 'closed', 'closed', '', 'field_5a66a29028de8', '', '', '2018-01-23 02:49:05', '2018-01-23 02:49:05', '', 4, 'http://localhost:8888/?post_type=acf-field&p=45', 8, 'acf-field', '', 0),
(46, 1, '2018-01-23 03:09:20', '2018-01-23 03:09:20', '', 'About', '', 'publish', 'closed', 'closed', '', 'about', '', '', '2018-01-23 03:09:20', '2018-01-23 03:09:20', '', 0, 'http://localhost:8888/?page_id=46', 0, 'page', '', 0),
(47, 1, '2018-01-23 03:09:20', '2018-01-23 03:09:20', '', 'About', '', 'inherit', 'closed', 'closed', '', '46-revision-v1', '', '', '2018-01-23 03:09:20', '2018-01-23 03:09:20', '', 46, 'http://localhost:8888/46-revision-v1/', 0, 'revision', '', 0),
(48, 1, '2018-01-23 03:09:52', '2018-01-23 03:09:52', '', 'Practice Areas', '', 'trash', 'closed', 'closed', '', 'practice-areas__trashed', '', '', '2018-08-22 11:48:51', '2018-08-22 19:48:51', '', 0, 'http://localhost:8888/?page_id=48', 0, 'page', '', 0),
(49, 1, '2018-01-23 03:09:50', '2018-01-23 03:09:50', '', 'Practice Areas', '', 'inherit', 'closed', 'closed', '', '48-revision-v1', '', '', '2018-01-23 03:09:50', '2018-01-23 03:09:50', '', 48, 'http://localhost:8888/48-revision-v1/', 0, 'revision', '', 0),
(50, 1, '2018-01-23 03:10:03', '2018-01-23 11:10:03', '', 'Practice Area', '', 'publish', 'closed', 'closed', '', 'practice-area', '', '', '2018-08-22 11:49:18', '2018-08-22 19:49:18', '', 0, 'http://localhost:8888/?page_id=50', 0, 'page', '', 0),
(51, 1, '2018-01-23 03:10:03', '2018-01-23 03:10:03', '', 'Practice Area', '', 'inherit', 'closed', 'closed', '', '50-revision-v1', '', '', '2018-01-23 03:10:03', '2018-01-23 03:10:03', '', 50, 'http://localhost:8888/50-revision-v1/', 0, 'revision', '', 0),
(52, 1, '2018-01-23 03:10:21', '2018-01-23 03:10:21', '', 'Testimonials', '', 'publish', 'closed', 'closed', '', 'testimonials', '', '', '2018-01-23 03:10:21', '2018-01-23 03:10:21', '', 0, 'http://localhost:8888/?page_id=52', 0, 'page', '', 0),
(53, 1, '2018-01-23 03:10:21', '2018-01-23 03:10:21', '', 'Testimonials', '', 'inherit', 'closed', 'closed', '', '52-revision-v1', '', '', '2018-01-23 03:10:21', '2018-01-23 03:10:21', '', 52, 'http://localhost:8888/52-revision-v1/', 0, 'revision', '', 0),
(54, 1, '2018-01-23 03:10:28', '2018-01-23 03:10:28', '', 'Results', '', 'publish', 'closed', 'closed', '', 'results', '', '', '2018-01-23 03:10:28', '2018-01-23 03:10:28', '', 0, 'http://localhost:8888/?page_id=54', 0, 'page', '', 0),
(55, 1, '2018-01-23 03:10:28', '2018-01-23 03:10:28', '', 'Results', '', 'inherit', 'closed', 'closed', '', '54-revision-v1', '', '', '2018-01-23 03:10:28', '2018-01-23 03:10:28', '', 54, 'http://localhost:8888/54-revision-v1/', 0, 'revision', '', 0),
(56, 1, '2018-01-23 03:10:38', '2018-01-23 03:10:38', '', 'Contact', '', 'publish', 'closed', 'closed', '', 'contact', '', '', '2018-01-23 03:10:38', '2018-01-23 03:10:38', '', 0, 'http://localhost:8888/?page_id=56', 0, 'page', '', 0),
(57, 1, '2018-01-23 03:10:38', '2018-01-23 03:10:38', '', 'Contact', '', 'inherit', 'closed', 'closed', '', '56-revision-v1', '', '', '2018-01-23 03:10:38', '2018-01-23 03:10:38', '', 56, 'http://localhost:8888/56-revision-v1/', 0, 'revision', '', 0),
(58, 1, '2018-01-23 03:11:51', '2018-01-23 03:11:51', '', 'Attorneys', '', 'trash', 'closed', 'closed', '', 'attorneys__trashed', '', '', '2018-08-22 11:48:46', '2018-08-22 19:48:46', '', 0, 'http://localhost:8888/?page_id=58', 0, 'page', '', 0),
(59, 1, '2018-01-23 03:11:51', '2018-01-23 03:11:51', '', 'Attorneys', '', 'inherit', 'closed', 'closed', '', '58-revision-v1', '', '', '2018-01-23 03:11:51', '2018-01-23 03:11:51', '', 58, 'http://localhost:8888/58-revision-v1/', 0, 'revision', '', 0),
(60, 1, '2018-01-23 03:12:05', '2018-01-23 11:12:05', '', 'Attorney Profile', '', 'publish', 'closed', 'closed', '', 'attorney-profile', '', '', '2018-08-22 11:49:12', '2018-08-22 19:49:12', '', 0, 'http://localhost:8888/?page_id=60', 0, 'page', '', 0),
(61, 1, '2018-01-23 03:12:05', '2018-01-23 03:12:05', '', 'Attorney Profile', '', 'inherit', 'closed', 'closed', '', '60-revision-v1', '', '', '2018-01-23 03:12:05', '2018-01-23 03:12:05', '', 60, 'http://localhost:8888/60-revision-v1/', 0, 'revision', '', 0),
(62, 1, '2018-01-23 03:12:18', '2018-01-23 03:12:18', '', 'Videos', '', 'publish', 'closed', 'closed', '', 'videos', '', '', '2018-01-23 03:12:18', '2018-01-23 03:12:18', '', 0, 'http://localhost:8888/?page_id=62', 0, 'page', '', 0),
(63, 1, '2018-01-23 03:12:18', '2018-01-23 03:12:18', '', 'Videos', '', 'inherit', 'closed', 'closed', '', '62-revision-v1', '', '', '2018-01-23 03:12:18', '2018-01-23 03:12:18', '', 62, 'http://localhost:8888/62-revision-v1/', 0, 'revision', '', 0),
(67, 1, '2018-08-21 14:25:31', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'open', 'open', '', '', '', '', '2018-08-21 14:25:31', '0000-00-00 00:00:00', '', 0, 'http://cannon-demo.com/?p=67', 0, 'post', '', 0),
(68, 1, '2018-08-22 11:46:14', '2018-08-22 19:46:14', '', 'About Us', '', 'trash', 'closed', 'closed', '', '__trashed', '', '', '2018-08-22 11:46:14', '2018-08-22 19:46:14', '', 0, 'http://cannon-demo.com/?page_id=68', 0, 'page', '', 0),
(69, 1, '2018-08-22 11:46:14', '2018-08-22 19:46:14', '', 'About Us', '', 'inherit', 'closed', 'closed', '', '68-revision-v1', '', '', '2018-08-22 11:46:14', '2018-08-22 19:46:14', '', 68, 'http://cannon-demo.com/68-revision-v1/', 0, 'revision', '', 0),
(70, 1, '2018-08-22 11:48:40', '2018-08-22 19:48:40', ' ', '', '', 'publish', 'closed', 'closed', '', '70', '', '', '2018-08-23 10:10:17', '2018-08-23 18:10:17', '', 0, 'http://cannon-demo.com/?p=70', 1, 'nav_menu_item', '', 0),
(71, 1, '2018-08-22 11:48:40', '2018-08-22 19:48:40', '', 'About', '', 'publish', 'closed', 'closed', '', 'about', '', '', '2018-08-23 10:10:17', '2018-08-23 18:10:17', '', 0, 'http://cannon-demo.com/?p=71', 2, 'nav_menu_item', '', 0),
(72, 1, '2018-08-22 11:48:40', '2018-08-22 19:48:40', ' ', '', '', 'publish', 'closed', 'closed', '', '72', '', '', '2018-08-23 10:10:17', '2018-08-23 18:10:17', '', 0, 'http://cannon-demo.com/?p=72', 3, 'nav_menu_item', '', 0),
(73, 1, '2018-08-22 11:48:40', '2018-08-22 19:48:40', '', 'Attorneys', '', 'publish', 'closed', 'closed', '', 'attorneys', '', '', '2018-08-23 10:10:18', '2018-08-23 18:10:18', '', 0, 'http://cannon-demo.com/?p=73', 4, 'nav_menu_item', '', 0),
(74, 1, '2018-08-22 11:48:40', '2018-08-22 19:48:40', ' ', '', '', 'publish', 'closed', 'closed', '', '74', '', '', '2018-08-23 10:10:18', '2018-08-23 18:10:18', '', 0, 'http://cannon-demo.com/?p=74', 5, 'nav_menu_item', '', 0),
(75, 1, '2018-08-22 11:48:40', '2018-08-22 19:48:40', ' ', '', '', 'publish', 'closed', 'closed', '', '75', '', '', '2018-08-23 10:10:18', '2018-08-23 18:10:18', '', 0, 'http://cannon-demo.com/?p=75', 9, 'nav_menu_item', '', 0),
(76, 1, '2018-08-22 11:48:40', '2018-08-22 19:48:40', ' ', '', '', 'publish', 'closed', 'closed', '', '76', '', '', '2018-08-23 10:10:18', '2018-08-23 18:10:18', '', 0, 'http://cannon-demo.com/?p=76', 10, 'nav_menu_item', '', 0),
(77, 1, '2018-08-22 11:48:40', '2018-08-22 19:48:40', ' ', '', '', 'publish', 'closed', 'closed', '', '77', '', '', '2018-08-23 10:10:18', '2018-08-23 18:10:18', '', 0, 'http://cannon-demo.com/?p=77', 11, 'nav_menu_item', '', 0),
(78, 1, '2018-08-22 11:48:40', '2018-08-22 19:48:40', ' ', '', '', 'publish', 'closed', 'closed', '', '78', '', '', '2018-08-23 10:10:18', '2018-08-23 18:10:18', '', 0, 'http://cannon-demo.com/?p=78', 12, 'nav_menu_item', '', 0),
(79, 1, '2018-08-23 08:01:14', '2018-08-23 16:01:14', '', 'Meet the Team', '', 'publish', 'closed', 'closed', '', 'meet-the-team', '', '', '2018-08-23 08:01:14', '2018-08-23 16:01:14', '', 0, 'http://cannon-demo.com/?page_id=79', 0, 'page', '', 0),
(80, 1, '2018-08-23 08:01:14', '2018-08-23 16:01:14', '', 'Meet the Team', '', 'inherit', 'closed', 'closed', '', '79-revision-v1', '', '', '2018-08-23 08:01:14', '2018-08-23 16:01:14', '', 79, 'http://cannon-demo.com/79-revision-v1/', 0, 'revision', '', 0),
(81, 1, '2018-08-23 08:01:26', '2018-08-23 16:01:26', ' ', '', '', 'publish', 'closed', 'closed', '', '81', '', '', '2018-08-23 10:10:18', '2018-08-23 18:10:18', '', 0, 'http://cannon-demo.com/?p=81', 6, 'nav_menu_item', '', 0),
(82, 1, '2018-08-23 10:10:06', '2018-08-23 18:10:06', '', 'Practice Areas', '', 'publish', 'closed', 'closed', '', 'practice-areas', '', '', '2018-08-23 10:10:18', '2018-08-23 18:10:18', '', 0, 'http://cannon-demo.com/?p=82', 7, 'nav_menu_item', '', 0),
(83, 1, '2018-08-23 10:10:06', '2018-08-23 18:10:06', ' ', '', '', 'publish', 'closed', 'closed', '', '83', '', '', '2018-08-23 10:10:18', '2018-08-23 18:10:18', '', 0, 'http://cannon-demo.com/?p=83', 8, 'nav_menu_item', '', 0) ;

#
# End of data contents of table `wp_posts`
# --------------------------------------------------------



#
# Delete any existing table `wp_rg_form`
#

DROP TABLE IF EXISTS `wp_rg_form`;


#
# Table structure of table `wp_rg_form`
#

CREATE TABLE `wp_rg_form` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(150) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `date_created` datetime NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `is_trash` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_rg_form`
#
INSERT INTO `wp_rg_form` ( `id`, `title`, `date_created`, `is_active`, `is_trash`) VALUES
(1, 'Contact', '2018-01-23 02:49:42', 1, 0) ;

#
# End of data contents of table `wp_rg_form`
# --------------------------------------------------------



#
# Delete any existing table `wp_rg_form_meta`
#

DROP TABLE IF EXISTS `wp_rg_form_meta`;


#
# Table structure of table `wp_rg_form_meta`
#

CREATE TABLE `wp_rg_form_meta` (
  `form_id` mediumint(8) unsigned NOT NULL,
  `display_meta` longtext COLLATE utf8mb4_unicode_520_ci,
  `entries_grid_meta` longtext COLLATE utf8mb4_unicode_520_ci,
  `confirmations` longtext COLLATE utf8mb4_unicode_520_ci,
  `notifications` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`form_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_rg_form_meta`
#
INSERT INTO `wp_rg_form_meta` ( `form_id`, `display_meta`, `entries_grid_meta`, `confirmations`, `notifications`) VALUES
(1, '{"title":"Contact","description":"","labelPlacement":"top_label","descriptionPlacement":"below","button":{"type":"text","text":"Submit","imageUrl":""},"fields":[],"version":"2.2.5","id":1,"notifications":{"5a66a2c69111e":{"id":"5a66a2c69111e","to":"{admin_email}","name":"Admin Notification","event":"form_submission","toType":"email","subject":"New submission from {form_title}","message":"{all_fields}"}},"confirmations":{"5a66a2c69162e":{"id":"5a66a2c69162e","name":"Default Confirmation","isDefault":true,"type":"message","message":"Thanks for contacting us! We will get in touch with you shortly.","url":"","pageId":"","queryString":""}},"subLabelPlacement":"below","cssClass":"","enableHoneypot":true,"enableAnimation":false,"save":{"enabled":false,"button":{"type":"link","text":"Save and Continue Later"}},"limitEntries":false,"limitEntriesCount":"","limitEntriesPeriod":"","limitEntriesMessage":"","scheduleForm":false,"scheduleStart":"","scheduleStartHour":"","scheduleStartMinute":"","scheduleStartAmpm":"","scheduleEnd":"","scheduleEndHour":"","scheduleEndMinute":"","scheduleEndAmpm":"","schedulePendingMessage":"","scheduleMessage":"","requireLogin":false,"requireLoginMessage":""}', NULL, '{"5a66a2c69162e":{"id":"5a66a2c69162e","name":"Default Confirmation","isDefault":true,"type":"page","message":"Thanks for contacting us! We will get in touch with you shortly.","url":"","pageId":37,"queryString":"","disableAutoformat":false,"conditionalLogic":[]}}', '{"5a66a2c69111e":{"isActive":true,"id":"5a66a2c69111e","name":"Admin Notification","service":"wordpress","event":"form_submission","to":"joe@1point21interactive.com","toType":"email","bcc":"","subject":"{Name:1} - Case Evaluation inquiry from clientname.com","message":"<div align=\\"center\\"><img src=\\"http:\\/\\/www.ilawyermarketing.com\\/images\\/ilawyerlogo.jpg\\" alt=\\"Website lead from iLawyerMarketing\\" \\/><\\/div>\\r\\n{all_fields}","from":"noreply@ilawyermarketing.org","fromName":"Clientwebsite.com","replyTo":"{Email: 3}","routing":null,"conditionalLogic":null,"disableAutoformat":false}}') ;

#
# End of data contents of table `wp_rg_form_meta`
# --------------------------------------------------------



#
# Delete any existing table `wp_rg_form_view`
#

DROP TABLE IF EXISTS `wp_rg_form_view`;


#
# Table structure of table `wp_rg_form_view`
#

CREATE TABLE `wp_rg_form_view` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `form_id` mediumint(8) unsigned NOT NULL,
  `date_created` datetime NOT NULL,
  `ip` char(15) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `count` mediumint(8) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `form_id` (`form_id`),
  KEY `date_created` (`date_created`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_rg_form_view`
#

#
# End of data contents of table `wp_rg_form_view`
# --------------------------------------------------------



#
# Delete any existing table `wp_rg_incomplete_submissions`
#

DROP TABLE IF EXISTS `wp_rg_incomplete_submissions`;


#
# Table structure of table `wp_rg_incomplete_submissions`
#

CREATE TABLE `wp_rg_incomplete_submissions` (
  `uuid` char(32) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `form_id` mediumint(8) unsigned NOT NULL,
  `date_created` datetime NOT NULL,
  `ip` varchar(39) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `source_url` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `submission` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  PRIMARY KEY (`uuid`),
  KEY `form_id` (`form_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_rg_incomplete_submissions`
#

#
# End of data contents of table `wp_rg_incomplete_submissions`
# --------------------------------------------------------



#
# Delete any existing table `wp_rg_lead`
#

DROP TABLE IF EXISTS `wp_rg_lead`;


#
# Table structure of table `wp_rg_lead`
#

CREATE TABLE `wp_rg_lead` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `form_id` mediumint(8) unsigned NOT NULL,
  `post_id` bigint(20) unsigned DEFAULT NULL,
  `date_created` datetime NOT NULL,
  `is_starred` tinyint(1) NOT NULL DEFAULT '0',
  `is_read` tinyint(1) NOT NULL DEFAULT '0',
  `ip` varchar(39) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `source_url` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_agent` varchar(250) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `currency` varchar(5) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `payment_status` varchar(15) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `payment_date` datetime DEFAULT NULL,
  `payment_amount` decimal(19,2) DEFAULT NULL,
  `transaction_id` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `is_fulfilled` tinyint(1) DEFAULT NULL,
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `transaction_type` tinyint(1) DEFAULT NULL,
  `status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'active',
  `payment_method` varchar(30) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `form_id` (`form_id`),
  KEY `status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_rg_lead`
#

#
# End of data contents of table `wp_rg_lead`
# --------------------------------------------------------



#
# Delete any existing table `wp_rg_lead_detail`
#

DROP TABLE IF EXISTS `wp_rg_lead_detail`;


#
# Table structure of table `wp_rg_lead_detail`
#

CREATE TABLE `wp_rg_lead_detail` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `lead_id` int(10) unsigned NOT NULL,
  `form_id` mediumint(8) unsigned NOT NULL,
  `field_number` float NOT NULL,
  `value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`id`),
  KEY `form_id` (`form_id`),
  KEY `lead_id` (`lead_id`),
  KEY `lead_field_number` (`lead_id`,`field_number`),
  KEY `lead_field_value` (`value`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_rg_lead_detail`
#

#
# End of data contents of table `wp_rg_lead_detail`
# --------------------------------------------------------



#
# Delete any existing table `wp_rg_lead_detail_long`
#

DROP TABLE IF EXISTS `wp_rg_lead_detail_long`;


#
# Table structure of table `wp_rg_lead_detail_long`
#

CREATE TABLE `wp_rg_lead_detail_long` (
  `lead_detail_id` bigint(20) unsigned NOT NULL,
  `value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`lead_detail_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_rg_lead_detail_long`
#

#
# End of data contents of table `wp_rg_lead_detail_long`
# --------------------------------------------------------



#
# Delete any existing table `wp_rg_lead_meta`
#

DROP TABLE IF EXISTS `wp_rg_lead_meta`;


#
# Table structure of table `wp_rg_lead_meta`
#

CREATE TABLE `wp_rg_lead_meta` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `form_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `lead_id` bigint(20) unsigned NOT NULL,
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`id`),
  KEY `lead_id` (`lead_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_rg_lead_meta`
#

#
# End of data contents of table `wp_rg_lead_meta`
# --------------------------------------------------------



#
# Delete any existing table `wp_rg_lead_notes`
#

DROP TABLE IF EXISTS `wp_rg_lead_notes`;


#
# Table structure of table `wp_rg_lead_notes`
#

CREATE TABLE `wp_rg_lead_notes` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `lead_id` int(10) unsigned NOT NULL,
  `user_name` varchar(250) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `user_id` bigint(20) DEFAULT NULL,
  `date_created` datetime NOT NULL,
  `value` longtext COLLATE utf8mb4_unicode_520_ci,
  `note_type` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `lead_id` (`lead_id`),
  KEY `lead_user_key` (`lead_id`,`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_rg_lead_notes`
#

#
# End of data contents of table `wp_rg_lead_notes`
# --------------------------------------------------------



#
# Delete any existing table `wp_term_relationships`
#

DROP TABLE IF EXISTS `wp_term_relationships`;


#
# Table structure of table `wp_term_relationships`
#

CREATE TABLE `wp_term_relationships` (
  `object_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_taxonomy_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_order` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  KEY `term_taxonomy_id` (`term_taxonomy_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_term_relationships`
#
INSERT INTO `wp_term_relationships` ( `object_id`, `term_taxonomy_id`, `term_order`) VALUES
(15, 1, 0),
(17, 1, 0),
(19, 1, 0),
(21, 1, 0),
(23, 1, 0),
(70, 2, 0),
(71, 2, 0),
(72, 2, 0),
(73, 2, 0),
(74, 2, 0),
(75, 2, 0),
(76, 2, 0),
(77, 2, 0),
(78, 2, 0),
(81, 2, 0),
(82, 2, 0),
(83, 2, 0) ;

#
# End of data contents of table `wp_term_relationships`
# --------------------------------------------------------



#
# Delete any existing table `wp_term_taxonomy`
#

DROP TABLE IF EXISTS `wp_term_taxonomy`;


#
# Table structure of table `wp_term_taxonomy`
#

CREATE TABLE `wp_term_taxonomy` (
  `term_taxonomy_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `taxonomy` varchar(32) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `description` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_taxonomy_id`),
  UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  KEY `taxonomy` (`taxonomy`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_term_taxonomy`
#
INSERT INTO `wp_term_taxonomy` ( `term_taxonomy_id`, `term_id`, `taxonomy`, `description`, `parent`, `count`) VALUES
(1, 1, 'category', '', 0, 5),
(2, 2, 'nav_menu', '', 0, 12) ;

#
# End of data contents of table `wp_term_taxonomy`
# --------------------------------------------------------



#
# Delete any existing table `wp_termmeta`
#

DROP TABLE IF EXISTS `wp_termmeta`;


#
# Table structure of table `wp_termmeta`
#

CREATE TABLE `wp_termmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`meta_id`),
  KEY `term_id` (`term_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_termmeta`
#

#
# End of data contents of table `wp_termmeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_terms`
#

DROP TABLE IF EXISTS `wp_terms`;


#
# Table structure of table `wp_terms`
#

CREATE TABLE `wp_terms` (
  `term_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `slug` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `term_group` bigint(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_id`),
  KEY `slug` (`slug`(191)),
  KEY `name` (`name`(191))
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_terms`
#
INSERT INTO `wp_terms` ( `term_id`, `name`, `slug`, `term_group`) VALUES
(1, 'Uncategorized', 'uncategorized', 0),
(2, 'Main Menu', 'main-menu', 0) ;

#
# End of data contents of table `wp_terms`
# --------------------------------------------------------



#
# Delete any existing table `wp_usermeta`
#

DROP TABLE IF EXISTS `wp_usermeta`;


#
# Table structure of table `wp_usermeta`
#

CREATE TABLE `wp_usermeta` (
  `umeta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`umeta_id`),
  KEY `user_id` (`user_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_usermeta`
#
INSERT INTO `wp_usermeta` ( `umeta_id`, `user_id`, `meta_key`, `meta_value`) VALUES
(1, 1, 'nickname', 'joe'),
(2, 1, 'first_name', ''),
(3, 1, 'last_name', ''),
(4, 1, 'description', ''),
(5, 1, 'rich_editing', 'true'),
(6, 1, 'comment_shortcuts', 'false'),
(7, 1, 'admin_color', 'fresh'),
(8, 1, 'use_ssl', '0'),
(9, 1, 'show_admin_bar_front', 'true'),
(10, 1, 'locale', ''),
(11, 1, 'wp_capabilities', 'a:1:{s:13:"administrator";b:1;}'),
(12, 1, 'wp_user_level', '10'),
(13, 1, 'dismissed_wp_pointers', 'wp496_privacy'),
(14, 1, 'show_welcome_panel', '1'),
(15, 1, 'session_tokens', 'a:1:{s:64:"3b3f0c277ff9cbd442381625310779a867f403cfdf560b42908d64efb899f98f";a:4:{s:10:"expiration";i:1535304497;s:2:"ip";s:3:"::1";s:2:"ua";s:121:"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36";s:5:"login";i:1535131697;}}'),
(16, 1, 'wp_user-settings', 'hidetb=1&editor=tinymce&libraryContent=browse&imgsize=full&posts_list_mode=list&mfold=o'),
(17, 1, 'wp_user-settings-time', '1531250034'),
(18, 1, 'wp_dashboard_quick_press_last_post_id', '67'),
(19, 1, 'community-events-location', 'a:1:{s:2:"ip";s:2:"::";}'),
(20, 1, 'managenav-menuscolumnshidden', 'a:5:{i:0;s:11:"link-target";i:1;s:11:"css-classes";i:2;s:3:"xfn";i:3;s:11:"description";i:4;s:15:"title-attribute";}'),
(21, 1, 'metaboxhidden_nav-menus', 'a:1:{i:0;s:12:"add-post_tag";}'),
(22, 1, 'nav_menu_recently_edited', '2'),
(23, 1, 'syntax_highlighting', 'true') ;

#
# End of data contents of table `wp_usermeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_users`
#

DROP TABLE IF EXISTS `wp_users`;


#
# Table structure of table `wp_users`
#

CREATE TABLE `wp_users` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_login` varchar(60) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_pass` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_nicename` varchar(50) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_email` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_url` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_activation_key` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_status` int(11) NOT NULL DEFAULT '0',
  `display_name` varchar(250) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`ID`),
  KEY `user_login_key` (`user_login`),
  KEY `user_nicename` (`user_nicename`),
  KEY `user_email` (`user_email`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_users`
#
INSERT INTO `wp_users` ( `ID`, `user_login`, `user_pass`, `user_nicename`, `user_email`, `user_url`, `user_registered`, `user_activation_key`, `user_status`, `display_name`) VALUES
(1, '1p21.admin', '$P$BuC8KR5MOXu/yqXl/MVslXPHQZ5KiG1', '1p21-admin', 'joe.t.oconnor@gmail.com', '', '2017-12-26 23:55:11', '', 0, '1p21.admin') ;

#
# End of data contents of table `wp_users`
# --------------------------------------------------------

#
# Add constraints back in and apply any alter data queries.
#

